from . import models

from rest_framework import serializers


class BailSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Bail
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'amountgranted', 
            'noofsureties', 
            'paid', 
            'paydate', 
        )


class BailSuretySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.BailSurety
        fields = (
            'pk', 
        )


class BailSuretyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.BailSuretyVersion
        fields = (
            'pk', 
            'bail', 
            'surety', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class BailVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.BailVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'hearing', 
            'defendant', 
            'amountgranted', 
            'noofsureties', 
            'paid', 
            'paydate', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Case
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'born_digital', 
            'ob_number', 
            'report_date', 
            'complaint', 
            'is_criminal', 
            'priority', 
            'should_investigate_further', 
            'evaluation_conclusion', 
            'investigation_assigment_date', 
            'investigation_assignment_note', 
            'investigation_plan', 
            'investigation_summary', 
            'investigation_review', 
            'investigation_complete', 
            'dpp_advice_requested', 
            'dpp_advice_request_date', 
            'dpp_advice_date', 
            'dpp_advice', 
            'send_to_trial', 
            'case_name', 
            'docketnumber', 
            'charge_sheet', 
            'charge_date', 
            'prosecution_notes', 
            'defense_notes', 
            'judgement', 
            'judgement_date', 
            'sentence_length_years', 
            'sentence_length_months', 
            'senetence_length_days', 
            'sentence_start_date', 
            'sentence_end_date', 
            'fine_amount', 
            'case_appealed', 
            'appeal_date', 
            'appeal_granted', 
            'appeal_expiry', 
            'case_closed', 
            'close_date', 
        )


class CaseCasecategorySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseCasecategory
        fields = (
            'pk', 
        )


class CaseCasecategoryVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseCasecategoryVersion
        fields = (
            'pk', 
            'case', 
            'casecategory', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseCauseofactionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseCauseofaction
        fields = (
            'pk', 
        )


class CaseCauseofactionVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseCauseofactionVersion
        fields = (
            'pk', 
            'case', 
            'causeofaction', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseDefendantSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseDefendant
        fields = (
            'pk', 
        )


class CaseDefendantVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseDefendantVersion
        fields = (
            'pk', 
            'case', 
            'defendant', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseNatureofsuitSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseNatureofsuit
        fields = (
            'pk', 
        )


class CaseNatureofsuitVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseNatureofsuitVersion
        fields = (
            'pk', 
            'case', 
            'natureofsuit', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CasePlaintiffSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CasePlaintiff
        fields = (
            'pk', 
        )


class CasePlaintiffVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CasePlaintiffVersion
        fields = (
            'pk', 
            'case', 
            'plaintiff', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CasePolofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CasePolofficer
        fields = (
            'pk', 
        )


class CasePolofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CasePolofficerVersion
        fields = (
            'pk', 
            'case', 
            'polofficer', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseProsecutorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseProsecutor
        fields = (
            'pk', 
        )


class CaseProsecutor2Serializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseProsecutor2
        fields = (
            'pk', 
        )


class CaseProsecutor2VersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseProsecutor2Version
        fields = (
            'pk', 
            'case', 
            'prosecutor', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseProsecutorVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseProsecutorVersion
        fields = (
            'pk', 
            'case', 
            'prosecutor', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseTagSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseTag
        fields = (
            'pk', 
        )


class CaseTagVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseTagVersion
        fields = (
            'pk', 
            'case', 
            'tag', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'id', 
            'born_digital', 
            'ob_number', 
            'police_station_reported', 
            'report_date', 
            'complaint', 
            'is_criminal', 
            'priority', 
            'should_investigate_further', 
            'evaluation_conclusion', 
            'investigation_assigment_date', 
            'investigation_assignment_note', 
            'investigation_plan', 
            'investigation_summary', 
            'investigation_review', 
            'investigation_complete', 
            'dpp_advice_requested', 
            'dpp_advice_request_date', 
            'dpp_advice_date', 
            'dpp_advice', 
            'send_to_trial', 
            'case_name', 
            'docketnumber', 
            'charge_sheet', 
            'charge_date', 
            'prosecution_notes', 
            'defense_notes', 
            'judgement', 
            'judgement_date', 
            'sentence_length_years', 
            'sentence_length_months', 
            'senetence_length_days', 
            'sentence_start_date', 
            'sentence_end_date', 
            'fine_amount', 
            'case_appealed', 
            'appeal_date', 
            'appeal_granted', 
            'appeal_expiry', 
            'case_closed', 
            'close_date', 
            'reported_to', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseWitnessSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseWitness
        fields = (
            'pk', 
        )


class CaseWitnessVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseWitnessVersion
        fields = (
            'pk', 
            'case', 
            'witness', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CasecategorySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Casecategory
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'indictable', 
            'is_criminal', 
        )


class CasecategoryVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CasecategoryVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'indictable', 
            'is_criminal', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CaseinvestigationSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Caseinvestigation
        fields = (
            'pk', 
        )


class CaseinvestigationVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CaseinvestigationVersion
        fields = (
            'pk', 
            'pol_officers', 
            'cases', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CauseofactionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Causeofaction
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'criminal', 
        )


class CauseofactionFilingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CauseofactionFiling
        fields = (
            'pk', 
        )


class CauseofactionFilingVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CauseofactionFilingVersion
        fields = (
            'pk', 
            'causeofaction', 
            'filing', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CauseofactionHearingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CauseofactionHearing
        fields = (
            'pk', 
        )


class CauseofactionHearingVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CauseofactionHearingVersion
        fields = (
            'pk', 
            'causeofaction', 
            'hearing', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CauseofactionVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CauseofactionVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'criminal', 
            'parent_coa', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CommitaltypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Commitaltype
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class CommitaltypePrisoncommitalSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CommitaltypePrisoncommital
        fields = (
            'pk', 
            'prisoncommital_warrantno', 
        )


class CommitaltypePrisoncommitalVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CommitaltypePrisoncommitalVersion
        fields = (
            'pk', 
            'commitaltype', 
            'prisoncommital_prison', 
            'prisoncommital_warrantno', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CommitaltypeVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CommitaltypeVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class ConstituencySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Constituency
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class ConstituencyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ConstituencyVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'county', 
            'town', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CountySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.County
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class CountyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CountyVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CourtSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Court
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class CourtVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CourtVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'court_station', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CourtlevelSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Courtlevel
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class CourtlevelVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CourtlevelVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class CourtstationSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Courtstation
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'residentmagistrate', 
            'registrar', 
            'num_of_courts', 
        )


class CourtstationVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CourtstationVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'id', 
            'residentmagistrate', 
            'registrar', 
            'court_level', 
            'num_of_courts', 
            'town', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DefendantSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Defendant
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'allergies', 
            'chronic_conditions', 
            'chronic_medications', 
            'hbp', 
            'diabetes', 
            'hiv', 
            'current_health_status', 
            'bc_id', 
            'bc_number', 
            'bc_serial', 
            'bc_place', 
            'bc_scan', 
            'citizenship', 
            'nat_id_num', 
            'nat_id_serial', 
            'nat_id_scan', 
            'pp_no', 
            'pp_issue_date', 
            'pp_issue_place', 
            'pp_scan', 
            'pp_expiry_date', 
            'kin1_name', 
            'kin1_phone', 
            'kin1_email', 
            'kin1_addr', 
            'kin2_name', 
            'kin1_relation', 
            'kin2_phone', 
            'kin2_email', 
            'kin2_addr', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'blood_group', 
            'striking_features', 
            'height_m', 
            'weight_kg', 
            'eye_colour', 
            'hair_colour', 
            'complexion', 
            'religion', 
            'ethnicity', 
            'fp_lthumb', 
            'pgm', 
            'wsq', 
            'xyt', 
            'fp_left2', 
            'fp_left3', 
            'fp_left4', 
            'fp_left5', 
            'fp_rthumb', 
            'fp_right2', 
            'fp_right3', 
            'fp_right4', 
            'fp_right5', 
            'palm_left', 
            'palm_right', 
            'eye_left', 
            'eye_right', 
            'employed', 
            'employer', 
            'employer_contact', 
            'employ_date', 
            'employ_duration', 
            'termination_date', 
            'employ_role', 
            'supervisor', 
            'supervisor_contact', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'juvenile', 
            'casecount', 
        )


class DefendantGateregisterSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantGateregister
        fields = (
            'pk', 
        )


class DefendantGateregisterVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantGateregisterVersion
        fields = (
            'pk', 
            'defendant', 
            'gateregister', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DefendantHearingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantHearing
        fields = (
            'pk', 
        )


class DefendantHearingVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantHearingVersion
        fields = (
            'pk', 
            'defendant', 
            'hearing', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DefendantMedeventSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantMedevent
        fields = (
            'pk', 
        )


class DefendantMedeventVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantMedeventVersion
        fields = (
            'pk', 
            'defendant', 
            'medevent', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DefendantVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DefendantVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'allergies', 
            'chronic_conditions', 
            'chronic_medications', 
            'hbp', 
            'diabetes', 
            'hiv', 
            'current_health_status', 
            'bc_id', 
            'bc_number', 
            'bc_serial', 
            'bc_place', 
            'bc_scan', 
            'citizenship', 
            'nat_id_num', 
            'nat_id_serial', 
            'nat_id_scan', 
            'pp_no', 
            'pp_issue_date', 
            'pp_issue_place', 
            'pp_scan', 
            'pp_expiry_date', 
            'kin1_name', 
            'kin1_phone', 
            'kin1_email', 
            'kin1_addr', 
            'kin2_name', 
            'kin1_relation', 
            'kin2_phone', 
            'kin2_email', 
            'kin2_addr', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'blood_group', 
            'striking_features', 
            'height_m', 
            'weight_kg', 
            'eye_colour', 
            'hair_colour', 
            'complexion', 
            'religion', 
            'ethnicity', 
            'fp_lthumb', 
            'pgm', 
            'wsq', 
            'xyt', 
            'fp_left2', 
            'fp_left3', 
            'fp_left4', 
            'fp_left5', 
            'fp_rthumb', 
            'fp_right2', 
            'fp_right3', 
            'fp_right4', 
            'fp_right5', 
            'palm_left', 
            'palm_right', 
            'eye_left', 
            'eye_right', 
            'employed', 
            'employer', 
            'employer_contact', 
            'employ_date', 
            'employ_duration', 
            'termination_date', 
            'employ_role', 
            'supervisor', 
            'supervisor_contact', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'juvenile', 
            'gender', 
            'prisoncell', 
            'casecount', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DisciplineSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Discipline
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
        )


class DisciplineVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DisciplineVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'id', 
            'defendant', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DocStoreSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocStore
        fields = (
            'pk', 
            'name', 
            'description', 
            'notes', 
            'data', 
        )


class DocarchiveSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Docarchive
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'doc', 
            'scandate', 
            'archival', 
        )


class DocarchiveTagSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocarchiveTag
        fields = (
            'pk', 
        )


class DocarchiveTagVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocarchiveTagVersion
        fields = (
            'pk', 
            'docarchive', 
            'tag', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DocarchiveVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocarchiveVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'name', 
            'doc', 
            'scandate', 
            'archival', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DoctemplateSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Doctemplate
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'mime_type', 
            'doc', 
            'doc_text', 
            'doc_binary', 
            'doc_title', 
            'subject', 
            'author', 
            'keywords', 
            'comments', 
            'doc_type', 
            'char_count', 
            'word_count', 
            'lines', 
            'paragraphs', 
            'file_size_bytes', 
            'producer_prog', 
            'immutable', 
            'page_size', 
            'page_count', 
            'hashx', 
            'audio_duration_secs', 
            'audio_frame_rate', 
            'audio_channels', 
        )


class DoctemplateVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DoctemplateVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'mime_type', 
            'doc', 
            'doc_text', 
            'doc_binary', 
            'doc_title', 
            'subject', 
            'author', 
            'keywords', 
            'comments', 
            'doc_type', 
            'char_count', 
            'word_count', 
            'lines', 
            'paragraphs', 
            'file_size_bytes', 
            'producer_prog', 
            'immutable', 
            'page_size', 
            'page_count', 
            'hashx', 
            'audio_duration_secs', 
            'audio_frame_rate', 
            'audio_channels', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DocumentSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Document
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'mime_type', 
            'doc', 
            'doc_text', 
            'doc_binary', 
            'doc_title', 
            'subject', 
            'author', 
            'keywords', 
            'comments', 
            'doc_type', 
            'char_count', 
            'word_count', 
            'lines', 
            'paragraphs', 
            'file_size_bytes', 
            'producer_prog', 
            'immutable', 
            'page_size', 
            'page_count', 
            'hashx', 
            'audio_duration_secs', 
            'audio_frame_rate', 
            'audio_channels', 
            'confidential', 
            'pagecount', 
            'locked', 
            'hash', 
        )


class DocumentTagSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocumentTag
        fields = (
            'pk', 
        )


class DocumentTagVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocumentTagVersion
        fields = (
            'pk', 
            'document', 
            'tag', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class DocumentVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.DocumentVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'mime_type', 
            'doc', 
            'doc_text', 
            'doc_binary', 
            'doc_title', 
            'subject', 
            'author', 
            'keywords', 
            'comments', 
            'doc_type', 
            'char_count', 
            'word_count', 
            'lines', 
            'paragraphs', 
            'file_size_bytes', 
            'producer_prog', 
            'immutable', 
            'page_size', 
            'page_count', 
            'hashx', 
            'audio_duration_secs', 
            'audio_frame_rate', 
            'audio_channels', 
            'id', 
            'filing', 
            'doc_template', 
            'confidential', 
            'pagecount', 
            'locked', 
            'hash', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class EventlogSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Eventlog
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'temporal', 
            'event', 
            'severity', 
            'alert', 
            'notes', 
            'tbl', 
            'colname', 
            'colbefore', 
            'colafter', 
        )


class EventlogVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.EventlogVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'temporal', 
            'event', 
            'severity', 
            'alert', 
            'notes', 
            'tbl', 
            'colname', 
            'colbefore', 
            'colafter', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class FilingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Filing
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'uploaddate', 
            'pagecount', 
            'totalfees', 
            'assessedfees', 
            'receiptverified', 
            'amountpaid', 
            'feebalance', 
            'paymenthistory', 
            'urgent', 
            'urgentreason', 
        )


class FilingFilingtypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingFilingtype
        fields = (
            'pk', 
        )


class FilingFilingtypeVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingFilingtypeVersion
        fields = (
            'pk', 
            'filing', 
            'filingtype', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class FilingPaymentSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingPayment
        fields = (
            'pk', 
        )


class FilingPaymentVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingPaymentVersion
        fields = (
            'pk', 
            'filing', 
            'payment', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class FilingVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'uploaddate', 
            'pagecount', 
            'totalfees', 
            'filing_attorney', 
            'filing_prosecutor', 
            'assessedfees', 
            'receiptverified', 
            'amountpaid', 
            'feebalance', 
            'paymenthistory', 
            'case', 
            'urgent', 
            'urgentreason', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class FilingtypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Filingtype
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'fees', 
            'perpagecost', 
            'paid_per_page', 
        )


class FilingtypeVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.FilingtypeVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'fees', 
            'perpagecost', 
            'paid_per_page', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class GateregisterSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Gateregister
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'opentime', 
            'closedtime', 
            'movementdirection', 
            'reason', 
            'staffmovement', 
            'goodsmovement', 
            'vehicle_reg', 
            'vehicle_color', 
        )


class GateregisterVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GateregisterVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'prison', 
            'opentime', 
            'closedtime', 
            'movementdirection', 
            'reason', 
            'staffmovement', 
            'goodsmovement', 
            'vehicle_reg', 
            'vehicle_color', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class GateregisterWarderSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GateregisterWarder
        fields = (
            'pk', 
        )


class GateregisterWarder2Serializer(serializers.ModelSerializer):

    class Meta:
        model = models.GateregisterWarder2
        fields = (
            'pk', 
        )


class GateregisterWarder2VersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GateregisterWarder2Version
        fields = (
            'pk', 
            'gateregister', 
            'warder', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class GateregisterWarderVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GateregisterWarderVersion
        fields = (
            'pk', 
            'gateregister', 
            'warder', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class GenderSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Gender
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'description', 
            'notes', 
            'name', 
        )


class GenderVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.GenderVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'description', 
            'notes', 
            'id', 
            'name', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Hearing
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'hearingdate', 
            'adjourned', 
            'completed', 
            'remandwarrant', 
            'remanddays', 
            'remanddate', 
            'remandwarrantexpirydate', 
            'nexthearingdate', 
            'finalhearing', 
            'transcript', 
            'audio', 
            'video', 
        )


class HearingJudicialofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingJudicialofficer
        fields = (
            'pk', 
        )


class HearingJudicialofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingJudicialofficerVersion
        fields = (
            'pk', 
            'hearing', 
            'judicialofficer', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingLawyersSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingLawyers
        fields = (
            'pk', 
        )


class HearingLawyersVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingLawyersVersion
        fields = (
            'pk', 
            'hearing', 
            'lawyers', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingPolofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingPolofficer
        fields = (
            'pk', 
        )


class HearingPolofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingPolofficerVersion
        fields = (
            'pk', 
            'hearing', 
            'polofficer', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingProsecutorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingProsecutor
        fields = (
            'pk', 
        )


class HearingProsecutorVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingProsecutorVersion
        fields = (
            'pk', 
            'hearing', 
            'prosecutor', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingTagSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingTag
        fields = (
            'pk', 
        )


class HearingTagVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingTagVersion
        fields = (
            'pk', 
            'hearing', 
            'tag', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'id', 
            'hearingdate', 
            'adjourned', 
            'completed', 
            'case', 
            'court', 
            'remandwarrant', 
            'hearing_type', 
            'remanddays', 
            'remanddate', 
            'remandwarrantexpirydate', 
            'nexthearingdate', 
            'finalhearing', 
            'transcript', 
            'audio', 
            'video', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingWitnessSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingWitness
        fields = (
            'pk', 
        )


class HearingWitnessVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingWitnessVersion
        fields = (
            'pk', 
            'hearing', 
            'witness', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class HearingtypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Hearingtype
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class HearingtypeVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.HearingtypeVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class InvestigationSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Investigation
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'actiondate', 
            'evidence', 
            'narrative', 
            'weather', 
            'location', 
        )


class InvestigationPolofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.InvestigationPolofficer
        fields = (
            'pk', 
        )


class InvestigationPolofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.InvestigationPolofficerVersion
        fields = (
            'pk', 
            'investigation', 
            'polofficer', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class InvestigationVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.InvestigationVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'id', 
            'case', 
            'actiondate', 
            'evidence', 
            'narrative', 
            'weather', 
            'location', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class InvestigationWitnessSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.InvestigationWitness
        fields = (
            'pk', 
        )


class InvestigationWitnessVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.InvestigationWitnessVersion
        fields = (
            'pk', 
            'investigation', 
            'witness', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class JoRankSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.JoRank
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'appelation', 
            'informaladdress', 
        )


class JoRankVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.JoRankVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'appelation', 
            'informaladdress', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class JudicialofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Judicialofficer
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
        )


class JudicialofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.JudicialofficerVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'court', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class LawfirmSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Lawfirm
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
        )


class LawfirmVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.LawfirmVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class LawyersSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Lawyers
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'barnumber', 
            'admissiondate', 
        )


class LawyersVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.LawyersVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'barnumber', 
            'law_firm', 
            'admissiondate', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class MedeventSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Medevent
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
        )


class MedeventVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.MedeventVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class NatureofsuitSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Natureofsuit
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class NatureofsuitVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.NatureofsuitVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PaymentSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Payment
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'datepaid', 
            'amount', 
            'paymentreference', 
            'paymentconfirmed', 
            'paidby', 
            'msisdn', 
            'receiptnumber', 
            'ispartial', 
            'billrefnumber', 
            'paymentdescription', 
        )


class PaymentVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PaymentVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'datepaid', 
            'amount', 
            'paymentreference', 
            'paymentconfirmed', 
            'paidby', 
            'msisdn', 
            'receiptnumber', 
            'ispartial', 
            'bail', 
            'billrefnumber', 
            'payment_method', 
            'paymentdescription', 
            'case', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PaymentmethodSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Paymentmethod
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'key', 
            'secret', 
            'portal', 
            'tillnumber', 
            'shortcode', 
        )


class PaymentmethodVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PaymentmethodVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'key', 
            'secret', 
            'portal', 
            'tillnumber', 
            'shortcode', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PlaintiffSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Plaintiff
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'juvenile', 
        )


class PlaintiffVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PlaintiffVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'juvenile', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PolicerankSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Policerank
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class PolicerankVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolicerankVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PoliceroleSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Policerole
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class PoliceroleVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PoliceroleVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PolicestationSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Policestation
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'has_forensic_lab', 
            'officercommanding', 
        )


class PolicestationVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolicestationVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'id', 
            'town', 
            'has_forensic_lab', 
            'officercommanding', 
            'police_station_type', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PolicestationtypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Policestationtype
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class PolicestationtypeVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolicestationtypeVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PolofficerSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Polofficer
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'servicenumber', 
            'postdate', 
        )


class PolofficerPoliceroleSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolofficerPolicerole
        fields = (
            'pk', 
        )


class PolofficerPoliceroleVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolofficerPoliceroleVersion
        fields = (
            'pk', 
            'polofficer', 
            'policerole', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PolofficerVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PolofficerVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'police_rank', 
            'gender', 
            'servicenumber', 
            'reports_to', 
            'pol_supervisor', 
            'postdate', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisonSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prison
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'warden', 
            'capacity', 
            'population', 
            'cellcount', 
            'gatecount', 
        )


class PrisonSecurityrankSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisonSecurityrank
        fields = (
            'pk', 
        )


class PrisonSecurityrankVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisonSecurityrankVersion
        fields = (
            'pk', 
            'prison', 
            'securityrank', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisonVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisonVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'place_name', 
            'lat', 
            'lng', 
            'alt', 
            'map', 
            'info', 
            'pin', 
            'pin_color', 
            'pin_icon', 
            'centered', 
            'nearest_feature', 
            'id', 
            'town', 
            'warden', 
            'capacity', 
            'population', 
            'cellcount', 
            'gatecount', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisoncellSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prisoncell
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
        )


class PrisoncellVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisoncellVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'prison', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisoncommitalSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prisoncommital
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'warrantno', 
            'warrantdate', 
            'hascourtdate', 
            'warrant', 
            'warrantduration', 
            'warrantexpiry', 
            'history', 
            'earliestrelease', 
            'releasedate', 
            'property', 
            'itemcount', 
            'releasenotes', 
            'commitalnotes', 
            'paroledate', 
            'escaped', 
            'escapedate', 
            'escapedetails', 
        )


class PrisoncommitalVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisoncommitalVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'prison', 
            'warrantno', 
            'defendant', 
            'hearing', 
            'warrantdate', 
            'hascourtdate', 
            'judicial_officer_warrant', 
            'warrant', 
            'warrantduration', 
            'warrantexpiry', 
            'history', 
            'earliestrelease', 
            'releasedate', 
            'property', 
            'itemcount', 
            'releasenotes', 
            'commitalnotes', 
            'police_officer_commiting', 
            'paroledate', 
            'escaped', 
            'escapedate', 
            'escapedetails', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisoncommitalWarderSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisoncommitalWarder
        fields = (
            'pk', 
            'prisoncommital_warrantno', 
        )


class PrisoncommitalWarderVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisoncommitalWarderVersion
        fields = (
            'pk', 
            'prisoncommital_prison', 
            'prisoncommital_warrantno', 
            'warder', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class PrisonerpropertySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prisonerproperty
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'prison_commital_warrantno', 
            'receipted', 
        )


class PrisonerpropertyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.PrisonerpropertyVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'prison_commital_prison', 
            'prison_commital_warrantno', 
            'receipted', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class ProsecutorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prosecutor
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
        )


class ProsecutorProsecutorteamSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ProsecutorProsecutorteam
        fields = (
            'pk', 
        )


class ProsecutorProsecutorteamVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ProsecutorProsecutorteamVersion
        fields = (
            'pk', 
            'prosecutor', 
            'prosecutorteam', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class ProsecutorVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ProsecutorVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class ProsecutorteamSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Prosecutorteam
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class ProsecutorteamVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.ProsecutorteamVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class RemissionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Remission
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'prison_commital_warrantno', 
            'daysearned', 
            'dateearned', 
            'amount', 
        )


class RemissionVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.RemissionVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'id', 
            'prison_commital_prison', 
            'prison_commital_warrantno', 
            'daysearned', 
            'dateearned', 
            'amount', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class SecurityrankSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Securityrank
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class SecurityrankVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.SecurityrankVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class SubcountySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Subcounty
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class SubcountyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.SubcountyVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'county', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class SuretySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Surety
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
        )


class SuretyVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.SuretyVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class TagSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Tag
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class TagVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.TagVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class TownSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Town
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class TownVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.TownVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'subcounty', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class TransactionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Transaction
        fields = (
            'pk', 
            'issued_at', 
            'id', 
            'remote_addr', 
        )


class VisitSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Visit
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'visitdate', 
            'visitnotes', 
        )


class VisitVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.VisitVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'priority', 
            'segment', 
            'task_group', 
            'sequence', 
            'action', 
            'activity_description', 
            'goal', 
            'status', 
            'planned_start', 
            'actual_start', 
            'start_notes', 
            'planned_end', 
            'actual_end', 
            'end_notes', 
            'deadline', 
            'not_started', 
            'early_start', 
            'late_start', 
            'completed', 
            'early_end', 
            'late_end', 
            'deviation_expected', 
            'contingency_plan', 
            'budget', 
            'spend_td', 
            'balance_avail', 
            'over_budget', 
            'under_budget', 
            'vistors', 
            'defendants', 
            'visitdate', 
            'visitnotes', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class VisitorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Visitor
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
        )


class VisitorVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.VisitorVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'gender', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class WarderSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Warder
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
        )


class WarderVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.WarderVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'prison', 
            'warder_rank', 
            'reports_to', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class WarderrankSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Warderrank
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
        )


class WarderrankVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.WarderrankVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'name', 
            'description', 
            'notes', 
            'id', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


class WitnessSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Witness
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'fordefense', 
        )


class WitnessVersionSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.WitnessVersion
        fields = (
            'pk', 
            'created_on', 
            'changed_on', 
            'firstname', 
            'surname', 
            'othernames', 
            'dob', 
            'marital_status', 
            'photo', 
            'age_today', 
            'mobile', 
            'other_mobile', 
            'fixed_line', 
            'other_fixed_line', 
            'email', 
            'other_email', 
            'address_line_1', 
            'address_line_2', 
            'zipcode', 
            'town', 
            'country', 
            'facebook', 
            'twitter', 
            'instagram', 
            'whatsapp', 
            'other_whatsapp', 
            'fax', 
            'gcode', 
            'okhi', 
            'id', 
            'fordefense', 
            'gender', 
            'changed_by_fk', 
            'created_by_fk', 
            'transaction_id', 
            'end_transaction_id', 
            'operation_type', 
        )


