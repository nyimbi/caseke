from django.contrib import admin
from django import forms
from .models import Bail, BailSurety, BailSuretyVersion, BailVersion, Case, CaseCasecategory, CaseCasecategoryVersion, CaseCauseofaction, CaseCauseofactionVersion, CaseDefendant, CaseDefendantVersion, CaseNatureofsuit, CaseNatureofsuitVersion, CasePlaintiff, CasePlaintiffVersion, CasePolofficer, CasePolofficerVersion, CaseProsecutor, CaseProsecutor2, CaseProsecutor2Version, CaseProsecutorVersion, CaseTag, CaseTagVersion, CaseVersion, CaseWitness, CaseWitnessVersion, Casecategory, CasecategoryVersion, Caseinvestigation, CaseinvestigationVersion, Causeofaction, CauseofactionFiling, CauseofactionFilingVersion, CauseofactionHearing, CauseofactionHearingVersion, CauseofactionVersion, Commitaltype, CommitaltypePrisoncommital, CommitaltypePrisoncommitalVersion, CommitaltypeVersion, Constituency, ConstituencyVersion, County, CountyVersion, Court, CourtVersion, Courtlevel, CourtlevelVersion, Courtstation, CourtstationVersion, Defendant, DefendantGateregister, DefendantGateregisterVersion, DefendantHearing, DefendantHearingVersion, DefendantMedevent, DefendantMedeventVersion, DefendantVersion, Discipline, DisciplineVersion, DocStore, Docarchive, DocarchiveTag, DocarchiveTagVersion, DocarchiveVersion, Doctemplate, DoctemplateVersion, Document, DocumentTag, DocumentTagVersion, DocumentVersion, Eventlog, EventlogVersion, Filing, FilingFilingtype, FilingFilingtypeVersion, FilingPayment, FilingPaymentVersion, FilingVersion, Filingtype, FilingtypeVersion, Gateregister, GateregisterVersion, GateregisterWarder, GateregisterWarder2, GateregisterWarder2Version, GateregisterWarderVersion, Gender, GenderVersion, Hearing, HearingJudicialofficer, HearingJudicialofficerVersion, HearingLawyers, HearingLawyersVersion, HearingPolofficer, HearingPolofficerVersion, HearingProsecutor, HearingProsecutorVersion, HearingTag, HearingTagVersion, HearingVersion, HearingWitness, HearingWitnessVersion, Hearingtype, HearingtypeVersion, Investigation, InvestigationPolofficer, InvestigationPolofficerVersion, InvestigationVersion, InvestigationWitness, InvestigationWitnessVersion, JoRank, JoRankVersion, Judicialofficer, JudicialofficerVersion, Lawfirm, LawfirmVersion, Lawyers, LawyersVersion, Medevent, MedeventVersion, Natureofsuit, NatureofsuitVersion, Payment, PaymentVersion, Paymentmethod, PaymentmethodVersion, Plaintiff, PlaintiffVersion, Policerank, PolicerankVersion, Policerole, PoliceroleVersion, Policestation, PolicestationVersion, Policestationtype, PolicestationtypeVersion, Polofficer, PolofficerPolicerole, PolofficerPoliceroleVersion, PolofficerVersion, Prison, PrisonSecurityrank, PrisonSecurityrankVersion, PrisonVersion, Prisoncell, PrisoncellVersion, Prisoncommital, PrisoncommitalVersion, PrisoncommitalWarder, PrisoncommitalWarderVersion, Prisonerproperty, PrisonerpropertyVersion, Prosecutor, ProsecutorProsecutorteam, ProsecutorProsecutorteamVersion, ProsecutorVersion, Prosecutorteam, ProsecutorteamVersion, Remission, RemissionVersion, Securityrank, SecurityrankVersion, Subcounty, SubcountyVersion, Surety, SuretyVersion, Tag, TagVersion, Town, TownVersion, Transaction, Visit, VisitVersion, Visitor, VisitorVersion, Warder, WarderVersion, Warderrank, WarderrankVersion, Witness, WitnessVersion

class BailAdminForm(forms.ModelForm):

    class Meta:
        model = Bail
        fields = '__all__'


class BailAdmin(admin.ModelAdmin):
    form = BailAdminForm
    list_display = ['created_on', 'changed_on', 'amountgranted', 'noofsureties', 'paid', 'paydate']
    readonly_fields = ['created_on', 'changed_on', 'amountgranted', 'noofsureties', 'paid', 'paydate']

admin.site.register(Bail, BailAdmin)


class BailSuretyAdminForm(forms.ModelForm):

    class Meta:
        model = BailSurety
        fields = '__all__'


class BailSuretyAdmin(admin.ModelAdmin):
    form = BailSuretyAdminForm


admin.site.register(BailSurety, BailSuretyAdmin)


class BailSuretyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = BailSuretyVersion
        fields = '__all__'


class BailSuretyVersionAdmin(admin.ModelAdmin):
    form = BailSuretyVersionAdminForm
    list_display = ['bail', 'surety', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['bail', 'surety', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(BailSuretyVersion, BailSuretyVersionAdmin)


class BailVersionAdminForm(forms.ModelForm):

    class Meta:
        model = BailVersion
        fields = '__all__'


class BailVersionAdmin(admin.ModelAdmin):
    form = BailVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'hearing', 'defendant', 'amountgranted', 'noofsureties', 'paid', 'paydate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'hearing', 'defendant', 'amountgranted', 'noofsureties', 'paid', 'paydate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(BailVersion, BailVersionAdmin)


class CaseAdminForm(forms.ModelForm):

    class Meta:
        model = Case
        fields = '__all__'


class CaseAdmin(admin.ModelAdmin):
    form = CaseAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'born_digital', 'ob_number', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'born_digital', 'ob_number', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date']

admin.site.register(Case, CaseAdmin)


class CaseCasecategoryAdminForm(forms.ModelForm):

    class Meta:
        model = CaseCasecategory
        fields = '__all__'


class CaseCasecategoryAdmin(admin.ModelAdmin):
    form = CaseCasecategoryAdminForm


admin.site.register(CaseCasecategory, CaseCasecategoryAdmin)


class CaseCasecategoryVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseCasecategoryVersion
        fields = '__all__'


class CaseCasecategoryVersionAdmin(admin.ModelAdmin):
    form = CaseCasecategoryVersionAdminForm
    list_display = ['case', 'casecategory', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'casecategory', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseCasecategoryVersion, CaseCasecategoryVersionAdmin)


class CaseCauseofactionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseCauseofaction
        fields = '__all__'


class CaseCauseofactionAdmin(admin.ModelAdmin):
    form = CaseCauseofactionAdminForm


admin.site.register(CaseCauseofaction, CaseCauseofactionAdmin)


class CaseCauseofactionVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseCauseofactionVersion
        fields = '__all__'


class CaseCauseofactionVersionAdmin(admin.ModelAdmin):
    form = CaseCauseofactionVersionAdminForm
    list_display = ['case', 'causeofaction', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'causeofaction', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseCauseofactionVersion, CaseCauseofactionVersionAdmin)


class CaseDefendantAdminForm(forms.ModelForm):

    class Meta:
        model = CaseDefendant
        fields = '__all__'


class CaseDefendantAdmin(admin.ModelAdmin):
    form = CaseDefendantAdminForm


admin.site.register(CaseDefendant, CaseDefendantAdmin)


class CaseDefendantVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseDefendantVersion
        fields = '__all__'


class CaseDefendantVersionAdmin(admin.ModelAdmin):
    form = CaseDefendantVersionAdminForm
    list_display = ['case', 'defendant', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'defendant', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseDefendantVersion, CaseDefendantVersionAdmin)


class CaseNatureofsuitAdminForm(forms.ModelForm):

    class Meta:
        model = CaseNatureofsuit
        fields = '__all__'


class CaseNatureofsuitAdmin(admin.ModelAdmin):
    form = CaseNatureofsuitAdminForm


admin.site.register(CaseNatureofsuit, CaseNatureofsuitAdmin)


class CaseNatureofsuitVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseNatureofsuitVersion
        fields = '__all__'


class CaseNatureofsuitVersionAdmin(admin.ModelAdmin):
    form = CaseNatureofsuitVersionAdminForm
    list_display = ['case', 'natureofsuit', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'natureofsuit', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseNatureofsuitVersion, CaseNatureofsuitVersionAdmin)


class CasePlaintiffAdminForm(forms.ModelForm):

    class Meta:
        model = CasePlaintiff
        fields = '__all__'


class CasePlaintiffAdmin(admin.ModelAdmin):
    form = CasePlaintiffAdminForm


admin.site.register(CasePlaintiff, CasePlaintiffAdmin)


class CasePlaintiffVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CasePlaintiffVersion
        fields = '__all__'


class CasePlaintiffVersionAdmin(admin.ModelAdmin):
    form = CasePlaintiffVersionAdminForm
    list_display = ['case', 'plaintiff', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'plaintiff', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CasePlaintiffVersion, CasePlaintiffVersionAdmin)


class CasePolofficerAdminForm(forms.ModelForm):

    class Meta:
        model = CasePolofficer
        fields = '__all__'


class CasePolofficerAdmin(admin.ModelAdmin):
    form = CasePolofficerAdminForm


admin.site.register(CasePolofficer, CasePolofficerAdmin)


class CasePolofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CasePolofficerVersion
        fields = '__all__'


class CasePolofficerVersionAdmin(admin.ModelAdmin):
    form = CasePolofficerVersionAdminForm
    list_display = ['case', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CasePolofficerVersion, CasePolofficerVersionAdmin)


class CaseProsecutorAdminForm(forms.ModelForm):

    class Meta:
        model = CaseProsecutor
        fields = '__all__'


class CaseProsecutorAdmin(admin.ModelAdmin):
    form = CaseProsecutorAdminForm


admin.site.register(CaseProsecutor, CaseProsecutorAdmin)


class CaseProsecutor2AdminForm(forms.ModelForm):

    class Meta:
        model = CaseProsecutor2
        fields = '__all__'


class CaseProsecutor2Admin(admin.ModelAdmin):
    form = CaseProsecutor2AdminForm


admin.site.register(CaseProsecutor2, CaseProsecutor2Admin)


class CaseProsecutor2VersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseProsecutor2Version
        fields = '__all__'


class CaseProsecutor2VersionAdmin(admin.ModelAdmin):
    form = CaseProsecutor2VersionAdminForm
    list_display = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseProsecutor2Version, CaseProsecutor2VersionAdmin)


class CaseProsecutorVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseProsecutorVersion
        fields = '__all__'


class CaseProsecutorVersionAdmin(admin.ModelAdmin):
    form = CaseProsecutorVersionAdminForm
    list_display = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseProsecutorVersion, CaseProsecutorVersionAdmin)


class CaseTagAdminForm(forms.ModelForm):

    class Meta:
        model = CaseTag
        fields = '__all__'


class CaseTagAdmin(admin.ModelAdmin):
    form = CaseTagAdminForm


admin.site.register(CaseTag, CaseTagAdmin)


class CaseTagVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseTagVersion
        fields = '__all__'


class CaseTagVersionAdmin(admin.ModelAdmin):
    form = CaseTagVersionAdminForm
    list_display = ['case', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseTagVersion, CaseTagVersionAdmin)


class CaseVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseVersion
        fields = '__all__'


class CaseVersionAdmin(admin.ModelAdmin):
    form = CaseVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'born_digital', 'ob_number', 'police_station_reported', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date', 'reported_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'born_digital', 'ob_number', 'police_station_reported', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date', 'reported_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseVersion, CaseVersionAdmin)


class CaseWitnessAdminForm(forms.ModelForm):

    class Meta:
        model = CaseWitness
        fields = '__all__'


class CaseWitnessAdmin(admin.ModelAdmin):
    form = CaseWitnessAdminForm


admin.site.register(CaseWitness, CaseWitnessAdmin)


class CaseWitnessVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseWitnessVersion
        fields = '__all__'


class CaseWitnessVersionAdmin(admin.ModelAdmin):
    form = CaseWitnessVersionAdminForm
    list_display = ['case', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['case', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseWitnessVersion, CaseWitnessVersionAdmin)


class CasecategoryAdminForm(forms.ModelForm):

    class Meta:
        model = Casecategory
        fields = '__all__'


class CasecategoryAdmin(admin.ModelAdmin):
    form = CasecategoryAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'indictable', 'is_criminal']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'indictable', 'is_criminal']

admin.site.register(Casecategory, CasecategoryAdmin)


class CasecategoryVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CasecategoryVersion
        fields = '__all__'


class CasecategoryVersionAdmin(admin.ModelAdmin):
    form = CasecategoryVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'indictable', 'is_criminal', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'indictable', 'is_criminal', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CasecategoryVersion, CasecategoryVersionAdmin)


class CaseinvestigationAdminForm(forms.ModelForm):

    class Meta:
        model = Caseinvestigation
        fields = '__all__'


class CaseinvestigationAdmin(admin.ModelAdmin):
    form = CaseinvestigationAdminForm


admin.site.register(Caseinvestigation, CaseinvestigationAdmin)


class CaseinvestigationVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CaseinvestigationVersion
        fields = '__all__'


class CaseinvestigationVersionAdmin(admin.ModelAdmin):
    form = CaseinvestigationVersionAdminForm
    list_display = ['pol_officers', 'cases', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['pol_officers', 'cases', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CaseinvestigationVersion, CaseinvestigationVersionAdmin)


class CauseofactionAdminForm(forms.ModelForm):

    class Meta:
        model = Causeofaction
        fields = '__all__'


class CauseofactionAdmin(admin.ModelAdmin):
    form = CauseofactionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'criminal']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'criminal']

admin.site.register(Causeofaction, CauseofactionAdmin)


class CauseofactionFilingAdminForm(forms.ModelForm):

    class Meta:
        model = CauseofactionFiling
        fields = '__all__'


class CauseofactionFilingAdmin(admin.ModelAdmin):
    form = CauseofactionFilingAdminForm


admin.site.register(CauseofactionFiling, CauseofactionFilingAdmin)


class CauseofactionFilingVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CauseofactionFilingVersion
        fields = '__all__'


class CauseofactionFilingVersionAdmin(admin.ModelAdmin):
    form = CauseofactionFilingVersionAdminForm
    list_display = ['causeofaction', 'filing', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['causeofaction', 'filing', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CauseofactionFilingVersion, CauseofactionFilingVersionAdmin)


class CauseofactionHearingAdminForm(forms.ModelForm):

    class Meta:
        model = CauseofactionHearing
        fields = '__all__'


class CauseofactionHearingAdmin(admin.ModelAdmin):
    form = CauseofactionHearingAdminForm


admin.site.register(CauseofactionHearing, CauseofactionHearingAdmin)


class CauseofactionHearingVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CauseofactionHearingVersion
        fields = '__all__'


class CauseofactionHearingVersionAdmin(admin.ModelAdmin):
    form = CauseofactionHearingVersionAdminForm
    list_display = ['causeofaction', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['causeofaction', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CauseofactionHearingVersion, CauseofactionHearingVersionAdmin)


class CauseofactionVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CauseofactionVersion
        fields = '__all__'


class CauseofactionVersionAdmin(admin.ModelAdmin):
    form = CauseofactionVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'criminal', 'parent_coa', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'criminal', 'parent_coa', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CauseofactionVersion, CauseofactionVersionAdmin)


class CommitaltypeAdminForm(forms.ModelForm):

    class Meta:
        model = Commitaltype
        fields = '__all__'


class CommitaltypeAdmin(admin.ModelAdmin):
    form = CommitaltypeAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Commitaltype, CommitaltypeAdmin)


class CommitaltypePrisoncommitalAdminForm(forms.ModelForm):

    class Meta:
        model = CommitaltypePrisoncommital
        fields = '__all__'


class CommitaltypePrisoncommitalAdmin(admin.ModelAdmin):
    form = CommitaltypePrisoncommitalAdminForm
    list_display = ['prisoncommital_warrantno']
    readonly_fields = ['prisoncommital_warrantno']

admin.site.register(CommitaltypePrisoncommital, CommitaltypePrisoncommitalAdmin)


class CommitaltypePrisoncommitalVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CommitaltypePrisoncommitalVersion
        fields = '__all__'


class CommitaltypePrisoncommitalVersionAdmin(admin.ModelAdmin):
    form = CommitaltypePrisoncommitalVersionAdminForm
    list_display = ['commitaltype', 'prisoncommital_prison', 'prisoncommital_warrantno', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['commitaltype', 'prisoncommital_prison', 'prisoncommital_warrantno', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CommitaltypePrisoncommitalVersion, CommitaltypePrisoncommitalVersionAdmin)


class CommitaltypeVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CommitaltypeVersion
        fields = '__all__'


class CommitaltypeVersionAdmin(admin.ModelAdmin):
    form = CommitaltypeVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CommitaltypeVersion, CommitaltypeVersionAdmin)


class ConstituencyAdminForm(forms.ModelForm):

    class Meta:
        model = Constituency
        fields = '__all__'


class ConstituencyAdmin(admin.ModelAdmin):
    form = ConstituencyAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Constituency, ConstituencyAdmin)


class ConstituencyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = ConstituencyVersion
        fields = '__all__'


class ConstituencyVersionAdmin(admin.ModelAdmin):
    form = ConstituencyVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(ConstituencyVersion, ConstituencyVersionAdmin)


class CountyAdminForm(forms.ModelForm):

    class Meta:
        model = County
        fields = '__all__'


class CountyAdmin(admin.ModelAdmin):
    form = CountyAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(County, CountyAdmin)


class CountyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CountyVersion
        fields = '__all__'


class CountyVersionAdmin(admin.ModelAdmin):
    form = CountyVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CountyVersion, CountyVersionAdmin)


class CourtAdminForm(forms.ModelForm):

    class Meta:
        model = Court
        fields = '__all__'


class CourtAdmin(admin.ModelAdmin):
    form = CourtAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Court, CourtAdmin)


class CourtVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CourtVersion
        fields = '__all__'


class CourtVersionAdmin(admin.ModelAdmin):
    form = CourtVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'court_station', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'court_station', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CourtVersion, CourtVersionAdmin)


class CourtlevelAdminForm(forms.ModelForm):

    class Meta:
        model = Courtlevel
        fields = '__all__'


class CourtlevelAdmin(admin.ModelAdmin):
    form = CourtlevelAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Courtlevel, CourtlevelAdmin)


class CourtlevelVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CourtlevelVersion
        fields = '__all__'


class CourtlevelVersionAdmin(admin.ModelAdmin):
    form = CourtlevelVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CourtlevelVersion, CourtlevelVersionAdmin)


class CourtstationAdminForm(forms.ModelForm):

    class Meta:
        model = Courtstation
        fields = '__all__'


class CourtstationAdmin(admin.ModelAdmin):
    form = CourtstationAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'residentmagistrate', 'registrar', 'num_of_courts']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'residentmagistrate', 'registrar', 'num_of_courts']

admin.site.register(Courtstation, CourtstationAdmin)


class CourtstationVersionAdminForm(forms.ModelForm):

    class Meta:
        model = CourtstationVersion
        fields = '__all__'


class CourtstationVersionAdmin(admin.ModelAdmin):
    form = CourtstationVersionAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'residentmagistrate', 'registrar', 'court_level', 'num_of_courts', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'residentmagistrate', 'registrar', 'court_level', 'num_of_courts', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(CourtstationVersion, CourtstationVersionAdmin)


class DefendantAdminForm(forms.ModelForm):

    class Meta:
        model = Defendant
        fields = '__all__'


class DefendantAdmin(admin.ModelAdmin):
    form = DefendantAdminForm
    list_display = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile', 'casecount']
    readonly_fields = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile', 'casecount']

admin.site.register(Defendant, DefendantAdmin)


class DefendantGateregisterAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantGateregister
        fields = '__all__'


class DefendantGateregisterAdmin(admin.ModelAdmin):
    form = DefendantGateregisterAdminForm


admin.site.register(DefendantGateregister, DefendantGateregisterAdmin)


class DefendantGateregisterVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantGateregisterVersion
        fields = '__all__'


class DefendantGateregisterVersionAdmin(admin.ModelAdmin):
    form = DefendantGateregisterVersionAdminForm
    list_display = ['defendant', 'gateregister', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['defendant', 'gateregister', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DefendantGateregisterVersion, DefendantGateregisterVersionAdmin)


class DefendantHearingAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantHearing
        fields = '__all__'


class DefendantHearingAdmin(admin.ModelAdmin):
    form = DefendantHearingAdminForm


admin.site.register(DefendantHearing, DefendantHearingAdmin)


class DefendantHearingVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantHearingVersion
        fields = '__all__'


class DefendantHearingVersionAdmin(admin.ModelAdmin):
    form = DefendantHearingVersionAdminForm
    list_display = ['defendant', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['defendant', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DefendantHearingVersion, DefendantHearingVersionAdmin)


class DefendantMedeventAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantMedevent
        fields = '__all__'


class DefendantMedeventAdmin(admin.ModelAdmin):
    form = DefendantMedeventAdminForm


admin.site.register(DefendantMedevent, DefendantMedeventAdmin)


class DefendantMedeventVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantMedeventVersion
        fields = '__all__'


class DefendantMedeventVersionAdmin(admin.ModelAdmin):
    form = DefendantMedeventVersionAdminForm
    list_display = ['defendant', 'medevent', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['defendant', 'medevent', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DefendantMedeventVersion, DefendantMedeventVersionAdmin)


class DefendantVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DefendantVersion
        fields = '__all__'


class DefendantVersionAdmin(admin.ModelAdmin):
    form = DefendantVersionAdminForm
    list_display = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'juvenile', 'gender', 'prisoncell', 'casecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'juvenile', 'gender', 'prisoncell', 'casecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DefendantVersion, DefendantVersionAdmin)


class DisciplineAdminForm(forms.ModelForm):

    class Meta:
        model = Discipline
        fields = '__all__'


class DisciplineAdmin(admin.ModelAdmin):
    form = DisciplineAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget']

admin.site.register(Discipline, DisciplineAdmin)


class DisciplineVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DisciplineVersion
        fields = '__all__'


class DisciplineVersionAdmin(admin.ModelAdmin):
    form = DisciplineVersionAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'defendant', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'defendant', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DisciplineVersion, DisciplineVersionAdmin)


class DocStoreAdminForm(forms.ModelForm):

    class Meta:
        model = DocStore
        fields = '__all__'


class DocStoreAdmin(admin.ModelAdmin):
    form = DocStoreAdminForm
    list_display = ['name', 'description', 'notes', 'data']
    readonly_fields = ['name', 'description', 'notes', 'data']

admin.site.register(DocStore, DocStoreAdmin)


class DocarchiveAdminForm(forms.ModelForm):

    class Meta:
        model = Docarchive
        fields = '__all__'


class DocarchiveAdmin(admin.ModelAdmin):
    form = DocarchiveAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'doc', 'scandate', 'archival']
    readonly_fields = ['created_on', 'changed_on', 'name', 'doc', 'scandate', 'archival']

admin.site.register(Docarchive, DocarchiveAdmin)


class DocarchiveTagAdminForm(forms.ModelForm):

    class Meta:
        model = DocarchiveTag
        fields = '__all__'


class DocarchiveTagAdmin(admin.ModelAdmin):
    form = DocarchiveTagAdminForm


admin.site.register(DocarchiveTag, DocarchiveTagAdmin)


class DocarchiveTagVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DocarchiveTagVersion
        fields = '__all__'


class DocarchiveTagVersionAdmin(admin.ModelAdmin):
    form = DocarchiveTagVersionAdminForm
    list_display = ['docarchive', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['docarchive', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DocarchiveTagVersion, DocarchiveTagVersionAdmin)


class DocarchiveVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DocarchiveVersion
        fields = '__all__'


class DocarchiveVersionAdmin(admin.ModelAdmin):
    form = DocarchiveVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'name', 'doc', 'scandate', 'archival', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'name', 'doc', 'scandate', 'archival', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DocarchiveVersion, DocarchiveVersionAdmin)


class DoctemplateAdminForm(forms.ModelForm):

    class Meta:
        model = Doctemplate
        fields = '__all__'


class DoctemplateAdmin(admin.ModelAdmin):
    form = DoctemplateAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels']

admin.site.register(Doctemplate, DoctemplateAdmin)


class DoctemplateVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DoctemplateVersion
        fields = '__all__'


class DoctemplateVersionAdmin(admin.ModelAdmin):
    form = DoctemplateVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DoctemplateVersion, DoctemplateVersionAdmin)


class DocumentAdminForm(forms.ModelForm):

    class Meta:
        model = Document
        fields = '__all__'


class DocumentAdmin(admin.ModelAdmin):
    form = DocumentAdminForm
    list_display = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'confidential', 'pagecount', 'locked', 'hash']
    readonly_fields = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'confidential', 'pagecount', 'locked', 'hash']

admin.site.register(Document, DocumentAdmin)


class DocumentTagAdminForm(forms.ModelForm):

    class Meta:
        model = DocumentTag
        fields = '__all__'


class DocumentTagAdmin(admin.ModelAdmin):
    form = DocumentTagAdminForm


admin.site.register(DocumentTag, DocumentTagAdmin)


class DocumentTagVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DocumentTagVersion
        fields = '__all__'


class DocumentTagVersionAdmin(admin.ModelAdmin):
    form = DocumentTagVersionAdminForm
    list_display = ['document', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['document', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DocumentTagVersion, DocumentTagVersionAdmin)


class DocumentVersionAdminForm(forms.ModelForm):

    class Meta:
        model = DocumentVersion
        fields = '__all__'


class DocumentVersionAdmin(admin.ModelAdmin):
    form = DocumentVersionAdminForm
    list_display = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'filing', 'doc_template', 'confidential', 'pagecount', 'locked', 'hash', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'filing', 'doc_template', 'confidential', 'pagecount', 'locked', 'hash', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(DocumentVersion, DocumentVersionAdmin)


class EventlogAdminForm(forms.ModelForm):

    class Meta:
        model = Eventlog
        fields = '__all__'


class EventlogAdmin(admin.ModelAdmin):
    form = EventlogAdminForm
    list_display = ['created_on', 'changed_on', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter']
    readonly_fields = ['created_on', 'changed_on', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter']

admin.site.register(Eventlog, EventlogAdmin)


class EventlogVersionAdminForm(forms.ModelForm):

    class Meta:
        model = EventlogVersion
        fields = '__all__'


class EventlogVersionAdmin(admin.ModelAdmin):
    form = EventlogVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(EventlogVersion, EventlogVersionAdmin)


class FilingAdminForm(forms.ModelForm):

    class Meta:
        model = Filing
        fields = '__all__'


class FilingAdmin(admin.ModelAdmin):
    form = FilingAdminForm
    list_display = ['created_on', 'changed_on', 'uploaddate', 'pagecount', 'totalfees', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'urgent', 'urgentreason']
    readonly_fields = ['created_on', 'changed_on', 'uploaddate', 'pagecount', 'totalfees', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'urgent', 'urgentreason']

admin.site.register(Filing, FilingAdmin)


class FilingFilingtypeAdminForm(forms.ModelForm):

    class Meta:
        model = FilingFilingtype
        fields = '__all__'


class FilingFilingtypeAdmin(admin.ModelAdmin):
    form = FilingFilingtypeAdminForm


admin.site.register(FilingFilingtype, FilingFilingtypeAdmin)


class FilingFilingtypeVersionAdminForm(forms.ModelForm):

    class Meta:
        model = FilingFilingtypeVersion
        fields = '__all__'


class FilingFilingtypeVersionAdmin(admin.ModelAdmin):
    form = FilingFilingtypeVersionAdminForm
    list_display = ['filing', 'filingtype', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['filing', 'filingtype', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(FilingFilingtypeVersion, FilingFilingtypeVersionAdmin)


class FilingPaymentAdminForm(forms.ModelForm):

    class Meta:
        model = FilingPayment
        fields = '__all__'


class FilingPaymentAdmin(admin.ModelAdmin):
    form = FilingPaymentAdminForm


admin.site.register(FilingPayment, FilingPaymentAdmin)


class FilingPaymentVersionAdminForm(forms.ModelForm):

    class Meta:
        model = FilingPaymentVersion
        fields = '__all__'


class FilingPaymentVersionAdmin(admin.ModelAdmin):
    form = FilingPaymentVersionAdminForm
    list_display = ['filing', 'payment', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['filing', 'payment', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(FilingPaymentVersion, FilingPaymentVersionAdmin)


class FilingVersionAdminForm(forms.ModelForm):

    class Meta:
        model = FilingVersion
        fields = '__all__'


class FilingVersionAdmin(admin.ModelAdmin):
    form = FilingVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'uploaddate', 'pagecount', 'totalfees', 'filing_attorney', 'filing_prosecutor', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'case', 'urgent', 'urgentreason', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'uploaddate', 'pagecount', 'totalfees', 'filing_attorney', 'filing_prosecutor', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'case', 'urgent', 'urgentreason', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(FilingVersion, FilingVersionAdmin)


class FilingtypeAdminForm(forms.ModelForm):

    class Meta:
        model = Filingtype
        fields = '__all__'


class FilingtypeAdmin(admin.ModelAdmin):
    form = FilingtypeAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'fees', 'perpagecost', 'paid_per_page']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'fees', 'perpagecost', 'paid_per_page']

admin.site.register(Filingtype, FilingtypeAdmin)


class FilingtypeVersionAdminForm(forms.ModelForm):

    class Meta:
        model = FilingtypeVersion
        fields = '__all__'


class FilingtypeVersionAdmin(admin.ModelAdmin):
    form = FilingtypeVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'fees', 'perpagecost', 'paid_per_page', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'fees', 'perpagecost', 'paid_per_page', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(FilingtypeVersion, FilingtypeVersionAdmin)


class GateregisterAdminForm(forms.ModelForm):

    class Meta:
        model = Gateregister
        fields = '__all__'


class GateregisterAdmin(admin.ModelAdmin):
    form = GateregisterAdminForm
    list_display = ['created_on', 'changed_on', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color']
    readonly_fields = ['created_on', 'changed_on', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color']

admin.site.register(Gateregister, GateregisterAdmin)


class GateregisterVersionAdminForm(forms.ModelForm):

    class Meta:
        model = GateregisterVersion
        fields = '__all__'


class GateregisterVersionAdmin(admin.ModelAdmin):
    form = GateregisterVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'prison', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'prison', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(GateregisterVersion, GateregisterVersionAdmin)


class GateregisterWarderAdminForm(forms.ModelForm):

    class Meta:
        model = GateregisterWarder
        fields = '__all__'


class GateregisterWarderAdmin(admin.ModelAdmin):
    form = GateregisterWarderAdminForm


admin.site.register(GateregisterWarder, GateregisterWarderAdmin)


class GateregisterWarder2AdminForm(forms.ModelForm):

    class Meta:
        model = GateregisterWarder2
        fields = '__all__'


class GateregisterWarder2Admin(admin.ModelAdmin):
    form = GateregisterWarder2AdminForm


admin.site.register(GateregisterWarder2, GateregisterWarder2Admin)


class GateregisterWarder2VersionAdminForm(forms.ModelForm):

    class Meta:
        model = GateregisterWarder2Version
        fields = '__all__'


class GateregisterWarder2VersionAdmin(admin.ModelAdmin):
    form = GateregisterWarder2VersionAdminForm
    list_display = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(GateregisterWarder2Version, GateregisterWarder2VersionAdmin)


class GateregisterWarderVersionAdminForm(forms.ModelForm):

    class Meta:
        model = GateregisterWarderVersion
        fields = '__all__'


class GateregisterWarderVersionAdmin(admin.ModelAdmin):
    form = GateregisterWarderVersionAdminForm
    list_display = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(GateregisterWarderVersion, GateregisterWarderVersionAdmin)


class GenderAdminForm(forms.ModelForm):

    class Meta:
        model = Gender
        fields = '__all__'


class GenderAdmin(admin.ModelAdmin):
    form = GenderAdminForm
    list_display = ['created_on', 'changed_on', 'description', 'notes', 'name']
    readonly_fields = ['created_on', 'changed_on', 'description', 'notes', 'name']

admin.site.register(Gender, GenderAdmin)


class GenderVersionAdminForm(forms.ModelForm):

    class Meta:
        model = GenderVersion
        fields = '__all__'


class GenderVersionAdmin(admin.ModelAdmin):
    form = GenderVersionAdminForm
    list_display = ['created_on', 'changed_on', 'description', 'notes', 'id', 'name', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'description', 'notes', 'id', 'name', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(GenderVersion, GenderVersionAdmin)


class HearingAdminForm(forms.ModelForm):

    class Meta:
        model = Hearing
        fields = '__all__'


class HearingAdmin(admin.ModelAdmin):
    form = HearingAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'hearingdate', 'adjourned', 'completed', 'remandwarrant', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'hearingdate', 'adjourned', 'completed', 'remandwarrant', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video']

admin.site.register(Hearing, HearingAdmin)


class HearingJudicialofficerAdminForm(forms.ModelForm):

    class Meta:
        model = HearingJudicialofficer
        fields = '__all__'


class HearingJudicialofficerAdmin(admin.ModelAdmin):
    form = HearingJudicialofficerAdminForm


admin.site.register(HearingJudicialofficer, HearingJudicialofficerAdmin)


class HearingJudicialofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingJudicialofficerVersion
        fields = '__all__'


class HearingJudicialofficerVersionAdmin(admin.ModelAdmin):
    form = HearingJudicialofficerVersionAdminForm
    list_display = ['hearing', 'judicialofficer', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'judicialofficer', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingJudicialofficerVersion, HearingJudicialofficerVersionAdmin)


class HearingLawyersAdminForm(forms.ModelForm):

    class Meta:
        model = HearingLawyers
        fields = '__all__'


class HearingLawyersAdmin(admin.ModelAdmin):
    form = HearingLawyersAdminForm


admin.site.register(HearingLawyers, HearingLawyersAdmin)


class HearingLawyersVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingLawyersVersion
        fields = '__all__'


class HearingLawyersVersionAdmin(admin.ModelAdmin):
    form = HearingLawyersVersionAdminForm
    list_display = ['hearing', 'lawyers', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'lawyers', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingLawyersVersion, HearingLawyersVersionAdmin)


class HearingPolofficerAdminForm(forms.ModelForm):

    class Meta:
        model = HearingPolofficer
        fields = '__all__'


class HearingPolofficerAdmin(admin.ModelAdmin):
    form = HearingPolofficerAdminForm


admin.site.register(HearingPolofficer, HearingPolofficerAdmin)


class HearingPolofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingPolofficerVersion
        fields = '__all__'


class HearingPolofficerVersionAdmin(admin.ModelAdmin):
    form = HearingPolofficerVersionAdminForm
    list_display = ['hearing', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingPolofficerVersion, HearingPolofficerVersionAdmin)


class HearingProsecutorAdminForm(forms.ModelForm):

    class Meta:
        model = HearingProsecutor
        fields = '__all__'


class HearingProsecutorAdmin(admin.ModelAdmin):
    form = HearingProsecutorAdminForm


admin.site.register(HearingProsecutor, HearingProsecutorAdmin)


class HearingProsecutorVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingProsecutorVersion
        fields = '__all__'


class HearingProsecutorVersionAdmin(admin.ModelAdmin):
    form = HearingProsecutorVersionAdminForm
    list_display = ['hearing', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingProsecutorVersion, HearingProsecutorVersionAdmin)


class HearingTagAdminForm(forms.ModelForm):

    class Meta:
        model = HearingTag
        fields = '__all__'


class HearingTagAdmin(admin.ModelAdmin):
    form = HearingTagAdminForm


admin.site.register(HearingTag, HearingTagAdmin)


class HearingTagVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingTagVersion
        fields = '__all__'


class HearingTagVersionAdmin(admin.ModelAdmin):
    form = HearingTagVersionAdminForm
    list_display = ['hearing', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingTagVersion, HearingTagVersionAdmin)


class HearingVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingVersion
        fields = '__all__'


class HearingVersionAdmin(admin.ModelAdmin):
    form = HearingVersionAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'hearingdate', 'adjourned', 'completed', 'case', 'court', 'remandwarrant', 'hearing_type', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'hearingdate', 'adjourned', 'completed', 'case', 'court', 'remandwarrant', 'hearing_type', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingVersion, HearingVersionAdmin)


class HearingWitnessAdminForm(forms.ModelForm):

    class Meta:
        model = HearingWitness
        fields = '__all__'


class HearingWitnessAdmin(admin.ModelAdmin):
    form = HearingWitnessAdminForm


admin.site.register(HearingWitness, HearingWitnessAdmin)


class HearingWitnessVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingWitnessVersion
        fields = '__all__'


class HearingWitnessVersionAdmin(admin.ModelAdmin):
    form = HearingWitnessVersionAdminForm
    list_display = ['hearing', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['hearing', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingWitnessVersion, HearingWitnessVersionAdmin)


class HearingtypeAdminForm(forms.ModelForm):

    class Meta:
        model = Hearingtype
        fields = '__all__'


class HearingtypeAdmin(admin.ModelAdmin):
    form = HearingtypeAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Hearingtype, HearingtypeAdmin)


class HearingtypeVersionAdminForm(forms.ModelForm):

    class Meta:
        model = HearingtypeVersion
        fields = '__all__'


class HearingtypeVersionAdmin(admin.ModelAdmin):
    form = HearingtypeVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(HearingtypeVersion, HearingtypeVersionAdmin)


class InvestigationAdminForm(forms.ModelForm):

    class Meta:
        model = Investigation
        fields = '__all__'


class InvestigationAdmin(admin.ModelAdmin):
    form = InvestigationAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'actiondate', 'evidence', 'narrative', 'weather', 'location']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'actiondate', 'evidence', 'narrative', 'weather', 'location']

admin.site.register(Investigation, InvestigationAdmin)


class InvestigationPolofficerAdminForm(forms.ModelForm):

    class Meta:
        model = InvestigationPolofficer
        fields = '__all__'


class InvestigationPolofficerAdmin(admin.ModelAdmin):
    form = InvestigationPolofficerAdminForm


admin.site.register(InvestigationPolofficer, InvestigationPolofficerAdmin)


class InvestigationPolofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = InvestigationPolofficerVersion
        fields = '__all__'


class InvestigationPolofficerVersionAdmin(admin.ModelAdmin):
    form = InvestigationPolofficerVersionAdminForm
    list_display = ['investigation', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['investigation', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(InvestigationPolofficerVersion, InvestigationPolofficerVersionAdmin)


class InvestigationVersionAdminForm(forms.ModelForm):

    class Meta:
        model = InvestigationVersion
        fields = '__all__'


class InvestigationVersionAdmin(admin.ModelAdmin):
    form = InvestigationVersionAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'case', 'actiondate', 'evidence', 'narrative', 'weather', 'location', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'case', 'actiondate', 'evidence', 'narrative', 'weather', 'location', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(InvestigationVersion, InvestigationVersionAdmin)


class InvestigationWitnessAdminForm(forms.ModelForm):

    class Meta:
        model = InvestigationWitness
        fields = '__all__'


class InvestigationWitnessAdmin(admin.ModelAdmin):
    form = InvestigationWitnessAdminForm


admin.site.register(InvestigationWitness, InvestigationWitnessAdmin)


class InvestigationWitnessVersionAdminForm(forms.ModelForm):

    class Meta:
        model = InvestigationWitnessVersion
        fields = '__all__'


class InvestigationWitnessVersionAdmin(admin.ModelAdmin):
    form = InvestigationWitnessVersionAdminForm
    list_display = ['investigation', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['investigation', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(InvestigationWitnessVersion, InvestigationWitnessVersionAdmin)


class JoRankAdminForm(forms.ModelForm):

    class Meta:
        model = JoRank
        fields = '__all__'


class JoRankAdmin(admin.ModelAdmin):
    form = JoRankAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'appelation', 'informaladdress']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'appelation', 'informaladdress']

admin.site.register(JoRank, JoRankAdmin)


class JoRankVersionAdminForm(forms.ModelForm):

    class Meta:
        model = JoRankVersion
        fields = '__all__'


class JoRankVersionAdmin(admin.ModelAdmin):
    form = JoRankVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'appelation', 'informaladdress', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'appelation', 'informaladdress', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(JoRankVersion, JoRankVersionAdmin)


class JudicialofficerAdminForm(forms.ModelForm):

    class Meta:
        model = Judicialofficer
        fields = '__all__'


class JudicialofficerAdmin(admin.ModelAdmin):
    form = JudicialofficerAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']

admin.site.register(Judicialofficer, JudicialofficerAdmin)


class JudicialofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = JudicialofficerVersion
        fields = '__all__'


class JudicialofficerVersionAdmin(admin.ModelAdmin):
    form = JudicialofficerVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'court', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'court', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(JudicialofficerVersion, JudicialofficerVersionAdmin)


class LawfirmAdminForm(forms.ModelForm):

    class Meta:
        model = Lawfirm
        fields = '__all__'


class LawfirmAdmin(admin.ModelAdmin):
    form = LawfirmAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature']

admin.site.register(Lawfirm, LawfirmAdmin)


class LawfirmVersionAdminForm(forms.ModelForm):

    class Meta:
        model = LawfirmVersion
        fields = '__all__'


class LawfirmVersionAdmin(admin.ModelAdmin):
    form = LawfirmVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(LawfirmVersion, LawfirmVersionAdmin)


class LawyersAdminForm(forms.ModelForm):

    class Meta:
        model = Lawyers
        fields = '__all__'


class LawyersAdmin(admin.ModelAdmin):
    form = LawyersAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'barnumber', 'admissiondate']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'barnumber', 'admissiondate']

admin.site.register(Lawyers, LawyersAdmin)


class LawyersVersionAdminForm(forms.ModelForm):

    class Meta:
        model = LawyersVersion
        fields = '__all__'


class LawyersVersionAdmin(admin.ModelAdmin):
    form = LawyersVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'barnumber', 'law_firm', 'admissiondate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'barnumber', 'law_firm', 'admissiondate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(LawyersVersion, LawyersVersionAdmin)


class MedeventAdminForm(forms.ModelForm):

    class Meta:
        model = Medevent
        fields = '__all__'


class MedeventAdmin(admin.ModelAdmin):
    form = MedeventAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget']

admin.site.register(Medevent, MedeventAdmin)


class MedeventVersionAdminForm(forms.ModelForm):

    class Meta:
        model = MedeventVersion
        fields = '__all__'


class MedeventVersionAdmin(admin.ModelAdmin):
    form = MedeventVersionAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(MedeventVersion, MedeventVersionAdmin)


class NatureofsuitAdminForm(forms.ModelForm):

    class Meta:
        model = Natureofsuit
        fields = '__all__'


class NatureofsuitAdmin(admin.ModelAdmin):
    form = NatureofsuitAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Natureofsuit, NatureofsuitAdmin)


class NatureofsuitVersionAdminForm(forms.ModelForm):

    class Meta:
        model = NatureofsuitVersion
        fields = '__all__'


class NatureofsuitVersionAdmin(admin.ModelAdmin):
    form = NatureofsuitVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(NatureofsuitVersion, NatureofsuitVersionAdmin)


class PaymentAdminForm(forms.ModelForm):

    class Meta:
        model = Payment
        fields = '__all__'


class PaymentAdmin(admin.ModelAdmin):
    form = PaymentAdminForm
    list_display = ['created_on', 'changed_on', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'billrefnumber', 'paymentdescription']
    readonly_fields = ['created_on', 'changed_on', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'billrefnumber', 'paymentdescription']

admin.site.register(Payment, PaymentAdmin)


class PaymentVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PaymentVersion
        fields = '__all__'


class PaymentVersionAdmin(admin.ModelAdmin):
    form = PaymentVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'bail', 'billrefnumber', 'payment_method', 'paymentdescription', 'case', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'bail', 'billrefnumber', 'payment_method', 'paymentdescription', 'case', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PaymentVersion, PaymentVersionAdmin)


class PaymentmethodAdminForm(forms.ModelForm):

    class Meta:
        model = Paymentmethod
        fields = '__all__'


class PaymentmethodAdmin(admin.ModelAdmin):
    form = PaymentmethodAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'key', 'secret', 'portal', 'tillnumber', 'shortcode']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'key', 'secret', 'portal', 'tillnumber', 'shortcode']

admin.site.register(Paymentmethod, PaymentmethodAdmin)


class PaymentmethodVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PaymentmethodVersion
        fields = '__all__'


class PaymentmethodVersionAdmin(admin.ModelAdmin):
    form = PaymentmethodVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'key', 'secret', 'portal', 'tillnumber', 'shortcode', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'key', 'secret', 'portal', 'tillnumber', 'shortcode', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PaymentmethodVersion, PaymentmethodVersionAdmin)


class PlaintiffAdminForm(forms.ModelForm):

    class Meta:
        model = Plaintiff
        fields = '__all__'


class PlaintiffAdmin(admin.ModelAdmin):
    form = PlaintiffAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile']

admin.site.register(Plaintiff, PlaintiffAdmin)


class PlaintiffVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PlaintiffVersion
        fields = '__all__'


class PlaintiffVersionAdmin(admin.ModelAdmin):
    form = PlaintiffVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'juvenile', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'juvenile', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PlaintiffVersion, PlaintiffVersionAdmin)


class PolicerankAdminForm(forms.ModelForm):

    class Meta:
        model = Policerank
        fields = '__all__'


class PolicerankAdmin(admin.ModelAdmin):
    form = PolicerankAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Policerank, PolicerankAdmin)


class PolicerankVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PolicerankVersion
        fields = '__all__'


class PolicerankVersionAdmin(admin.ModelAdmin):
    form = PolicerankVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PolicerankVersion, PolicerankVersionAdmin)


class PoliceroleAdminForm(forms.ModelForm):

    class Meta:
        model = Policerole
        fields = '__all__'


class PoliceroleAdmin(admin.ModelAdmin):
    form = PoliceroleAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Policerole, PoliceroleAdmin)


class PoliceroleVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PoliceroleVersion
        fields = '__all__'


class PoliceroleVersionAdmin(admin.ModelAdmin):
    form = PoliceroleVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PoliceroleVersion, PoliceroleVersionAdmin)


class PolicestationAdminForm(forms.ModelForm):

    class Meta:
        model = Policestation
        fields = '__all__'


class PolicestationAdmin(admin.ModelAdmin):
    form = PolicestationAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'has_forensic_lab', 'officercommanding']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'has_forensic_lab', 'officercommanding']

admin.site.register(Policestation, PolicestationAdmin)


class PolicestationVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PolicestationVersion
        fields = '__all__'


class PolicestationVersionAdmin(admin.ModelAdmin):
    form = PolicestationVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'has_forensic_lab', 'officercommanding', 'police_station_type', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'has_forensic_lab', 'officercommanding', 'police_station_type', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PolicestationVersion, PolicestationVersionAdmin)


class PolicestationtypeAdminForm(forms.ModelForm):

    class Meta:
        model = Policestationtype
        fields = '__all__'


class PolicestationtypeAdmin(admin.ModelAdmin):
    form = PolicestationtypeAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Policestationtype, PolicestationtypeAdmin)


class PolicestationtypeVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PolicestationtypeVersion
        fields = '__all__'


class PolicestationtypeVersionAdmin(admin.ModelAdmin):
    form = PolicestationtypeVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PolicestationtypeVersion, PolicestationtypeVersionAdmin)


class PolofficerAdminForm(forms.ModelForm):

    class Meta:
        model = Polofficer
        fields = '__all__'


class PolofficerAdmin(admin.ModelAdmin):
    form = PolofficerAdminForm
    list_display = ['created_on', 'changed_on', 'servicenumber', 'postdate']
    readonly_fields = ['created_on', 'changed_on', 'servicenumber', 'postdate']

admin.site.register(Polofficer, PolofficerAdmin)


class PolofficerPoliceroleAdminForm(forms.ModelForm):

    class Meta:
        model = PolofficerPolicerole
        fields = '__all__'


class PolofficerPoliceroleAdmin(admin.ModelAdmin):
    form = PolofficerPoliceroleAdminForm


admin.site.register(PolofficerPolicerole, PolofficerPoliceroleAdmin)


class PolofficerPoliceroleVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PolofficerPoliceroleVersion
        fields = '__all__'


class PolofficerPoliceroleVersionAdmin(admin.ModelAdmin):
    form = PolofficerPoliceroleVersionAdminForm
    list_display = ['polofficer', 'policerole', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['polofficer', 'policerole', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PolofficerPoliceroleVersion, PolofficerPoliceroleVersionAdmin)


class PolofficerVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PolofficerVersion
        fields = '__all__'


class PolofficerVersionAdmin(admin.ModelAdmin):
    form = PolofficerVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'police_rank', 'gender', 'servicenumber', 'reports_to', 'pol_supervisor', 'postdate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'police_rank', 'gender', 'servicenumber', 'reports_to', 'pol_supervisor', 'postdate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PolofficerVersion, PolofficerVersionAdmin)


class PrisonAdminForm(forms.ModelForm):

    class Meta:
        model = Prison
        fields = '__all__'


class PrisonAdmin(admin.ModelAdmin):
    form = PrisonAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'warden', 'capacity', 'population', 'cellcount', 'gatecount']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'warden', 'capacity', 'population', 'cellcount', 'gatecount']

admin.site.register(Prison, PrisonAdmin)


class PrisonSecurityrankAdminForm(forms.ModelForm):

    class Meta:
        model = PrisonSecurityrank
        fields = '__all__'


class PrisonSecurityrankAdmin(admin.ModelAdmin):
    form = PrisonSecurityrankAdminForm


admin.site.register(PrisonSecurityrank, PrisonSecurityrankAdmin)


class PrisonSecurityrankVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisonSecurityrankVersion
        fields = '__all__'


class PrisonSecurityrankVersionAdmin(admin.ModelAdmin):
    form = PrisonSecurityrankVersionAdminForm
    list_display = ['prison', 'securityrank', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['prison', 'securityrank', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisonSecurityrankVersion, PrisonSecurityrankVersionAdmin)


class PrisonVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisonVersion
        fields = '__all__'


class PrisonVersionAdmin(admin.ModelAdmin):
    form = PrisonVersionAdminForm
    list_display = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'warden', 'capacity', 'population', 'cellcount', 'gatecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'warden', 'capacity', 'population', 'cellcount', 'gatecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisonVersion, PrisonVersionAdmin)


class PrisoncellAdminForm(forms.ModelForm):

    class Meta:
        model = Prisoncell
        fields = '__all__'


class PrisoncellAdmin(admin.ModelAdmin):
    form = PrisoncellAdminForm
    list_display = ['created_on', 'changed_on']
    readonly_fields = ['created_on', 'changed_on']

admin.site.register(Prisoncell, PrisoncellAdmin)


class PrisoncellVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisoncellVersion
        fields = '__all__'


class PrisoncellVersionAdmin(admin.ModelAdmin):
    form = PrisoncellVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'prison', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'prison', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisoncellVersion, PrisoncellVersionAdmin)


class PrisoncommitalAdminForm(forms.ModelForm):

    class Meta:
        model = Prisoncommital
        fields = '__all__'


class PrisoncommitalAdmin(admin.ModelAdmin):
    form = PrisoncommitalAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'warrantno', 'warrantdate', 'hascourtdate', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'paroledate', 'escaped', 'escapedate', 'escapedetails']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'warrantno', 'warrantdate', 'hascourtdate', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'paroledate', 'escaped', 'escapedate', 'escapedetails']

admin.site.register(Prisoncommital, PrisoncommitalAdmin)


class PrisoncommitalVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisoncommitalVersion
        fields = '__all__'


class PrisoncommitalVersionAdmin(admin.ModelAdmin):
    form = PrisoncommitalVersionAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'prison', 'warrantno', 'defendant', 'hearing', 'warrantdate', 'hascourtdate', 'judicial_officer_warrant', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'police_officer_commiting', 'paroledate', 'escaped', 'escapedate', 'escapedetails', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'prison', 'warrantno', 'defendant', 'hearing', 'warrantdate', 'hascourtdate', 'judicial_officer_warrant', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'police_officer_commiting', 'paroledate', 'escaped', 'escapedate', 'escapedetails', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisoncommitalVersion, PrisoncommitalVersionAdmin)


class PrisoncommitalWarderAdminForm(forms.ModelForm):

    class Meta:
        model = PrisoncommitalWarder
        fields = '__all__'


class PrisoncommitalWarderAdmin(admin.ModelAdmin):
    form = PrisoncommitalWarderAdminForm
    list_display = ['prisoncommital_warrantno']
    readonly_fields = ['prisoncommital_warrantno']

admin.site.register(PrisoncommitalWarder, PrisoncommitalWarderAdmin)


class PrisoncommitalWarderVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisoncommitalWarderVersion
        fields = '__all__'


class PrisoncommitalWarderVersionAdmin(admin.ModelAdmin):
    form = PrisoncommitalWarderVersionAdminForm
    list_display = ['prisoncommital_prison', 'prisoncommital_warrantno', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['prisoncommital_prison', 'prisoncommital_warrantno', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisoncommitalWarderVersion, PrisoncommitalWarderVersionAdmin)


class PrisonerpropertyAdminForm(forms.ModelForm):

    class Meta:
        model = Prisonerproperty
        fields = '__all__'


class PrisonerpropertyAdmin(admin.ModelAdmin):
    form = PrisonerpropertyAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'prison_commital_warrantno', 'receipted']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'prison_commital_warrantno', 'receipted']

admin.site.register(Prisonerproperty, PrisonerpropertyAdmin)


class PrisonerpropertyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = PrisonerpropertyVersion
        fields = '__all__'


class PrisonerpropertyVersionAdmin(admin.ModelAdmin):
    form = PrisonerpropertyVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'receipted', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'receipted', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(PrisonerpropertyVersion, PrisonerpropertyVersionAdmin)


class ProsecutorAdminForm(forms.ModelForm):

    class Meta:
        model = Prosecutor
        fields = '__all__'


class ProsecutorAdmin(admin.ModelAdmin):
    form = ProsecutorAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']

admin.site.register(Prosecutor, ProsecutorAdmin)


class ProsecutorProsecutorteamAdminForm(forms.ModelForm):

    class Meta:
        model = ProsecutorProsecutorteam
        fields = '__all__'


class ProsecutorProsecutorteamAdmin(admin.ModelAdmin):
    form = ProsecutorProsecutorteamAdminForm


admin.site.register(ProsecutorProsecutorteam, ProsecutorProsecutorteamAdmin)


class ProsecutorProsecutorteamVersionAdminForm(forms.ModelForm):

    class Meta:
        model = ProsecutorProsecutorteamVersion
        fields = '__all__'


class ProsecutorProsecutorteamVersionAdmin(admin.ModelAdmin):
    form = ProsecutorProsecutorteamVersionAdminForm
    list_display = ['prosecutor', 'prosecutorteam', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['prosecutor', 'prosecutorteam', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(ProsecutorProsecutorteamVersion, ProsecutorProsecutorteamVersionAdmin)


class ProsecutorVersionAdminForm(forms.ModelForm):

    class Meta:
        model = ProsecutorVersion
        fields = '__all__'


class ProsecutorVersionAdmin(admin.ModelAdmin):
    form = ProsecutorVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(ProsecutorVersion, ProsecutorVersionAdmin)


class ProsecutorteamAdminForm(forms.ModelForm):

    class Meta:
        model = Prosecutorteam
        fields = '__all__'


class ProsecutorteamAdmin(admin.ModelAdmin):
    form = ProsecutorteamAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Prosecutorteam, ProsecutorteamAdmin)


class ProsecutorteamVersionAdminForm(forms.ModelForm):

    class Meta:
        model = ProsecutorteamVersion
        fields = '__all__'


class ProsecutorteamVersionAdmin(admin.ModelAdmin):
    form = ProsecutorteamVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(ProsecutorteamVersion, ProsecutorteamVersionAdmin)


class RemissionAdminForm(forms.ModelForm):

    class Meta:
        model = Remission
        fields = '__all__'


class RemissionAdmin(admin.ModelAdmin):
    form = RemissionAdminForm
    list_display = ['created_on', 'changed_on', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount']
    readonly_fields = ['created_on', 'changed_on', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount']

admin.site.register(Remission, RemissionAdmin)


class RemissionVersionAdminForm(forms.ModelForm):

    class Meta:
        model = RemissionVersion
        fields = '__all__'


class RemissionVersionAdmin(admin.ModelAdmin):
    form = RemissionVersionAdminForm
    list_display = ['created_on', 'changed_on', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(RemissionVersion, RemissionVersionAdmin)


class SecurityrankAdminForm(forms.ModelForm):

    class Meta:
        model = Securityrank
        fields = '__all__'


class SecurityrankAdmin(admin.ModelAdmin):
    form = SecurityrankAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Securityrank, SecurityrankAdmin)


class SecurityrankVersionAdminForm(forms.ModelForm):

    class Meta:
        model = SecurityrankVersion
        fields = '__all__'


class SecurityrankVersionAdmin(admin.ModelAdmin):
    form = SecurityrankVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(SecurityrankVersion, SecurityrankVersionAdmin)


class SubcountyAdminForm(forms.ModelForm):

    class Meta:
        model = Subcounty
        fields = '__all__'


class SubcountyAdmin(admin.ModelAdmin):
    form = SubcountyAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Subcounty, SubcountyAdmin)


class SubcountyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = SubcountyVersion
        fields = '__all__'


class SubcountyVersionAdmin(admin.ModelAdmin):
    form = SubcountyVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(SubcountyVersion, SubcountyVersionAdmin)


class SuretyAdminForm(forms.ModelForm):

    class Meta:
        model = Surety
        fields = '__all__'


class SuretyAdmin(admin.ModelAdmin):
    form = SuretyAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']

admin.site.register(Surety, SuretyAdmin)


class SuretyVersionAdminForm(forms.ModelForm):

    class Meta:
        model = SuretyVersion
        fields = '__all__'


class SuretyVersionAdmin(admin.ModelAdmin):
    form = SuretyVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(SuretyVersion, SuretyVersionAdmin)


class TagAdminForm(forms.ModelForm):

    class Meta:
        model = Tag
        fields = '__all__'


class TagAdmin(admin.ModelAdmin):
    form = TagAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Tag, TagAdmin)


class TagVersionAdminForm(forms.ModelForm):

    class Meta:
        model = TagVersion
        fields = '__all__'


class TagVersionAdmin(admin.ModelAdmin):
    form = TagVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(TagVersion, TagVersionAdmin)


class TownAdminForm(forms.ModelForm):

    class Meta:
        model = Town
        fields = '__all__'


class TownAdmin(admin.ModelAdmin):
    form = TownAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Town, TownAdmin)


class TownVersionAdminForm(forms.ModelForm):

    class Meta:
        model = TownVersion
        fields = '__all__'


class TownVersionAdmin(admin.ModelAdmin):
    form = TownVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'subcounty', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'subcounty', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(TownVersion, TownVersionAdmin)


class TransactionAdminForm(forms.ModelForm):

    class Meta:
        model = Transaction
        fields = '__all__'


class TransactionAdmin(admin.ModelAdmin):
    form = TransactionAdminForm
    list_display = ['issued_at', 'id', 'remote_addr']
    readonly_fields = ['issued_at', 'id', 'remote_addr']

admin.site.register(Transaction, TransactionAdmin)


class VisitAdminForm(forms.ModelForm):

    class Meta:
        model = Visit
        fields = '__all__'


class VisitAdmin(admin.ModelAdmin):
    form = VisitAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'visitdate', 'visitnotes']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'visitdate', 'visitnotes']

admin.site.register(Visit, VisitAdmin)


class VisitVersionAdminForm(forms.ModelForm):

    class Meta:
        model = VisitVersion
        fields = '__all__'


class VisitVersionAdmin(admin.ModelAdmin):
    form = VisitVersionAdminForm
    list_display = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'vistors', 'defendants', 'visitdate', 'visitnotes', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'vistors', 'defendants', 'visitdate', 'visitnotes', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(VisitVersion, VisitVersionAdmin)


class VisitorAdminForm(forms.ModelForm):

    class Meta:
        model = Visitor
        fields = '__all__'


class VisitorAdmin(admin.ModelAdmin):
    form = VisitorAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']

admin.site.register(Visitor, VisitorAdmin)


class VisitorVersionAdminForm(forms.ModelForm):

    class Meta:
        model = VisitorVersion
        fields = '__all__'


class VisitorVersionAdmin(admin.ModelAdmin):
    form = VisitorVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(VisitorVersion, VisitorVersionAdmin)


class WarderAdminForm(forms.ModelForm):

    class Meta:
        model = Warder
        fields = '__all__'


class WarderAdmin(admin.ModelAdmin):
    form = WarderAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi']

admin.site.register(Warder, WarderAdmin)


class WarderVersionAdminForm(forms.ModelForm):

    class Meta:
        model = WarderVersion
        fields = '__all__'


class WarderVersionAdmin(admin.ModelAdmin):
    form = WarderVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'prison', 'warder_rank', 'reports_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'prison', 'warder_rank', 'reports_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(WarderVersion, WarderVersionAdmin)


class WarderrankAdminForm(forms.ModelForm):

    class Meta:
        model = Warderrank
        fields = '__all__'


class WarderrankAdmin(admin.ModelAdmin):
    form = WarderrankAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes']

admin.site.register(Warderrank, WarderrankAdmin)


class WarderrankVersionAdminForm(forms.ModelForm):

    class Meta:
        model = WarderrankVersion
        fields = '__all__'


class WarderrankVersionAdmin(admin.ModelAdmin):
    form = WarderrankVersionAdminForm
    list_display = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(WarderrankVersion, WarderrankVersionAdmin)


class WitnessAdminForm(forms.ModelForm):

    class Meta:
        model = Witness
        fields = '__all__'


class WitnessAdmin(admin.ModelAdmin):
    form = WitnessAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'fordefense']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'fordefense']

admin.site.register(Witness, WitnessAdmin)


class WitnessVersionAdminForm(forms.ModelForm):

    class Meta:
        model = WitnessVersion
        fields = '__all__'


class WitnessVersionAdmin(admin.ModelAdmin):
    form = WitnessVersionAdminForm
    list_display = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'fordefense', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']
    readonly_fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'fordefense', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']

admin.site.register(WitnessVersion, WitnessVersionAdmin)


