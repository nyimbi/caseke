from django.core.urlresolvers import reverse
from django_extensions.db.fields import AutoSlugField
from django.db.models import *
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth import get_user_model
from django.contrib.auth import models as auth_models
from django.db import models as models
from django_extensions.db import fields as extension_fields


class Bail(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    amountgranted = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    noofsureties = IntegerField(blank=True, null=True)
    paid = NullBooleanField()
    paydate = DateField(blank=True, null=True)

    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing')
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_bail_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_bail_update', args=(self.pk,))


class BailSurety(models.Model):


    # Relationship Fields
    bail = ForeignKey('casemgmt.Bail', models.DO_NOTHING, db_column='bail', primary_key=True)
    surety = ForeignKey('casemgmt.Surety', models.DO_NOTHING, db_column='surety')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_bailsurety_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_bailsurety_update', args=(self.pk,))


class BailSuretyVersion(models.Model):

    # Fields
    bail = IntegerField(primary_key=True)
    surety = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_bailsuretyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_bailsuretyversion_update', args=(self.pk,))


class BailVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    hearing = IntegerField(blank=True, null=True)
    defendant = IntegerField(blank=True, null=True)
    amountgranted = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    noofsureties = IntegerField(blank=True, null=True)
    paid = NullBooleanField()
    paydate = DateField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_bailversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_bailversion_update', args=(self.pk,))


class Case(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    born_digital = NullBooleanField()
    ob_number = CharField(max_length=20)
    report_date = DateTimeField(blank=True, null=True)
    complaint = TextField()
    is_criminal = NullBooleanField()
    priority = IntegerField(blank=True, null=True)
    should_investigate_further = NullBooleanField()
    evaluation_conclusion = TextField(blank=True, null=True)
    investigation_assigment_date = DateTimeField(blank=True, null=True)
    investigation_assignment_note = TextField(blank=True, null=True)
    investigation_plan = TextField(blank=True, null=True)
    investigation_summary = TextField(blank=True, null=True)
    investigation_review = TextField(blank=True, null=True)
    investigation_complete = NullBooleanField()
    dpp_advice_requested = NullBooleanField()
    dpp_advice_request_date = DateField(blank=True, null=True)
    dpp_advice_date = DateField(blank=True, null=True)
    dpp_advice = TextField(blank=True, null=True)
    send_to_trial = NullBooleanField()
    case_name = CharField(max_length=400, blank=True, null=True)
    docketnumber = CharField(max_length=100, blank=True, null=True)
    charge_sheet = TextField(blank=True, null=True)
    charge_date = DateTimeField(blank=True, null=True)
    prosecution_notes = TextField(blank=True, null=True)
    defense_notes = TextField(blank=True, null=True)
    judgement = TextField(blank=True, null=True)
    judgement_date = DateTimeField(blank=True, null=True)
    sentence_length_years = IntegerField(blank=True, null=True)
    sentence_length_months = IntegerField(blank=True, null=True)
    senetence_length_days = IntegerField(blank=True, null=True)
    sentence_start_date = DateField(blank=True, null=True)
    sentence_end_date = DateField(blank=True, null=True)
    fine_amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    case_appealed = NullBooleanField()
    appeal_date = DateTimeField(blank=True, null=True)
    appeal_granted = NullBooleanField()
    appeal_expiry = DateField(blank=True, null=True)
    case_closed = NullBooleanField()
    close_date = DateField(blank=True, null=True)

    # Relationship Fields
    police_station_reported = ForeignKey('casemgmt.Policestation', models.DO_NOTHING, db_column='police_station_reported')
    reported_to = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='reported_to', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_case_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_case_update', args=(self.pk,))


class CaseCasecategory(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    casecategory = ForeignKey('casemgmt.Casecategory', models.DO_NOTHING, db_column='casecategory')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecasecategory_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecasecategory_update', args=(self.pk,))


class CaseCasecategoryVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    casecategory = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecasecategoryversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecasecategoryversion_update', args=(self.pk,))


class CaseCauseofaction(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    causeofaction = ForeignKey('casemgmt.Causeofaction', models.DO_NOTHING, db_column='causeofaction')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecauseofaction_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecauseofaction_update', args=(self.pk,))


class CaseCauseofactionVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    causeofaction = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecauseofactionversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecauseofactionversion_update', args=(self.pk,))


class CaseDefendant(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casedefendant_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casedefendant_update', args=(self.pk,))


class CaseDefendantVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    defendant = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casedefendantversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casedefendantversion_update', args=(self.pk,))


class CaseNatureofsuit(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    natureofsuit = ForeignKey('casemgmt.Natureofsuit', models.DO_NOTHING, db_column='natureofsuit')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casenatureofsuit_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casenatureofsuit_update', args=(self.pk,))


class CaseNatureofsuitVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    natureofsuit = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casenatureofsuitversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casenatureofsuitversion_update', args=(self.pk,))


class CasePlaintiff(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    plaintiff = ForeignKey('casemgmt.Plaintiff', models.DO_NOTHING, db_column='plaintiff')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseplaintiff_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseplaintiff_update', args=(self.pk,))


class CasePlaintiffVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    plaintiff = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseplaintiffversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseplaintiffversion_update', args=(self.pk,))


class CasePolofficer(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    polofficer = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='polofficer')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casepolofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casepolofficer_update', args=(self.pk,))


class CasePolofficerVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    polofficer = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casepolofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casepolofficerversion_update', args=(self.pk,))


class CaseProsecutor(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    prosecutor = ForeignKey('casemgmt.Prosecutor', models.DO_NOTHING, db_column='prosecutor')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseprosecutor_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseprosecutor_update', args=(self.pk,))


class CaseProsecutor2(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    prosecutor = ForeignKey('casemgmt.Prosecutor', models.DO_NOTHING, db_column='prosecutor')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseprosecutor2_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseprosecutor2_update', args=(self.pk,))


class CaseProsecutor2Version(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    prosecutor = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseprosecutor2version_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseprosecutor2version_update', args=(self.pk,))


class CaseProsecutorVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    prosecutor = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseprosecutorversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseprosecutorversion_update', args=(self.pk,))


class CaseTag(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    tag = ForeignKey('casemgmt.Tag', models.DO_NOTHING, db_column='tag')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casetag_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casetag_update', args=(self.pk,))


class CaseTagVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    tag = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casetagversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casetagversion_update', args=(self.pk,))


class CaseVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    id = IntegerField(primary_key=True)
    born_digital = NullBooleanField()
    ob_number = CharField(max_length=20, blank=True, null=True)
    police_station_reported = IntegerField(blank=True, null=True)
    report_date = DateTimeField(blank=True, null=True)
    complaint = TextField(blank=True, null=True)
    is_criminal = NullBooleanField()
    priority = IntegerField(blank=True, null=True)
    should_investigate_further = NullBooleanField()
    evaluation_conclusion = TextField(blank=True, null=True)
    investigation_assigment_date = DateTimeField(blank=True, null=True)
    investigation_assignment_note = TextField(blank=True, null=True)
    investigation_plan = TextField(blank=True, null=True)
    investigation_summary = TextField(blank=True, null=True)
    investigation_review = TextField(blank=True, null=True)
    investigation_complete = NullBooleanField()
    dpp_advice_requested = NullBooleanField()
    dpp_advice_request_date = DateField(blank=True, null=True)
    dpp_advice_date = DateField(blank=True, null=True)
    dpp_advice = TextField(blank=True, null=True)
    send_to_trial = NullBooleanField()
    case_name = CharField(max_length=400, blank=True, null=True)
    docketnumber = CharField(max_length=100, blank=True, null=True)
    charge_sheet = TextField(blank=True, null=True)
    charge_date = DateTimeField(blank=True, null=True)
    prosecution_notes = TextField(blank=True, null=True)
    defense_notes = TextField(blank=True, null=True)
    judgement = TextField(blank=True, null=True)
    judgement_date = DateTimeField(blank=True, null=True)
    sentence_length_years = IntegerField(blank=True, null=True)
    sentence_length_months = IntegerField(blank=True, null=True)
    senetence_length_days = IntegerField(blank=True, null=True)
    sentence_start_date = DateField(blank=True, null=True)
    sentence_end_date = DateField(blank=True, null=True)
    fine_amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    case_appealed = NullBooleanField()
    appeal_date = DateTimeField(blank=True, null=True)
    appeal_granted = NullBooleanField()
    appeal_expiry = DateField(blank=True, null=True)
    case_closed = NullBooleanField()
    close_date = DateField(blank=True, null=True)
    reported_to = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseversion_update', args=(self.pk,))


class CaseWitness(models.Model):


    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', primary_key=True)
    witness = ForeignKey('casemgmt.Witness', models.DO_NOTHING, db_column='witness')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casewitness_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casewitness_update', args=(self.pk,))


class CaseWitnessVersion(models.Model):

    # Fields
    case = IntegerField(primary_key=True)
    witness = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casewitnessversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casewitnessversion_update', args=(self.pk,))


class Casecategory(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    indictable = NullBooleanField()
    is_criminal = NullBooleanField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecategory_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecategory_update', args=(self.pk,))


class CasecategoryVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    indictable = NullBooleanField()
    is_criminal = NullBooleanField()
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_casecategoryversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_casecategoryversion_update', args=(self.pk,))


class Caseinvestigation(models.Model):


    # Relationship Fields
    pol_officers = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='pol_officers', primary_key=True)
    cases = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='cases')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseinvestigation_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseinvestigation_update', args=(self.pk,))


class CaseinvestigationVersion(models.Model):

    # Fields
    pol_officers = IntegerField(primary_key=True)
    cases = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_caseinvestigationversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_caseinvestigationversion_update', args=(self.pk,))


class Causeofaction(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    criminal = BooleanField()

    # Relationship Fields
    parent_coa = ForeignKey('casemgmt.self', models.DO_NOTHING, db_column='parent_coa', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofaction_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofaction_update', args=(self.pk,))


class CauseofactionFiling(models.Model):


    # Relationship Fields
    causeofaction = ForeignKey('casemgmt.Causeofaction', models.DO_NOTHING, db_column='causeofaction', primary_key=True)
    filing = ForeignKey('casemgmt.Filing', models.DO_NOTHING, db_column='filing')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofactionfiling_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofactionfiling_update', args=(self.pk,))


class CauseofactionFilingVersion(models.Model):

    # Fields
    causeofaction = IntegerField(primary_key=True)
    filing = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofactionfilingversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofactionfilingversion_update', args=(self.pk,))


class CauseofactionHearing(models.Model):


    # Relationship Fields
    causeofaction = ForeignKey('casemgmt.Causeofaction', models.DO_NOTHING, db_column='causeofaction', primary_key=True)
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofactionhearing_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofactionhearing_update', args=(self.pk,))


class CauseofactionHearingVersion(models.Model):

    # Fields
    causeofaction = IntegerField(primary_key=True)
    hearing = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofactionhearingversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofactionhearingversion_update', args=(self.pk,))


class CauseofactionVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    criminal = NullBooleanField()
    parent_coa = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_causeofactionversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_causeofactionversion_update', args=(self.pk,))


class Commitaltype(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_commitaltype_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_commitaltype_update', args=(self.pk,))


class CommitaltypePrisoncommital(models.Model):

    # Fields
    prisoncommital_warrantno = CharField(max_length=100)

    # Relationship Fields
    commitaltype = ForeignKey('casemgmt.Commitaltype', models.DO_NOTHING, db_column='commitaltype', primary_key=True)
    prisoncommital_prison = ForeignKey('casemgmt.Prisoncommital', models.DO_NOTHING, db_column='prisoncommital_prison')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_commitaltypeprisoncommital_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_commitaltypeprisoncommital_update', args=(self.pk,))


class CommitaltypePrisoncommitalVersion(models.Model):

    # Fields
    commitaltype = IntegerField(primary_key=True)
    prisoncommital_prison = IntegerField()
    prisoncommital_warrantno = CharField(max_length=100)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_commitaltypeprisoncommitalversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_commitaltypeprisoncommitalversion_update', args=(self.pk,))


class CommitaltypeVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_commitaltypeversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_commitaltypeversion_update', args=(self.pk,))


class Constituency(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    county = ForeignKey('casemgmt.County', models.DO_NOTHING, db_column='county')
    town = ForeignKey('casemgmt.Town', models.DO_NOTHING, db_column='town', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_constituency_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_constituency_update', args=(self.pk,))


class ConstituencyVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    county = IntegerField(blank=True, null=True)
    town = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_constituencyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_constituencyversion_update', args=(self.pk,))


class County(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_county_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_county_update', args=(self.pk,))


class CountyVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_countyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_countyversion_update', args=(self.pk,))


class Court(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    court_station = ForeignKey('casemgmt.Courtstation', models.DO_NOTHING, db_column='court_station')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_court_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_court_update', args=(self.pk,))


class CourtVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    court_station = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_courtversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_courtversion_update', args=(self.pk,))


class Courtlevel(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_courtlevel_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_courtlevel_update', args=(self.pk,))


class CourtlevelVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_courtlevelversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_courtlevelversion_update', args=(self.pk,))


class Courtstation(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    residentmagistrate = CharField(max_length=100, blank=True, null=True)
    registrar = CharField(max_length=100)
    num_of_courts = IntegerField(blank=True, null=True)

    # Relationship Fields
    court_level = ForeignKey('casemgmt.Courtlevel', models.DO_NOTHING, db_column='court_level')
    town = ForeignKey('casemgmt.Town', models.DO_NOTHING, db_column='town')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_courtstation_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_courtstation_update', args=(self.pk,))


class CourtstationVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    id = IntegerField(primary_key=True)
    residentmagistrate = CharField(max_length=100, blank=True, null=True)
    registrar = CharField(max_length=100, blank=True, null=True)
    court_level = IntegerField(blank=True, null=True)
    num_of_courts = IntegerField(blank=True, null=True)
    town = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_courtstationversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_courtstationversion_update', args=(self.pk,))


class Defendant(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    allergies = TextField(blank=True, null=True)
    chronic_conditions = TextField(blank=True, null=True)
    chronic_medications = TextField(blank=True, null=True)
    hbp = NullBooleanField()
    diabetes = NullBooleanField()
    hiv = NullBooleanField()
    current_health_status = TextField(blank=True, null=True)
    bc_id = CharField(max_length=20, blank=True, null=True)
    bc_number = CharField(max_length=20, blank=True, null=True)
    bc_serial = CharField(max_length=20, blank=True, null=True)
    bc_place = CharField(max_length=20, blank=True, null=True)
    bc_scan = TextField(blank=True, null=True)
    citizenship = CharField(max_length=20, blank=True, null=True)
    nat_id_num = CharField(max_length=15, blank=True, null=True)
    nat_id_serial = CharField(max_length=30, blank=True, null=True)
    nat_id_scan = TextField(blank=True, null=True)
    pp_no = CharField(max_length=20, blank=True, null=True)
    pp_issue_date = DateField(blank=True, null=True)
    pp_issue_place = CharField(max_length=40, blank=True, null=True)
    pp_scan = TextField(blank=True, null=True)
    pp_expiry_date = DateField(blank=True, null=True)
    kin1_name = CharField(max_length=100, blank=True, null=True)
    kin1_phone = CharField(max_length=50, blank=True, null=True)
    kin1_email = CharField(max_length=125, blank=True, null=True)
    kin1_addr = TextField(blank=True, null=True)
    kin2_name = CharField(max_length=100, blank=True, null=True)
    kin1_relation = CharField(max_length=100, blank=True, null=True)
    kin2_phone = CharField(max_length=50, blank=True, null=True)
    kin2_email = CharField(max_length=125, blank=True, null=True)
    kin2_addr = TextField(blank=True, null=True)
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    blood_group = CharField(max_length=3, blank=True, null=True)
    striking_features = TextField(blank=True, null=True)
    height_m = FloatField(blank=True, null=True)
    weight_kg = FloatField(blank=True, null=True)
    eye_colour = CharField(max_length=20, blank=True, null=True)
    hair_colour = CharField(max_length=20, blank=True, null=True)
    complexion = CharField(max_length=50, blank=True, null=True)
    religion = CharField(max_length=20, blank=True, null=True)
    ethnicity = CharField(max_length=40, blank=True, null=True)
    fp_lthumb = TextField(blank=True, null=True)
    pgm = BinaryField(blank=True, null=True)
    wsq = BinaryField(blank=True, null=True)
    xyt = BinaryField(blank=True, null=True)
    fp_left2 = TextField(blank=True, null=True)
    fp_left3 = TextField(blank=True, null=True)
    fp_left4 = TextField(blank=True, null=True)
    fp_left5 = TextField(blank=True, null=True)
    fp_rthumb = TextField(blank=True, null=True)
    fp_right2 = TextField(blank=True, null=True)
    fp_right3 = TextField(blank=True, null=True)
    fp_right4 = TextField(blank=True, null=True)
    fp_right5 = TextField(blank=True, null=True)
    palm_left = TextField(blank=True, null=True)
    palm_right = TextField(blank=True, null=True)
    eye_left = TextField(blank=True, null=True)
    eye_right = TextField(blank=True, null=True)
    employed = NullBooleanField()
    employer = CharField(max_length=60, blank=True, null=True)
    employer_contact = TextField(blank=True, null=True)
    employ_date = DateField(blank=True, null=True)
    employ_duration = IntegerField(blank=True, null=True)
    termination_date = DateField(blank=True, null=True)
    employ_role = CharField(max_length=50, blank=True, null=True)
    supervisor = CharField(max_length=50, blank=True, null=True)
    supervisor_contact = TextField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    juvenile = NullBooleanField()
    casecount = IntegerField(blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender')
    prisoncell = ForeignKey('casemgmt.Prisoncell', models.DO_NOTHING, db_column='prisoncell', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendant_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendant_update', args=(self.pk,))


class DefendantGateregister(models.Model):


    # Relationship Fields
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant', primary_key=True)
    gateregister = ForeignKey('casemgmt.Gateregister', models.DO_NOTHING, db_column='gateregister')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendantgateregister_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendantgateregister_update', args=(self.pk,))


class DefendantGateregisterVersion(models.Model):

    # Fields
    defendant = IntegerField(primary_key=True)
    gateregister = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendantgateregisterversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendantgateregisterversion_update', args=(self.pk,))


class DefendantHearing(models.Model):


    # Relationship Fields
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant', primary_key=True)
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendanthearing_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendanthearing_update', args=(self.pk,))


class DefendantHearingVersion(models.Model):

    # Fields
    defendant = IntegerField(primary_key=True)
    hearing = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendanthearingversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendanthearingversion_update', args=(self.pk,))


class DefendantMedevent(models.Model):


    # Relationship Fields
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant', primary_key=True)
    medevent = ForeignKey('casemgmt.Medevent', models.DO_NOTHING, db_column='medevent')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendantmedevent_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendantmedevent_update', args=(self.pk,))


class DefendantMedeventVersion(models.Model):

    # Fields
    defendant = IntegerField(primary_key=True)
    medevent = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendantmedeventversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendantmedeventversion_update', args=(self.pk,))


class DefendantVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    allergies = TextField(blank=True, null=True)
    chronic_conditions = TextField(blank=True, null=True)
    chronic_medications = TextField(blank=True, null=True)
    hbp = NullBooleanField()
    diabetes = NullBooleanField()
    hiv = NullBooleanField()
    current_health_status = TextField(blank=True, null=True)
    bc_id = CharField(max_length=20, blank=True, null=True)
    bc_number = CharField(max_length=20, blank=True, null=True)
    bc_serial = CharField(max_length=20, blank=True, null=True)
    bc_place = CharField(max_length=20, blank=True, null=True)
    bc_scan = TextField(blank=True, null=True)
    citizenship = CharField(max_length=20, blank=True, null=True)
    nat_id_num = CharField(max_length=15, blank=True, null=True)
    nat_id_serial = CharField(max_length=30, blank=True, null=True)
    nat_id_scan = TextField(blank=True, null=True)
    pp_no = CharField(max_length=20, blank=True, null=True)
    pp_issue_date = DateField(blank=True, null=True)
    pp_issue_place = CharField(max_length=40, blank=True, null=True)
    pp_scan = TextField(blank=True, null=True)
    pp_expiry_date = DateField(blank=True, null=True)
    kin1_name = CharField(max_length=100, blank=True, null=True)
    kin1_phone = CharField(max_length=50, blank=True, null=True)
    kin1_email = CharField(max_length=125, blank=True, null=True)
    kin1_addr = TextField(blank=True, null=True)
    kin2_name = CharField(max_length=100, blank=True, null=True)
    kin1_relation = CharField(max_length=100, blank=True, null=True)
    kin2_phone = CharField(max_length=50, blank=True, null=True)
    kin2_email = CharField(max_length=125, blank=True, null=True)
    kin2_addr = TextField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    blood_group = CharField(max_length=3, blank=True, null=True)
    striking_features = TextField(blank=True, null=True)
    height_m = FloatField(blank=True, null=True)
    weight_kg = FloatField(blank=True, null=True)
    eye_colour = CharField(max_length=20, blank=True, null=True)
    hair_colour = CharField(max_length=20, blank=True, null=True)
    complexion = CharField(max_length=50, blank=True, null=True)
    religion = CharField(max_length=20, blank=True, null=True)
    ethnicity = CharField(max_length=40, blank=True, null=True)
    fp_lthumb = TextField(blank=True, null=True)
    pgm = BinaryField(blank=True, null=True)
    wsq = BinaryField(blank=True, null=True)
    xyt = BinaryField(blank=True, null=True)
    fp_left2 = TextField(blank=True, null=True)
    fp_left3 = TextField(blank=True, null=True)
    fp_left4 = TextField(blank=True, null=True)
    fp_left5 = TextField(blank=True, null=True)
    fp_rthumb = TextField(blank=True, null=True)
    fp_right2 = TextField(blank=True, null=True)
    fp_right3 = TextField(blank=True, null=True)
    fp_right4 = TextField(blank=True, null=True)
    fp_right5 = TextField(blank=True, null=True)
    palm_left = TextField(blank=True, null=True)
    palm_right = TextField(blank=True, null=True)
    eye_left = TextField(blank=True, null=True)
    eye_right = TextField(blank=True, null=True)
    employed = NullBooleanField()
    employer = CharField(max_length=60, blank=True, null=True)
    employer_contact = TextField(blank=True, null=True)
    employ_date = DateField(blank=True, null=True)
    employ_duration = IntegerField(blank=True, null=True)
    termination_date = DateField(blank=True, null=True)
    employ_role = CharField(max_length=50, blank=True, null=True)
    supervisor = CharField(max_length=50, blank=True, null=True)
    supervisor_contact = TextField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    juvenile = NullBooleanField()
    gender = IntegerField(blank=True, null=True)
    prisoncell = IntegerField(blank=True, null=True)
    casecount = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_defendantversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_defendantversion_update', args=(self.pk,))


class Discipline(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()

    # Relationship Fields
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_discipline_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_discipline_update', args=(self.pk,))


class DisciplineVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    id = IntegerField(primary_key=True)
    defendant = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_disciplineversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_disciplineversion_update', args=(self.pk,))


class DocStore(models.Model):

    # Fields
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    data = BinaryField(blank=True, null=True)


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_docstore_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_docstore_update', args=(self.pk,))


class Docarchive(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = TextField(blank=True, null=True)
    doc = TextField(blank=True, null=True)
    scandate = DateTimeField(blank=True, null=True)
    archival = NullBooleanField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_docarchive_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_docarchive_update', args=(self.pk,))


class DocarchiveTag(models.Model):


    # Relationship Fields
    docarchive = ForeignKey('casemgmt.Docarchive', models.DO_NOTHING, db_column='docarchive', primary_key=True)
    tag = ForeignKey('casemgmt.Tag', models.DO_NOTHING, db_column='tag')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_docarchivetag_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_docarchivetag_update', args=(self.pk,))


class DocarchiveTagVersion(models.Model):

    # Fields
    docarchive = IntegerField(primary_key=True)
    tag = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_docarchivetagversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_docarchivetagversion_update', args=(self.pk,))


class DocarchiveVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    name = TextField(blank=True, null=True)
    doc = TextField(blank=True, null=True)
    scandate = DateTimeField(blank=True, null=True)
    archival = NullBooleanField()
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_docarchiveversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_docarchiveversion_update', args=(self.pk,))


class Doctemplate(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    mime_type = CharField(max_length=60, blank=True, null=True)
    doc = TextField(blank=True, null=True)
    doc_text = TextField(blank=True, null=True)
    doc_binary = TextField(blank=True, null=True)
    doc_title = CharField(max_length=200, blank=True, null=True)
    subject = CharField(max_length=100, blank=True, null=True)
    author = CharField(max_length=100, blank=True, null=True)
    keywords = CharField(max_length=200, blank=True, null=True)
    comments = TextField(blank=True, null=True)
    doc_type = CharField(max_length=5, blank=True, null=True)
    char_count = IntegerField(blank=True, null=True)
    word_count = IntegerField(blank=True, null=True)
    lines = IntegerField(blank=True, null=True)
    paragraphs = IntegerField(blank=True, null=True)
    file_size_bytes = IntegerField(blank=True, null=True)
    producer_prog = CharField(max_length=40, blank=True, null=True)
    immutable = NullBooleanField()
    page_size = CharField(max_length=40, blank=True, null=True)
    page_count = IntegerField(blank=True, null=True)
    hashx = CharField(max_length=40, blank=True, null=True)
    audio_duration_secs = IntegerField(blank=True, null=True)
    audio_frame_rate = IntegerField(blank=True, null=True)
    audio_channels = IntegerField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_doctemplate_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_doctemplate_update', args=(self.pk,))


class DoctemplateVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    mime_type = CharField(max_length=60, blank=True, null=True)
    doc = TextField(blank=True, null=True)
    doc_text = TextField(blank=True, null=True)
    doc_binary = TextField(blank=True, null=True)
    doc_title = CharField(max_length=200, blank=True, null=True)
    subject = CharField(max_length=100, blank=True, null=True)
    author = CharField(max_length=100, blank=True, null=True)
    keywords = CharField(max_length=200, blank=True, null=True)
    comments = TextField(blank=True, null=True)
    doc_type = CharField(max_length=5, blank=True, null=True)
    char_count = IntegerField(blank=True, null=True)
    word_count = IntegerField(blank=True, null=True)
    lines = IntegerField(blank=True, null=True)
    paragraphs = IntegerField(blank=True, null=True)
    file_size_bytes = IntegerField(blank=True, null=True)
    producer_prog = CharField(max_length=40, blank=True, null=True)
    immutable = NullBooleanField()
    page_size = CharField(max_length=40, blank=True, null=True)
    page_count = IntegerField(blank=True, null=True)
    hashx = CharField(max_length=40, blank=True, null=True)
    audio_duration_secs = IntegerField(blank=True, null=True)
    audio_frame_rate = IntegerField(blank=True, null=True)
    audio_channels = IntegerField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_doctemplateversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_doctemplateversion_update', args=(self.pk,))


class Document(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    mime_type = CharField(max_length=60, blank=True, null=True)
    doc = TextField(blank=True, null=True)
    doc_text = TextField(blank=True, null=True)
    doc_binary = TextField(blank=True, null=True)
    doc_title = CharField(max_length=200, blank=True, null=True)
    subject = CharField(max_length=100, blank=True, null=True)
    author = CharField(max_length=100, blank=True, null=True)
    keywords = CharField(max_length=200, blank=True, null=True)
    comments = TextField(blank=True, null=True)
    doc_type = CharField(max_length=5, blank=True, null=True)
    char_count = IntegerField(blank=True, null=True)
    word_count = IntegerField(blank=True, null=True)
    lines = IntegerField(blank=True, null=True)
    paragraphs = IntegerField(blank=True, null=True)
    file_size_bytes = IntegerField(blank=True, null=True)
    producer_prog = CharField(max_length=40, blank=True, null=True)
    immutable = NullBooleanField()
    page_size = CharField(max_length=40, blank=True, null=True)
    page_count = IntegerField(blank=True, null=True)
    hashx = CharField(max_length=40, blank=True, null=True)
    audio_duration_secs = IntegerField(blank=True, null=True)
    audio_frame_rate = IntegerField(blank=True, null=True)
    audio_channels = IntegerField(blank=True, null=True)
    confidential = NullBooleanField()
    pagecount = IntegerField(blank=True, null=True)
    locked = NullBooleanField()
    hash = TextField(blank=True, null=True)

    # Relationship Fields
    filing = ForeignKey('casemgmt.Filing', models.DO_NOTHING, db_column='filing')
    doc_template = ForeignKey('casemgmt.Doctemplate', models.DO_NOTHING, db_column='doc_template', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_document_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_document_update', args=(self.pk,))


class DocumentTag(models.Model):


    # Relationship Fields
    document = ForeignKey('casemgmt.Document', models.DO_NOTHING, db_column='document', primary_key=True)
    tag = ForeignKey('casemgmt.Tag', models.DO_NOTHING, db_column='tag')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_documenttag_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_documenttag_update', args=(self.pk,))


class DocumentTagVersion(models.Model):

    # Fields
    document = IntegerField(primary_key=True)
    tag = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_documenttagversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_documenttagversion_update', args=(self.pk,))


class DocumentVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    mime_type = CharField(max_length=60, blank=True, null=True)
    doc = TextField(blank=True, null=True)
    doc_text = TextField(blank=True, null=True)
    doc_binary = TextField(blank=True, null=True)
    doc_title = CharField(max_length=200, blank=True, null=True)
    subject = CharField(max_length=100, blank=True, null=True)
    author = CharField(max_length=100, blank=True, null=True)
    keywords = CharField(max_length=200, blank=True, null=True)
    comments = TextField(blank=True, null=True)
    doc_type = CharField(max_length=5, blank=True, null=True)
    char_count = IntegerField(blank=True, null=True)
    word_count = IntegerField(blank=True, null=True)
    lines = IntegerField(blank=True, null=True)
    paragraphs = IntegerField(blank=True, null=True)
    file_size_bytes = IntegerField(blank=True, null=True)
    producer_prog = CharField(max_length=40, blank=True, null=True)
    immutable = NullBooleanField()
    page_size = CharField(max_length=40, blank=True, null=True)
    page_count = IntegerField(blank=True, null=True)
    hashx = CharField(max_length=40, blank=True, null=True)
    audio_duration_secs = IntegerField(blank=True, null=True)
    audio_frame_rate = IntegerField(blank=True, null=True)
    audio_channels = IntegerField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    filing = IntegerField(blank=True, null=True)
    doc_template = IntegerField(blank=True, null=True)
    confidential = NullBooleanField()
    pagecount = IntegerField(blank=True, null=True)
    locked = NullBooleanField()
    hash = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_documentversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_documentversion_update', args=(self.pk,))


class Eventlog(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    temporal = DateTimeField(blank=True, null=True)
    event = TextField(blank=True, null=True)
    severity = IntegerField(blank=True, null=True)
    alert = NullBooleanField()
    notes = TextField(blank=True, null=True)
    tbl = TextField(blank=True, null=True)
    colname = TextField(blank=True, null=True)
    colbefore = TextField(blank=True, null=True)
    colafter = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_eventlog_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_eventlog_update', args=(self.pk,))


class EventlogVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    temporal = DateTimeField(blank=True, null=True)
    event = TextField(blank=True, null=True)
    severity = IntegerField(blank=True, null=True)
    alert = NullBooleanField()
    notes = TextField(blank=True, null=True)
    tbl = TextField(blank=True, null=True)
    colname = TextField(blank=True, null=True)
    colbefore = TextField(blank=True, null=True)
    colafter = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_eventlogversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_eventlogversion_update', args=(self.pk,))


class Filing(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    uploaddate = DateTimeField(blank=True, null=True)
    pagecount = IntegerField(blank=True, null=True)
    totalfees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    assessedfees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    receiptverified = NullBooleanField()
    amountpaid = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    feebalance = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paymenthistory = TextField()
    urgent = NullBooleanField()
    urgentreason = TextField(blank=True, null=True)

    # Relationship Fields
    filing_attorney = ForeignKey('casemgmt.Lawyers', models.DO_NOTHING, db_column='filing_attorney')
    filing_prosecutor = ForeignKey('casemgmt.Prosecutor', models.DO_NOTHING, db_column='filing_prosecutor')
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filing_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filing_update', args=(self.pk,))


class FilingFilingtype(models.Model):


    # Relationship Fields
    filing = ForeignKey('casemgmt.Filing', models.DO_NOTHING, db_column='filing', primary_key=True)
    filingtype = ForeignKey('casemgmt.Filingtype', models.DO_NOTHING, db_column='filingtype')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingfilingtype_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingfilingtype_update', args=(self.pk,))


class FilingFilingtypeVersion(models.Model):

    # Fields
    filing = IntegerField(primary_key=True)
    filingtype = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingfilingtypeversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingfilingtypeversion_update', args=(self.pk,))


class FilingPayment(models.Model):


    # Relationship Fields
    filing = ForeignKey('casemgmt.Filing', models.DO_NOTHING, db_column='filing', primary_key=True)
    payment = ForeignKey('casemgmt.Payment', models.DO_NOTHING, db_column='payment')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingpayment_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingpayment_update', args=(self.pk,))


class FilingPaymentVersion(models.Model):

    # Fields
    filing = IntegerField(primary_key=True)
    payment = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingpaymentversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingpaymentversion_update', args=(self.pk,))


class FilingVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    uploaddate = DateTimeField(blank=True, null=True)
    pagecount = IntegerField(blank=True, null=True)
    totalfees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    filing_attorney = IntegerField(blank=True, null=True)
    filing_prosecutor = IntegerField(blank=True, null=True)
    assessedfees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    receiptverified = NullBooleanField()
    amountpaid = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    feebalance = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paymenthistory = TextField(blank=True, null=True)
    case = IntegerField(blank=True, null=True)
    urgent = NullBooleanField()
    urgentreason = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingversion_update', args=(self.pk,))


class Filingtype(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    fees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    perpagecost = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paid_per_page = NullBooleanField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingtype_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingtype_update', args=(self.pk,))


class FilingtypeVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    fees = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    perpagecost = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paid_per_page = NullBooleanField()
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_filingtypeversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_filingtypeversion_update', args=(self.pk,))


class Gateregister(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    opentime = DateTimeField(blank=True, null=True)
    closedtime = DateTimeField(blank=True, null=True)
    movementdirection = NullBooleanField()
    reason = TextField(blank=True, null=True)
    staffmovement = NullBooleanField()
    goodsmovement = TextField()
    vehicle_reg = TextField(blank=True, null=True)
    vehicle_color = TextField()

    # Relationship Fields
    prison = ForeignKey('casemgmt.Prison', models.DO_NOTHING, db_column='prison')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregister_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregister_update', args=(self.pk,))


class GateregisterVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    prison = IntegerField(blank=True, null=True)
    opentime = DateTimeField(blank=True, null=True)
    closedtime = DateTimeField(blank=True, null=True)
    movementdirection = NullBooleanField()
    reason = TextField(blank=True, null=True)
    staffmovement = NullBooleanField()
    goodsmovement = TextField(blank=True, null=True)
    vehicle_reg = TextField(blank=True, null=True)
    vehicle_color = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregisterversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregisterversion_update', args=(self.pk,))


class GateregisterWarder(models.Model):


    # Relationship Fields
    gateregister = ForeignKey('casemgmt.Gateregister', models.DO_NOTHING, db_column='gateregister', primary_key=True)
    warder = ForeignKey('casemgmt.Warder', models.DO_NOTHING, db_column='warder')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregisterwarder_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregisterwarder_update', args=(self.pk,))


class GateregisterWarder2(models.Model):


    # Relationship Fields
    gateregister = ForeignKey('casemgmt.Gateregister', models.DO_NOTHING, db_column='gateregister', primary_key=True)
    warder = ForeignKey('casemgmt.Warder', models.DO_NOTHING, db_column='warder')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregisterwarder2_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregisterwarder2_update', args=(self.pk,))


class GateregisterWarder2Version(models.Model):

    # Fields
    gateregister = IntegerField(primary_key=True)
    warder = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregisterwarder2version_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregisterwarder2version_update', args=(self.pk,))


class GateregisterWarderVersion(models.Model):

    # Fields
    gateregister = IntegerField(primary_key=True)
    warder = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gateregisterwarderversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gateregisterwarderversion_update', args=(self.pk,))


class Gender(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    name = CharField(unique=True, max_length=20)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_gender_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_gender_update', args=(self.pk,))


class GenderVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    name = CharField(max_length=20, blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_genderversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_genderversion_update', args=(self.pk,))


class Hearing(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    hearingdate = DateTimeField()
    adjourned = NullBooleanField()
    completed = NullBooleanField()
    remandwarrant = TextField(blank=True, null=True)
    remanddays = IntegerField(blank=True, null=True)
    remanddate = DateField(blank=True, null=True)
    remandwarrantexpirydate = DateField(blank=True, null=True)
    nexthearingdate = DateField(blank=True, null=True)
    finalhearing = BooleanField()
    transcript = TextField(blank=True, null=True)
    audio = TextField(blank=True, null=True)
    video = TextField(blank=True, null=True)

    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case')
    court = ForeignKey('casemgmt.Court', models.DO_NOTHING, db_column='court')
    hearing_type = ForeignKey('casemgmt.Hearingtype', models.DO_NOTHING, db_column='hearing_type')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearing_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearing_update', args=(self.pk,))


class HearingJudicialofficer(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    judicialofficer = ForeignKey('casemgmt.Judicialofficer', models.DO_NOTHING, db_column='judicialofficer')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingjudicialofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingjudicialofficer_update', args=(self.pk,))


class HearingJudicialofficerVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    judicialofficer = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingjudicialofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingjudicialofficerversion_update', args=(self.pk,))


class HearingLawyers(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    lawyers = ForeignKey('casemgmt.Lawyers', models.DO_NOTHING, db_column='lawyers')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearinglawyers_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearinglawyers_update', args=(self.pk,))


class HearingLawyersVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    lawyers = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearinglawyersversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearinglawyersversion_update', args=(self.pk,))


class HearingPolofficer(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    polofficer = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='polofficer')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingpolofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingpolofficer_update', args=(self.pk,))


class HearingPolofficerVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    polofficer = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingpolofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingpolofficerversion_update', args=(self.pk,))


class HearingProsecutor(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    prosecutor = ForeignKey('casemgmt.Prosecutor', models.DO_NOTHING, db_column='prosecutor')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingprosecutor_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingprosecutor_update', args=(self.pk,))


class HearingProsecutorVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    prosecutor = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingprosecutorversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingprosecutorversion_update', args=(self.pk,))


class HearingTag(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    tag = ForeignKey('casemgmt.Tag', models.DO_NOTHING, db_column='tag')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingtag_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingtag_update', args=(self.pk,))


class HearingTagVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    tag = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingtagversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingtagversion_update', args=(self.pk,))


class HearingVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    id = IntegerField(primary_key=True)
    hearingdate = DateTimeField(blank=True, null=True)
    adjourned = NullBooleanField()
    completed = NullBooleanField()
    case = IntegerField(blank=True, null=True)
    court = IntegerField(blank=True, null=True)
    remandwarrant = TextField(blank=True, null=True)
    hearing_type = IntegerField(blank=True, null=True)
    remanddays = IntegerField(blank=True, null=True)
    remanddate = DateField(blank=True, null=True)
    remandwarrantexpirydate = DateField(blank=True, null=True)
    nexthearingdate = DateField(blank=True, null=True)
    finalhearing = NullBooleanField()
    transcript = TextField(blank=True, null=True)
    audio = TextField(blank=True, null=True)
    video = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingversion_update', args=(self.pk,))


class HearingWitness(models.Model):


    # Relationship Fields
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing', primary_key=True)
    witness = ForeignKey('casemgmt.Witness', models.DO_NOTHING, db_column='witness')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingwitness_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingwitness_update', args=(self.pk,))


class HearingWitnessVersion(models.Model):

    # Fields
    hearing = IntegerField(primary_key=True)
    witness = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingwitnessversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingwitnessversion_update', args=(self.pk,))


class Hearingtype(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingtype_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingtype_update', args=(self.pk,))


class HearingtypeVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_hearingtypeversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_hearingtypeversion_update', args=(self.pk,))


class Investigation(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    actiondate = DateTimeField(blank=True, null=True)
    evidence = TextField()
    narrative = TextField()
    weather = TextField()
    location = TextField()

    # Relationship Fields
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigation_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigation_update', args=(self.pk,))


class InvestigationPolofficer(models.Model):


    # Relationship Fields
    investigation = ForeignKey('casemgmt.Investigation', models.DO_NOTHING, db_column='investigation', primary_key=True)
    polofficer = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='polofficer')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigationpolofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigationpolofficer_update', args=(self.pk,))


class InvestigationPolofficerVersion(models.Model):

    # Fields
    investigation = IntegerField(primary_key=True)
    polofficer = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigationpolofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigationpolofficerversion_update', args=(self.pk,))


class InvestigationVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    id = IntegerField(primary_key=True)
    case = IntegerField(blank=True, null=True)
    actiondate = DateTimeField(blank=True, null=True)
    evidence = TextField(blank=True, null=True)
    narrative = TextField(blank=True, null=True)
    weather = TextField(blank=True, null=True)
    location = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigationversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigationversion_update', args=(self.pk,))


class InvestigationWitness(models.Model):


    # Relationship Fields
    investigation = ForeignKey('casemgmt.Investigation', models.DO_NOTHING, db_column='investigation', primary_key=True)
    witness = ForeignKey('casemgmt.Witness', models.DO_NOTHING, db_column='witness')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigationwitness_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigationwitness_update', args=(self.pk,))


class InvestigationWitnessVersion(models.Model):

    # Fields
    investigation = IntegerField(primary_key=True)
    witness = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_investigationwitnessversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_investigationwitnessversion_update', args=(self.pk,))


class JoRank(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    appelation = TextField()
    informaladdress = TextField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_jorank_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_jorank_update', args=(self.pk,))


class JoRankVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    appelation = TextField(blank=True, null=True)
    informaladdress = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_jorankversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_jorankversion_update', args=(self.pk,))


class Judicialofficer(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender', blank=True, null=True)
    court = ForeignKey('casemgmt.Court', models.DO_NOTHING, db_column='court')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_judicialofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_judicialofficer_update', args=(self.pk,))


class JudicialofficerVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    court = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_judicialofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_judicialofficerversion_update', args=(self.pk,))


class Lawfirm(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_lawfirm_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_lawfirm_update', args=(self.pk,))


class LawfirmVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_lawfirmversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_lawfirmversion_update', args=(self.pk,))


class Lawyers(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    barnumber = CharField(max_length=20, blank=True, null=True)
    admissiondate = DateField(blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender', blank=True, null=True)
    law_firm = ForeignKey('casemgmt.Lawfirm', models.DO_NOTHING, db_column='law_firm', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_lawyers_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_lawyers_update', args=(self.pk,))


class LawyersVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    barnumber = CharField(max_length=20, blank=True, null=True)
    law_firm = IntegerField(blank=True, null=True)
    admissiondate = DateField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_lawyersversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_lawyersversion_update', args=(self.pk,))


class Medevent(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_medevent_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_medevent_update', args=(self.pk,))


class MedeventVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_medeventversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_medeventversion_update', args=(self.pk,))


class Natureofsuit(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_natureofsuit_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_natureofsuit_update', args=(self.pk,))


class NatureofsuitVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_natureofsuitversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_natureofsuitversion_update', args=(self.pk,))


class Payment(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    datepaid = DateTimeField(blank=True, null=True)
    amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paymentreference = CharField(max_length=80)
    paymentconfirmed = NullBooleanField()
    paidby = TextField()
    msisdn = TextField(blank=True, null=True)
    receiptnumber = CharField(max_length=100)
    ispartial = NullBooleanField()
    billrefnumber = TextField()
    paymentdescription = TextField()

    # Relationship Fields
    bail = ForeignKey('casemgmt.Bail', models.DO_NOTHING, db_column='bail')
    payment_method = ForeignKey('casemgmt.Paymentmethod', models.DO_NOTHING, db_column='payment_method')
    case = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='case', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_payment_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_payment_update', args=(self.pk,))


class PaymentVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    datepaid = DateTimeField(blank=True, null=True)
    amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    paymentreference = CharField(max_length=80, blank=True, null=True)
    paymentconfirmed = NullBooleanField()
    paidby = TextField(blank=True, null=True)
    msisdn = TextField(blank=True, null=True)
    receiptnumber = CharField(max_length=100, blank=True, null=True)
    ispartial = NullBooleanField()
    bail = IntegerField(blank=True, null=True)
    billrefnumber = TextField(blank=True, null=True)
    payment_method = IntegerField(blank=True, null=True)
    paymentdescription = TextField(blank=True, null=True)
    case = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_paymentversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_paymentversion_update', args=(self.pk,))


class Paymentmethod(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    key = TextField()
    secret = TextField()
    portal = TextField()
    tillnumber = TextField()
    shortcode = TextField()

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_paymentmethod_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_paymentmethod_update', args=(self.pk,))


class PaymentmethodVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    key = TextField(blank=True, null=True)
    secret = TextField(blank=True, null=True)
    portal = TextField(blank=True, null=True)
    tillnumber = TextField(blank=True, null=True)
    shortcode = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_paymentmethodversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_paymentmethodversion_update', args=(self.pk,))


class Plaintiff(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    juvenile = NullBooleanField()

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_plaintiff_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_plaintiff_update', args=(self.pk,))


class PlaintiffVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    juvenile = NullBooleanField()
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_plaintiffversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_plaintiffversion_update', args=(self.pk,))


class Policerank(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policerank_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policerank_update', args=(self.pk,))


class PolicerankVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policerankversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policerankversion_update', args=(self.pk,))


class Policerole(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policerole_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policerole_update', args=(self.pk,))


class PoliceroleVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policeroleversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policeroleversion_update', args=(self.pk,))


class Policestation(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    has_forensic_lab = NullBooleanField()
    officercommanding = CharField(max_length=100, blank=True, null=True)

    # Relationship Fields
    town = ForeignKey('casemgmt.Town', models.DO_NOTHING, db_column='town')
    police_station_type = ForeignKey('casemgmt.Policestationtype', models.DO_NOTHING, db_column='police_station_type')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policestation_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policestation_update', args=(self.pk,))


class PolicestationVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    id = IntegerField(primary_key=True)
    town = IntegerField(blank=True, null=True)
    has_forensic_lab = NullBooleanField()
    officercommanding = CharField(max_length=100, blank=True, null=True)
    police_station_type = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policestationversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policestationversion_update', args=(self.pk,))


class Policestationtype(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policestationtype_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policestationtype_update', args=(self.pk,))


class PolicestationtypeVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_policestationtypeversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_policestationtypeversion_update', args=(self.pk,))


class Polofficer(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    servicenumber = TextField(blank=True, null=True)
    postdate = DateField(blank=True, null=True)

    # Relationship Fields
    police_rank = ForeignKey('casemgmt.Policerank', models.DO_NOTHING, db_column='police_rank')
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender')
    reports_to = ForeignKey('casemgmt.self', models.DO_NOTHING, db_column='reports_to', blank=True, null=True)
    pol_supervisor = ForeignKey('casemgmt.Case', models.DO_NOTHING, db_column='pol_supervisor')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_polofficer_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_polofficer_update', args=(self.pk,))


class PolofficerPolicerole(models.Model):


    # Relationship Fields
    polofficer = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='polofficer', primary_key=True)
    policerole = ForeignKey('casemgmt.Policerole', models.DO_NOTHING, db_column='policerole')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_polofficerpolicerole_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_polofficerpolicerole_update', args=(self.pk,))


class PolofficerPoliceroleVersion(models.Model):

    # Fields
    polofficer = IntegerField(primary_key=True)
    policerole = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_polofficerpoliceroleversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_polofficerpoliceroleversion_update', args=(self.pk,))


class PolofficerVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    police_rank = IntegerField(blank=True, null=True)
    gender = IntegerField(blank=True, null=True)
    servicenumber = TextField(blank=True, null=True)
    reports_to = IntegerField(blank=True, null=True)
    pol_supervisor = IntegerField(blank=True, null=True)
    postdate = DateField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_polofficerversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_polofficerversion_update', args=(self.pk,))


class Prison(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    warden = CharField(max_length=100, blank=True, null=True)
    capacity = IntegerField(blank=True, null=True)
    population = IntegerField(blank=True, null=True)
    cellcount = IntegerField(blank=True, null=True)
    gatecount = IntegerField(blank=True, null=True)

    # Relationship Fields
    town = ForeignKey('casemgmt.Town', models.DO_NOTHING, db_column='town')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prison_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prison_update', args=(self.pk,))


class PrisonSecurityrank(models.Model):


    # Relationship Fields
    prison = ForeignKey('casemgmt.Prison', models.DO_NOTHING, db_column='prison', primary_key=True)
    securityrank = ForeignKey('casemgmt.Securityrank', models.DO_NOTHING, db_column='securityrank')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisonsecurityrank_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisonsecurityrank_update', args=(self.pk,))


class PrisonSecurityrankVersion(models.Model):

    # Fields
    prison = IntegerField(primary_key=True)
    securityrank = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisonsecurityrankversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisonsecurityrankversion_update', args=(self.pk,))


class PrisonVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    place_name = CharField(max_length=40, blank=True, null=True)
    lat = FloatField(blank=True, null=True)
    lng = FloatField(blank=True, null=True)
    alt = FloatField(blank=True, null=True)
    map = TextField(blank=True, null=True)
    info = TextField(blank=True, null=True)
    pin = NullBooleanField()
    pin_color = CharField(max_length=20, blank=True, null=True)
    pin_icon = CharField(max_length=50, blank=True, null=True)
    centered = NullBooleanField()
    nearest_feature = CharField(max_length=100, blank=True, null=True)
    id = IntegerField(primary_key=True)
    town = IntegerField(blank=True, null=True)
    warden = CharField(max_length=100, blank=True, null=True)
    capacity = IntegerField(blank=True, null=True)
    population = IntegerField(blank=True, null=True)
    cellcount = IntegerField(blank=True, null=True)
    gatecount = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisonversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisonversion_update', args=(self.pk,))


class Prisoncell(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()

    # Relationship Fields
    prison = ForeignKey('casemgmt.Prison', models.DO_NOTHING, db_column='prison')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncell_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncell_update', args=(self.pk,))


class PrisoncellVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    prison = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncellversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncellversion_update', args=(self.pk,))


class Prisoncommital(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    warrantno = CharField(max_length=100)
    warrantdate = DateTimeField(blank=True, null=True)
    hascourtdate = NullBooleanField()
    warrant = TextField()
    warrantduration = IntegerField()
    warrantexpiry = DateTimeField(blank=True, null=True)
    history = TextField()
    earliestrelease = DateField(blank=True, null=True)
    releasedate = DateTimeField(blank=True, null=True)
    property = TextField(blank=True, null=True)
    itemcount = IntegerField(blank=True, null=True)
    releasenotes = TextField(blank=True, null=True)
    commitalnotes = TextField(blank=True, null=True)
    paroledate = DateField(blank=True, null=True)
    escaped = NullBooleanField()
    escapedate = DateTimeField(blank=True, null=True)
    escapedetails = TextField(blank=True, null=True)

    # Relationship Fields
    prison = ForeignKey('casemgmt.Prison', models.DO_NOTHING, db_column='prison', primary_key=True)
    defendant = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendant')
    hearing = ForeignKey('casemgmt.Hearing', models.DO_NOTHING, db_column='hearing')
    judicial_officer_warrant = ForeignKey('casemgmt.Judicialofficer', models.DO_NOTHING, db_column='judicial_officer_warrant')
    police_officer_commiting = ForeignKey('casemgmt.Polofficer', models.DO_NOTHING, db_column='police_officer_commiting')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncommital_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncommital_update', args=(self.pk,))


class PrisoncommitalVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    prison = IntegerField(primary_key=True)
    warrantno = CharField(max_length=100)
    defendant = IntegerField(blank=True, null=True)
    hearing = IntegerField(blank=True, null=True)
    warrantdate = DateTimeField(blank=True, null=True)
    hascourtdate = NullBooleanField()
    judicial_officer_warrant = IntegerField(blank=True, null=True)
    warrant = TextField(blank=True, null=True)
    warrantduration = IntegerField(blank=True, null=True)
    warrantexpiry = DateTimeField(blank=True, null=True)
    history = TextField(blank=True, null=True)
    earliestrelease = DateField(blank=True, null=True)
    releasedate = DateTimeField(blank=True, null=True)
    property = TextField(blank=True, null=True)
    itemcount = IntegerField(blank=True, null=True)
    releasenotes = TextField(blank=True, null=True)
    commitalnotes = TextField(blank=True, null=True)
    police_officer_commiting = IntegerField(blank=True, null=True)
    paroledate = DateField(blank=True, null=True)
    escaped = NullBooleanField()
    escapedate = DateTimeField(blank=True, null=True)
    escapedetails = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncommitalversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncommitalversion_update', args=(self.pk,))


class PrisoncommitalWarder(models.Model):

    # Fields
    prisoncommital_warrantno = CharField(max_length=100)

    # Relationship Fields
    prisoncommital_prison = ForeignKey('casemgmt.Prisoncommital', models.DO_NOTHING, db_column='prisoncommital_prison', primary_key=True)
    warder = ForeignKey('casemgmt.Warder', models.DO_NOTHING, db_column='warder')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncommitalwarder_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncommitalwarder_update', args=(self.pk,))


class PrisoncommitalWarderVersion(models.Model):

    # Fields
    prisoncommital_prison = IntegerField(primary_key=True)
    prisoncommital_warrantno = CharField(max_length=100)
    warder = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisoncommitalwarderversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisoncommitalwarderversion_update', args=(self.pk,))


class Prisonerproperty(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    prison_commital_warrantno = CharField(max_length=100)
    receipted = NullBooleanField()

    # Relationship Fields
    prison_commital_prison = ForeignKey('casemgmt.Prisoncommital', models.DO_NOTHING, db_column='prison_commital_prison')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisonerproperty_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisonerproperty_update', args=(self.pk,))


class PrisonerpropertyVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    prison_commital_prison = IntegerField(blank=True, null=True)
    prison_commital_warrantno = CharField(max_length=100, blank=True, null=True)
    receipted = NullBooleanField()
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prisonerpropertyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prisonerpropertyversion_update', args=(self.pk,))


class Prosecutor(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutor_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutor_update', args=(self.pk,))


class ProsecutorProsecutorteam(models.Model):


    # Relationship Fields
    prosecutor = ForeignKey('casemgmt.Prosecutor', models.DO_NOTHING, db_column='prosecutor', primary_key=True)
    prosecutorteam = ForeignKey('casemgmt.Prosecutorteam', models.DO_NOTHING, db_column='prosecutorteam')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutorprosecutorteam_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutorprosecutorteam_update', args=(self.pk,))


class ProsecutorProsecutorteamVersion(models.Model):

    # Fields
    prosecutor = IntegerField(primary_key=True)
    prosecutorteam = IntegerField()
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutorprosecutorteamversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutorprosecutorteamversion_update', args=(self.pk,))


class ProsecutorVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutorversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutorversion_update', args=(self.pk,))


class Prosecutorteam(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutorteam_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutorteam_update', args=(self.pk,))


class ProsecutorteamVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_prosecutorteamversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_prosecutorteamversion_update', args=(self.pk,))


class Remission(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    prison_commital_warrantno = CharField(max_length=100)
    daysearned = IntegerField(blank=True, null=True)
    dateearned = DateField(blank=True, null=True)
    amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)

    # Relationship Fields
    prison_commital_prison = ForeignKey('casemgmt.Prisoncommital', models.DO_NOTHING, db_column='prison_commital_prison')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_remission_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_remission_update', args=(self.pk,))


class RemissionVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    prison_commital_prison = IntegerField(blank=True, null=True)
    prison_commital_warrantno = CharField(max_length=100, blank=True, null=True)
    daysearned = IntegerField(blank=True, null=True)
    dateearned = DateField(blank=True, null=True)
    amount = DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_remissionversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_remissionversion_update', args=(self.pk,))


class Securityrank(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_securityrank_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_securityrank_update', args=(self.pk,))


class SecurityrankVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_securityrankversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_securityrankversion_update', args=(self.pk,))


class Subcounty(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    county = ForeignKey('casemgmt.County', models.DO_NOTHING, db_column='county')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_subcounty_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_subcounty_update', args=(self.pk,))


class SubcountyVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    county = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_subcountyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_subcountyversion_update', args=(self.pk,))


class Surety(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_surety_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_surety_update', args=(self.pk,))


class SuretyVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_suretyversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_suretyversion_update', args=(self.pk,))


class Tag(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_tag_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_tag_update', args=(self.pk,))


class TagVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_tagversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_tagversion_update', args=(self.pk,))


class Town(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    subcounty = ForeignKey('casemgmt.Subcounty', models.DO_NOTHING, db_column='subcounty')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_town_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_town_update', args=(self.pk,))


class TownVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    subcounty = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_townversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_townversion_update', args=(self.pk,))


class Transaction(models.Model):

    # Fields
    issued_at = DateTimeField(blank=True, null=True)
    id = BigIntegerField(primary_key=True)
    remote_addr = CharField(max_length=50, blank=True, null=True)

    # Relationship Fields
    user = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, blank=True, null=True)

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_transaction_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_transaction_update', args=(self.pk,))


class Visit(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    visitdate = DateTimeField(blank=True, null=True)
    visitnotes = TextField(blank=True, null=True)

    # Relationship Fields
    vistors = ForeignKey('casemgmt.Visitor', models.DO_NOTHING, db_column='vistors', primary_key=True)
    defendants = ForeignKey('casemgmt.Defendant', models.DO_NOTHING, db_column='defendants')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_visit_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_visit_update', args=(self.pk,))


class VisitVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    priority = IntegerField(blank=True, null=True)
    segment = IntegerField(blank=True, null=True)
    task_group = IntegerField(blank=True, null=True)
    sequence = IntegerField(blank=True, null=True)
    action = CharField(max_length=40, blank=True, null=True)
    activity_description = TextField(blank=True, null=True)
    goal = TextField(blank=True, null=True)
    status = CharField(max_length=40, blank=True, null=True)
    planned_start = DateField(blank=True, null=True)
    actual_start = DateField(blank=True, null=True)
    start_notes = CharField(max_length=100, blank=True, null=True)
    planned_end = DateField(blank=True, null=True)
    actual_end = DateTimeField(blank=True, null=True)
    end_notes = CharField(max_length=100, blank=True, null=True)
    deadline = DateField(blank=True, null=True)
    not_started = NullBooleanField()
    early_start = NullBooleanField()
    late_start = NullBooleanField()
    completed = NullBooleanField()
    early_end = NullBooleanField()
    late_end = NullBooleanField()
    deviation_expected = NullBooleanField()
    contingency_plan = TextField(blank=True, null=True)
    budget = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    spend_td = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    balance_avail = DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    over_budget = NullBooleanField()
    under_budget = NullBooleanField()
    vistors = IntegerField(primary_key=True)
    defendants = IntegerField()
    visitdate = DateTimeField(blank=True, null=True)
    visitnotes = TextField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_visitversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_visitversion_update', args=(self.pk,))


class Visitor(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_visitor_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_visitor_update', args=(self.pk,))


class VisitorVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    gender = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_visitorversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_visitorversion_update', args=(self.pk,))


class Warder(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)

    # Relationship Fields
    prison = ForeignKey('casemgmt.Prison', models.DO_NOTHING, db_column='prison')
    warder_rank = ForeignKey('casemgmt.Warderrank', models.DO_NOTHING, db_column='warder_rank')
    reports_to = ForeignKey('casemgmt.self', models.DO_NOTHING, db_column='reports_to', blank=True, null=True)
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_warder_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_warder_update', args=(self.pk,))


class WarderVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    prison = IntegerField(blank=True, null=True)
    warder_rank = IntegerField(blank=True, null=True)
    reports_to = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_warderversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_warderversion_update', args=(self.pk,))


class Warderrank(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    name = CharField(unique=True, max_length=100)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)

    # Relationship Fields
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_warderrank_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_warderrank_update', args=(self.pk,))


class WarderrankVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    name = CharField(max_length=100, blank=True, null=True)
    description = CharField(max_length=100, blank=True, null=True)
    notes = TextField(blank=True, null=True)
    id = IntegerField(primary_key=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_warderrankversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_warderrankversion_update', args=(self.pk,))


class Witness(models.Model):

    # Fields
    created_on = DateTimeField()
    changed_on = DateTimeField()
    firstname = CharField(max_length=40)
    surname = CharField(max_length=40)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    fordefense = NullBooleanField()

    # Relationship Fields
    gender = ForeignKey('casemgmt.Gender', models.DO_NOTHING, db_column='gender')
    changed_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='changed_by_fk')
    created_by_fk = ForeignKey('casemgmt.AbUser', models.DO_NOTHING, db_column='created_by_fk')

    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_witness_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_witness_update', args=(self.pk,))


class WitnessVersion(models.Model):

    # Fields
    created_on = DateTimeField(blank=True, null=True)
    changed_on = DateTimeField(blank=True, null=True)
    firstname = CharField(max_length=40, blank=True, null=True)
    surname = CharField(max_length=40, blank=True, null=True)
    othernames = CharField(max_length=40, blank=True, null=True)
    dob = DateField(blank=True, null=True)
    marital_status = CharField(max_length=10, blank=True, null=True)
    photo = TextField(blank=True, null=True)
    age_today = IntegerField(blank=True, null=True)
    mobile = CharField(max_length=30, blank=True, null=True)
    other_mobile = CharField(max_length=30, blank=True, null=True)
    fixed_line = CharField(max_length=30, blank=True, null=True)
    other_fixed_line = CharField(max_length=20, blank=True, null=True)
    email = CharField(max_length=60, blank=True, null=True)
    other_email = CharField(max_length=60, blank=True, null=True)
    address_line_1 = CharField(max_length=200, blank=True, null=True)
    address_line_2 = CharField(max_length=200, blank=True, null=True)
    zipcode = CharField(max_length=30, blank=True, null=True)
    town = CharField(max_length=40, blank=True, null=True)
    country = CharField(max_length=50, blank=True, null=True)
    facebook = CharField(max_length=40, blank=True, null=True)
    twitter = CharField(max_length=40, blank=True, null=True)
    instagram = CharField(max_length=40, blank=True, null=True)
    whatsapp = NullBooleanField()
    other_whatsapp = NullBooleanField()
    fax = CharField(max_length=30, blank=True, null=True)
    gcode = CharField(max_length=40, blank=True, null=True)
    okhi = CharField(max_length=40, blank=True, null=True)
    id = IntegerField(primary_key=True)
    fordefense = NullBooleanField()
    gender = IntegerField(blank=True, null=True)
    changed_by_fk = IntegerField(blank=True, null=True)
    created_by_fk = IntegerField(blank=True, null=True)
    transaction_id = BigIntegerField()
    end_transaction_id = BigIntegerField(blank=True, null=True)
    operation_type = SmallIntegerField()


    class Meta:
        ordering = ('-pk',)

    def __unicode__(self):
        return u'%s' % self.pk

    def get_absolute_url(self):
        return reverse('casemgmt_witnessversion_detail', args=(self.pk,))


    def get_update_url(self):
        return reverse('casemgmt_witnessversion_update', args=(self.pk,))


