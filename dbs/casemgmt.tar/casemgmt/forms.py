from django import forms
from .models import Bail, BailSurety, BailSuretyVersion, BailVersion, Case, CaseCasecategory, CaseCasecategoryVersion, CaseCauseofaction, CaseCauseofactionVersion, CaseDefendant, CaseDefendantVersion, CaseNatureofsuit, CaseNatureofsuitVersion, CasePlaintiff, CasePlaintiffVersion, CasePolofficer, CasePolofficerVersion, CaseProsecutor, CaseProsecutor2, CaseProsecutor2Version, CaseProsecutorVersion, CaseTag, CaseTagVersion, CaseVersion, CaseWitness, CaseWitnessVersion, Casecategory, CasecategoryVersion, Caseinvestigation, CaseinvestigationVersion, Causeofaction, CauseofactionFiling, CauseofactionFilingVersion, CauseofactionHearing, CauseofactionHearingVersion, CauseofactionVersion, Commitaltype, CommitaltypePrisoncommital, CommitaltypePrisoncommitalVersion, CommitaltypeVersion, Constituency, ConstituencyVersion, County, CountyVersion, Court, CourtVersion, Courtlevel, CourtlevelVersion, Courtstation, CourtstationVersion, Defendant, DefendantGateregister, DefendantGateregisterVersion, DefendantHearing, DefendantHearingVersion, DefendantMedevent, DefendantMedeventVersion, DefendantVersion, Discipline, DisciplineVersion, DocStore, Docarchive, DocarchiveTag, DocarchiveTagVersion, DocarchiveVersion, Doctemplate, DoctemplateVersion, Document, DocumentTag, DocumentTagVersion, DocumentVersion, Eventlog, EventlogVersion, Filing, FilingFilingtype, FilingFilingtypeVersion, FilingPayment, FilingPaymentVersion, FilingVersion, Filingtype, FilingtypeVersion, Gateregister, GateregisterVersion, GateregisterWarder, GateregisterWarder2, GateregisterWarder2Version, GateregisterWarderVersion, Gender, GenderVersion, Hearing, HearingJudicialofficer, HearingJudicialofficerVersion, HearingLawyers, HearingLawyersVersion, HearingPolofficer, HearingPolofficerVersion, HearingProsecutor, HearingProsecutorVersion, HearingTag, HearingTagVersion, HearingVersion, HearingWitness, HearingWitnessVersion, Hearingtype, HearingtypeVersion, Investigation, InvestigationPolofficer, InvestigationPolofficerVersion, InvestigationVersion, InvestigationWitness, InvestigationWitnessVersion, JoRank, JoRankVersion, Judicialofficer, JudicialofficerVersion, Lawfirm, LawfirmVersion, Lawyers, LawyersVersion, Medevent, MedeventVersion, Natureofsuit, NatureofsuitVersion, Payment, PaymentVersion, Paymentmethod, PaymentmethodVersion, Plaintiff, PlaintiffVersion, Policerank, PolicerankVersion, Policerole, PoliceroleVersion, Policestation, PolicestationVersion, Policestationtype, PolicestationtypeVersion, Polofficer, PolofficerPolicerole, PolofficerPoliceroleVersion, PolofficerVersion, Prison, PrisonSecurityrank, PrisonSecurityrankVersion, PrisonVersion, Prisoncell, PrisoncellVersion, Prisoncommital, PrisoncommitalVersion, PrisoncommitalWarder, PrisoncommitalWarderVersion, Prisonerproperty, PrisonerpropertyVersion, Prosecutor, ProsecutorProsecutorteam, ProsecutorProsecutorteamVersion, ProsecutorVersion, Prosecutorteam, ProsecutorteamVersion, Remission, RemissionVersion, Securityrank, SecurityrankVersion, Subcounty, SubcountyVersion, Surety, SuretyVersion, Tag, TagVersion, Town, TownVersion, Transaction, Visit, VisitVersion, Visitor, VisitorVersion, Warder, WarderVersion, Warderrank, WarderrankVersion, Witness, WitnessVersion


class BailForm(forms.ModelForm):
    class Meta:
        model = Bail
        fields = ['created_on', 'changed_on', 'amountgranted', 'noofsureties', 'paid', 'paydate', 'hearing', 'defendant', 'changed_by_fk', 'created_by_fk']


class BailSuretyForm(forms.ModelForm):
    class Meta:
        model = BailSurety
        fields = ['bail', 'surety']


class BailSuretyVersionForm(forms.ModelForm):
    class Meta:
        model = BailSuretyVersion
        fields = ['bail', 'surety', 'transaction_id', 'end_transaction_id', 'operation_type']


class BailVersionForm(forms.ModelForm):
    class Meta:
        model = BailVersion
        fields = ['created_on', 'changed_on', 'id', 'hearing', 'defendant', 'amountgranted', 'noofsureties', 'paid', 'paydate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseForm(forms.ModelForm):
    class Meta:
        model = Case
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'born_digital', 'ob_number', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date', 'police_station_reported', 'reported_to', 'changed_by_fk', 'created_by_fk']


class CaseCasecategoryForm(forms.ModelForm):
    class Meta:
        model = CaseCasecategory
        fields = ['case', 'casecategory']


class CaseCasecategoryVersionForm(forms.ModelForm):
    class Meta:
        model = CaseCasecategoryVersion
        fields = ['case', 'casecategory', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseCauseofactionForm(forms.ModelForm):
    class Meta:
        model = CaseCauseofaction
        fields = ['case', 'causeofaction']


class CaseCauseofactionVersionForm(forms.ModelForm):
    class Meta:
        model = CaseCauseofactionVersion
        fields = ['case', 'causeofaction', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseDefendantForm(forms.ModelForm):
    class Meta:
        model = CaseDefendant
        fields = ['case', 'defendant']


class CaseDefendantVersionForm(forms.ModelForm):
    class Meta:
        model = CaseDefendantVersion
        fields = ['case', 'defendant', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseNatureofsuitForm(forms.ModelForm):
    class Meta:
        model = CaseNatureofsuit
        fields = ['case', 'natureofsuit']


class CaseNatureofsuitVersionForm(forms.ModelForm):
    class Meta:
        model = CaseNatureofsuitVersion
        fields = ['case', 'natureofsuit', 'transaction_id', 'end_transaction_id', 'operation_type']


class CasePlaintiffForm(forms.ModelForm):
    class Meta:
        model = CasePlaintiff
        fields = ['case', 'plaintiff']


class CasePlaintiffVersionForm(forms.ModelForm):
    class Meta:
        model = CasePlaintiffVersion
        fields = ['case', 'plaintiff', 'transaction_id', 'end_transaction_id', 'operation_type']


class CasePolofficerForm(forms.ModelForm):
    class Meta:
        model = CasePolofficer
        fields = ['case', 'polofficer']


class CasePolofficerVersionForm(forms.ModelForm):
    class Meta:
        model = CasePolofficerVersion
        fields = ['case', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseProsecutorForm(forms.ModelForm):
    class Meta:
        model = CaseProsecutor
        fields = ['case', 'prosecutor']


class CaseProsecutor2Form(forms.ModelForm):
    class Meta:
        model = CaseProsecutor2
        fields = ['case', 'prosecutor']


class CaseProsecutor2VersionForm(forms.ModelForm):
    class Meta:
        model = CaseProsecutor2Version
        fields = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseProsecutorVersionForm(forms.ModelForm):
    class Meta:
        model = CaseProsecutorVersion
        fields = ['case', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseTagForm(forms.ModelForm):
    class Meta:
        model = CaseTag
        fields = ['case', 'tag']


class CaseTagVersionForm(forms.ModelForm):
    class Meta:
        model = CaseTagVersion
        fields = ['case', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseVersionForm(forms.ModelForm):
    class Meta:
        model = CaseVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'born_digital', 'ob_number', 'police_station_reported', 'report_date', 'complaint', 'is_criminal', 'priority', 'should_investigate_further', 'evaluation_conclusion', 'investigation_assigment_date', 'investigation_assignment_note', 'investigation_plan', 'investigation_summary', 'investigation_review', 'investigation_complete', 'dpp_advice_requested', 'dpp_advice_request_date', 'dpp_advice_date', 'dpp_advice', 'send_to_trial', 'case_name', 'docketnumber', 'charge_sheet', 'charge_date', 'prosecution_notes', 'defense_notes', 'judgement', 'judgement_date', 'sentence_length_years', 'sentence_length_months', 'senetence_length_days', 'sentence_start_date', 'sentence_end_date', 'fine_amount', 'case_appealed', 'appeal_date', 'appeal_granted', 'appeal_expiry', 'case_closed', 'close_date', 'reported_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseWitnessForm(forms.ModelForm):
    class Meta:
        model = CaseWitness
        fields = ['case', 'witness']


class CaseWitnessVersionForm(forms.ModelForm):
    class Meta:
        model = CaseWitnessVersion
        fields = ['case', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']


class CasecategoryForm(forms.ModelForm):
    class Meta:
        model = Casecategory
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'indictable', 'is_criminal', 'changed_by_fk', 'created_by_fk']


class CasecategoryVersionForm(forms.ModelForm):
    class Meta:
        model = CasecategoryVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'indictable', 'is_criminal', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CaseinvestigationForm(forms.ModelForm):
    class Meta:
        model = Caseinvestigation
        fields = ['pol_officers', 'cases']


class CaseinvestigationVersionForm(forms.ModelForm):
    class Meta:
        model = CaseinvestigationVersion
        fields = ['pol_officers', 'cases', 'transaction_id', 'end_transaction_id', 'operation_type']


class CauseofactionForm(forms.ModelForm):
    class Meta:
        model = Causeofaction
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'criminal', 'parent_coa', 'changed_by_fk', 'created_by_fk']


class CauseofactionFilingForm(forms.ModelForm):
    class Meta:
        model = CauseofactionFiling
        fields = ['causeofaction', 'filing']


class CauseofactionFilingVersionForm(forms.ModelForm):
    class Meta:
        model = CauseofactionFilingVersion
        fields = ['causeofaction', 'filing', 'transaction_id', 'end_transaction_id', 'operation_type']


class CauseofactionHearingForm(forms.ModelForm):
    class Meta:
        model = CauseofactionHearing
        fields = ['causeofaction', 'hearing']


class CauseofactionHearingVersionForm(forms.ModelForm):
    class Meta:
        model = CauseofactionHearingVersion
        fields = ['causeofaction', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']


class CauseofactionVersionForm(forms.ModelForm):
    class Meta:
        model = CauseofactionVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'criminal', 'parent_coa', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CommitaltypeForm(forms.ModelForm):
    class Meta:
        model = Commitaltype
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class CommitaltypePrisoncommitalForm(forms.ModelForm):
    class Meta:
        model = CommitaltypePrisoncommital
        fields = ['prisoncommital_warrantno', 'commitaltype', 'prisoncommital_prison']


class CommitaltypePrisoncommitalVersionForm(forms.ModelForm):
    class Meta:
        model = CommitaltypePrisoncommitalVersion
        fields = ['commitaltype', 'prisoncommital_prison', 'prisoncommital_warrantno', 'transaction_id', 'end_transaction_id', 'operation_type']


class CommitaltypeVersionForm(forms.ModelForm):
    class Meta:
        model = CommitaltypeVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class ConstituencyForm(forms.ModelForm):
    class Meta:
        model = Constituency
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'county', 'town', 'changed_by_fk', 'created_by_fk']


class ConstituencyVersionForm(forms.ModelForm):
    class Meta:
        model = ConstituencyVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CountyForm(forms.ModelForm):
    class Meta:
        model = County
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class CountyVersionForm(forms.ModelForm):
    class Meta:
        model = CountyVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CourtForm(forms.ModelForm):
    class Meta:
        model = Court
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'court_station', 'changed_by_fk', 'created_by_fk']


class CourtVersionForm(forms.ModelForm):
    class Meta:
        model = CourtVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'court_station', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CourtlevelForm(forms.ModelForm):
    class Meta:
        model = Courtlevel
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class CourtlevelVersionForm(forms.ModelForm):
    class Meta:
        model = CourtlevelVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class CourtstationForm(forms.ModelForm):
    class Meta:
        model = Courtstation
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'residentmagistrate', 'registrar', 'num_of_courts', 'court_level', 'town', 'changed_by_fk', 'created_by_fk']


class CourtstationVersionForm(forms.ModelForm):
    class Meta:
        model = CourtstationVersion
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'residentmagistrate', 'registrar', 'court_level', 'num_of_courts', 'town', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class DefendantForm(forms.ModelForm):
    class Meta:
        model = Defendant
        fields = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile', 'casecount', 'gender', 'prisoncell', 'changed_by_fk', 'created_by_fk']


class DefendantGateregisterForm(forms.ModelForm):
    class Meta:
        model = DefendantGateregister
        fields = ['defendant', 'gateregister']


class DefendantGateregisterVersionForm(forms.ModelForm):
    class Meta:
        model = DefendantGateregisterVersion
        fields = ['defendant', 'gateregister', 'transaction_id', 'end_transaction_id', 'operation_type']


class DefendantHearingForm(forms.ModelForm):
    class Meta:
        model = DefendantHearing
        fields = ['defendant', 'hearing']


class DefendantHearingVersionForm(forms.ModelForm):
    class Meta:
        model = DefendantHearingVersion
        fields = ['defendant', 'hearing', 'transaction_id', 'end_transaction_id', 'operation_type']


class DefendantMedeventForm(forms.ModelForm):
    class Meta:
        model = DefendantMedevent
        fields = ['defendant', 'medevent']


class DefendantMedeventVersionForm(forms.ModelForm):
    class Meta:
        model = DefendantMedeventVersion
        fields = ['defendant', 'medevent', 'transaction_id', 'end_transaction_id', 'operation_type']


class DefendantVersionForm(forms.ModelForm):
    class Meta:
        model = DefendantVersion
        fields = ['created_on', 'changed_on', 'allergies', 'chronic_conditions', 'chronic_medications', 'hbp', 'diabetes', 'hiv', 'current_health_status', 'bc_id', 'bc_number', 'bc_serial', 'bc_place', 'bc_scan', 'citizenship', 'nat_id_num', 'nat_id_serial', 'nat_id_scan', 'pp_no', 'pp_issue_date', 'pp_issue_place', 'pp_scan', 'pp_expiry_date', 'kin1_name', 'kin1_phone', 'kin1_email', 'kin1_addr', 'kin2_name', 'kin1_relation', 'kin2_phone', 'kin2_email', 'kin2_addr', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'blood_group', 'striking_features', 'height_m', 'weight_kg', 'eye_colour', 'hair_colour', 'complexion', 'religion', 'ethnicity', 'fp_lthumb', 'pgm', 'wsq', 'xyt', 'fp_left2', 'fp_left3', 'fp_left4', 'fp_left5', 'fp_rthumb', 'fp_right2', 'fp_right3', 'fp_right4', 'fp_right5', 'palm_left', 'palm_right', 'eye_left', 'eye_right', 'employed', 'employer', 'employer_contact', 'employ_date', 'employ_duration', 'termination_date', 'employ_role', 'supervisor', 'supervisor_contact', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'juvenile', 'gender', 'prisoncell', 'casecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class DisciplineForm(forms.ModelForm):
    class Meta:
        model = Discipline
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'defendant', 'changed_by_fk', 'created_by_fk']


class DisciplineVersionForm(forms.ModelForm):
    class Meta:
        model = DisciplineVersion
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'defendant', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class DocStoreForm(forms.ModelForm):
    class Meta:
        model = DocStore
        fields = ['name', 'description', 'notes', 'data']


class DocarchiveForm(forms.ModelForm):
    class Meta:
        model = Docarchive
        fields = ['created_on', 'changed_on', 'name', 'doc', 'scandate', 'archival', 'changed_by_fk', 'created_by_fk']


class DocarchiveTagForm(forms.ModelForm):
    class Meta:
        model = DocarchiveTag
        fields = ['docarchive', 'tag']


class DocarchiveTagVersionForm(forms.ModelForm):
    class Meta:
        model = DocarchiveTagVersion
        fields = ['docarchive', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']


class DocarchiveVersionForm(forms.ModelForm):
    class Meta:
        model = DocarchiveVersion
        fields = ['created_on', 'changed_on', 'id', 'name', 'doc', 'scandate', 'archival', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class DoctemplateForm(forms.ModelForm):
    class Meta:
        model = Doctemplate
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'changed_by_fk', 'created_by_fk']


class DoctemplateVersionForm(forms.ModelForm):
    class Meta:
        model = DoctemplateVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class DocumentForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'confidential', 'pagecount', 'locked', 'hash', 'filing', 'doc_template', 'changed_by_fk', 'created_by_fk']


class DocumentTagForm(forms.ModelForm):
    class Meta:
        model = DocumentTag
        fields = ['document', 'tag']


class DocumentTagVersionForm(forms.ModelForm):
    class Meta:
        model = DocumentTagVersion
        fields = ['document', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']


class DocumentVersionForm(forms.ModelForm):
    class Meta:
        model = DocumentVersion
        fields = ['created_on', 'changed_on', 'mime_type', 'doc', 'doc_text', 'doc_binary', 'doc_title', 'subject', 'author', 'keywords', 'comments', 'doc_type', 'char_count', 'word_count', 'lines', 'paragraphs', 'file_size_bytes', 'producer_prog', 'immutable', 'page_size', 'page_count', 'hashx', 'audio_duration_secs', 'audio_frame_rate', 'audio_channels', 'id', 'filing', 'doc_template', 'confidential', 'pagecount', 'locked', 'hash', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class EventlogForm(forms.ModelForm):
    class Meta:
        model = Eventlog
        fields = ['created_on', 'changed_on', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter', 'changed_by_fk', 'created_by_fk']


class EventlogVersionForm(forms.ModelForm):
    class Meta:
        model = EventlogVersion
        fields = ['created_on', 'changed_on', 'id', 'temporal', 'event', 'severity', 'alert', 'notes', 'tbl', 'colname', 'colbefore', 'colafter', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class FilingForm(forms.ModelForm):
    class Meta:
        model = Filing
        fields = ['created_on', 'changed_on', 'uploaddate', 'pagecount', 'totalfees', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'urgent', 'urgentreason', 'filing_attorney', 'filing_prosecutor', 'case', 'changed_by_fk', 'created_by_fk']


class FilingFilingtypeForm(forms.ModelForm):
    class Meta:
        model = FilingFilingtype
        fields = ['filing', 'filingtype']


class FilingFilingtypeVersionForm(forms.ModelForm):
    class Meta:
        model = FilingFilingtypeVersion
        fields = ['filing', 'filingtype', 'transaction_id', 'end_transaction_id', 'operation_type']


class FilingPaymentForm(forms.ModelForm):
    class Meta:
        model = FilingPayment
        fields = ['filing', 'payment']


class FilingPaymentVersionForm(forms.ModelForm):
    class Meta:
        model = FilingPaymentVersion
        fields = ['filing', 'payment', 'transaction_id', 'end_transaction_id', 'operation_type']


class FilingVersionForm(forms.ModelForm):
    class Meta:
        model = FilingVersion
        fields = ['created_on', 'changed_on', 'id', 'uploaddate', 'pagecount', 'totalfees', 'filing_attorney', 'filing_prosecutor', 'assessedfees', 'receiptverified', 'amountpaid', 'feebalance', 'paymenthistory', 'case', 'urgent', 'urgentreason', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class FilingtypeForm(forms.ModelForm):
    class Meta:
        model = Filingtype
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'fees', 'perpagecost', 'paid_per_page', 'changed_by_fk', 'created_by_fk']


class FilingtypeVersionForm(forms.ModelForm):
    class Meta:
        model = FilingtypeVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'fees', 'perpagecost', 'paid_per_page', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class GateregisterForm(forms.ModelForm):
    class Meta:
        model = Gateregister
        fields = ['created_on', 'changed_on', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color', 'prison', 'changed_by_fk', 'created_by_fk']


class GateregisterVersionForm(forms.ModelForm):
    class Meta:
        model = GateregisterVersion
        fields = ['created_on', 'changed_on', 'id', 'prison', 'opentime', 'closedtime', 'movementdirection', 'reason', 'staffmovement', 'goodsmovement', 'vehicle_reg', 'vehicle_color', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class GateregisterWarderForm(forms.ModelForm):
    class Meta:
        model = GateregisterWarder
        fields = ['gateregister', 'warder']


class GateregisterWarder2Form(forms.ModelForm):
    class Meta:
        model = GateregisterWarder2
        fields = ['gateregister', 'warder']


class GateregisterWarder2VersionForm(forms.ModelForm):
    class Meta:
        model = GateregisterWarder2Version
        fields = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']


class GateregisterWarderVersionForm(forms.ModelForm):
    class Meta:
        model = GateregisterWarderVersion
        fields = ['gateregister', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']


class GenderForm(forms.ModelForm):
    class Meta:
        model = Gender
        fields = ['created_on', 'changed_on', 'description', 'notes', 'name', 'changed_by_fk', 'created_by_fk']


class GenderVersionForm(forms.ModelForm):
    class Meta:
        model = GenderVersion
        fields = ['created_on', 'changed_on', 'description', 'notes', 'id', 'name', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingForm(forms.ModelForm):
    class Meta:
        model = Hearing
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'hearingdate', 'adjourned', 'completed', 'remandwarrant', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video', 'case', 'court', 'hearing_type', 'changed_by_fk', 'created_by_fk']


class HearingJudicialofficerForm(forms.ModelForm):
    class Meta:
        model = HearingJudicialofficer
        fields = ['hearing', 'judicialofficer']


class HearingJudicialofficerVersionForm(forms.ModelForm):
    class Meta:
        model = HearingJudicialofficerVersion
        fields = ['hearing', 'judicialofficer', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingLawyersForm(forms.ModelForm):
    class Meta:
        model = HearingLawyers
        fields = ['hearing', 'lawyers']


class HearingLawyersVersionForm(forms.ModelForm):
    class Meta:
        model = HearingLawyersVersion
        fields = ['hearing', 'lawyers', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingPolofficerForm(forms.ModelForm):
    class Meta:
        model = HearingPolofficer
        fields = ['hearing', 'polofficer']


class HearingPolofficerVersionForm(forms.ModelForm):
    class Meta:
        model = HearingPolofficerVersion
        fields = ['hearing', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingProsecutorForm(forms.ModelForm):
    class Meta:
        model = HearingProsecutor
        fields = ['hearing', 'prosecutor']


class HearingProsecutorVersionForm(forms.ModelForm):
    class Meta:
        model = HearingProsecutorVersion
        fields = ['hearing', 'prosecutor', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingTagForm(forms.ModelForm):
    class Meta:
        model = HearingTag
        fields = ['hearing', 'tag']


class HearingTagVersionForm(forms.ModelForm):
    class Meta:
        model = HearingTagVersion
        fields = ['hearing', 'tag', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingVersionForm(forms.ModelForm):
    class Meta:
        model = HearingVersion
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'hearingdate', 'adjourned', 'completed', 'case', 'court', 'remandwarrant', 'hearing_type', 'remanddays', 'remanddate', 'remandwarrantexpirydate', 'nexthearingdate', 'finalhearing', 'transcript', 'audio', 'video', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingWitnessForm(forms.ModelForm):
    class Meta:
        model = HearingWitness
        fields = ['hearing', 'witness']


class HearingWitnessVersionForm(forms.ModelForm):
    class Meta:
        model = HearingWitnessVersion
        fields = ['hearing', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']


class HearingtypeForm(forms.ModelForm):
    class Meta:
        model = Hearingtype
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class HearingtypeVersionForm(forms.ModelForm):
    class Meta:
        model = HearingtypeVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class InvestigationForm(forms.ModelForm):
    class Meta:
        model = Investigation
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'actiondate', 'evidence', 'narrative', 'weather', 'location', 'case', 'changed_by_fk', 'created_by_fk']


class InvestigationPolofficerForm(forms.ModelForm):
    class Meta:
        model = InvestigationPolofficer
        fields = ['investigation', 'polofficer']


class InvestigationPolofficerVersionForm(forms.ModelForm):
    class Meta:
        model = InvestigationPolofficerVersion
        fields = ['investigation', 'polofficer', 'transaction_id', 'end_transaction_id', 'operation_type']


class InvestigationVersionForm(forms.ModelForm):
    class Meta:
        model = InvestigationVersion
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'case', 'actiondate', 'evidence', 'narrative', 'weather', 'location', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class InvestigationWitnessForm(forms.ModelForm):
    class Meta:
        model = InvestigationWitness
        fields = ['investigation', 'witness']


class InvestigationWitnessVersionForm(forms.ModelForm):
    class Meta:
        model = InvestigationWitnessVersion
        fields = ['investigation', 'witness', 'transaction_id', 'end_transaction_id', 'operation_type']


class JoRankForm(forms.ModelForm):
    class Meta:
        model = JoRank
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'appelation', 'informaladdress', 'changed_by_fk', 'created_by_fk']


class JoRankVersionForm(forms.ModelForm):
    class Meta:
        model = JoRankVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'appelation', 'informaladdress', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class JudicialofficerForm(forms.ModelForm):
    class Meta:
        model = Judicialofficer
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'gender', 'court', 'changed_by_fk', 'created_by_fk']


class JudicialofficerVersionForm(forms.ModelForm):
    class Meta:
        model = JudicialofficerVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'court', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class LawfirmForm(forms.ModelForm):
    class Meta:
        model = Lawfirm
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'changed_by_fk', 'created_by_fk']


class LawfirmVersionForm(forms.ModelForm):
    class Meta:
        model = LawfirmVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class LawyersForm(forms.ModelForm):
    class Meta:
        model = Lawyers
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'barnumber', 'admissiondate', 'gender', 'law_firm', 'changed_by_fk', 'created_by_fk']


class LawyersVersionForm(forms.ModelForm):
    class Meta:
        model = LawyersVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'barnumber', 'law_firm', 'admissiondate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class MedeventForm(forms.ModelForm):
    class Meta:
        model = Medevent
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'changed_by_fk', 'created_by_fk']


class MedeventVersionForm(forms.ModelForm):
    class Meta:
        model = MedeventVersion
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class NatureofsuitForm(forms.ModelForm):
    class Meta:
        model = Natureofsuit
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class NatureofsuitVersionForm(forms.ModelForm):
    class Meta:
        model = NatureofsuitVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['created_on', 'changed_on', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'billrefnumber', 'paymentdescription', 'bail', 'payment_method', 'case', 'changed_by_fk', 'created_by_fk']


class PaymentVersionForm(forms.ModelForm):
    class Meta:
        model = PaymentVersion
        fields = ['created_on', 'changed_on', 'id', 'datepaid', 'amount', 'paymentreference', 'paymentconfirmed', 'paidby', 'msisdn', 'receiptnumber', 'ispartial', 'bail', 'billrefnumber', 'payment_method', 'paymentdescription', 'case', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PaymentmethodForm(forms.ModelForm):
    class Meta:
        model = Paymentmethod
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'key', 'secret', 'portal', 'tillnumber', 'shortcode', 'changed_by_fk', 'created_by_fk']


class PaymentmethodVersionForm(forms.ModelForm):
    class Meta:
        model = PaymentmethodVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'key', 'secret', 'portal', 'tillnumber', 'shortcode', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PlaintiffForm(forms.ModelForm):
    class Meta:
        model = Plaintiff
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'juvenile', 'gender', 'changed_by_fk', 'created_by_fk']


class PlaintiffVersionForm(forms.ModelForm):
    class Meta:
        model = PlaintiffVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'juvenile', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PolicerankForm(forms.ModelForm):
    class Meta:
        model = Policerank
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class PolicerankVersionForm(forms.ModelForm):
    class Meta:
        model = PolicerankVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PoliceroleForm(forms.ModelForm):
    class Meta:
        model = Policerole
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class PoliceroleVersionForm(forms.ModelForm):
    class Meta:
        model = PoliceroleVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PolicestationForm(forms.ModelForm):
    class Meta:
        model = Policestation
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'has_forensic_lab', 'officercommanding', 'town', 'police_station_type', 'changed_by_fk', 'created_by_fk']


class PolicestationVersionForm(forms.ModelForm):
    class Meta:
        model = PolicestationVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'has_forensic_lab', 'officercommanding', 'police_station_type', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PolicestationtypeForm(forms.ModelForm):
    class Meta:
        model = Policestationtype
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class PolicestationtypeVersionForm(forms.ModelForm):
    class Meta:
        model = PolicestationtypeVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PolofficerForm(forms.ModelForm):
    class Meta:
        model = Polofficer
        fields = ['created_on', 'changed_on', 'servicenumber', 'postdate', 'police_rank', 'gender', 'reports_to', 'pol_supervisor', 'changed_by_fk', 'created_by_fk']


class PolofficerPoliceroleForm(forms.ModelForm):
    class Meta:
        model = PolofficerPolicerole
        fields = ['polofficer', 'policerole']


class PolofficerPoliceroleVersionForm(forms.ModelForm):
    class Meta:
        model = PolofficerPoliceroleVersion
        fields = ['polofficer', 'policerole', 'transaction_id', 'end_transaction_id', 'operation_type']


class PolofficerVersionForm(forms.ModelForm):
    class Meta:
        model = PolofficerVersion
        fields = ['created_on', 'changed_on', 'id', 'police_rank', 'gender', 'servicenumber', 'reports_to', 'pol_supervisor', 'postdate', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisonForm(forms.ModelForm):
    class Meta:
        model = Prison
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'warden', 'capacity', 'population', 'cellcount', 'gatecount', 'town', 'changed_by_fk', 'created_by_fk']


class PrisonSecurityrankForm(forms.ModelForm):
    class Meta:
        model = PrisonSecurityrank
        fields = ['prison', 'securityrank']


class PrisonSecurityrankVersionForm(forms.ModelForm):
    class Meta:
        model = PrisonSecurityrankVersion
        fields = ['prison', 'securityrank', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisonVersionForm(forms.ModelForm):
    class Meta:
        model = PrisonVersion
        fields = ['created_on', 'changed_on', 'place_name', 'lat', 'lng', 'alt', 'map', 'info', 'pin', 'pin_color', 'pin_icon', 'centered', 'nearest_feature', 'id', 'town', 'warden', 'capacity', 'population', 'cellcount', 'gatecount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisoncellForm(forms.ModelForm):
    class Meta:
        model = Prisoncell
        fields = ['created_on', 'changed_on', 'prison', 'changed_by_fk', 'created_by_fk']


class PrisoncellVersionForm(forms.ModelForm):
    class Meta:
        model = PrisoncellVersion
        fields = ['created_on', 'changed_on', 'id', 'prison', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisoncommitalForm(forms.ModelForm):
    class Meta:
        model = Prisoncommital
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'warrantno', 'warrantdate', 'hascourtdate', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'paroledate', 'escaped', 'escapedate', 'escapedetails', 'prison', 'defendant', 'hearing', 'judicial_officer_warrant', 'police_officer_commiting', 'changed_by_fk', 'created_by_fk']


class PrisoncommitalVersionForm(forms.ModelForm):
    class Meta:
        model = PrisoncommitalVersion
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'prison', 'warrantno', 'defendant', 'hearing', 'warrantdate', 'hascourtdate', 'judicial_officer_warrant', 'warrant', 'warrantduration', 'warrantexpiry', 'history', 'earliestrelease', 'releasedate', 'property', 'itemcount', 'releasenotes', 'commitalnotes', 'police_officer_commiting', 'paroledate', 'escaped', 'escapedate', 'escapedetails', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisoncommitalWarderForm(forms.ModelForm):
    class Meta:
        model = PrisoncommitalWarder
        fields = ['prisoncommital_warrantno', 'prisoncommital_prison', 'warder']


class PrisoncommitalWarderVersionForm(forms.ModelForm):
    class Meta:
        model = PrisoncommitalWarderVersion
        fields = ['prisoncommital_prison', 'prisoncommital_warrantno', 'warder', 'transaction_id', 'end_transaction_id', 'operation_type']


class PrisonerpropertyForm(forms.ModelForm):
    class Meta:
        model = Prisonerproperty
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'prison_commital_warrantno', 'receipted', 'prison_commital_prison', 'changed_by_fk', 'created_by_fk']


class PrisonerpropertyVersionForm(forms.ModelForm):
    class Meta:
        model = PrisonerpropertyVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'receipted', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class ProsecutorForm(forms.ModelForm):
    class Meta:
        model = Prosecutor
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'gender', 'changed_by_fk', 'created_by_fk']


class ProsecutorProsecutorteamForm(forms.ModelForm):
    class Meta:
        model = ProsecutorProsecutorteam
        fields = ['prosecutor', 'prosecutorteam']


class ProsecutorProsecutorteamVersionForm(forms.ModelForm):
    class Meta:
        model = ProsecutorProsecutorteamVersion
        fields = ['prosecutor', 'prosecutorteam', 'transaction_id', 'end_transaction_id', 'operation_type']


class ProsecutorVersionForm(forms.ModelForm):
    class Meta:
        model = ProsecutorVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class ProsecutorteamForm(forms.ModelForm):
    class Meta:
        model = Prosecutorteam
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class ProsecutorteamVersionForm(forms.ModelForm):
    class Meta:
        model = ProsecutorteamVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class RemissionForm(forms.ModelForm):
    class Meta:
        model = Remission
        fields = ['created_on', 'changed_on', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount', 'prison_commital_prison', 'changed_by_fk', 'created_by_fk']


class RemissionVersionForm(forms.ModelForm):
    class Meta:
        model = RemissionVersion
        fields = ['created_on', 'changed_on', 'id', 'prison_commital_prison', 'prison_commital_warrantno', 'daysearned', 'dateearned', 'amount', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class SecurityrankForm(forms.ModelForm):
    class Meta:
        model = Securityrank
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class SecurityrankVersionForm(forms.ModelForm):
    class Meta:
        model = SecurityrankVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class SubcountyForm(forms.ModelForm):
    class Meta:
        model = Subcounty
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'county', 'changed_by_fk', 'created_by_fk']


class SubcountyVersionForm(forms.ModelForm):
    class Meta:
        model = SubcountyVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'county', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class SuretyForm(forms.ModelForm):
    class Meta:
        model = Surety
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'gender', 'changed_by_fk', 'created_by_fk']


class SuretyVersionForm(forms.ModelForm):
    class Meta:
        model = SuretyVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class TagForm(forms.ModelForm):
    class Meta:
        model = Tag
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class TagVersionForm(forms.ModelForm):
    class Meta:
        model = TagVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class TownForm(forms.ModelForm):
    class Meta:
        model = Town
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'subcounty', 'changed_by_fk', 'created_by_fk']


class TownVersionForm(forms.ModelForm):
    class Meta:
        model = TownVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'subcounty', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = ['issued_at', 'id', 'remote_addr', 'user']


class VisitForm(forms.ModelForm):
    class Meta:
        model = Visit
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'visitdate', 'visitnotes', 'vistors', 'defendants', 'changed_by_fk', 'created_by_fk']


class VisitVersionForm(forms.ModelForm):
    class Meta:
        model = VisitVersion
        fields = ['created_on', 'changed_on', 'priority', 'segment', 'task_group', 'sequence', 'action', 'activity_description', 'goal', 'status', 'planned_start', 'actual_start', 'start_notes', 'planned_end', 'actual_end', 'end_notes', 'deadline', 'not_started', 'early_start', 'late_start', 'completed', 'early_end', 'late_end', 'deviation_expected', 'contingency_plan', 'budget', 'spend_td', 'balance_avail', 'over_budget', 'under_budget', 'vistors', 'defendants', 'visitdate', 'visitnotes', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class VisitorForm(forms.ModelForm):
    class Meta:
        model = Visitor
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'gender', 'changed_by_fk', 'created_by_fk']


class VisitorVersionForm(forms.ModelForm):
    class Meta:
        model = VisitorVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class WarderForm(forms.ModelForm):
    class Meta:
        model = Warder
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'prison', 'warder_rank', 'reports_to', 'changed_by_fk', 'created_by_fk']


class WarderVersionForm(forms.ModelForm):
    class Meta:
        model = WarderVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'prison', 'warder_rank', 'reports_to', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class WarderrankForm(forms.ModelForm):
    class Meta:
        model = Warderrank
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'changed_by_fk', 'created_by_fk']


class WarderrankVersionForm(forms.ModelForm):
    class Meta:
        model = WarderrankVersion
        fields = ['created_on', 'changed_on', 'name', 'description', 'notes', 'id', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


class WitnessForm(forms.ModelForm):
    class Meta:
        model = Witness
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'fordefense', 'gender', 'changed_by_fk', 'created_by_fk']


class WitnessVersionForm(forms.ModelForm):
    class Meta:
        model = WitnessVersion
        fields = ['created_on', 'changed_on', 'firstname', 'surname', 'othernames', 'dob', 'marital_status', 'photo', 'age_today', 'mobile', 'other_mobile', 'fixed_line', 'other_fixed_line', 'email', 'other_email', 'address_line_1', 'address_line_2', 'zipcode', 'town', 'country', 'facebook', 'twitter', 'instagram', 'whatsapp', 'other_whatsapp', 'fax', 'gcode', 'okhi', 'id', 'fordefense', 'gender', 'changed_by_fk', 'created_by_fk', 'transaction_id', 'end_transaction_id', 'operation_type']


