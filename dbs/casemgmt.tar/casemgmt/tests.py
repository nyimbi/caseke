import unittest
from django.core.urlresolvers import reverse
from django.test import Client
from .models import Bail, BailSurety, BailSuretyVersion, BailVersion, Case, CaseCasecategory, CaseCasecategoryVersion, CaseCauseofaction, CaseCauseofactionVersion, CaseDefendant, CaseDefendantVersion, CaseNatureofsuit, CaseNatureofsuitVersion, CasePlaintiff, CasePlaintiffVersion, CasePolofficer, CasePolofficerVersion, CaseProsecutor, CaseProsecutor2, CaseProsecutor2Version, CaseProsecutorVersion, CaseTag, CaseTagVersion, CaseVersion, CaseWitness, CaseWitnessVersion, Casecategory, CasecategoryVersion, Caseinvestigation, CaseinvestigationVersion, Causeofaction, CauseofactionFiling, CauseofactionFilingVersion, CauseofactionHearing, CauseofactionHearingVersion, CauseofactionVersion, Commitaltype, CommitaltypePrisoncommital, CommitaltypePrisoncommitalVersion, CommitaltypeVersion, Constituency, ConstituencyVersion, County, CountyVersion, Court, CourtVersion, Courtlevel, CourtlevelVersion, Courtstation, CourtstationVersion, Defendant, DefendantGateregister, DefendantGateregisterVersion, DefendantHearing, DefendantHearingVersion, DefendantMedevent, DefendantMedeventVersion, DefendantVersion, Discipline, DisciplineVersion, DocStore, Docarchive, DocarchiveTag, DocarchiveTagVersion, DocarchiveVersion, Doctemplate, DoctemplateVersion, Document, DocumentTag, DocumentTagVersion, DocumentVersion, Eventlog, EventlogVersion, Filing, FilingFilingtype, FilingFilingtypeVersion, FilingPayment, FilingPaymentVersion, FilingVersion, Filingtype, FilingtypeVersion, Gateregister, GateregisterVersion, GateregisterWarder, GateregisterWarder2, GateregisterWarder2Version, GateregisterWarderVersion, Gender, GenderVersion, Hearing, HearingJudicialofficer, HearingJudicialofficerVersion, HearingLawyers, HearingLawyersVersion, HearingPolofficer, HearingPolofficerVersion, HearingProsecutor, HearingProsecutorVersion, HearingTag, HearingTagVersion, HearingVersion, HearingWitness, HearingWitnessVersion, Hearingtype, HearingtypeVersion, Investigation, InvestigationPolofficer, InvestigationPolofficerVersion, InvestigationVersion, InvestigationWitness, InvestigationWitnessVersion, JoRank, JoRankVersion, Judicialofficer, JudicialofficerVersion, Lawfirm, LawfirmVersion, Lawyers, LawyersVersion, Medevent, MedeventVersion, Natureofsuit, NatureofsuitVersion, Payment, PaymentVersion, Paymentmethod, PaymentmethodVersion, Plaintiff, PlaintiffVersion, Policerank, PolicerankVersion, Policerole, PoliceroleVersion, Policestation, PolicestationVersion, Policestationtype, PolicestationtypeVersion, Polofficer, PolofficerPolicerole, PolofficerPoliceroleVersion, PolofficerVersion, Prison, PrisonSecurityrank, PrisonSecurityrankVersion, PrisonVersion, Prisoncell, PrisoncellVersion, Prisoncommital, PrisoncommitalVersion, PrisoncommitalWarder, PrisoncommitalWarderVersion, Prisonerproperty, PrisonerpropertyVersion, Prosecutor, ProsecutorProsecutorteam, ProsecutorProsecutorteamVersion, ProsecutorVersion, Prosecutorteam, ProsecutorteamVersion, Remission, RemissionVersion, Securityrank, SecurityrankVersion, Subcounty, SubcountyVersion, Surety, SuretyVersion, Tag, TagVersion, Town, TownVersion, Transaction, Visit, VisitVersion, Visitor, VisitorVersion, Warder, WarderVersion, Warderrank, WarderrankVersion, Witness, WitnessVersion
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType


def create_django_contrib_auth_models_user(**kwargs):
    defaults = {}
    defaults["username"] = "username"
    defaults["email"] = "username@tempurl.com"
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_django_contrib_auth_models_group(**kwargs):
    defaults = {}
    defaults["name"] = "group"
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_django_contrib_contenttypes_models_contenttype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_bail(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["amountgranted"] = "amountgranted"
    defaults["noofsureties"] = "noofsureties"
    defaults["paid"] = "paid"
    defaults["paydate"] = "paydate"
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_'hearing'()
    if "defendant" not in defaults:
        defaults["defendant"] = create_'defendant'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Bail.objects.create(**defaults)


def create_bailsurety(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "bail" not in defaults:
        defaults["bail"] = create_bail()
    if "surety" not in defaults:
        defaults["surety"] = create_'surety'()
    return BailSurety.objects.create(**defaults)


def create_bailsuretyversion(**kwargs):
    defaults = {}
    defaults["bail"] = "bail"
    defaults["surety"] = "surety"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return BailSuretyVersion.objects.create(**defaults)


def create_bailversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["hearing"] = "hearing"
    defaults["defendant"] = "defendant"
    defaults["amountgranted"] = "amountgranted"
    defaults["noofsureties"] = "noofsureties"
    defaults["paid"] = "paid"
    defaults["paydate"] = "paydate"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return BailVersion.objects.create(**defaults)


def create_case(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["born_digital"] = "born_digital"
    defaults["ob_number"] = "ob_number"
    defaults["report_date"] = "report_date"
    defaults["complaint"] = "complaint"
    defaults["is_criminal"] = "is_criminal"
    defaults["priority"] = "priority"
    defaults["should_investigate_further"] = "should_investigate_further"
    defaults["evaluation_conclusion"] = "evaluation_conclusion"
    defaults["investigation_assigment_date"] = "investigation_assigment_date"
    defaults["investigation_assignment_note"] = "investigation_assignment_note"
    defaults["investigation_plan"] = "investigation_plan"
    defaults["investigation_summary"] = "investigation_summary"
    defaults["investigation_review"] = "investigation_review"
    defaults["investigation_complete"] = "investigation_complete"
    defaults["dpp_advice_requested"] = "dpp_advice_requested"
    defaults["dpp_advice_request_date"] = "dpp_advice_request_date"
    defaults["dpp_advice_date"] = "dpp_advice_date"
    defaults["dpp_advice"] = "dpp_advice"
    defaults["send_to_trial"] = "send_to_trial"
    defaults["case_name"] = "case_name"
    defaults["docketnumber"] = "docketnumber"
    defaults["charge_sheet"] = "charge_sheet"
    defaults["charge_date"] = "charge_date"
    defaults["prosecution_notes"] = "prosecution_notes"
    defaults["defense_notes"] = "defense_notes"
    defaults["judgement"] = "judgement"
    defaults["judgement_date"] = "judgement_date"
    defaults["sentence_length_years"] = "sentence_length_years"
    defaults["sentence_length_months"] = "sentence_length_months"
    defaults["senetence_length_days"] = "senetence_length_days"
    defaults["sentence_start_date"] = "sentence_start_date"
    defaults["sentence_end_date"] = "sentence_end_date"
    defaults["fine_amount"] = "fine_amount"
    defaults["case_appealed"] = "case_appealed"
    defaults["appeal_date"] = "appeal_date"
    defaults["appeal_granted"] = "appeal_granted"
    defaults["appeal_expiry"] = "appeal_expiry"
    defaults["case_closed"] = "case_closed"
    defaults["close_date"] = "close_date"
    defaults.update(**kwargs)
    if "police_station_reported" not in defaults:
        defaults["police_station_reported"] = create_'policestation'()
    if "reported_to" not in defaults:
        defaults["reported_to"] = create_'polofficer'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Case.objects.create(**defaults)


def create_casecasecategory(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "casecategory" not in defaults:
        defaults["casecategory"] = create_'casecategory'()
    return CaseCasecategory.objects.create(**defaults)


def create_casecasecategoryversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["casecategory"] = "casecategory"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseCasecategoryVersion.objects.create(**defaults)


def create_casecauseofaction(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "causeofaction" not in defaults:
        defaults["causeofaction"] = create_'causeofaction'()
    return CaseCauseofaction.objects.create(**defaults)


def create_casecauseofactionversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["causeofaction"] = "causeofaction"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseCauseofactionVersion.objects.create(**defaults)


def create_casedefendant(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "defendant" not in defaults:
        defaults["defendant"] = create_'defendant'()
    return CaseDefendant.objects.create(**defaults)


def create_casedefendantversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["defendant"] = "defendant"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseDefendantVersion.objects.create(**defaults)


def create_casenatureofsuit(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "natureofsuit" not in defaults:
        defaults["natureofsuit"] = create_'natureofsuit'()
    return CaseNatureofsuit.objects.create(**defaults)


def create_casenatureofsuitversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["natureofsuit"] = "natureofsuit"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseNatureofsuitVersion.objects.create(**defaults)


def create_caseplaintiff(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "plaintiff" not in defaults:
        defaults["plaintiff"] = create_'plaintiff'()
    return CasePlaintiff.objects.create(**defaults)


def create_caseplaintiffversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["plaintiff"] = "plaintiff"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CasePlaintiffVersion.objects.create(**defaults)


def create_casepolofficer(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "polofficer" not in defaults:
        defaults["polofficer"] = create_'polofficer'()
    return CasePolofficer.objects.create(**defaults)


def create_casepolofficerversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["polofficer"] = "polofficer"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CasePolofficerVersion.objects.create(**defaults)


def create_caseprosecutor(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "prosecutor" not in defaults:
        defaults["prosecutor"] = create_'prosecutor'()
    return CaseProsecutor.objects.create(**defaults)


def create_caseprosecutor2(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "prosecutor" not in defaults:
        defaults["prosecutor"] = create_'prosecutor'()
    return CaseProsecutor2.objects.create(**defaults)


def create_caseprosecutor2version(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["prosecutor"] = "prosecutor"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseProsecutor2Version.objects.create(**defaults)


def create_caseprosecutorversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["prosecutor"] = "prosecutor"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseProsecutorVersion.objects.create(**defaults)


def create_casetag(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "tag" not in defaults:
        defaults["tag"] = create_'tag'()
    return CaseTag.objects.create(**defaults)


def create_casetagversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["tag"] = "tag"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseTagVersion.objects.create(**defaults)


def create_caseversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["id"] = "id"
    defaults["born_digital"] = "born_digital"
    defaults["ob_number"] = "ob_number"
    defaults["police_station_reported"] = "police_station_reported"
    defaults["report_date"] = "report_date"
    defaults["complaint"] = "complaint"
    defaults["is_criminal"] = "is_criminal"
    defaults["priority"] = "priority"
    defaults["should_investigate_further"] = "should_investigate_further"
    defaults["evaluation_conclusion"] = "evaluation_conclusion"
    defaults["investigation_assigment_date"] = "investigation_assigment_date"
    defaults["investigation_assignment_note"] = "investigation_assignment_note"
    defaults["investigation_plan"] = "investigation_plan"
    defaults["investigation_summary"] = "investigation_summary"
    defaults["investigation_review"] = "investigation_review"
    defaults["investigation_complete"] = "investigation_complete"
    defaults["dpp_advice_requested"] = "dpp_advice_requested"
    defaults["dpp_advice_request_date"] = "dpp_advice_request_date"
    defaults["dpp_advice_date"] = "dpp_advice_date"
    defaults["dpp_advice"] = "dpp_advice"
    defaults["send_to_trial"] = "send_to_trial"
    defaults["case_name"] = "case_name"
    defaults["docketnumber"] = "docketnumber"
    defaults["charge_sheet"] = "charge_sheet"
    defaults["charge_date"] = "charge_date"
    defaults["prosecution_notes"] = "prosecution_notes"
    defaults["defense_notes"] = "defense_notes"
    defaults["judgement"] = "judgement"
    defaults["judgement_date"] = "judgement_date"
    defaults["sentence_length_years"] = "sentence_length_years"
    defaults["sentence_length_months"] = "sentence_length_months"
    defaults["senetence_length_days"] = "senetence_length_days"
    defaults["sentence_start_date"] = "sentence_start_date"
    defaults["sentence_end_date"] = "sentence_end_date"
    defaults["fine_amount"] = "fine_amount"
    defaults["case_appealed"] = "case_appealed"
    defaults["appeal_date"] = "appeal_date"
    defaults["appeal_granted"] = "appeal_granted"
    defaults["appeal_expiry"] = "appeal_expiry"
    defaults["case_closed"] = "case_closed"
    defaults["close_date"] = "close_date"
    defaults["reported_to"] = "reported_to"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseVersion.objects.create(**defaults)


def create_casewitness(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "witness" not in defaults:
        defaults["witness"] = create_'witness'()
    return CaseWitness.objects.create(**defaults)


def create_casewitnessversion(**kwargs):
    defaults = {}
    defaults["case"] = "case"
    defaults["witness"] = "witness"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseWitnessVersion.objects.create(**defaults)


def create_casecategory(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["indictable"] = "indictable"
    defaults["is_criminal"] = "is_criminal"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Casecategory.objects.create(**defaults)


def create_casecategoryversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["indictable"] = "indictable"
    defaults["is_criminal"] = "is_criminal"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CasecategoryVersion.objects.create(**defaults)


def create_caseinvestigation(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "pol_officers" not in defaults:
        defaults["pol_officers"] = create_'polofficer'()
    if "cases" not in defaults:
        defaults["cases"] = create_case()
    return Caseinvestigation.objects.create(**defaults)


def create_caseinvestigationversion(**kwargs):
    defaults = {}
    defaults["pol_officers"] = "pol_officers"
    defaults["cases"] = "cases"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CaseinvestigationVersion.objects.create(**defaults)


def create_causeofaction(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["criminal"] = "criminal"
    defaults.update(**kwargs)
    if "parent_coa" not in defaults:
        defaults["parent_coa"] = create_'self'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Causeofaction.objects.create(**defaults)


def create_causeofactionfiling(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "causeofaction" not in defaults:
        defaults["causeofaction"] = create_causeofaction()
    if "filing" not in defaults:
        defaults["filing"] = create_'filing'()
    return CauseofactionFiling.objects.create(**defaults)


def create_causeofactionfilingversion(**kwargs):
    defaults = {}
    defaults["causeofaction"] = "causeofaction"
    defaults["filing"] = "filing"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CauseofactionFilingVersion.objects.create(**defaults)


def create_causeofactionhearing(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "causeofaction" not in defaults:
        defaults["causeofaction"] = create_causeofaction()
    if "hearing" not in defaults:
        defaults["hearing"] = create_'hearing'()
    return CauseofactionHearing.objects.create(**defaults)


def create_causeofactionhearingversion(**kwargs):
    defaults = {}
    defaults["causeofaction"] = "causeofaction"
    defaults["hearing"] = "hearing"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CauseofactionHearingVersion.objects.create(**defaults)


def create_causeofactionversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["criminal"] = "criminal"
    defaults["parent_coa"] = "parent_coa"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CauseofactionVersion.objects.create(**defaults)


def create_commitaltype(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Commitaltype.objects.create(**defaults)


def create_commitaltypeprisoncommital(**kwargs):
    defaults = {}
    defaults["prisoncommital_warrantno"] = "prisoncommital_warrantno"
    defaults.update(**kwargs)
    if "commitaltype" not in defaults:
        defaults["commitaltype"] = create_commitaltype()
    if "prisoncommital_prison" not in defaults:
        defaults["prisoncommital_prison"] = create_'prisoncommital'()
    return CommitaltypePrisoncommital.objects.create(**defaults)


def create_commitaltypeprisoncommitalversion(**kwargs):
    defaults = {}
    defaults["commitaltype"] = "commitaltype"
    defaults["prisoncommital_prison"] = "prisoncommital_prison"
    defaults["prisoncommital_warrantno"] = "prisoncommital_warrantno"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CommitaltypePrisoncommitalVersion.objects.create(**defaults)


def create_commitaltypeversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CommitaltypeVersion.objects.create(**defaults)


def create_constituency(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "county" not in defaults:
        defaults["county"] = create_'county'()
    if "town" not in defaults:
        defaults["town"] = create_'town'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Constituency.objects.create(**defaults)


def create_constituencyversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["county"] = "county"
    defaults["town"] = "town"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return ConstituencyVersion.objects.create(**defaults)


def create_county(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return County.objects.create(**defaults)


def create_countyversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CountyVersion.objects.create(**defaults)


def create_court(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "court_station" not in defaults:
        defaults["court_station"] = create_'courtstation'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Court.objects.create(**defaults)


def create_courtversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["court_station"] = "court_station"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CourtVersion.objects.create(**defaults)


def create_courtlevel(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Courtlevel.objects.create(**defaults)


def create_courtlevelversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CourtlevelVersion.objects.create(**defaults)


def create_courtstation(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["residentmagistrate"] = "residentmagistrate"
    defaults["registrar"] = "registrar"
    defaults["num_of_courts"] = "num_of_courts"
    defaults.update(**kwargs)
    if "court_level" not in defaults:
        defaults["court_level"] = create_courtlevel()
    if "town" not in defaults:
        defaults["town"] = create_'town'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Courtstation.objects.create(**defaults)


def create_courtstationversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["id"] = "id"
    defaults["residentmagistrate"] = "residentmagistrate"
    defaults["registrar"] = "registrar"
    defaults["court_level"] = "court_level"
    defaults["num_of_courts"] = "num_of_courts"
    defaults["town"] = "town"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return CourtstationVersion.objects.create(**defaults)


def create_defendant(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["allergies"] = "allergies"
    defaults["chronic_conditions"] = "chronic_conditions"
    defaults["chronic_medications"] = "chronic_medications"
    defaults["hbp"] = "hbp"
    defaults["diabetes"] = "diabetes"
    defaults["hiv"] = "hiv"
    defaults["current_health_status"] = "current_health_status"
    defaults["bc_id"] = "bc_id"
    defaults["bc_number"] = "bc_number"
    defaults["bc_serial"] = "bc_serial"
    defaults["bc_place"] = "bc_place"
    defaults["bc_scan"] = "bc_scan"
    defaults["citizenship"] = "citizenship"
    defaults["nat_id_num"] = "nat_id_num"
    defaults["nat_id_serial"] = "nat_id_serial"
    defaults["nat_id_scan"] = "nat_id_scan"
    defaults["pp_no"] = "pp_no"
    defaults["pp_issue_date"] = "pp_issue_date"
    defaults["pp_issue_place"] = "pp_issue_place"
    defaults["pp_scan"] = "pp_scan"
    defaults["pp_expiry_date"] = "pp_expiry_date"
    defaults["kin1_name"] = "kin1_name"
    defaults["kin1_phone"] = "kin1_phone"
    defaults["kin1_email"] = "kin1_email"
    defaults["kin1_addr"] = "kin1_addr"
    defaults["kin2_name"] = "kin2_name"
    defaults["kin1_relation"] = "kin1_relation"
    defaults["kin2_phone"] = "kin2_phone"
    defaults["kin2_email"] = "kin2_email"
    defaults["kin2_addr"] = "kin2_addr"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["blood_group"] = "blood_group"
    defaults["striking_features"] = "striking_features"
    defaults["height_m"] = "height_m"
    defaults["weight_kg"] = "weight_kg"
    defaults["eye_colour"] = "eye_colour"
    defaults["hair_colour"] = "hair_colour"
    defaults["complexion"] = "complexion"
    defaults["religion"] = "religion"
    defaults["ethnicity"] = "ethnicity"
    defaults["fp_lthumb"] = "fp_lthumb"
    defaults["pgm"] = "pgm"
    defaults["wsq"] = "wsq"
    defaults["xyt"] = "xyt"
    defaults["fp_left2"] = "fp_left2"
    defaults["fp_left3"] = "fp_left3"
    defaults["fp_left4"] = "fp_left4"
    defaults["fp_left5"] = "fp_left5"
    defaults["fp_rthumb"] = "fp_rthumb"
    defaults["fp_right2"] = "fp_right2"
    defaults["fp_right3"] = "fp_right3"
    defaults["fp_right4"] = "fp_right4"
    defaults["fp_right5"] = "fp_right5"
    defaults["palm_left"] = "palm_left"
    defaults["palm_right"] = "palm_right"
    defaults["eye_left"] = "eye_left"
    defaults["eye_right"] = "eye_right"
    defaults["employed"] = "employed"
    defaults["employer"] = "employer"
    defaults["employer_contact"] = "employer_contact"
    defaults["employ_date"] = "employ_date"
    defaults["employ_duration"] = "employ_duration"
    defaults["termination_date"] = "termination_date"
    defaults["employ_role"] = "employ_role"
    defaults["supervisor"] = "supervisor"
    defaults["supervisor_contact"] = "supervisor_contact"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["juvenile"] = "juvenile"
    defaults["casecount"] = "casecount"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_'gender'()
    if "prisoncell" not in defaults:
        defaults["prisoncell"] = create_'prisoncell'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Defendant.objects.create(**defaults)


def create_defendantgateregister(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "defendant" not in defaults:
        defaults["defendant"] = create_defendant()
    if "gateregister" not in defaults:
        defaults["gateregister"] = create_'gateregister'()
    return DefendantGateregister.objects.create(**defaults)


def create_defendantgateregisterversion(**kwargs):
    defaults = {}
    defaults["defendant"] = "defendant"
    defaults["gateregister"] = "gateregister"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DefendantGateregisterVersion.objects.create(**defaults)


def create_defendanthearing(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "defendant" not in defaults:
        defaults["defendant"] = create_defendant()
    if "hearing" not in defaults:
        defaults["hearing"] = create_'hearing'()
    return DefendantHearing.objects.create(**defaults)


def create_defendanthearingversion(**kwargs):
    defaults = {}
    defaults["defendant"] = "defendant"
    defaults["hearing"] = "hearing"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DefendantHearingVersion.objects.create(**defaults)


def create_defendantmedevent(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "defendant" not in defaults:
        defaults["defendant"] = create_defendant()
    if "medevent" not in defaults:
        defaults["medevent"] = create_'medevent'()
    return DefendantMedevent.objects.create(**defaults)


def create_defendantmedeventversion(**kwargs):
    defaults = {}
    defaults["defendant"] = "defendant"
    defaults["medevent"] = "medevent"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DefendantMedeventVersion.objects.create(**defaults)


def create_defendantversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["allergies"] = "allergies"
    defaults["chronic_conditions"] = "chronic_conditions"
    defaults["chronic_medications"] = "chronic_medications"
    defaults["hbp"] = "hbp"
    defaults["diabetes"] = "diabetes"
    defaults["hiv"] = "hiv"
    defaults["current_health_status"] = "current_health_status"
    defaults["bc_id"] = "bc_id"
    defaults["bc_number"] = "bc_number"
    defaults["bc_serial"] = "bc_serial"
    defaults["bc_place"] = "bc_place"
    defaults["bc_scan"] = "bc_scan"
    defaults["citizenship"] = "citizenship"
    defaults["nat_id_num"] = "nat_id_num"
    defaults["nat_id_serial"] = "nat_id_serial"
    defaults["nat_id_scan"] = "nat_id_scan"
    defaults["pp_no"] = "pp_no"
    defaults["pp_issue_date"] = "pp_issue_date"
    defaults["pp_issue_place"] = "pp_issue_place"
    defaults["pp_scan"] = "pp_scan"
    defaults["pp_expiry_date"] = "pp_expiry_date"
    defaults["kin1_name"] = "kin1_name"
    defaults["kin1_phone"] = "kin1_phone"
    defaults["kin1_email"] = "kin1_email"
    defaults["kin1_addr"] = "kin1_addr"
    defaults["kin2_name"] = "kin2_name"
    defaults["kin1_relation"] = "kin1_relation"
    defaults["kin2_phone"] = "kin2_phone"
    defaults["kin2_email"] = "kin2_email"
    defaults["kin2_addr"] = "kin2_addr"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["blood_group"] = "blood_group"
    defaults["striking_features"] = "striking_features"
    defaults["height_m"] = "height_m"
    defaults["weight_kg"] = "weight_kg"
    defaults["eye_colour"] = "eye_colour"
    defaults["hair_colour"] = "hair_colour"
    defaults["complexion"] = "complexion"
    defaults["religion"] = "religion"
    defaults["ethnicity"] = "ethnicity"
    defaults["fp_lthumb"] = "fp_lthumb"
    defaults["pgm"] = "pgm"
    defaults["wsq"] = "wsq"
    defaults["xyt"] = "xyt"
    defaults["fp_left2"] = "fp_left2"
    defaults["fp_left3"] = "fp_left3"
    defaults["fp_left4"] = "fp_left4"
    defaults["fp_left5"] = "fp_left5"
    defaults["fp_rthumb"] = "fp_rthumb"
    defaults["fp_right2"] = "fp_right2"
    defaults["fp_right3"] = "fp_right3"
    defaults["fp_right4"] = "fp_right4"
    defaults["fp_right5"] = "fp_right5"
    defaults["palm_left"] = "palm_left"
    defaults["palm_right"] = "palm_right"
    defaults["eye_left"] = "eye_left"
    defaults["eye_right"] = "eye_right"
    defaults["employed"] = "employed"
    defaults["employer"] = "employer"
    defaults["employer_contact"] = "employer_contact"
    defaults["employ_date"] = "employ_date"
    defaults["employ_duration"] = "employ_duration"
    defaults["termination_date"] = "termination_date"
    defaults["employ_role"] = "employ_role"
    defaults["supervisor"] = "supervisor"
    defaults["supervisor_contact"] = "supervisor_contact"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["juvenile"] = "juvenile"
    defaults["gender"] = "gender"
    defaults["prisoncell"] = "prisoncell"
    defaults["casecount"] = "casecount"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DefendantVersion.objects.create(**defaults)


def create_discipline(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults.update(**kwargs)
    if "defendant" not in defaults:
        defaults["defendant"] = create_defendant()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Discipline.objects.create(**defaults)


def create_disciplineversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["id"] = "id"
    defaults["defendant"] = "defendant"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DisciplineVersion.objects.create(**defaults)


def create_docstore(**kwargs):
    defaults = {}
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["data"] = "data"
    defaults.update(**kwargs)
    return DocStore.objects.create(**defaults)


def create_docarchive(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["doc"] = "doc"
    defaults["scandate"] = "scandate"
    defaults["archival"] = "archival"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Docarchive.objects.create(**defaults)


def create_docarchivetag(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "docarchive" not in defaults:
        defaults["docarchive"] = create_docarchive()
    if "tag" not in defaults:
        defaults["tag"] = create_'tag'()
    return DocarchiveTag.objects.create(**defaults)


def create_docarchivetagversion(**kwargs):
    defaults = {}
    defaults["docarchive"] = "docarchive"
    defaults["tag"] = "tag"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DocarchiveTagVersion.objects.create(**defaults)


def create_docarchiveversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["name"] = "name"
    defaults["doc"] = "doc"
    defaults["scandate"] = "scandate"
    defaults["archival"] = "archival"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DocarchiveVersion.objects.create(**defaults)


def create_doctemplate(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["mime_type"] = "mime_type"
    defaults["doc"] = "doc"
    defaults["doc_text"] = "doc_text"
    defaults["doc_binary"] = "doc_binary"
    defaults["doc_title"] = "doc_title"
    defaults["subject"] = "subject"
    defaults["author"] = "author"
    defaults["keywords"] = "keywords"
    defaults["comments"] = "comments"
    defaults["doc_type"] = "doc_type"
    defaults["char_count"] = "char_count"
    defaults["word_count"] = "word_count"
    defaults["lines"] = "lines"
    defaults["paragraphs"] = "paragraphs"
    defaults["file_size_bytes"] = "file_size_bytes"
    defaults["producer_prog"] = "producer_prog"
    defaults["immutable"] = "immutable"
    defaults["page_size"] = "page_size"
    defaults["page_count"] = "page_count"
    defaults["hashx"] = "hashx"
    defaults["audio_duration_secs"] = "audio_duration_secs"
    defaults["audio_frame_rate"] = "audio_frame_rate"
    defaults["audio_channels"] = "audio_channels"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Doctemplate.objects.create(**defaults)


def create_doctemplateversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["mime_type"] = "mime_type"
    defaults["doc"] = "doc"
    defaults["doc_text"] = "doc_text"
    defaults["doc_binary"] = "doc_binary"
    defaults["doc_title"] = "doc_title"
    defaults["subject"] = "subject"
    defaults["author"] = "author"
    defaults["keywords"] = "keywords"
    defaults["comments"] = "comments"
    defaults["doc_type"] = "doc_type"
    defaults["char_count"] = "char_count"
    defaults["word_count"] = "word_count"
    defaults["lines"] = "lines"
    defaults["paragraphs"] = "paragraphs"
    defaults["file_size_bytes"] = "file_size_bytes"
    defaults["producer_prog"] = "producer_prog"
    defaults["immutable"] = "immutable"
    defaults["page_size"] = "page_size"
    defaults["page_count"] = "page_count"
    defaults["hashx"] = "hashx"
    defaults["audio_duration_secs"] = "audio_duration_secs"
    defaults["audio_frame_rate"] = "audio_frame_rate"
    defaults["audio_channels"] = "audio_channels"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DoctemplateVersion.objects.create(**defaults)


def create_document(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["mime_type"] = "mime_type"
    defaults["doc"] = "doc"
    defaults["doc_text"] = "doc_text"
    defaults["doc_binary"] = "doc_binary"
    defaults["doc_title"] = "doc_title"
    defaults["subject"] = "subject"
    defaults["author"] = "author"
    defaults["keywords"] = "keywords"
    defaults["comments"] = "comments"
    defaults["doc_type"] = "doc_type"
    defaults["char_count"] = "char_count"
    defaults["word_count"] = "word_count"
    defaults["lines"] = "lines"
    defaults["paragraphs"] = "paragraphs"
    defaults["file_size_bytes"] = "file_size_bytes"
    defaults["producer_prog"] = "producer_prog"
    defaults["immutable"] = "immutable"
    defaults["page_size"] = "page_size"
    defaults["page_count"] = "page_count"
    defaults["hashx"] = "hashx"
    defaults["audio_duration_secs"] = "audio_duration_secs"
    defaults["audio_frame_rate"] = "audio_frame_rate"
    defaults["audio_channels"] = "audio_channels"
    defaults["confidential"] = "confidential"
    defaults["pagecount"] = "pagecount"
    defaults["locked"] = "locked"
    defaults["hash"] = "hash"
    defaults.update(**kwargs)
    if "filing" not in defaults:
        defaults["filing"] = create_'filing'()
    if "doc_template" not in defaults:
        defaults["doc_template"] = create_doctemplate()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Document.objects.create(**defaults)


def create_documenttag(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "document" not in defaults:
        defaults["document"] = create_document()
    if "tag" not in defaults:
        defaults["tag"] = create_'tag'()
    return DocumentTag.objects.create(**defaults)


def create_documenttagversion(**kwargs):
    defaults = {}
    defaults["document"] = "document"
    defaults["tag"] = "tag"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DocumentTagVersion.objects.create(**defaults)


def create_documentversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["mime_type"] = "mime_type"
    defaults["doc"] = "doc"
    defaults["doc_text"] = "doc_text"
    defaults["doc_binary"] = "doc_binary"
    defaults["doc_title"] = "doc_title"
    defaults["subject"] = "subject"
    defaults["author"] = "author"
    defaults["keywords"] = "keywords"
    defaults["comments"] = "comments"
    defaults["doc_type"] = "doc_type"
    defaults["char_count"] = "char_count"
    defaults["word_count"] = "word_count"
    defaults["lines"] = "lines"
    defaults["paragraphs"] = "paragraphs"
    defaults["file_size_bytes"] = "file_size_bytes"
    defaults["producer_prog"] = "producer_prog"
    defaults["immutable"] = "immutable"
    defaults["page_size"] = "page_size"
    defaults["page_count"] = "page_count"
    defaults["hashx"] = "hashx"
    defaults["audio_duration_secs"] = "audio_duration_secs"
    defaults["audio_frame_rate"] = "audio_frame_rate"
    defaults["audio_channels"] = "audio_channels"
    defaults["id"] = "id"
    defaults["filing"] = "filing"
    defaults["doc_template"] = "doc_template"
    defaults["confidential"] = "confidential"
    defaults["pagecount"] = "pagecount"
    defaults["locked"] = "locked"
    defaults["hash"] = "hash"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return DocumentVersion.objects.create(**defaults)


def create_eventlog(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["temporal"] = "temporal"
    defaults["event"] = "event"
    defaults["severity"] = "severity"
    defaults["alert"] = "alert"
    defaults["notes"] = "notes"
    defaults["tbl"] = "tbl"
    defaults["colname"] = "colname"
    defaults["colbefore"] = "colbefore"
    defaults["colafter"] = "colafter"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Eventlog.objects.create(**defaults)


def create_eventlogversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["temporal"] = "temporal"
    defaults["event"] = "event"
    defaults["severity"] = "severity"
    defaults["alert"] = "alert"
    defaults["notes"] = "notes"
    defaults["tbl"] = "tbl"
    defaults["colname"] = "colname"
    defaults["colbefore"] = "colbefore"
    defaults["colafter"] = "colafter"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return EventlogVersion.objects.create(**defaults)


def create_filing(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["uploaddate"] = "uploaddate"
    defaults["pagecount"] = "pagecount"
    defaults["totalfees"] = "totalfees"
    defaults["assessedfees"] = "assessedfees"
    defaults["receiptverified"] = "receiptverified"
    defaults["amountpaid"] = "amountpaid"
    defaults["feebalance"] = "feebalance"
    defaults["paymenthistory"] = "paymenthistory"
    defaults["urgent"] = "urgent"
    defaults["urgentreason"] = "urgentreason"
    defaults.update(**kwargs)
    if "filing_attorney" not in defaults:
        defaults["filing_attorney"] = create_'lawyers'()
    if "filing_prosecutor" not in defaults:
        defaults["filing_prosecutor"] = create_'prosecutor'()
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Filing.objects.create(**defaults)


def create_filingfilingtype(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "filing" not in defaults:
        defaults["filing"] = create_filing()
    if "filingtype" not in defaults:
        defaults["filingtype"] = create_'filingtype'()
    return FilingFilingtype.objects.create(**defaults)


def create_filingfilingtypeversion(**kwargs):
    defaults = {}
    defaults["filing"] = "filing"
    defaults["filingtype"] = "filingtype"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return FilingFilingtypeVersion.objects.create(**defaults)


def create_filingpayment(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "filing" not in defaults:
        defaults["filing"] = create_filing()
    if "payment" not in defaults:
        defaults["payment"] = create_'payment'()
    return FilingPayment.objects.create(**defaults)


def create_filingpaymentversion(**kwargs):
    defaults = {}
    defaults["filing"] = "filing"
    defaults["payment"] = "payment"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return FilingPaymentVersion.objects.create(**defaults)


def create_filingversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["uploaddate"] = "uploaddate"
    defaults["pagecount"] = "pagecount"
    defaults["totalfees"] = "totalfees"
    defaults["filing_attorney"] = "filing_attorney"
    defaults["filing_prosecutor"] = "filing_prosecutor"
    defaults["assessedfees"] = "assessedfees"
    defaults["receiptverified"] = "receiptverified"
    defaults["amountpaid"] = "amountpaid"
    defaults["feebalance"] = "feebalance"
    defaults["paymenthistory"] = "paymenthistory"
    defaults["case"] = "case"
    defaults["urgent"] = "urgent"
    defaults["urgentreason"] = "urgentreason"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return FilingVersion.objects.create(**defaults)


def create_filingtype(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["fees"] = "fees"
    defaults["perpagecost"] = "perpagecost"
    defaults["paid_per_page"] = "paid_per_page"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Filingtype.objects.create(**defaults)


def create_filingtypeversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["fees"] = "fees"
    defaults["perpagecost"] = "perpagecost"
    defaults["paid_per_page"] = "paid_per_page"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return FilingtypeVersion.objects.create(**defaults)


def create_gateregister(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["opentime"] = "opentime"
    defaults["closedtime"] = "closedtime"
    defaults["movementdirection"] = "movementdirection"
    defaults["reason"] = "reason"
    defaults["staffmovement"] = "staffmovement"
    defaults["goodsmovement"] = "goodsmovement"
    defaults["vehicle_reg"] = "vehicle_reg"
    defaults["vehicle_color"] = "vehicle_color"
    defaults.update(**kwargs)
    if "prison" not in defaults:
        defaults["prison"] = create_'prison'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Gateregister.objects.create(**defaults)


def create_gateregisterversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["prison"] = "prison"
    defaults["opentime"] = "opentime"
    defaults["closedtime"] = "closedtime"
    defaults["movementdirection"] = "movementdirection"
    defaults["reason"] = "reason"
    defaults["staffmovement"] = "staffmovement"
    defaults["goodsmovement"] = "goodsmovement"
    defaults["vehicle_reg"] = "vehicle_reg"
    defaults["vehicle_color"] = "vehicle_color"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return GateregisterVersion.objects.create(**defaults)


def create_gateregisterwarder(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "gateregister" not in defaults:
        defaults["gateregister"] = create_gateregister()
    if "warder" not in defaults:
        defaults["warder"] = create_'warder'()
    return GateregisterWarder.objects.create(**defaults)


def create_gateregisterwarder2(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "gateregister" not in defaults:
        defaults["gateregister"] = create_gateregister()
    if "warder" not in defaults:
        defaults["warder"] = create_'warder'()
    return GateregisterWarder2.objects.create(**defaults)


def create_gateregisterwarder2version(**kwargs):
    defaults = {}
    defaults["gateregister"] = "gateregister"
    defaults["warder"] = "warder"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return GateregisterWarder2Version.objects.create(**defaults)


def create_gateregisterwarderversion(**kwargs):
    defaults = {}
    defaults["gateregister"] = "gateregister"
    defaults["warder"] = "warder"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return GateregisterWarderVersion.objects.create(**defaults)


def create_gender(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["name"] = "name"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Gender.objects.create(**defaults)


def create_genderversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["name"] = "name"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return GenderVersion.objects.create(**defaults)


def create_hearing(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["hearingdate"] = "hearingdate"
    defaults["adjourned"] = "adjourned"
    defaults["completed"] = "completed"
    defaults["remandwarrant"] = "remandwarrant"
    defaults["remanddays"] = "remanddays"
    defaults["remanddate"] = "remanddate"
    defaults["remandwarrantexpirydate"] = "remandwarrantexpirydate"
    defaults["nexthearingdate"] = "nexthearingdate"
    defaults["finalhearing"] = "finalhearing"
    defaults["transcript"] = "transcript"
    defaults["audio"] = "audio"
    defaults["video"] = "video"
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "court" not in defaults:
        defaults["court"] = create_court()
    if "hearing_type" not in defaults:
        defaults["hearing_type"] = create_'hearingtype'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Hearing.objects.create(**defaults)


def create_hearingjudicialofficer(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "judicialofficer" not in defaults:
        defaults["judicialofficer"] = create_'judicialofficer'()
    return HearingJudicialofficer.objects.create(**defaults)


def create_hearingjudicialofficerversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["judicialofficer"] = "judicialofficer"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingJudicialofficerVersion.objects.create(**defaults)


def create_hearinglawyers(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "lawyers" not in defaults:
        defaults["lawyers"] = create_'lawyers'()
    return HearingLawyers.objects.create(**defaults)


def create_hearinglawyersversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["lawyers"] = "lawyers"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingLawyersVersion.objects.create(**defaults)


def create_hearingpolofficer(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "polofficer" not in defaults:
        defaults["polofficer"] = create_'polofficer'()
    return HearingPolofficer.objects.create(**defaults)


def create_hearingpolofficerversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["polofficer"] = "polofficer"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingPolofficerVersion.objects.create(**defaults)


def create_hearingprosecutor(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "prosecutor" not in defaults:
        defaults["prosecutor"] = create_'prosecutor'()
    return HearingProsecutor.objects.create(**defaults)


def create_hearingprosecutorversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["prosecutor"] = "prosecutor"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingProsecutorVersion.objects.create(**defaults)


def create_hearingtag(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "tag" not in defaults:
        defaults["tag"] = create_'tag'()
    return HearingTag.objects.create(**defaults)


def create_hearingtagversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["tag"] = "tag"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingTagVersion.objects.create(**defaults)


def create_hearingversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["id"] = "id"
    defaults["hearingdate"] = "hearingdate"
    defaults["adjourned"] = "adjourned"
    defaults["completed"] = "completed"
    defaults["case"] = "case"
    defaults["court"] = "court"
    defaults["remandwarrant"] = "remandwarrant"
    defaults["hearing_type"] = "hearing_type"
    defaults["remanddays"] = "remanddays"
    defaults["remanddate"] = "remanddate"
    defaults["remandwarrantexpirydate"] = "remandwarrantexpirydate"
    defaults["nexthearingdate"] = "nexthearingdate"
    defaults["finalhearing"] = "finalhearing"
    defaults["transcript"] = "transcript"
    defaults["audio"] = "audio"
    defaults["video"] = "video"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingVersion.objects.create(**defaults)


def create_hearingwitness(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "witness" not in defaults:
        defaults["witness"] = create_'witness'()
    return HearingWitness.objects.create(**defaults)


def create_hearingwitnessversion(**kwargs):
    defaults = {}
    defaults["hearing"] = "hearing"
    defaults["witness"] = "witness"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingWitnessVersion.objects.create(**defaults)


def create_hearingtype(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Hearingtype.objects.create(**defaults)


def create_hearingtypeversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return HearingtypeVersion.objects.create(**defaults)


def create_investigation(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["actiondate"] = "actiondate"
    defaults["evidence"] = "evidence"
    defaults["narrative"] = "narrative"
    defaults["weather"] = "weather"
    defaults["location"] = "location"
    defaults.update(**kwargs)
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Investigation.objects.create(**defaults)


def create_investigationpolofficer(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "investigation" not in defaults:
        defaults["investigation"] = create_investigation()
    if "polofficer" not in defaults:
        defaults["polofficer"] = create_'polofficer'()
    return InvestigationPolofficer.objects.create(**defaults)


def create_investigationpolofficerversion(**kwargs):
    defaults = {}
    defaults["investigation"] = "investigation"
    defaults["polofficer"] = "polofficer"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return InvestigationPolofficerVersion.objects.create(**defaults)


def create_investigationversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["id"] = "id"
    defaults["case"] = "case"
    defaults["actiondate"] = "actiondate"
    defaults["evidence"] = "evidence"
    defaults["narrative"] = "narrative"
    defaults["weather"] = "weather"
    defaults["location"] = "location"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return InvestigationVersion.objects.create(**defaults)


def create_investigationwitness(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "investigation" not in defaults:
        defaults["investigation"] = create_investigation()
    if "witness" not in defaults:
        defaults["witness"] = create_'witness'()
    return InvestigationWitness.objects.create(**defaults)


def create_investigationwitnessversion(**kwargs):
    defaults = {}
    defaults["investigation"] = "investigation"
    defaults["witness"] = "witness"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return InvestigationWitnessVersion.objects.create(**defaults)


def create_jorank(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["appelation"] = "appelation"
    defaults["informaladdress"] = "informaladdress"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return JoRank.objects.create(**defaults)


def create_jorankversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["appelation"] = "appelation"
    defaults["informaladdress"] = "informaladdress"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return JoRankVersion.objects.create(**defaults)


def create_judicialofficer(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "court" not in defaults:
        defaults["court"] = create_court()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Judicialofficer.objects.create(**defaults)


def create_judicialofficerversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["court"] = "court"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return JudicialofficerVersion.objects.create(**defaults)


def create_lawfirm(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Lawfirm.objects.create(**defaults)


def create_lawfirmversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return LawfirmVersion.objects.create(**defaults)


def create_lawyers(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["barnumber"] = "barnumber"
    defaults["admissiondate"] = "admissiondate"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "law_firm" not in defaults:
        defaults["law_firm"] = create_lawfirm()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Lawyers.objects.create(**defaults)


def create_lawyersversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["barnumber"] = "barnumber"
    defaults["law_firm"] = "law_firm"
    defaults["admissiondate"] = "admissiondate"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return LawyersVersion.objects.create(**defaults)


def create_medevent(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Medevent.objects.create(**defaults)


def create_medeventversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return MedeventVersion.objects.create(**defaults)


def create_natureofsuit(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Natureofsuit.objects.create(**defaults)


def create_natureofsuitversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return NatureofsuitVersion.objects.create(**defaults)


def create_payment(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["datepaid"] = "datepaid"
    defaults["amount"] = "amount"
    defaults["paymentreference"] = "paymentreference"
    defaults["paymentconfirmed"] = "paymentconfirmed"
    defaults["paidby"] = "paidby"
    defaults["msisdn"] = "msisdn"
    defaults["receiptnumber"] = "receiptnumber"
    defaults["ispartial"] = "ispartial"
    defaults["billrefnumber"] = "billrefnumber"
    defaults["paymentdescription"] = "paymentdescription"
    defaults.update(**kwargs)
    if "bail" not in defaults:
        defaults["bail"] = create_bail()
    if "payment_method" not in defaults:
        defaults["payment_method"] = create_'paymentmethod'()
    if "case" not in defaults:
        defaults["case"] = create_case()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Payment.objects.create(**defaults)


def create_paymentversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["datepaid"] = "datepaid"
    defaults["amount"] = "amount"
    defaults["paymentreference"] = "paymentreference"
    defaults["paymentconfirmed"] = "paymentconfirmed"
    defaults["paidby"] = "paidby"
    defaults["msisdn"] = "msisdn"
    defaults["receiptnumber"] = "receiptnumber"
    defaults["ispartial"] = "ispartial"
    defaults["bail"] = "bail"
    defaults["billrefnumber"] = "billrefnumber"
    defaults["payment_method"] = "payment_method"
    defaults["paymentdescription"] = "paymentdescription"
    defaults["case"] = "case"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PaymentVersion.objects.create(**defaults)


def create_paymentmethod(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["key"] = "key"
    defaults["secret"] = "secret"
    defaults["portal"] = "portal"
    defaults["tillnumber"] = "tillnumber"
    defaults["shortcode"] = "shortcode"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Paymentmethod.objects.create(**defaults)


def create_paymentmethodversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["key"] = "key"
    defaults["secret"] = "secret"
    defaults["portal"] = "portal"
    defaults["tillnumber"] = "tillnumber"
    defaults["shortcode"] = "shortcode"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PaymentmethodVersion.objects.create(**defaults)


def create_plaintiff(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["juvenile"] = "juvenile"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Plaintiff.objects.create(**defaults)


def create_plaintiffversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["juvenile"] = "juvenile"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PlaintiffVersion.objects.create(**defaults)


def create_policerank(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Policerank.objects.create(**defaults)


def create_policerankversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PolicerankVersion.objects.create(**defaults)


def create_policerole(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Policerole.objects.create(**defaults)


def create_policeroleversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PoliceroleVersion.objects.create(**defaults)


def create_policestation(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["has_forensic_lab"] = "has_forensic_lab"
    defaults["officercommanding"] = "officercommanding"
    defaults.update(**kwargs)
    if "town" not in defaults:
        defaults["town"] = create_'town'()
    if "police_station_type" not in defaults:
        defaults["police_station_type"] = create_'policestationtype'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Policestation.objects.create(**defaults)


def create_policestationversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["id"] = "id"
    defaults["town"] = "town"
    defaults["has_forensic_lab"] = "has_forensic_lab"
    defaults["officercommanding"] = "officercommanding"
    defaults["police_station_type"] = "police_station_type"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PolicestationVersion.objects.create(**defaults)


def create_policestationtype(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Policestationtype.objects.create(**defaults)


def create_policestationtypeversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PolicestationtypeVersion.objects.create(**defaults)


def create_polofficer(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["servicenumber"] = "servicenumber"
    defaults["postdate"] = "postdate"
    defaults.update(**kwargs)
    if "police_rank" not in defaults:
        defaults["police_rank"] = create_policerank()
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "reports_to" not in defaults:
        defaults["reports_to"] = create_'self'()
    if "pol_supervisor" not in defaults:
        defaults["pol_supervisor"] = create_case()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Polofficer.objects.create(**defaults)


def create_polofficerpolicerole(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "polofficer" not in defaults:
        defaults["polofficer"] = create_polofficer()
    if "policerole" not in defaults:
        defaults["policerole"] = create_policerole()
    return PolofficerPolicerole.objects.create(**defaults)


def create_polofficerpoliceroleversion(**kwargs):
    defaults = {}
    defaults["polofficer"] = "polofficer"
    defaults["policerole"] = "policerole"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PolofficerPoliceroleVersion.objects.create(**defaults)


def create_polofficerversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["police_rank"] = "police_rank"
    defaults["gender"] = "gender"
    defaults["servicenumber"] = "servicenumber"
    defaults["reports_to"] = "reports_to"
    defaults["pol_supervisor"] = "pol_supervisor"
    defaults["postdate"] = "postdate"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PolofficerVersion.objects.create(**defaults)


def create_prison(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["warden"] = "warden"
    defaults["capacity"] = "capacity"
    defaults["population"] = "population"
    defaults["cellcount"] = "cellcount"
    defaults["gatecount"] = "gatecount"
    defaults.update(**kwargs)
    if "town" not in defaults:
        defaults["town"] = create_'town'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prison.objects.create(**defaults)


def create_prisonsecurityrank(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "prison" not in defaults:
        defaults["prison"] = create_prison()
    if "securityrank" not in defaults:
        defaults["securityrank"] = create_'securityrank'()
    return PrisonSecurityrank.objects.create(**defaults)


def create_prisonsecurityrankversion(**kwargs):
    defaults = {}
    defaults["prison"] = "prison"
    defaults["securityrank"] = "securityrank"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisonSecurityrankVersion.objects.create(**defaults)


def create_prisonversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["place_name"] = "place_name"
    defaults["lat"] = "lat"
    defaults["lng"] = "lng"
    defaults["alt"] = "alt"
    defaults["map"] = "map"
    defaults["info"] = "info"
    defaults["pin"] = "pin"
    defaults["pin_color"] = "pin_color"
    defaults["pin_icon"] = "pin_icon"
    defaults["centered"] = "centered"
    defaults["nearest_feature"] = "nearest_feature"
    defaults["id"] = "id"
    defaults["town"] = "town"
    defaults["warden"] = "warden"
    defaults["capacity"] = "capacity"
    defaults["population"] = "population"
    defaults["cellcount"] = "cellcount"
    defaults["gatecount"] = "gatecount"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisonVersion.objects.create(**defaults)


def create_prisoncell(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults.update(**kwargs)
    if "prison" not in defaults:
        defaults["prison"] = create_prison()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prisoncell.objects.create(**defaults)


def create_prisoncellversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["prison"] = "prison"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisoncellVersion.objects.create(**defaults)


def create_prisoncommital(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["warrantno"] = "warrantno"
    defaults["warrantdate"] = "warrantdate"
    defaults["hascourtdate"] = "hascourtdate"
    defaults["warrant"] = "warrant"
    defaults["warrantduration"] = "warrantduration"
    defaults["warrantexpiry"] = "warrantexpiry"
    defaults["history"] = "history"
    defaults["earliestrelease"] = "earliestrelease"
    defaults["releasedate"] = "releasedate"
    defaults["property"] = "property"
    defaults["itemcount"] = "itemcount"
    defaults["releasenotes"] = "releasenotes"
    defaults["commitalnotes"] = "commitalnotes"
    defaults["paroledate"] = "paroledate"
    defaults["escaped"] = "escaped"
    defaults["escapedate"] = "escapedate"
    defaults["escapedetails"] = "escapedetails"
    defaults.update(**kwargs)
    if "prison" not in defaults:
        defaults["prison"] = create_prison()
    if "defendant" not in defaults:
        defaults["defendant"] = create_defendant()
    if "hearing" not in defaults:
        defaults["hearing"] = create_hearing()
    if "judicial_officer_warrant" not in defaults:
        defaults["judicial_officer_warrant"] = create_judicialofficer()
    if "police_officer_commiting" not in defaults:
        defaults["police_officer_commiting"] = create_polofficer()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prisoncommital.objects.create(**defaults)


def create_prisoncommitalversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["prison"] = "prison"
    defaults["warrantno"] = "warrantno"
    defaults["defendant"] = "defendant"
    defaults["hearing"] = "hearing"
    defaults["warrantdate"] = "warrantdate"
    defaults["hascourtdate"] = "hascourtdate"
    defaults["judicial_officer_warrant"] = "judicial_officer_warrant"
    defaults["warrant"] = "warrant"
    defaults["warrantduration"] = "warrantduration"
    defaults["warrantexpiry"] = "warrantexpiry"
    defaults["history"] = "history"
    defaults["earliestrelease"] = "earliestrelease"
    defaults["releasedate"] = "releasedate"
    defaults["property"] = "property"
    defaults["itemcount"] = "itemcount"
    defaults["releasenotes"] = "releasenotes"
    defaults["commitalnotes"] = "commitalnotes"
    defaults["police_officer_commiting"] = "police_officer_commiting"
    defaults["paroledate"] = "paroledate"
    defaults["escaped"] = "escaped"
    defaults["escapedate"] = "escapedate"
    defaults["escapedetails"] = "escapedetails"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisoncommitalVersion.objects.create(**defaults)


def create_prisoncommitalwarder(**kwargs):
    defaults = {}
    defaults["prisoncommital_warrantno"] = "prisoncommital_warrantno"
    defaults.update(**kwargs)
    if "prisoncommital_prison" not in defaults:
        defaults["prisoncommital_prison"] = create_prisoncommital()
    if "warder" not in defaults:
        defaults["warder"] = create_'warder'()
    return PrisoncommitalWarder.objects.create(**defaults)


def create_prisoncommitalwarderversion(**kwargs):
    defaults = {}
    defaults["prisoncommital_prison"] = "prisoncommital_prison"
    defaults["prisoncommital_warrantno"] = "prisoncommital_warrantno"
    defaults["warder"] = "warder"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisoncommitalWarderVersion.objects.create(**defaults)


def create_prisonerproperty(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["prison_commital_warrantno"] = "prison_commital_warrantno"
    defaults["receipted"] = "receipted"
    defaults.update(**kwargs)
    if "prison_commital_prison" not in defaults:
        defaults["prison_commital_prison"] = create_prisoncommital()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prisonerproperty.objects.create(**defaults)


def create_prisonerpropertyversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["prison_commital_prison"] = "prison_commital_prison"
    defaults["prison_commital_warrantno"] = "prison_commital_warrantno"
    defaults["receipted"] = "receipted"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return PrisonerpropertyVersion.objects.create(**defaults)


def create_prosecutor(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prosecutor.objects.create(**defaults)


def create_prosecutorprosecutorteam(**kwargs):
    defaults = {}
    defaults.update(**kwargs)
    if "prosecutor" not in defaults:
        defaults["prosecutor"] = create_prosecutor()
    if "prosecutorteam" not in defaults:
        defaults["prosecutorteam"] = create_'prosecutorteam'()
    return ProsecutorProsecutorteam.objects.create(**defaults)


def create_prosecutorprosecutorteamversion(**kwargs):
    defaults = {}
    defaults["prosecutor"] = "prosecutor"
    defaults["prosecutorteam"] = "prosecutorteam"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return ProsecutorProsecutorteamVersion.objects.create(**defaults)


def create_prosecutorversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return ProsecutorVersion.objects.create(**defaults)


def create_prosecutorteam(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Prosecutorteam.objects.create(**defaults)


def create_prosecutorteamversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return ProsecutorteamVersion.objects.create(**defaults)


def create_remission(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["prison_commital_warrantno"] = "prison_commital_warrantno"
    defaults["daysearned"] = "daysearned"
    defaults["dateearned"] = "dateearned"
    defaults["amount"] = "amount"
    defaults.update(**kwargs)
    if "prison_commital_prison" not in defaults:
        defaults["prison_commital_prison"] = create_prisoncommital()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Remission.objects.create(**defaults)


def create_remissionversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["id"] = "id"
    defaults["prison_commital_prison"] = "prison_commital_prison"
    defaults["prison_commital_warrantno"] = "prison_commital_warrantno"
    defaults["daysearned"] = "daysearned"
    defaults["dateearned"] = "dateearned"
    defaults["amount"] = "amount"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return RemissionVersion.objects.create(**defaults)


def create_securityrank(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Securityrank.objects.create(**defaults)


def create_securityrankversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return SecurityrankVersion.objects.create(**defaults)


def create_subcounty(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "county" not in defaults:
        defaults["county"] = create_county()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Subcounty.objects.create(**defaults)


def create_subcountyversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["county"] = "county"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return SubcountyVersion.objects.create(**defaults)


def create_surety(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Surety.objects.create(**defaults)


def create_suretyversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return SuretyVersion.objects.create(**defaults)


def create_tag(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Tag.objects.create(**defaults)


def create_tagversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return TagVersion.objects.create(**defaults)


def create_town(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "subcounty" not in defaults:
        defaults["subcounty"] = create_subcounty()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Town.objects.create(**defaults)


def create_townversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["subcounty"] = "subcounty"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return TownVersion.objects.create(**defaults)


def create_transaction(**kwargs):
    defaults = {}
    defaults["issued_at"] = "issued_at"
    defaults["id"] = "id"
    defaults["remote_addr"] = "remote_addr"
    defaults.update(**kwargs)
    if "user" not in defaults:
        defaults["user"] = create_abuser()
    return Transaction.objects.create(**defaults)


def create_visit(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["visitdate"] = "visitdate"
    defaults["visitnotes"] = "visitnotes"
    defaults.update(**kwargs)
    if "vistors" not in defaults:
        defaults["vistors"] = create_'visitor'()
    if "defendants" not in defaults:
        defaults["defendants"] = create_defendant()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Visit.objects.create(**defaults)


def create_visitversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["priority"] = "priority"
    defaults["segment"] = "segment"
    defaults["task_group"] = "task_group"
    defaults["sequence"] = "sequence"
    defaults["action"] = "action"
    defaults["activity_description"] = "activity_description"
    defaults["goal"] = "goal"
    defaults["status"] = "status"
    defaults["planned_start"] = "planned_start"
    defaults["actual_start"] = "actual_start"
    defaults["start_notes"] = "start_notes"
    defaults["planned_end"] = "planned_end"
    defaults["actual_end"] = "actual_end"
    defaults["end_notes"] = "end_notes"
    defaults["deadline"] = "deadline"
    defaults["not_started"] = "not_started"
    defaults["early_start"] = "early_start"
    defaults["late_start"] = "late_start"
    defaults["completed"] = "completed"
    defaults["early_end"] = "early_end"
    defaults["late_end"] = "late_end"
    defaults["deviation_expected"] = "deviation_expected"
    defaults["contingency_plan"] = "contingency_plan"
    defaults["budget"] = "budget"
    defaults["spend_td"] = "spend_td"
    defaults["balance_avail"] = "balance_avail"
    defaults["over_budget"] = "over_budget"
    defaults["under_budget"] = "under_budget"
    defaults["vistors"] = "vistors"
    defaults["defendants"] = "defendants"
    defaults["visitdate"] = "visitdate"
    defaults["visitnotes"] = "visitnotes"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return VisitVersion.objects.create(**defaults)


def create_visitor(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Visitor.objects.create(**defaults)


def create_visitorversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["gender"] = "gender"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return VisitorVersion.objects.create(**defaults)


def create_warder(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults.update(**kwargs)
    if "prison" not in defaults:
        defaults["prison"] = create_prison()
    if "warder_rank" not in defaults:
        defaults["warder_rank"] = create_'warderrank'()
    if "reports_to" not in defaults:
        defaults["reports_to"] = create_'self'()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Warder.objects.create(**defaults)


def create_warderversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["prison"] = "prison"
    defaults["warder_rank"] = "warder_rank"
    defaults["reports_to"] = "reports_to"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return WarderVersion.objects.create(**defaults)


def create_warderrank(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults.update(**kwargs)
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Warderrank.objects.create(**defaults)


def create_warderrankversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["name"] = "name"
    defaults["description"] = "description"
    defaults["notes"] = "notes"
    defaults["id"] = "id"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return WarderrankVersion.objects.create(**defaults)


def create_witness(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["fordefense"] = "fordefense"
    defaults.update(**kwargs)
    if "gender" not in defaults:
        defaults["gender"] = create_gender()
    if "changed_by_fk" not in defaults:
        defaults["changed_by_fk"] = create_abuser()
    if "created_by_fk" not in defaults:
        defaults["created_by_fk"] = create_abuser()
    return Witness.objects.create(**defaults)


def create_witnessversion(**kwargs):
    defaults = {}
    defaults["created_on"] = "created_on"
    defaults["changed_on"] = "changed_on"
    defaults["firstname"] = "firstname"
    defaults["surname"] = "surname"
    defaults["othernames"] = "othernames"
    defaults["dob"] = "dob"
    defaults["marital_status"] = "marital_status"
    defaults["photo"] = "photo"
    defaults["age_today"] = "age_today"
    defaults["mobile"] = "mobile"
    defaults["other_mobile"] = "other_mobile"
    defaults["fixed_line"] = "fixed_line"
    defaults["other_fixed_line"] = "other_fixed_line"
    defaults["email"] = "email"
    defaults["other_email"] = "other_email"
    defaults["address_line_1"] = "address_line_1"
    defaults["address_line_2"] = "address_line_2"
    defaults["zipcode"] = "zipcode"
    defaults["town"] = "town"
    defaults["country"] = "country"
    defaults["facebook"] = "facebook"
    defaults["twitter"] = "twitter"
    defaults["instagram"] = "instagram"
    defaults["whatsapp"] = "whatsapp"
    defaults["other_whatsapp"] = "other_whatsapp"
    defaults["fax"] = "fax"
    defaults["gcode"] = "gcode"
    defaults["okhi"] = "okhi"
    defaults["id"] = "id"
    defaults["fordefense"] = "fordefense"
    defaults["gender"] = "gender"
    defaults["changed_by_fk"] = "changed_by_fk"
    defaults["created_by_fk"] = "created_by_fk"
    defaults["transaction_id"] = "transaction_id"
    defaults["end_transaction_id"] = "end_transaction_id"
    defaults["operation_type"] = "operation_type"
    defaults.update(**kwargs)
    return WitnessVersion.objects.create(**defaults)


class BailViewTest(unittest.TestCase):
    '''
    Tests for Bail
    '''
    def setUp(self):
        self.client = Client()

    def test_list_bail(self):
        url = reverse('casemgmt_bail_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_bail(self):
        url = reverse('casemgmt_bail_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "amountgranted": "amountgranted",
            "noofsureties": "noofsureties",
            "paid": "paid",
            "paydate": "paydate",
            "hearing": create_'hearing'().pk,
            "defendant": create_'defendant'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_bail(self):
        bail = create_bail()
        url = reverse('casemgmt_bail_detail', args=[bail.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_bail(self):
        bail = create_bail()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "amountgranted": "amountgranted",
            "noofsureties": "noofsureties",
            "paid": "paid",
            "paydate": "paydate",
            "hearing": create_'hearing'().pk,
            "defendant": create_'defendant'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_bail_update', args=[bail.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class BailSuretyViewTest(unittest.TestCase):
    '''
    Tests for BailSurety
    '''
    def setUp(self):
        self.client = Client()

    def test_list_bailsurety(self):
        url = reverse('casemgmt_bailsurety_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_bailsurety(self):
        url = reverse('casemgmt_bailsurety_create')
        data = {
            "bail": create_bail().pk,
            "surety": create_'surety'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_bailsurety(self):
        bailsurety = create_bailsurety()
        url = reverse('casemgmt_bailsurety_detail', args=[bailsurety.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_bailsurety(self):
        bailsurety = create_bailsurety()
        data = {
            "bail": create_bail().pk,
            "surety": create_'surety'().pk,
        }
        url = reverse('casemgmt_bailsurety_update', args=[bailsurety.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class BailSuretyVersionViewTest(unittest.TestCase):
    '''
    Tests for BailSuretyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_bailsuretyversion(self):
        url = reverse('casemgmt_bailsuretyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_bailsuretyversion(self):
        url = reverse('casemgmt_bailsuretyversion_create')
        data = {
            "bail": "bail",
            "surety": "surety",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_bailsuretyversion(self):
        bailsuretyversion = create_bailsuretyversion()
        url = reverse('casemgmt_bailsuretyversion_detail', args=[bailsuretyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_bailsuretyversion(self):
        bailsuretyversion = create_bailsuretyversion()
        data = {
            "bail": "bail",
            "surety": "surety",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_bailsuretyversion_update', args=[bailsuretyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class BailVersionViewTest(unittest.TestCase):
    '''
    Tests for BailVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_bailversion(self):
        url = reverse('casemgmt_bailversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_bailversion(self):
        url = reverse('casemgmt_bailversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "hearing": "hearing",
            "defendant": "defendant",
            "amountgranted": "amountgranted",
            "noofsureties": "noofsureties",
            "paid": "paid",
            "paydate": "paydate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_bailversion(self):
        bailversion = create_bailversion()
        url = reverse('casemgmt_bailversion_detail', args=[bailversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_bailversion(self):
        bailversion = create_bailversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "hearing": "hearing",
            "defendant": "defendant",
            "amountgranted": "amountgranted",
            "noofsureties": "noofsureties",
            "paid": "paid",
            "paydate": "paydate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_bailversion_update', args=[bailversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseViewTest(unittest.TestCase):
    '''
    Tests for Case
    '''
    def setUp(self):
        self.client = Client()

    def test_list_case(self):
        url = reverse('casemgmt_case_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_case(self):
        url = reverse('casemgmt_case_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "born_digital": "born_digital",
            "ob_number": "ob_number",
            "report_date": "report_date",
            "complaint": "complaint",
            "is_criminal": "is_criminal",
            "priority": "priority",
            "should_investigate_further": "should_investigate_further",
            "evaluation_conclusion": "evaluation_conclusion",
            "investigation_assigment_date": "investigation_assigment_date",
            "investigation_assignment_note": "investigation_assignment_note",
            "investigation_plan": "investigation_plan",
            "investigation_summary": "investigation_summary",
            "investigation_review": "investigation_review",
            "investigation_complete": "investigation_complete",
            "dpp_advice_requested": "dpp_advice_requested",
            "dpp_advice_request_date": "dpp_advice_request_date",
            "dpp_advice_date": "dpp_advice_date",
            "dpp_advice": "dpp_advice",
            "send_to_trial": "send_to_trial",
            "case_name": "case_name",
            "docketnumber": "docketnumber",
            "charge_sheet": "charge_sheet",
            "charge_date": "charge_date",
            "prosecution_notes": "prosecution_notes",
            "defense_notes": "defense_notes",
            "judgement": "judgement",
            "judgement_date": "judgement_date",
            "sentence_length_years": "sentence_length_years",
            "sentence_length_months": "sentence_length_months",
            "senetence_length_days": "senetence_length_days",
            "sentence_start_date": "sentence_start_date",
            "sentence_end_date": "sentence_end_date",
            "fine_amount": "fine_amount",
            "case_appealed": "case_appealed",
            "appeal_date": "appeal_date",
            "appeal_granted": "appeal_granted",
            "appeal_expiry": "appeal_expiry",
            "case_closed": "case_closed",
            "close_date": "close_date",
            "police_station_reported": create_'policestation'().pk,
            "reported_to": create_'polofficer'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_case(self):
        case = create_case()
        url = reverse('casemgmt_case_detail', args=[case.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_case(self):
        case = create_case()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "born_digital": "born_digital",
            "ob_number": "ob_number",
            "report_date": "report_date",
            "complaint": "complaint",
            "is_criminal": "is_criminal",
            "priority": "priority",
            "should_investigate_further": "should_investigate_further",
            "evaluation_conclusion": "evaluation_conclusion",
            "investigation_assigment_date": "investigation_assigment_date",
            "investigation_assignment_note": "investigation_assignment_note",
            "investigation_plan": "investigation_plan",
            "investigation_summary": "investigation_summary",
            "investigation_review": "investigation_review",
            "investigation_complete": "investigation_complete",
            "dpp_advice_requested": "dpp_advice_requested",
            "dpp_advice_request_date": "dpp_advice_request_date",
            "dpp_advice_date": "dpp_advice_date",
            "dpp_advice": "dpp_advice",
            "send_to_trial": "send_to_trial",
            "case_name": "case_name",
            "docketnumber": "docketnumber",
            "charge_sheet": "charge_sheet",
            "charge_date": "charge_date",
            "prosecution_notes": "prosecution_notes",
            "defense_notes": "defense_notes",
            "judgement": "judgement",
            "judgement_date": "judgement_date",
            "sentence_length_years": "sentence_length_years",
            "sentence_length_months": "sentence_length_months",
            "senetence_length_days": "senetence_length_days",
            "sentence_start_date": "sentence_start_date",
            "sentence_end_date": "sentence_end_date",
            "fine_amount": "fine_amount",
            "case_appealed": "case_appealed",
            "appeal_date": "appeal_date",
            "appeal_granted": "appeal_granted",
            "appeal_expiry": "appeal_expiry",
            "case_closed": "case_closed",
            "close_date": "close_date",
            "police_station_reported": create_'policestation'().pk,
            "reported_to": create_'polofficer'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_case_update', args=[case.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseCasecategoryViewTest(unittest.TestCase):
    '''
    Tests for CaseCasecategory
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecasecategory(self):
        url = reverse('casemgmt_casecasecategory_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecasecategory(self):
        url = reverse('casemgmt_casecasecategory_create')
        data = {
            "case": create_case().pk,
            "casecategory": create_'casecategory'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecasecategory(self):
        casecasecategory = create_casecasecategory()
        url = reverse('casemgmt_casecasecategory_detail', args=[casecasecategory.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecasecategory(self):
        casecasecategory = create_casecasecategory()
        data = {
            "case": create_case().pk,
            "casecategory": create_'casecategory'().pk,
        }
        url = reverse('casemgmt_casecasecategory_update', args=[casecasecategory.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseCasecategoryVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseCasecategoryVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecasecategoryversion(self):
        url = reverse('casemgmt_casecasecategoryversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecasecategoryversion(self):
        url = reverse('casemgmt_casecasecategoryversion_create')
        data = {
            "case": "case",
            "casecategory": "casecategory",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecasecategoryversion(self):
        casecasecategoryversion = create_casecasecategoryversion()
        url = reverse('casemgmt_casecasecategoryversion_detail', args=[casecasecategoryversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecasecategoryversion(self):
        casecasecategoryversion = create_casecasecategoryversion()
        data = {
            "case": "case",
            "casecategory": "casecategory",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casecasecategoryversion_update', args=[casecasecategoryversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseCauseofactionViewTest(unittest.TestCase):
    '''
    Tests for CaseCauseofaction
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecauseofaction(self):
        url = reverse('casemgmt_casecauseofaction_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecauseofaction(self):
        url = reverse('casemgmt_casecauseofaction_create')
        data = {
            "case": create_case().pk,
            "causeofaction": create_'causeofaction'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecauseofaction(self):
        casecauseofaction = create_casecauseofaction()
        url = reverse('casemgmt_casecauseofaction_detail', args=[casecauseofaction.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecauseofaction(self):
        casecauseofaction = create_casecauseofaction()
        data = {
            "case": create_case().pk,
            "causeofaction": create_'causeofaction'().pk,
        }
        url = reverse('casemgmt_casecauseofaction_update', args=[casecauseofaction.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseCauseofactionVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseCauseofactionVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecauseofactionversion(self):
        url = reverse('casemgmt_casecauseofactionversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecauseofactionversion(self):
        url = reverse('casemgmt_casecauseofactionversion_create')
        data = {
            "case": "case",
            "causeofaction": "causeofaction",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecauseofactionversion(self):
        casecauseofactionversion = create_casecauseofactionversion()
        url = reverse('casemgmt_casecauseofactionversion_detail', args=[casecauseofactionversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecauseofactionversion(self):
        casecauseofactionversion = create_casecauseofactionversion()
        data = {
            "case": "case",
            "causeofaction": "causeofaction",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casecauseofactionversion_update', args=[casecauseofactionversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseDefendantViewTest(unittest.TestCase):
    '''
    Tests for CaseDefendant
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casedefendant(self):
        url = reverse('casemgmt_casedefendant_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casedefendant(self):
        url = reverse('casemgmt_casedefendant_create')
        data = {
            "case": create_case().pk,
            "defendant": create_'defendant'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casedefendant(self):
        casedefendant = create_casedefendant()
        url = reverse('casemgmt_casedefendant_detail', args=[casedefendant.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casedefendant(self):
        casedefendant = create_casedefendant()
        data = {
            "case": create_case().pk,
            "defendant": create_'defendant'().pk,
        }
        url = reverse('casemgmt_casedefendant_update', args=[casedefendant.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseDefendantVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseDefendantVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casedefendantversion(self):
        url = reverse('casemgmt_casedefendantversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casedefendantversion(self):
        url = reverse('casemgmt_casedefendantversion_create')
        data = {
            "case": "case",
            "defendant": "defendant",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casedefendantversion(self):
        casedefendantversion = create_casedefendantversion()
        url = reverse('casemgmt_casedefendantversion_detail', args=[casedefendantversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casedefendantversion(self):
        casedefendantversion = create_casedefendantversion()
        data = {
            "case": "case",
            "defendant": "defendant",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casedefendantversion_update', args=[casedefendantversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseNatureofsuitViewTest(unittest.TestCase):
    '''
    Tests for CaseNatureofsuit
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casenatureofsuit(self):
        url = reverse('casemgmt_casenatureofsuit_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casenatureofsuit(self):
        url = reverse('casemgmt_casenatureofsuit_create')
        data = {
            "case": create_case().pk,
            "natureofsuit": create_'natureofsuit'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casenatureofsuit(self):
        casenatureofsuit = create_casenatureofsuit()
        url = reverse('casemgmt_casenatureofsuit_detail', args=[casenatureofsuit.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casenatureofsuit(self):
        casenatureofsuit = create_casenatureofsuit()
        data = {
            "case": create_case().pk,
            "natureofsuit": create_'natureofsuit'().pk,
        }
        url = reverse('casemgmt_casenatureofsuit_update', args=[casenatureofsuit.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseNatureofsuitVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseNatureofsuitVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casenatureofsuitversion(self):
        url = reverse('casemgmt_casenatureofsuitversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casenatureofsuitversion(self):
        url = reverse('casemgmt_casenatureofsuitversion_create')
        data = {
            "case": "case",
            "natureofsuit": "natureofsuit",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casenatureofsuitversion(self):
        casenatureofsuitversion = create_casenatureofsuitversion()
        url = reverse('casemgmt_casenatureofsuitversion_detail', args=[casenatureofsuitversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casenatureofsuitversion(self):
        casenatureofsuitversion = create_casenatureofsuitversion()
        data = {
            "case": "case",
            "natureofsuit": "natureofsuit",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casenatureofsuitversion_update', args=[casenatureofsuitversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasePlaintiffViewTest(unittest.TestCase):
    '''
    Tests for CasePlaintiff
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseplaintiff(self):
        url = reverse('casemgmt_caseplaintiff_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseplaintiff(self):
        url = reverse('casemgmt_caseplaintiff_create')
        data = {
            "case": create_case().pk,
            "plaintiff": create_'plaintiff'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseplaintiff(self):
        caseplaintiff = create_caseplaintiff()
        url = reverse('casemgmt_caseplaintiff_detail', args=[caseplaintiff.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseplaintiff(self):
        caseplaintiff = create_caseplaintiff()
        data = {
            "case": create_case().pk,
            "plaintiff": create_'plaintiff'().pk,
        }
        url = reverse('casemgmt_caseplaintiff_update', args=[caseplaintiff.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasePlaintiffVersionViewTest(unittest.TestCase):
    '''
    Tests for CasePlaintiffVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseplaintiffversion(self):
        url = reverse('casemgmt_caseplaintiffversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseplaintiffversion(self):
        url = reverse('casemgmt_caseplaintiffversion_create')
        data = {
            "case": "case",
            "plaintiff": "plaintiff",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseplaintiffversion(self):
        caseplaintiffversion = create_caseplaintiffversion()
        url = reverse('casemgmt_caseplaintiffversion_detail', args=[caseplaintiffversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseplaintiffversion(self):
        caseplaintiffversion = create_caseplaintiffversion()
        data = {
            "case": "case",
            "plaintiff": "plaintiff",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_caseplaintiffversion_update', args=[caseplaintiffversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasePolofficerViewTest(unittest.TestCase):
    '''
    Tests for CasePolofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casepolofficer(self):
        url = reverse('casemgmt_casepolofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casepolofficer(self):
        url = reverse('casemgmt_casepolofficer_create')
        data = {
            "case": create_case().pk,
            "polofficer": create_'polofficer'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casepolofficer(self):
        casepolofficer = create_casepolofficer()
        url = reverse('casemgmt_casepolofficer_detail', args=[casepolofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casepolofficer(self):
        casepolofficer = create_casepolofficer()
        data = {
            "case": create_case().pk,
            "polofficer": create_'polofficer'().pk,
        }
        url = reverse('casemgmt_casepolofficer_update', args=[casepolofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasePolofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for CasePolofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casepolofficerversion(self):
        url = reverse('casemgmt_casepolofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casepolofficerversion(self):
        url = reverse('casemgmt_casepolofficerversion_create')
        data = {
            "case": "case",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casepolofficerversion(self):
        casepolofficerversion = create_casepolofficerversion()
        url = reverse('casemgmt_casepolofficerversion_detail', args=[casepolofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casepolofficerversion(self):
        casepolofficerversion = create_casepolofficerversion()
        data = {
            "case": "case",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casepolofficerversion_update', args=[casepolofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseProsecutorViewTest(unittest.TestCase):
    '''
    Tests for CaseProsecutor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseprosecutor(self):
        url = reverse('casemgmt_caseprosecutor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseprosecutor(self):
        url = reverse('casemgmt_caseprosecutor_create')
        data = {
            "case": create_case().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseprosecutor(self):
        caseprosecutor = create_caseprosecutor()
        url = reverse('casemgmt_caseprosecutor_detail', args=[caseprosecutor.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseprosecutor(self):
        caseprosecutor = create_caseprosecutor()
        data = {
            "case": create_case().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        url = reverse('casemgmt_caseprosecutor_update', args=[caseprosecutor.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseProsecutor2ViewTest(unittest.TestCase):
    '''
    Tests for CaseProsecutor2
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseprosecutor2(self):
        url = reverse('casemgmt_caseprosecutor2_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseprosecutor2(self):
        url = reverse('casemgmt_caseprosecutor2_create')
        data = {
            "case": create_case().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseprosecutor2(self):
        caseprosecutor2 = create_caseprosecutor2()
        url = reverse('casemgmt_caseprosecutor2_detail', args=[caseprosecutor2.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseprosecutor2(self):
        caseprosecutor2 = create_caseprosecutor2()
        data = {
            "case": create_case().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        url = reverse('casemgmt_caseprosecutor2_update', args=[caseprosecutor2.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseProsecutor2VersionViewTest(unittest.TestCase):
    '''
    Tests for CaseProsecutor2Version
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseprosecutor2version(self):
        url = reverse('casemgmt_caseprosecutor2version_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseprosecutor2version(self):
        url = reverse('casemgmt_caseprosecutor2version_create')
        data = {
            "case": "case",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseprosecutor2version(self):
        caseprosecutor2version = create_caseprosecutor2version()
        url = reverse('casemgmt_caseprosecutor2version_detail', args=[caseprosecutor2version.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseprosecutor2version(self):
        caseprosecutor2version = create_caseprosecutor2version()
        data = {
            "case": "case",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_caseprosecutor2version_update', args=[caseprosecutor2version.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseProsecutorVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseProsecutorVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseprosecutorversion(self):
        url = reverse('casemgmt_caseprosecutorversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseprosecutorversion(self):
        url = reverse('casemgmt_caseprosecutorversion_create')
        data = {
            "case": "case",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseprosecutorversion(self):
        caseprosecutorversion = create_caseprosecutorversion()
        url = reverse('casemgmt_caseprosecutorversion_detail', args=[caseprosecutorversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseprosecutorversion(self):
        caseprosecutorversion = create_caseprosecutorversion()
        data = {
            "case": "case",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_caseprosecutorversion_update', args=[caseprosecutorversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseTagViewTest(unittest.TestCase):
    '''
    Tests for CaseTag
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casetag(self):
        url = reverse('casemgmt_casetag_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casetag(self):
        url = reverse('casemgmt_casetag_create')
        data = {
            "case": create_case().pk,
            "tag": create_'tag'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casetag(self):
        casetag = create_casetag()
        url = reverse('casemgmt_casetag_detail', args=[casetag.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casetag(self):
        casetag = create_casetag()
        data = {
            "case": create_case().pk,
            "tag": create_'tag'().pk,
        }
        url = reverse('casemgmt_casetag_update', args=[casetag.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseTagVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseTagVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casetagversion(self):
        url = reverse('casemgmt_casetagversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casetagversion(self):
        url = reverse('casemgmt_casetagversion_create')
        data = {
            "case": "case",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casetagversion(self):
        casetagversion = create_casetagversion()
        url = reverse('casemgmt_casetagversion_detail', args=[casetagversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casetagversion(self):
        casetagversion = create_casetagversion()
        data = {
            "case": "case",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casetagversion_update', args=[casetagversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseversion(self):
        url = reverse('casemgmt_caseversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseversion(self):
        url = reverse('casemgmt_caseversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "born_digital": "born_digital",
            "ob_number": "ob_number",
            "police_station_reported": "police_station_reported",
            "report_date": "report_date",
            "complaint": "complaint",
            "is_criminal": "is_criminal",
            "priority": "priority",
            "should_investigate_further": "should_investigate_further",
            "evaluation_conclusion": "evaluation_conclusion",
            "investigation_assigment_date": "investigation_assigment_date",
            "investigation_assignment_note": "investigation_assignment_note",
            "investigation_plan": "investigation_plan",
            "investigation_summary": "investigation_summary",
            "investigation_review": "investigation_review",
            "investigation_complete": "investigation_complete",
            "dpp_advice_requested": "dpp_advice_requested",
            "dpp_advice_request_date": "dpp_advice_request_date",
            "dpp_advice_date": "dpp_advice_date",
            "dpp_advice": "dpp_advice",
            "send_to_trial": "send_to_trial",
            "case_name": "case_name",
            "docketnumber": "docketnumber",
            "charge_sheet": "charge_sheet",
            "charge_date": "charge_date",
            "prosecution_notes": "prosecution_notes",
            "defense_notes": "defense_notes",
            "judgement": "judgement",
            "judgement_date": "judgement_date",
            "sentence_length_years": "sentence_length_years",
            "sentence_length_months": "sentence_length_months",
            "senetence_length_days": "senetence_length_days",
            "sentence_start_date": "sentence_start_date",
            "sentence_end_date": "sentence_end_date",
            "fine_amount": "fine_amount",
            "case_appealed": "case_appealed",
            "appeal_date": "appeal_date",
            "appeal_granted": "appeal_granted",
            "appeal_expiry": "appeal_expiry",
            "case_closed": "case_closed",
            "close_date": "close_date",
            "reported_to": "reported_to",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseversion(self):
        caseversion = create_caseversion()
        url = reverse('casemgmt_caseversion_detail', args=[caseversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseversion(self):
        caseversion = create_caseversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "born_digital": "born_digital",
            "ob_number": "ob_number",
            "police_station_reported": "police_station_reported",
            "report_date": "report_date",
            "complaint": "complaint",
            "is_criminal": "is_criminal",
            "priority": "priority",
            "should_investigate_further": "should_investigate_further",
            "evaluation_conclusion": "evaluation_conclusion",
            "investigation_assigment_date": "investigation_assigment_date",
            "investigation_assignment_note": "investigation_assignment_note",
            "investigation_plan": "investigation_plan",
            "investigation_summary": "investigation_summary",
            "investigation_review": "investigation_review",
            "investigation_complete": "investigation_complete",
            "dpp_advice_requested": "dpp_advice_requested",
            "dpp_advice_request_date": "dpp_advice_request_date",
            "dpp_advice_date": "dpp_advice_date",
            "dpp_advice": "dpp_advice",
            "send_to_trial": "send_to_trial",
            "case_name": "case_name",
            "docketnumber": "docketnumber",
            "charge_sheet": "charge_sheet",
            "charge_date": "charge_date",
            "prosecution_notes": "prosecution_notes",
            "defense_notes": "defense_notes",
            "judgement": "judgement",
            "judgement_date": "judgement_date",
            "sentence_length_years": "sentence_length_years",
            "sentence_length_months": "sentence_length_months",
            "senetence_length_days": "senetence_length_days",
            "sentence_start_date": "sentence_start_date",
            "sentence_end_date": "sentence_end_date",
            "fine_amount": "fine_amount",
            "case_appealed": "case_appealed",
            "appeal_date": "appeal_date",
            "appeal_granted": "appeal_granted",
            "appeal_expiry": "appeal_expiry",
            "case_closed": "case_closed",
            "close_date": "close_date",
            "reported_to": "reported_to",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_caseversion_update', args=[caseversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseWitnessViewTest(unittest.TestCase):
    '''
    Tests for CaseWitness
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casewitness(self):
        url = reverse('casemgmt_casewitness_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casewitness(self):
        url = reverse('casemgmt_casewitness_create')
        data = {
            "case": create_case().pk,
            "witness": create_'witness'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casewitness(self):
        casewitness = create_casewitness()
        url = reverse('casemgmt_casewitness_detail', args=[casewitness.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casewitness(self):
        casewitness = create_casewitness()
        data = {
            "case": create_case().pk,
            "witness": create_'witness'().pk,
        }
        url = reverse('casemgmt_casewitness_update', args=[casewitness.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseWitnessVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseWitnessVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casewitnessversion(self):
        url = reverse('casemgmt_casewitnessversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casewitnessversion(self):
        url = reverse('casemgmt_casewitnessversion_create')
        data = {
            "case": "case",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casewitnessversion(self):
        casewitnessversion = create_casewitnessversion()
        url = reverse('casemgmt_casewitnessversion_detail', args=[casewitnessversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casewitnessversion(self):
        casewitnessversion = create_casewitnessversion()
        data = {
            "case": "case",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casewitnessversion_update', args=[casewitnessversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasecategoryViewTest(unittest.TestCase):
    '''
    Tests for Casecategory
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecategory(self):
        url = reverse('casemgmt_casecategory_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecategory(self):
        url = reverse('casemgmt_casecategory_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "indictable": "indictable",
            "is_criminal": "is_criminal",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecategory(self):
        casecategory = create_casecategory()
        url = reverse('casemgmt_casecategory_detail', args=[casecategory.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecategory(self):
        casecategory = create_casecategory()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "indictable": "indictable",
            "is_criminal": "is_criminal",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_casecategory_update', args=[casecategory.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CasecategoryVersionViewTest(unittest.TestCase):
    '''
    Tests for CasecategoryVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_casecategoryversion(self):
        url = reverse('casemgmt_casecategoryversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_casecategoryversion(self):
        url = reverse('casemgmt_casecategoryversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "indictable": "indictable",
            "is_criminal": "is_criminal",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_casecategoryversion(self):
        casecategoryversion = create_casecategoryversion()
        url = reverse('casemgmt_casecategoryversion_detail', args=[casecategoryversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_casecategoryversion(self):
        casecategoryversion = create_casecategoryversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "indictable": "indictable",
            "is_criminal": "is_criminal",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_casecategoryversion_update', args=[casecategoryversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseinvestigationViewTest(unittest.TestCase):
    '''
    Tests for Caseinvestigation
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseinvestigation(self):
        url = reverse('casemgmt_caseinvestigation_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseinvestigation(self):
        url = reverse('casemgmt_caseinvestigation_create')
        data = {
            "pol_officers": create_'polofficer'().pk,
            "cases": create_case().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseinvestigation(self):
        caseinvestigation = create_caseinvestigation()
        url = reverse('casemgmt_caseinvestigation_detail', args=[caseinvestigation.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseinvestigation(self):
        caseinvestigation = create_caseinvestigation()
        data = {
            "pol_officers": create_'polofficer'().pk,
            "cases": create_case().pk,
        }
        url = reverse('casemgmt_caseinvestigation_update', args=[caseinvestigation.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CaseinvestigationVersionViewTest(unittest.TestCase):
    '''
    Tests for CaseinvestigationVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_caseinvestigationversion(self):
        url = reverse('casemgmt_caseinvestigationversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_caseinvestigationversion(self):
        url = reverse('casemgmt_caseinvestigationversion_create')
        data = {
            "pol_officers": "pol_officers",
            "cases": "cases",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_caseinvestigationversion(self):
        caseinvestigationversion = create_caseinvestigationversion()
        url = reverse('casemgmt_caseinvestigationversion_detail', args=[caseinvestigationversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_caseinvestigationversion(self):
        caseinvestigationversion = create_caseinvestigationversion()
        data = {
            "pol_officers": "pol_officers",
            "cases": "cases",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_caseinvestigationversion_update', args=[caseinvestigationversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionViewTest(unittest.TestCase):
    '''
    Tests for Causeofaction
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofaction(self):
        url = reverse('casemgmt_causeofaction_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofaction(self):
        url = reverse('casemgmt_causeofaction_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "criminal": "criminal",
            "parent_coa": create_'self'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofaction(self):
        causeofaction = create_causeofaction()
        url = reverse('casemgmt_causeofaction_detail', args=[causeofaction.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofaction(self):
        causeofaction = create_causeofaction()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "criminal": "criminal",
            "parent_coa": create_'self'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_causeofaction_update', args=[causeofaction.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionFilingViewTest(unittest.TestCase):
    '''
    Tests for CauseofactionFiling
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofactionfiling(self):
        url = reverse('casemgmt_causeofactionfiling_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofactionfiling(self):
        url = reverse('casemgmt_causeofactionfiling_create')
        data = {
            "causeofaction": create_causeofaction().pk,
            "filing": create_'filing'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofactionfiling(self):
        causeofactionfiling = create_causeofactionfiling()
        url = reverse('casemgmt_causeofactionfiling_detail', args=[causeofactionfiling.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofactionfiling(self):
        causeofactionfiling = create_causeofactionfiling()
        data = {
            "causeofaction": create_causeofaction().pk,
            "filing": create_'filing'().pk,
        }
        url = reverse('casemgmt_causeofactionfiling_update', args=[causeofactionfiling.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionFilingVersionViewTest(unittest.TestCase):
    '''
    Tests for CauseofactionFilingVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofactionfilingversion(self):
        url = reverse('casemgmt_causeofactionfilingversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofactionfilingversion(self):
        url = reverse('casemgmt_causeofactionfilingversion_create')
        data = {
            "causeofaction": "causeofaction",
            "filing": "filing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofactionfilingversion(self):
        causeofactionfilingversion = create_causeofactionfilingversion()
        url = reverse('casemgmt_causeofactionfilingversion_detail', args=[causeofactionfilingversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofactionfilingversion(self):
        causeofactionfilingversion = create_causeofactionfilingversion()
        data = {
            "causeofaction": "causeofaction",
            "filing": "filing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_causeofactionfilingversion_update', args=[causeofactionfilingversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionHearingViewTest(unittest.TestCase):
    '''
    Tests for CauseofactionHearing
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofactionhearing(self):
        url = reverse('casemgmt_causeofactionhearing_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofactionhearing(self):
        url = reverse('casemgmt_causeofactionhearing_create')
        data = {
            "causeofaction": create_causeofaction().pk,
            "hearing": create_'hearing'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofactionhearing(self):
        causeofactionhearing = create_causeofactionhearing()
        url = reverse('casemgmt_causeofactionhearing_detail', args=[causeofactionhearing.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofactionhearing(self):
        causeofactionhearing = create_causeofactionhearing()
        data = {
            "causeofaction": create_causeofaction().pk,
            "hearing": create_'hearing'().pk,
        }
        url = reverse('casemgmt_causeofactionhearing_update', args=[causeofactionhearing.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionHearingVersionViewTest(unittest.TestCase):
    '''
    Tests for CauseofactionHearingVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofactionhearingversion(self):
        url = reverse('casemgmt_causeofactionhearingversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofactionhearingversion(self):
        url = reverse('casemgmt_causeofactionhearingversion_create')
        data = {
            "causeofaction": "causeofaction",
            "hearing": "hearing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofactionhearingversion(self):
        causeofactionhearingversion = create_causeofactionhearingversion()
        url = reverse('casemgmt_causeofactionhearingversion_detail', args=[causeofactionhearingversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofactionhearingversion(self):
        causeofactionhearingversion = create_causeofactionhearingversion()
        data = {
            "causeofaction": "causeofaction",
            "hearing": "hearing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_causeofactionhearingversion_update', args=[causeofactionhearingversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CauseofactionVersionViewTest(unittest.TestCase):
    '''
    Tests for CauseofactionVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_causeofactionversion(self):
        url = reverse('casemgmt_causeofactionversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_causeofactionversion(self):
        url = reverse('casemgmt_causeofactionversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "criminal": "criminal",
            "parent_coa": "parent_coa",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_causeofactionversion(self):
        causeofactionversion = create_causeofactionversion()
        url = reverse('casemgmt_causeofactionversion_detail', args=[causeofactionversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_causeofactionversion(self):
        causeofactionversion = create_causeofactionversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "criminal": "criminal",
            "parent_coa": "parent_coa",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_causeofactionversion_update', args=[causeofactionversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CommitaltypeViewTest(unittest.TestCase):
    '''
    Tests for Commitaltype
    '''
    def setUp(self):
        self.client = Client()

    def test_list_commitaltype(self):
        url = reverse('casemgmt_commitaltype_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_commitaltype(self):
        url = reverse('casemgmt_commitaltype_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_commitaltype(self):
        commitaltype = create_commitaltype()
        url = reverse('casemgmt_commitaltype_detail', args=[commitaltype.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_commitaltype(self):
        commitaltype = create_commitaltype()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_commitaltype_update', args=[commitaltype.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CommitaltypePrisoncommitalViewTest(unittest.TestCase):
    '''
    Tests for CommitaltypePrisoncommital
    '''
    def setUp(self):
        self.client = Client()

    def test_list_commitaltypeprisoncommital(self):
        url = reverse('casemgmt_commitaltypeprisoncommital_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_commitaltypeprisoncommital(self):
        url = reverse('casemgmt_commitaltypeprisoncommital_create')
        data = {
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "commitaltype": create_commitaltype().pk,
            "prisoncommital_prison": create_'prisoncommital'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_commitaltypeprisoncommital(self):
        commitaltypeprisoncommital = create_commitaltypeprisoncommital()
        url = reverse('casemgmt_commitaltypeprisoncommital_detail', args=[commitaltypeprisoncommital.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_commitaltypeprisoncommital(self):
        commitaltypeprisoncommital = create_commitaltypeprisoncommital()
        data = {
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "commitaltype": create_commitaltype().pk,
            "prisoncommital_prison": create_'prisoncommital'().pk,
        }
        url = reverse('casemgmt_commitaltypeprisoncommital_update', args=[commitaltypeprisoncommital.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CommitaltypePrisoncommitalVersionViewTest(unittest.TestCase):
    '''
    Tests for CommitaltypePrisoncommitalVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_commitaltypeprisoncommitalversion(self):
        url = reverse('casemgmt_commitaltypeprisoncommitalversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_commitaltypeprisoncommitalversion(self):
        url = reverse('casemgmt_commitaltypeprisoncommitalversion_create')
        data = {
            "commitaltype": "commitaltype",
            "prisoncommital_prison": "prisoncommital_prison",
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_commitaltypeprisoncommitalversion(self):
        commitaltypeprisoncommitalversion = create_commitaltypeprisoncommitalversion()
        url = reverse('casemgmt_commitaltypeprisoncommitalversion_detail', args=[commitaltypeprisoncommitalversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_commitaltypeprisoncommitalversion(self):
        commitaltypeprisoncommitalversion = create_commitaltypeprisoncommitalversion()
        data = {
            "commitaltype": "commitaltype",
            "prisoncommital_prison": "prisoncommital_prison",
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_commitaltypeprisoncommitalversion_update', args=[commitaltypeprisoncommitalversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CommitaltypeVersionViewTest(unittest.TestCase):
    '''
    Tests for CommitaltypeVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_commitaltypeversion(self):
        url = reverse('casemgmt_commitaltypeversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_commitaltypeversion(self):
        url = reverse('casemgmt_commitaltypeversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_commitaltypeversion(self):
        commitaltypeversion = create_commitaltypeversion()
        url = reverse('casemgmt_commitaltypeversion_detail', args=[commitaltypeversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_commitaltypeversion(self):
        commitaltypeversion = create_commitaltypeversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_commitaltypeversion_update', args=[commitaltypeversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ConstituencyViewTest(unittest.TestCase):
    '''
    Tests for Constituency
    '''
    def setUp(self):
        self.client = Client()

    def test_list_constituency(self):
        url = reverse('casemgmt_constituency_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_constituency(self):
        url = reverse('casemgmt_constituency_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "county": create_'county'().pk,
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_constituency(self):
        constituency = create_constituency()
        url = reverse('casemgmt_constituency_detail', args=[constituency.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_constituency(self):
        constituency = create_constituency()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "county": create_'county'().pk,
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_constituency_update', args=[constituency.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ConstituencyVersionViewTest(unittest.TestCase):
    '''
    Tests for ConstituencyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_constituencyversion(self):
        url = reverse('casemgmt_constituencyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_constituencyversion(self):
        url = reverse('casemgmt_constituencyversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "county": "county",
            "town": "town",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_constituencyversion(self):
        constituencyversion = create_constituencyversion()
        url = reverse('casemgmt_constituencyversion_detail', args=[constituencyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_constituencyversion(self):
        constituencyversion = create_constituencyversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "county": "county",
            "town": "town",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_constituencyversion_update', args=[constituencyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CountyViewTest(unittest.TestCase):
    '''
    Tests for County
    '''
    def setUp(self):
        self.client = Client()

    def test_list_county(self):
        url = reverse('casemgmt_county_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_county(self):
        url = reverse('casemgmt_county_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_county(self):
        county = create_county()
        url = reverse('casemgmt_county_detail', args=[county.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_county(self):
        county = create_county()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_county_update', args=[county.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CountyVersionViewTest(unittest.TestCase):
    '''
    Tests for CountyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_countyversion(self):
        url = reverse('casemgmt_countyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_countyversion(self):
        url = reverse('casemgmt_countyversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_countyversion(self):
        countyversion = create_countyversion()
        url = reverse('casemgmt_countyversion_detail', args=[countyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_countyversion(self):
        countyversion = create_countyversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_countyversion_update', args=[countyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtViewTest(unittest.TestCase):
    '''
    Tests for Court
    '''
    def setUp(self):
        self.client = Client()

    def test_list_court(self):
        url = reverse('casemgmt_court_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_court(self):
        url = reverse('casemgmt_court_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "court_station": create_'courtstation'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_court(self):
        court = create_court()
        url = reverse('casemgmt_court_detail', args=[court.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_court(self):
        court = create_court()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "court_station": create_'courtstation'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_court_update', args=[court.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtVersionViewTest(unittest.TestCase):
    '''
    Tests for CourtVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_courtversion(self):
        url = reverse('casemgmt_courtversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_courtversion(self):
        url = reverse('casemgmt_courtversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "court_station": "court_station",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_courtversion(self):
        courtversion = create_courtversion()
        url = reverse('casemgmt_courtversion_detail', args=[courtversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_courtversion(self):
        courtversion = create_courtversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "court_station": "court_station",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_courtversion_update', args=[courtversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtlevelViewTest(unittest.TestCase):
    '''
    Tests for Courtlevel
    '''
    def setUp(self):
        self.client = Client()

    def test_list_courtlevel(self):
        url = reverse('casemgmt_courtlevel_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_courtlevel(self):
        url = reverse('casemgmt_courtlevel_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_courtlevel(self):
        courtlevel = create_courtlevel()
        url = reverse('casemgmt_courtlevel_detail', args=[courtlevel.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_courtlevel(self):
        courtlevel = create_courtlevel()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_courtlevel_update', args=[courtlevel.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtlevelVersionViewTest(unittest.TestCase):
    '''
    Tests for CourtlevelVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_courtlevelversion(self):
        url = reverse('casemgmt_courtlevelversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_courtlevelversion(self):
        url = reverse('casemgmt_courtlevelversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_courtlevelversion(self):
        courtlevelversion = create_courtlevelversion()
        url = reverse('casemgmt_courtlevelversion_detail', args=[courtlevelversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_courtlevelversion(self):
        courtlevelversion = create_courtlevelversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_courtlevelversion_update', args=[courtlevelversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtstationViewTest(unittest.TestCase):
    '''
    Tests for Courtstation
    '''
    def setUp(self):
        self.client = Client()

    def test_list_courtstation(self):
        url = reverse('casemgmt_courtstation_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_courtstation(self):
        url = reverse('casemgmt_courtstation_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "residentmagistrate": "residentmagistrate",
            "registrar": "registrar",
            "num_of_courts": "num_of_courts",
            "court_level": create_courtlevel().pk,
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_courtstation(self):
        courtstation = create_courtstation()
        url = reverse('casemgmt_courtstation_detail', args=[courtstation.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_courtstation(self):
        courtstation = create_courtstation()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "residentmagistrate": "residentmagistrate",
            "registrar": "registrar",
            "num_of_courts": "num_of_courts",
            "court_level": create_courtlevel().pk,
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_courtstation_update', args=[courtstation.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class CourtstationVersionViewTest(unittest.TestCase):
    '''
    Tests for CourtstationVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_courtstationversion(self):
        url = reverse('casemgmt_courtstationversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_courtstationversion(self):
        url = reverse('casemgmt_courtstationversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "residentmagistrate": "residentmagistrate",
            "registrar": "registrar",
            "court_level": "court_level",
            "num_of_courts": "num_of_courts",
            "town": "town",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_courtstationversion(self):
        courtstationversion = create_courtstationversion()
        url = reverse('casemgmt_courtstationversion_detail', args=[courtstationversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_courtstationversion(self):
        courtstationversion = create_courtstationversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "residentmagistrate": "residentmagistrate",
            "registrar": "registrar",
            "court_level": "court_level",
            "num_of_courts": "num_of_courts",
            "town": "town",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_courtstationversion_update', args=[courtstationversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantViewTest(unittest.TestCase):
    '''
    Tests for Defendant
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendant(self):
        url = reverse('casemgmt_defendant_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendant(self):
        url = reverse('casemgmt_defendant_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "allergies": "allergies",
            "chronic_conditions": "chronic_conditions",
            "chronic_medications": "chronic_medications",
            "hbp": "hbp",
            "diabetes": "diabetes",
            "hiv": "hiv",
            "current_health_status": "current_health_status",
            "bc_id": "bc_id",
            "bc_number": "bc_number",
            "bc_serial": "bc_serial",
            "bc_place": "bc_place",
            "bc_scan": "bc_scan",
            "citizenship": "citizenship",
            "nat_id_num": "nat_id_num",
            "nat_id_serial": "nat_id_serial",
            "nat_id_scan": "nat_id_scan",
            "pp_no": "pp_no",
            "pp_issue_date": "pp_issue_date",
            "pp_issue_place": "pp_issue_place",
            "pp_scan": "pp_scan",
            "pp_expiry_date": "pp_expiry_date",
            "kin1_name": "kin1_name",
            "kin1_phone": "kin1_phone",
            "kin1_email": "kin1_email",
            "kin1_addr": "kin1_addr",
            "kin2_name": "kin2_name",
            "kin1_relation": "kin1_relation",
            "kin2_phone": "kin2_phone",
            "kin2_email": "kin2_email",
            "kin2_addr": "kin2_addr",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "blood_group": "blood_group",
            "striking_features": "striking_features",
            "height_m": "height_m",
            "weight_kg": "weight_kg",
            "eye_colour": "eye_colour",
            "hair_colour": "hair_colour",
            "complexion": "complexion",
            "religion": "religion",
            "ethnicity": "ethnicity",
            "fp_lthumb": "fp_lthumb",
            "pgm": "pgm",
            "wsq": "wsq",
            "xyt": "xyt",
            "fp_left2": "fp_left2",
            "fp_left3": "fp_left3",
            "fp_left4": "fp_left4",
            "fp_left5": "fp_left5",
            "fp_rthumb": "fp_rthumb",
            "fp_right2": "fp_right2",
            "fp_right3": "fp_right3",
            "fp_right4": "fp_right4",
            "fp_right5": "fp_right5",
            "palm_left": "palm_left",
            "palm_right": "palm_right",
            "eye_left": "eye_left",
            "eye_right": "eye_right",
            "employed": "employed",
            "employer": "employer",
            "employer_contact": "employer_contact",
            "employ_date": "employ_date",
            "employ_duration": "employ_duration",
            "termination_date": "termination_date",
            "employ_role": "employ_role",
            "supervisor": "supervisor",
            "supervisor_contact": "supervisor_contact",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "juvenile": "juvenile",
            "casecount": "casecount",
            "gender": create_'gender'().pk,
            "prisoncell": create_'prisoncell'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendant(self):
        defendant = create_defendant()
        url = reverse('casemgmt_defendant_detail', args=[defendant.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendant(self):
        defendant = create_defendant()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "allergies": "allergies",
            "chronic_conditions": "chronic_conditions",
            "chronic_medications": "chronic_medications",
            "hbp": "hbp",
            "diabetes": "diabetes",
            "hiv": "hiv",
            "current_health_status": "current_health_status",
            "bc_id": "bc_id",
            "bc_number": "bc_number",
            "bc_serial": "bc_serial",
            "bc_place": "bc_place",
            "bc_scan": "bc_scan",
            "citizenship": "citizenship",
            "nat_id_num": "nat_id_num",
            "nat_id_serial": "nat_id_serial",
            "nat_id_scan": "nat_id_scan",
            "pp_no": "pp_no",
            "pp_issue_date": "pp_issue_date",
            "pp_issue_place": "pp_issue_place",
            "pp_scan": "pp_scan",
            "pp_expiry_date": "pp_expiry_date",
            "kin1_name": "kin1_name",
            "kin1_phone": "kin1_phone",
            "kin1_email": "kin1_email",
            "kin1_addr": "kin1_addr",
            "kin2_name": "kin2_name",
            "kin1_relation": "kin1_relation",
            "kin2_phone": "kin2_phone",
            "kin2_email": "kin2_email",
            "kin2_addr": "kin2_addr",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "blood_group": "blood_group",
            "striking_features": "striking_features",
            "height_m": "height_m",
            "weight_kg": "weight_kg",
            "eye_colour": "eye_colour",
            "hair_colour": "hair_colour",
            "complexion": "complexion",
            "religion": "religion",
            "ethnicity": "ethnicity",
            "fp_lthumb": "fp_lthumb",
            "pgm": "pgm",
            "wsq": "wsq",
            "xyt": "xyt",
            "fp_left2": "fp_left2",
            "fp_left3": "fp_left3",
            "fp_left4": "fp_left4",
            "fp_left5": "fp_left5",
            "fp_rthumb": "fp_rthumb",
            "fp_right2": "fp_right2",
            "fp_right3": "fp_right3",
            "fp_right4": "fp_right4",
            "fp_right5": "fp_right5",
            "palm_left": "palm_left",
            "palm_right": "palm_right",
            "eye_left": "eye_left",
            "eye_right": "eye_right",
            "employed": "employed",
            "employer": "employer",
            "employer_contact": "employer_contact",
            "employ_date": "employ_date",
            "employ_duration": "employ_duration",
            "termination_date": "termination_date",
            "employ_role": "employ_role",
            "supervisor": "supervisor",
            "supervisor_contact": "supervisor_contact",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "juvenile": "juvenile",
            "casecount": "casecount",
            "gender": create_'gender'().pk,
            "prisoncell": create_'prisoncell'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_defendant_update', args=[defendant.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantGateregisterViewTest(unittest.TestCase):
    '''
    Tests for DefendantGateregister
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendantgateregister(self):
        url = reverse('casemgmt_defendantgateregister_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendantgateregister(self):
        url = reverse('casemgmt_defendantgateregister_create')
        data = {
            "defendant": create_defendant().pk,
            "gateregister": create_'gateregister'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendantgateregister(self):
        defendantgateregister = create_defendantgateregister()
        url = reverse('casemgmt_defendantgateregister_detail', args=[defendantgateregister.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendantgateregister(self):
        defendantgateregister = create_defendantgateregister()
        data = {
            "defendant": create_defendant().pk,
            "gateregister": create_'gateregister'().pk,
        }
        url = reverse('casemgmt_defendantgateregister_update', args=[defendantgateregister.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantGateregisterVersionViewTest(unittest.TestCase):
    '''
    Tests for DefendantGateregisterVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendantgateregisterversion(self):
        url = reverse('casemgmt_defendantgateregisterversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendantgateregisterversion(self):
        url = reverse('casemgmt_defendantgateregisterversion_create')
        data = {
            "defendant": "defendant",
            "gateregister": "gateregister",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendantgateregisterversion(self):
        defendantgateregisterversion = create_defendantgateregisterversion()
        url = reverse('casemgmt_defendantgateregisterversion_detail', args=[defendantgateregisterversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendantgateregisterversion(self):
        defendantgateregisterversion = create_defendantgateregisterversion()
        data = {
            "defendant": "defendant",
            "gateregister": "gateregister",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_defendantgateregisterversion_update', args=[defendantgateregisterversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantHearingViewTest(unittest.TestCase):
    '''
    Tests for DefendantHearing
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendanthearing(self):
        url = reverse('casemgmt_defendanthearing_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendanthearing(self):
        url = reverse('casemgmt_defendanthearing_create')
        data = {
            "defendant": create_defendant().pk,
            "hearing": create_'hearing'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendanthearing(self):
        defendanthearing = create_defendanthearing()
        url = reverse('casemgmt_defendanthearing_detail', args=[defendanthearing.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendanthearing(self):
        defendanthearing = create_defendanthearing()
        data = {
            "defendant": create_defendant().pk,
            "hearing": create_'hearing'().pk,
        }
        url = reverse('casemgmt_defendanthearing_update', args=[defendanthearing.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantHearingVersionViewTest(unittest.TestCase):
    '''
    Tests for DefendantHearingVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendanthearingversion(self):
        url = reverse('casemgmt_defendanthearingversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendanthearingversion(self):
        url = reverse('casemgmt_defendanthearingversion_create')
        data = {
            "defendant": "defendant",
            "hearing": "hearing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendanthearingversion(self):
        defendanthearingversion = create_defendanthearingversion()
        url = reverse('casemgmt_defendanthearingversion_detail', args=[defendanthearingversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendanthearingversion(self):
        defendanthearingversion = create_defendanthearingversion()
        data = {
            "defendant": "defendant",
            "hearing": "hearing",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_defendanthearingversion_update', args=[defendanthearingversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantMedeventViewTest(unittest.TestCase):
    '''
    Tests for DefendantMedevent
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendantmedevent(self):
        url = reverse('casemgmt_defendantmedevent_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendantmedevent(self):
        url = reverse('casemgmt_defendantmedevent_create')
        data = {
            "defendant": create_defendant().pk,
            "medevent": create_'medevent'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendantmedevent(self):
        defendantmedevent = create_defendantmedevent()
        url = reverse('casemgmt_defendantmedevent_detail', args=[defendantmedevent.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendantmedevent(self):
        defendantmedevent = create_defendantmedevent()
        data = {
            "defendant": create_defendant().pk,
            "medevent": create_'medevent'().pk,
        }
        url = reverse('casemgmt_defendantmedevent_update', args=[defendantmedevent.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantMedeventVersionViewTest(unittest.TestCase):
    '''
    Tests for DefendantMedeventVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendantmedeventversion(self):
        url = reverse('casemgmt_defendantmedeventversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendantmedeventversion(self):
        url = reverse('casemgmt_defendantmedeventversion_create')
        data = {
            "defendant": "defendant",
            "medevent": "medevent",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendantmedeventversion(self):
        defendantmedeventversion = create_defendantmedeventversion()
        url = reverse('casemgmt_defendantmedeventversion_detail', args=[defendantmedeventversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendantmedeventversion(self):
        defendantmedeventversion = create_defendantmedeventversion()
        data = {
            "defendant": "defendant",
            "medevent": "medevent",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_defendantmedeventversion_update', args=[defendantmedeventversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DefendantVersionViewTest(unittest.TestCase):
    '''
    Tests for DefendantVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_defendantversion(self):
        url = reverse('casemgmt_defendantversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_defendantversion(self):
        url = reverse('casemgmt_defendantversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "allergies": "allergies",
            "chronic_conditions": "chronic_conditions",
            "chronic_medications": "chronic_medications",
            "hbp": "hbp",
            "diabetes": "diabetes",
            "hiv": "hiv",
            "current_health_status": "current_health_status",
            "bc_id": "bc_id",
            "bc_number": "bc_number",
            "bc_serial": "bc_serial",
            "bc_place": "bc_place",
            "bc_scan": "bc_scan",
            "citizenship": "citizenship",
            "nat_id_num": "nat_id_num",
            "nat_id_serial": "nat_id_serial",
            "nat_id_scan": "nat_id_scan",
            "pp_no": "pp_no",
            "pp_issue_date": "pp_issue_date",
            "pp_issue_place": "pp_issue_place",
            "pp_scan": "pp_scan",
            "pp_expiry_date": "pp_expiry_date",
            "kin1_name": "kin1_name",
            "kin1_phone": "kin1_phone",
            "kin1_email": "kin1_email",
            "kin1_addr": "kin1_addr",
            "kin2_name": "kin2_name",
            "kin1_relation": "kin1_relation",
            "kin2_phone": "kin2_phone",
            "kin2_email": "kin2_email",
            "kin2_addr": "kin2_addr",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "blood_group": "blood_group",
            "striking_features": "striking_features",
            "height_m": "height_m",
            "weight_kg": "weight_kg",
            "eye_colour": "eye_colour",
            "hair_colour": "hair_colour",
            "complexion": "complexion",
            "religion": "religion",
            "ethnicity": "ethnicity",
            "fp_lthumb": "fp_lthumb",
            "pgm": "pgm",
            "wsq": "wsq",
            "xyt": "xyt",
            "fp_left2": "fp_left2",
            "fp_left3": "fp_left3",
            "fp_left4": "fp_left4",
            "fp_left5": "fp_left5",
            "fp_rthumb": "fp_rthumb",
            "fp_right2": "fp_right2",
            "fp_right3": "fp_right3",
            "fp_right4": "fp_right4",
            "fp_right5": "fp_right5",
            "palm_left": "palm_left",
            "palm_right": "palm_right",
            "eye_left": "eye_left",
            "eye_right": "eye_right",
            "employed": "employed",
            "employer": "employer",
            "employer_contact": "employer_contact",
            "employ_date": "employ_date",
            "employ_duration": "employ_duration",
            "termination_date": "termination_date",
            "employ_role": "employ_role",
            "supervisor": "supervisor",
            "supervisor_contact": "supervisor_contact",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "juvenile": "juvenile",
            "gender": "gender",
            "prisoncell": "prisoncell",
            "casecount": "casecount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_defendantversion(self):
        defendantversion = create_defendantversion()
        url = reverse('casemgmt_defendantversion_detail', args=[defendantversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_defendantversion(self):
        defendantversion = create_defendantversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "allergies": "allergies",
            "chronic_conditions": "chronic_conditions",
            "chronic_medications": "chronic_medications",
            "hbp": "hbp",
            "diabetes": "diabetes",
            "hiv": "hiv",
            "current_health_status": "current_health_status",
            "bc_id": "bc_id",
            "bc_number": "bc_number",
            "bc_serial": "bc_serial",
            "bc_place": "bc_place",
            "bc_scan": "bc_scan",
            "citizenship": "citizenship",
            "nat_id_num": "nat_id_num",
            "nat_id_serial": "nat_id_serial",
            "nat_id_scan": "nat_id_scan",
            "pp_no": "pp_no",
            "pp_issue_date": "pp_issue_date",
            "pp_issue_place": "pp_issue_place",
            "pp_scan": "pp_scan",
            "pp_expiry_date": "pp_expiry_date",
            "kin1_name": "kin1_name",
            "kin1_phone": "kin1_phone",
            "kin1_email": "kin1_email",
            "kin1_addr": "kin1_addr",
            "kin2_name": "kin2_name",
            "kin1_relation": "kin1_relation",
            "kin2_phone": "kin2_phone",
            "kin2_email": "kin2_email",
            "kin2_addr": "kin2_addr",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "blood_group": "blood_group",
            "striking_features": "striking_features",
            "height_m": "height_m",
            "weight_kg": "weight_kg",
            "eye_colour": "eye_colour",
            "hair_colour": "hair_colour",
            "complexion": "complexion",
            "religion": "religion",
            "ethnicity": "ethnicity",
            "fp_lthumb": "fp_lthumb",
            "pgm": "pgm",
            "wsq": "wsq",
            "xyt": "xyt",
            "fp_left2": "fp_left2",
            "fp_left3": "fp_left3",
            "fp_left4": "fp_left4",
            "fp_left5": "fp_left5",
            "fp_rthumb": "fp_rthumb",
            "fp_right2": "fp_right2",
            "fp_right3": "fp_right3",
            "fp_right4": "fp_right4",
            "fp_right5": "fp_right5",
            "palm_left": "palm_left",
            "palm_right": "palm_right",
            "eye_left": "eye_left",
            "eye_right": "eye_right",
            "employed": "employed",
            "employer": "employer",
            "employer_contact": "employer_contact",
            "employ_date": "employ_date",
            "employ_duration": "employ_duration",
            "termination_date": "termination_date",
            "employ_role": "employ_role",
            "supervisor": "supervisor",
            "supervisor_contact": "supervisor_contact",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "juvenile": "juvenile",
            "gender": "gender",
            "prisoncell": "prisoncell",
            "casecount": "casecount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_defendantversion_update', args=[defendantversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DisciplineViewTest(unittest.TestCase):
    '''
    Tests for Discipline
    '''
    def setUp(self):
        self.client = Client()

    def test_list_discipline(self):
        url = reverse('casemgmt_discipline_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_discipline(self):
        url = reverse('casemgmt_discipline_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "defendant": create_defendant().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_discipline(self):
        discipline = create_discipline()
        url = reverse('casemgmt_discipline_detail', args=[discipline.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_discipline(self):
        discipline = create_discipline()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "defendant": create_defendant().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_discipline_update', args=[discipline.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DisciplineVersionViewTest(unittest.TestCase):
    '''
    Tests for DisciplineVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_disciplineversion(self):
        url = reverse('casemgmt_disciplineversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_disciplineversion(self):
        url = reverse('casemgmt_disciplineversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "defendant": "defendant",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_disciplineversion(self):
        disciplineversion = create_disciplineversion()
        url = reverse('casemgmt_disciplineversion_detail', args=[disciplineversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_disciplineversion(self):
        disciplineversion = create_disciplineversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "defendant": "defendant",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_disciplineversion_update', args=[disciplineversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocStoreViewTest(unittest.TestCase):
    '''
    Tests for DocStore
    '''
    def setUp(self):
        self.client = Client()

    def test_list_docstore(self):
        url = reverse('casemgmt_docstore_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_docstore(self):
        url = reverse('casemgmt_docstore_create')
        data = {
            "name": "name",
            "description": "description",
            "notes": "notes",
            "data": "data",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_docstore(self):
        docstore = create_docstore()
        url = reverse('casemgmt_docstore_detail', args=[docstore.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_docstore(self):
        docstore = create_docstore()
        data = {
            "name": "name",
            "description": "description",
            "notes": "notes",
            "data": "data",
        }
        url = reverse('casemgmt_docstore_update', args=[docstore.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocarchiveViewTest(unittest.TestCase):
    '''
    Tests for Docarchive
    '''
    def setUp(self):
        self.client = Client()

    def test_list_docarchive(self):
        url = reverse('casemgmt_docarchive_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_docarchive(self):
        url = reverse('casemgmt_docarchive_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "doc": "doc",
            "scandate": "scandate",
            "archival": "archival",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_docarchive(self):
        docarchive = create_docarchive()
        url = reverse('casemgmt_docarchive_detail', args=[docarchive.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_docarchive(self):
        docarchive = create_docarchive()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "doc": "doc",
            "scandate": "scandate",
            "archival": "archival",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_docarchive_update', args=[docarchive.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocarchiveTagViewTest(unittest.TestCase):
    '''
    Tests for DocarchiveTag
    '''
    def setUp(self):
        self.client = Client()

    def test_list_docarchivetag(self):
        url = reverse('casemgmt_docarchivetag_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_docarchivetag(self):
        url = reverse('casemgmt_docarchivetag_create')
        data = {
            "docarchive": create_docarchive().pk,
            "tag": create_'tag'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_docarchivetag(self):
        docarchivetag = create_docarchivetag()
        url = reverse('casemgmt_docarchivetag_detail', args=[docarchivetag.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_docarchivetag(self):
        docarchivetag = create_docarchivetag()
        data = {
            "docarchive": create_docarchive().pk,
            "tag": create_'tag'().pk,
        }
        url = reverse('casemgmt_docarchivetag_update', args=[docarchivetag.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocarchiveTagVersionViewTest(unittest.TestCase):
    '''
    Tests for DocarchiveTagVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_docarchivetagversion(self):
        url = reverse('casemgmt_docarchivetagversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_docarchivetagversion(self):
        url = reverse('casemgmt_docarchivetagversion_create')
        data = {
            "docarchive": "docarchive",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_docarchivetagversion(self):
        docarchivetagversion = create_docarchivetagversion()
        url = reverse('casemgmt_docarchivetagversion_detail', args=[docarchivetagversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_docarchivetagversion(self):
        docarchivetagversion = create_docarchivetagversion()
        data = {
            "docarchive": "docarchive",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_docarchivetagversion_update', args=[docarchivetagversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocarchiveVersionViewTest(unittest.TestCase):
    '''
    Tests for DocarchiveVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_docarchiveversion(self):
        url = reverse('casemgmt_docarchiveversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_docarchiveversion(self):
        url = reverse('casemgmt_docarchiveversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "name": "name",
            "doc": "doc",
            "scandate": "scandate",
            "archival": "archival",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_docarchiveversion(self):
        docarchiveversion = create_docarchiveversion()
        url = reverse('casemgmt_docarchiveversion_detail', args=[docarchiveversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_docarchiveversion(self):
        docarchiveversion = create_docarchiveversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "name": "name",
            "doc": "doc",
            "scandate": "scandate",
            "archival": "archival",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_docarchiveversion_update', args=[docarchiveversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DoctemplateViewTest(unittest.TestCase):
    '''
    Tests for Doctemplate
    '''
    def setUp(self):
        self.client = Client()

    def test_list_doctemplate(self):
        url = reverse('casemgmt_doctemplate_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_doctemplate(self):
        url = reverse('casemgmt_doctemplate_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_doctemplate(self):
        doctemplate = create_doctemplate()
        url = reverse('casemgmt_doctemplate_detail', args=[doctemplate.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_doctemplate(self):
        doctemplate = create_doctemplate()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_doctemplate_update', args=[doctemplate.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DoctemplateVersionViewTest(unittest.TestCase):
    '''
    Tests for DoctemplateVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_doctemplateversion(self):
        url = reverse('casemgmt_doctemplateversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_doctemplateversion(self):
        url = reverse('casemgmt_doctemplateversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_doctemplateversion(self):
        doctemplateversion = create_doctemplateversion()
        url = reverse('casemgmt_doctemplateversion_detail', args=[doctemplateversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_doctemplateversion(self):
        doctemplateversion = create_doctemplateversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_doctemplateversion_update', args=[doctemplateversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocumentViewTest(unittest.TestCase):
    '''
    Tests for Document
    '''
    def setUp(self):
        self.client = Client()

    def test_list_document(self):
        url = reverse('casemgmt_document_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_document(self):
        url = reverse('casemgmt_document_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "confidential": "confidential",
            "pagecount": "pagecount",
            "locked": "locked",
            "hash": "hash",
            "filing": create_'filing'().pk,
            "doc_template": create_doctemplate().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_document(self):
        document = create_document()
        url = reverse('casemgmt_document_detail', args=[document.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_document(self):
        document = create_document()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "confidential": "confidential",
            "pagecount": "pagecount",
            "locked": "locked",
            "hash": "hash",
            "filing": create_'filing'().pk,
            "doc_template": create_doctemplate().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_document_update', args=[document.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocumentTagViewTest(unittest.TestCase):
    '''
    Tests for DocumentTag
    '''
    def setUp(self):
        self.client = Client()

    def test_list_documenttag(self):
        url = reverse('casemgmt_documenttag_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_documenttag(self):
        url = reverse('casemgmt_documenttag_create')
        data = {
            "document": create_document().pk,
            "tag": create_'tag'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_documenttag(self):
        documenttag = create_documenttag()
        url = reverse('casemgmt_documenttag_detail', args=[documenttag.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_documenttag(self):
        documenttag = create_documenttag()
        data = {
            "document": create_document().pk,
            "tag": create_'tag'().pk,
        }
        url = reverse('casemgmt_documenttag_update', args=[documenttag.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocumentTagVersionViewTest(unittest.TestCase):
    '''
    Tests for DocumentTagVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_documenttagversion(self):
        url = reverse('casemgmt_documenttagversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_documenttagversion(self):
        url = reverse('casemgmt_documenttagversion_create')
        data = {
            "document": "document",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_documenttagversion(self):
        documenttagversion = create_documenttagversion()
        url = reverse('casemgmt_documenttagversion_detail', args=[documenttagversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_documenttagversion(self):
        documenttagversion = create_documenttagversion()
        data = {
            "document": "document",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_documenttagversion_update', args=[documenttagversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class DocumentVersionViewTest(unittest.TestCase):
    '''
    Tests for DocumentVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_documentversion(self):
        url = reverse('casemgmt_documentversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_documentversion(self):
        url = reverse('casemgmt_documentversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "id": "id",
            "filing": "filing",
            "doc_template": "doc_template",
            "confidential": "confidential",
            "pagecount": "pagecount",
            "locked": "locked",
            "hash": "hash",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_documentversion(self):
        documentversion = create_documentversion()
        url = reverse('casemgmt_documentversion_detail', args=[documentversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_documentversion(self):
        documentversion = create_documentversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "mime_type": "mime_type",
            "doc": "doc",
            "doc_text": "doc_text",
            "doc_binary": "doc_binary",
            "doc_title": "doc_title",
            "subject": "subject",
            "author": "author",
            "keywords": "keywords",
            "comments": "comments",
            "doc_type": "doc_type",
            "char_count": "char_count",
            "word_count": "word_count",
            "lines": "lines",
            "paragraphs": "paragraphs",
            "file_size_bytes": "file_size_bytes",
            "producer_prog": "producer_prog",
            "immutable": "immutable",
            "page_size": "page_size",
            "page_count": "page_count",
            "hashx": "hashx",
            "audio_duration_secs": "audio_duration_secs",
            "audio_frame_rate": "audio_frame_rate",
            "audio_channels": "audio_channels",
            "id": "id",
            "filing": "filing",
            "doc_template": "doc_template",
            "confidential": "confidential",
            "pagecount": "pagecount",
            "locked": "locked",
            "hash": "hash",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_documentversion_update', args=[documentversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class EventlogViewTest(unittest.TestCase):
    '''
    Tests for Eventlog
    '''
    def setUp(self):
        self.client = Client()

    def test_list_eventlog(self):
        url = reverse('casemgmt_eventlog_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_eventlog(self):
        url = reverse('casemgmt_eventlog_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "temporal": "temporal",
            "event": "event",
            "severity": "severity",
            "alert": "alert",
            "notes": "notes",
            "tbl": "tbl",
            "colname": "colname",
            "colbefore": "colbefore",
            "colafter": "colafter",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_eventlog(self):
        eventlog = create_eventlog()
        url = reverse('casemgmt_eventlog_detail', args=[eventlog.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_eventlog(self):
        eventlog = create_eventlog()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "temporal": "temporal",
            "event": "event",
            "severity": "severity",
            "alert": "alert",
            "notes": "notes",
            "tbl": "tbl",
            "colname": "colname",
            "colbefore": "colbefore",
            "colafter": "colafter",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_eventlog_update', args=[eventlog.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class EventlogVersionViewTest(unittest.TestCase):
    '''
    Tests for EventlogVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_eventlogversion(self):
        url = reverse('casemgmt_eventlogversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_eventlogversion(self):
        url = reverse('casemgmt_eventlogversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "temporal": "temporal",
            "event": "event",
            "severity": "severity",
            "alert": "alert",
            "notes": "notes",
            "tbl": "tbl",
            "colname": "colname",
            "colbefore": "colbefore",
            "colafter": "colafter",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_eventlogversion(self):
        eventlogversion = create_eventlogversion()
        url = reverse('casemgmt_eventlogversion_detail', args=[eventlogversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_eventlogversion(self):
        eventlogversion = create_eventlogversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "temporal": "temporal",
            "event": "event",
            "severity": "severity",
            "alert": "alert",
            "notes": "notes",
            "tbl": "tbl",
            "colname": "colname",
            "colbefore": "colbefore",
            "colafter": "colafter",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_eventlogversion_update', args=[eventlogversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingViewTest(unittest.TestCase):
    '''
    Tests for Filing
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filing(self):
        url = reverse('casemgmt_filing_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filing(self):
        url = reverse('casemgmt_filing_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "uploaddate": "uploaddate",
            "pagecount": "pagecount",
            "totalfees": "totalfees",
            "assessedfees": "assessedfees",
            "receiptverified": "receiptverified",
            "amountpaid": "amountpaid",
            "feebalance": "feebalance",
            "paymenthistory": "paymenthistory",
            "urgent": "urgent",
            "urgentreason": "urgentreason",
            "filing_attorney": create_'lawyers'().pk,
            "filing_prosecutor": create_'prosecutor'().pk,
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filing(self):
        filing = create_filing()
        url = reverse('casemgmt_filing_detail', args=[filing.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filing(self):
        filing = create_filing()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "uploaddate": "uploaddate",
            "pagecount": "pagecount",
            "totalfees": "totalfees",
            "assessedfees": "assessedfees",
            "receiptverified": "receiptverified",
            "amountpaid": "amountpaid",
            "feebalance": "feebalance",
            "paymenthistory": "paymenthistory",
            "urgent": "urgent",
            "urgentreason": "urgentreason",
            "filing_attorney": create_'lawyers'().pk,
            "filing_prosecutor": create_'prosecutor'().pk,
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_filing_update', args=[filing.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingFilingtypeViewTest(unittest.TestCase):
    '''
    Tests for FilingFilingtype
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingfilingtype(self):
        url = reverse('casemgmt_filingfilingtype_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingfilingtype(self):
        url = reverse('casemgmt_filingfilingtype_create')
        data = {
            "filing": create_filing().pk,
            "filingtype": create_'filingtype'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingfilingtype(self):
        filingfilingtype = create_filingfilingtype()
        url = reverse('casemgmt_filingfilingtype_detail', args=[filingfilingtype.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingfilingtype(self):
        filingfilingtype = create_filingfilingtype()
        data = {
            "filing": create_filing().pk,
            "filingtype": create_'filingtype'().pk,
        }
        url = reverse('casemgmt_filingfilingtype_update', args=[filingfilingtype.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingFilingtypeVersionViewTest(unittest.TestCase):
    '''
    Tests for FilingFilingtypeVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingfilingtypeversion(self):
        url = reverse('casemgmt_filingfilingtypeversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingfilingtypeversion(self):
        url = reverse('casemgmt_filingfilingtypeversion_create')
        data = {
            "filing": "filing",
            "filingtype": "filingtype",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingfilingtypeversion(self):
        filingfilingtypeversion = create_filingfilingtypeversion()
        url = reverse('casemgmt_filingfilingtypeversion_detail', args=[filingfilingtypeversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingfilingtypeversion(self):
        filingfilingtypeversion = create_filingfilingtypeversion()
        data = {
            "filing": "filing",
            "filingtype": "filingtype",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_filingfilingtypeversion_update', args=[filingfilingtypeversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingPaymentViewTest(unittest.TestCase):
    '''
    Tests for FilingPayment
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingpayment(self):
        url = reverse('casemgmt_filingpayment_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingpayment(self):
        url = reverse('casemgmt_filingpayment_create')
        data = {
            "filing": create_filing().pk,
            "payment": create_'payment'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingpayment(self):
        filingpayment = create_filingpayment()
        url = reverse('casemgmt_filingpayment_detail', args=[filingpayment.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingpayment(self):
        filingpayment = create_filingpayment()
        data = {
            "filing": create_filing().pk,
            "payment": create_'payment'().pk,
        }
        url = reverse('casemgmt_filingpayment_update', args=[filingpayment.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingPaymentVersionViewTest(unittest.TestCase):
    '''
    Tests for FilingPaymentVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingpaymentversion(self):
        url = reverse('casemgmt_filingpaymentversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingpaymentversion(self):
        url = reverse('casemgmt_filingpaymentversion_create')
        data = {
            "filing": "filing",
            "payment": "payment",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingpaymentversion(self):
        filingpaymentversion = create_filingpaymentversion()
        url = reverse('casemgmt_filingpaymentversion_detail', args=[filingpaymentversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingpaymentversion(self):
        filingpaymentversion = create_filingpaymentversion()
        data = {
            "filing": "filing",
            "payment": "payment",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_filingpaymentversion_update', args=[filingpaymentversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingVersionViewTest(unittest.TestCase):
    '''
    Tests for FilingVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingversion(self):
        url = reverse('casemgmt_filingversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingversion(self):
        url = reverse('casemgmt_filingversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "uploaddate": "uploaddate",
            "pagecount": "pagecount",
            "totalfees": "totalfees",
            "filing_attorney": "filing_attorney",
            "filing_prosecutor": "filing_prosecutor",
            "assessedfees": "assessedfees",
            "receiptverified": "receiptverified",
            "amountpaid": "amountpaid",
            "feebalance": "feebalance",
            "paymenthistory": "paymenthistory",
            "case": "case",
            "urgent": "urgent",
            "urgentreason": "urgentreason",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingversion(self):
        filingversion = create_filingversion()
        url = reverse('casemgmt_filingversion_detail', args=[filingversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingversion(self):
        filingversion = create_filingversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "uploaddate": "uploaddate",
            "pagecount": "pagecount",
            "totalfees": "totalfees",
            "filing_attorney": "filing_attorney",
            "filing_prosecutor": "filing_prosecutor",
            "assessedfees": "assessedfees",
            "receiptverified": "receiptverified",
            "amountpaid": "amountpaid",
            "feebalance": "feebalance",
            "paymenthistory": "paymenthistory",
            "case": "case",
            "urgent": "urgent",
            "urgentreason": "urgentreason",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_filingversion_update', args=[filingversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingtypeViewTest(unittest.TestCase):
    '''
    Tests for Filingtype
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingtype(self):
        url = reverse('casemgmt_filingtype_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingtype(self):
        url = reverse('casemgmt_filingtype_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "fees": "fees",
            "perpagecost": "perpagecost",
            "paid_per_page": "paid_per_page",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingtype(self):
        filingtype = create_filingtype()
        url = reverse('casemgmt_filingtype_detail', args=[filingtype.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingtype(self):
        filingtype = create_filingtype()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "fees": "fees",
            "perpagecost": "perpagecost",
            "paid_per_page": "paid_per_page",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_filingtype_update', args=[filingtype.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class FilingtypeVersionViewTest(unittest.TestCase):
    '''
    Tests for FilingtypeVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_filingtypeversion(self):
        url = reverse('casemgmt_filingtypeversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_filingtypeversion(self):
        url = reverse('casemgmt_filingtypeversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "fees": "fees",
            "perpagecost": "perpagecost",
            "paid_per_page": "paid_per_page",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_filingtypeversion(self):
        filingtypeversion = create_filingtypeversion()
        url = reverse('casemgmt_filingtypeversion_detail', args=[filingtypeversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_filingtypeversion(self):
        filingtypeversion = create_filingtypeversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "fees": "fees",
            "perpagecost": "perpagecost",
            "paid_per_page": "paid_per_page",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_filingtypeversion_update', args=[filingtypeversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterViewTest(unittest.TestCase):
    '''
    Tests for Gateregister
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregister(self):
        url = reverse('casemgmt_gateregister_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregister(self):
        url = reverse('casemgmt_gateregister_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "opentime": "opentime",
            "closedtime": "closedtime",
            "movementdirection": "movementdirection",
            "reason": "reason",
            "staffmovement": "staffmovement",
            "goodsmovement": "goodsmovement",
            "vehicle_reg": "vehicle_reg",
            "vehicle_color": "vehicle_color",
            "prison": create_'prison'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregister(self):
        gateregister = create_gateregister()
        url = reverse('casemgmt_gateregister_detail', args=[gateregister.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregister(self):
        gateregister = create_gateregister()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "opentime": "opentime",
            "closedtime": "closedtime",
            "movementdirection": "movementdirection",
            "reason": "reason",
            "staffmovement": "staffmovement",
            "goodsmovement": "goodsmovement",
            "vehicle_reg": "vehicle_reg",
            "vehicle_color": "vehicle_color",
            "prison": create_'prison'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_gateregister_update', args=[gateregister.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterVersionViewTest(unittest.TestCase):
    '''
    Tests for GateregisterVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregisterversion(self):
        url = reverse('casemgmt_gateregisterversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregisterversion(self):
        url = reverse('casemgmt_gateregisterversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison": "prison",
            "opentime": "opentime",
            "closedtime": "closedtime",
            "movementdirection": "movementdirection",
            "reason": "reason",
            "staffmovement": "staffmovement",
            "goodsmovement": "goodsmovement",
            "vehicle_reg": "vehicle_reg",
            "vehicle_color": "vehicle_color",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregisterversion(self):
        gateregisterversion = create_gateregisterversion()
        url = reverse('casemgmt_gateregisterversion_detail', args=[gateregisterversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregisterversion(self):
        gateregisterversion = create_gateregisterversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison": "prison",
            "opentime": "opentime",
            "closedtime": "closedtime",
            "movementdirection": "movementdirection",
            "reason": "reason",
            "staffmovement": "staffmovement",
            "goodsmovement": "goodsmovement",
            "vehicle_reg": "vehicle_reg",
            "vehicle_color": "vehicle_color",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_gateregisterversion_update', args=[gateregisterversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterWarderViewTest(unittest.TestCase):
    '''
    Tests for GateregisterWarder
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregisterwarder(self):
        url = reverse('casemgmt_gateregisterwarder_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregisterwarder(self):
        url = reverse('casemgmt_gateregisterwarder_create')
        data = {
            "gateregister": create_gateregister().pk,
            "warder": create_'warder'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregisterwarder(self):
        gateregisterwarder = create_gateregisterwarder()
        url = reverse('casemgmt_gateregisterwarder_detail', args=[gateregisterwarder.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregisterwarder(self):
        gateregisterwarder = create_gateregisterwarder()
        data = {
            "gateregister": create_gateregister().pk,
            "warder": create_'warder'().pk,
        }
        url = reverse('casemgmt_gateregisterwarder_update', args=[gateregisterwarder.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterWarder2ViewTest(unittest.TestCase):
    '''
    Tests for GateregisterWarder2
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregisterwarder2(self):
        url = reverse('casemgmt_gateregisterwarder2_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregisterwarder2(self):
        url = reverse('casemgmt_gateregisterwarder2_create')
        data = {
            "gateregister": create_gateregister().pk,
            "warder": create_'warder'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregisterwarder2(self):
        gateregisterwarder2 = create_gateregisterwarder2()
        url = reverse('casemgmt_gateregisterwarder2_detail', args=[gateregisterwarder2.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregisterwarder2(self):
        gateregisterwarder2 = create_gateregisterwarder2()
        data = {
            "gateregister": create_gateregister().pk,
            "warder": create_'warder'().pk,
        }
        url = reverse('casemgmt_gateregisterwarder2_update', args=[gateregisterwarder2.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterWarder2VersionViewTest(unittest.TestCase):
    '''
    Tests for GateregisterWarder2Version
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregisterwarder2version(self):
        url = reverse('casemgmt_gateregisterwarder2version_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregisterwarder2version(self):
        url = reverse('casemgmt_gateregisterwarder2version_create')
        data = {
            "gateregister": "gateregister",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregisterwarder2version(self):
        gateregisterwarder2version = create_gateregisterwarder2version()
        url = reverse('casemgmt_gateregisterwarder2version_detail', args=[gateregisterwarder2version.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregisterwarder2version(self):
        gateregisterwarder2version = create_gateregisterwarder2version()
        data = {
            "gateregister": "gateregister",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_gateregisterwarder2version_update', args=[gateregisterwarder2version.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GateregisterWarderVersionViewTest(unittest.TestCase):
    '''
    Tests for GateregisterWarderVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gateregisterwarderversion(self):
        url = reverse('casemgmt_gateregisterwarderversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gateregisterwarderversion(self):
        url = reverse('casemgmt_gateregisterwarderversion_create')
        data = {
            "gateregister": "gateregister",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gateregisterwarderversion(self):
        gateregisterwarderversion = create_gateregisterwarderversion()
        url = reverse('casemgmt_gateregisterwarderversion_detail', args=[gateregisterwarderversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gateregisterwarderversion(self):
        gateregisterwarderversion = create_gateregisterwarderversion()
        data = {
            "gateregister": "gateregister",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_gateregisterwarderversion_update', args=[gateregisterwarderversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GenderViewTest(unittest.TestCase):
    '''
    Tests for Gender
    '''
    def setUp(self):
        self.client = Client()

    def test_list_gender(self):
        url = reverse('casemgmt_gender_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_gender(self):
        url = reverse('casemgmt_gender_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "description": "description",
            "notes": "notes",
            "name": "name",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_gender(self):
        gender = create_gender()
        url = reverse('casemgmt_gender_detail', args=[gender.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_gender(self):
        gender = create_gender()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "description": "description",
            "notes": "notes",
            "name": "name",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_gender_update', args=[gender.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class GenderVersionViewTest(unittest.TestCase):
    '''
    Tests for GenderVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_genderversion(self):
        url = reverse('casemgmt_genderversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_genderversion(self):
        url = reverse('casemgmt_genderversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "name": "name",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_genderversion(self):
        genderversion = create_genderversion()
        url = reverse('casemgmt_genderversion_detail', args=[genderversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_genderversion(self):
        genderversion = create_genderversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "name": "name",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_genderversion_update', args=[genderversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingViewTest(unittest.TestCase):
    '''
    Tests for Hearing
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearing(self):
        url = reverse('casemgmt_hearing_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearing(self):
        url = reverse('casemgmt_hearing_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "hearingdate": "hearingdate",
            "adjourned": "adjourned",
            "completed": "completed",
            "remandwarrant": "remandwarrant",
            "remanddays": "remanddays",
            "remanddate": "remanddate",
            "remandwarrantexpirydate": "remandwarrantexpirydate",
            "nexthearingdate": "nexthearingdate",
            "finalhearing": "finalhearing",
            "transcript": "transcript",
            "audio": "audio",
            "video": "video",
            "case": create_case().pk,
            "court": create_court().pk,
            "hearing_type": create_'hearingtype'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearing(self):
        hearing = create_hearing()
        url = reverse('casemgmt_hearing_detail', args=[hearing.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearing(self):
        hearing = create_hearing()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "hearingdate": "hearingdate",
            "adjourned": "adjourned",
            "completed": "completed",
            "remandwarrant": "remandwarrant",
            "remanddays": "remanddays",
            "remanddate": "remanddate",
            "remandwarrantexpirydate": "remandwarrantexpirydate",
            "nexthearingdate": "nexthearingdate",
            "finalhearing": "finalhearing",
            "transcript": "transcript",
            "audio": "audio",
            "video": "video",
            "case": create_case().pk,
            "court": create_court().pk,
            "hearing_type": create_'hearingtype'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_hearing_update', args=[hearing.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingJudicialofficerViewTest(unittest.TestCase):
    '''
    Tests for HearingJudicialofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingjudicialofficer(self):
        url = reverse('casemgmt_hearingjudicialofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingjudicialofficer(self):
        url = reverse('casemgmt_hearingjudicialofficer_create')
        data = {
            "hearing": create_hearing().pk,
            "judicialofficer": create_'judicialofficer'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingjudicialofficer(self):
        hearingjudicialofficer = create_hearingjudicialofficer()
        url = reverse('casemgmt_hearingjudicialofficer_detail', args=[hearingjudicialofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingjudicialofficer(self):
        hearingjudicialofficer = create_hearingjudicialofficer()
        data = {
            "hearing": create_hearing().pk,
            "judicialofficer": create_'judicialofficer'().pk,
        }
        url = reverse('casemgmt_hearingjudicialofficer_update', args=[hearingjudicialofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingJudicialofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingJudicialofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingjudicialofficerversion(self):
        url = reverse('casemgmt_hearingjudicialofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingjudicialofficerversion(self):
        url = reverse('casemgmt_hearingjudicialofficerversion_create')
        data = {
            "hearing": "hearing",
            "judicialofficer": "judicialofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingjudicialofficerversion(self):
        hearingjudicialofficerversion = create_hearingjudicialofficerversion()
        url = reverse('casemgmt_hearingjudicialofficerversion_detail', args=[hearingjudicialofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingjudicialofficerversion(self):
        hearingjudicialofficerversion = create_hearingjudicialofficerversion()
        data = {
            "hearing": "hearing",
            "judicialofficer": "judicialofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingjudicialofficerversion_update', args=[hearingjudicialofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingLawyersViewTest(unittest.TestCase):
    '''
    Tests for HearingLawyers
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearinglawyers(self):
        url = reverse('casemgmt_hearinglawyers_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearinglawyers(self):
        url = reverse('casemgmt_hearinglawyers_create')
        data = {
            "hearing": create_hearing().pk,
            "lawyers": create_'lawyers'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearinglawyers(self):
        hearinglawyers = create_hearinglawyers()
        url = reverse('casemgmt_hearinglawyers_detail', args=[hearinglawyers.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearinglawyers(self):
        hearinglawyers = create_hearinglawyers()
        data = {
            "hearing": create_hearing().pk,
            "lawyers": create_'lawyers'().pk,
        }
        url = reverse('casemgmt_hearinglawyers_update', args=[hearinglawyers.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingLawyersVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingLawyersVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearinglawyersversion(self):
        url = reverse('casemgmt_hearinglawyersversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearinglawyersversion(self):
        url = reverse('casemgmt_hearinglawyersversion_create')
        data = {
            "hearing": "hearing",
            "lawyers": "lawyers",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearinglawyersversion(self):
        hearinglawyersversion = create_hearinglawyersversion()
        url = reverse('casemgmt_hearinglawyersversion_detail', args=[hearinglawyersversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearinglawyersversion(self):
        hearinglawyersversion = create_hearinglawyersversion()
        data = {
            "hearing": "hearing",
            "lawyers": "lawyers",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearinglawyersversion_update', args=[hearinglawyersversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingPolofficerViewTest(unittest.TestCase):
    '''
    Tests for HearingPolofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingpolofficer(self):
        url = reverse('casemgmt_hearingpolofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingpolofficer(self):
        url = reverse('casemgmt_hearingpolofficer_create')
        data = {
            "hearing": create_hearing().pk,
            "polofficer": create_'polofficer'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingpolofficer(self):
        hearingpolofficer = create_hearingpolofficer()
        url = reverse('casemgmt_hearingpolofficer_detail', args=[hearingpolofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingpolofficer(self):
        hearingpolofficer = create_hearingpolofficer()
        data = {
            "hearing": create_hearing().pk,
            "polofficer": create_'polofficer'().pk,
        }
        url = reverse('casemgmt_hearingpolofficer_update', args=[hearingpolofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingPolofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingPolofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingpolofficerversion(self):
        url = reverse('casemgmt_hearingpolofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingpolofficerversion(self):
        url = reverse('casemgmt_hearingpolofficerversion_create')
        data = {
            "hearing": "hearing",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingpolofficerversion(self):
        hearingpolofficerversion = create_hearingpolofficerversion()
        url = reverse('casemgmt_hearingpolofficerversion_detail', args=[hearingpolofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingpolofficerversion(self):
        hearingpolofficerversion = create_hearingpolofficerversion()
        data = {
            "hearing": "hearing",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingpolofficerversion_update', args=[hearingpolofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingProsecutorViewTest(unittest.TestCase):
    '''
    Tests for HearingProsecutor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingprosecutor(self):
        url = reverse('casemgmt_hearingprosecutor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingprosecutor(self):
        url = reverse('casemgmt_hearingprosecutor_create')
        data = {
            "hearing": create_hearing().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingprosecutor(self):
        hearingprosecutor = create_hearingprosecutor()
        url = reverse('casemgmt_hearingprosecutor_detail', args=[hearingprosecutor.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingprosecutor(self):
        hearingprosecutor = create_hearingprosecutor()
        data = {
            "hearing": create_hearing().pk,
            "prosecutor": create_'prosecutor'().pk,
        }
        url = reverse('casemgmt_hearingprosecutor_update', args=[hearingprosecutor.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingProsecutorVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingProsecutorVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingprosecutorversion(self):
        url = reverse('casemgmt_hearingprosecutorversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingprosecutorversion(self):
        url = reverse('casemgmt_hearingprosecutorversion_create')
        data = {
            "hearing": "hearing",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingprosecutorversion(self):
        hearingprosecutorversion = create_hearingprosecutorversion()
        url = reverse('casemgmt_hearingprosecutorversion_detail', args=[hearingprosecutorversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingprosecutorversion(self):
        hearingprosecutorversion = create_hearingprosecutorversion()
        data = {
            "hearing": "hearing",
            "prosecutor": "prosecutor",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingprosecutorversion_update', args=[hearingprosecutorversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingTagViewTest(unittest.TestCase):
    '''
    Tests for HearingTag
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingtag(self):
        url = reverse('casemgmt_hearingtag_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingtag(self):
        url = reverse('casemgmt_hearingtag_create')
        data = {
            "hearing": create_hearing().pk,
            "tag": create_'tag'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingtag(self):
        hearingtag = create_hearingtag()
        url = reverse('casemgmt_hearingtag_detail', args=[hearingtag.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingtag(self):
        hearingtag = create_hearingtag()
        data = {
            "hearing": create_hearing().pk,
            "tag": create_'tag'().pk,
        }
        url = reverse('casemgmt_hearingtag_update', args=[hearingtag.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingTagVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingTagVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingtagversion(self):
        url = reverse('casemgmt_hearingtagversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingtagversion(self):
        url = reverse('casemgmt_hearingtagversion_create')
        data = {
            "hearing": "hearing",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingtagversion(self):
        hearingtagversion = create_hearingtagversion()
        url = reverse('casemgmt_hearingtagversion_detail', args=[hearingtagversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingtagversion(self):
        hearingtagversion = create_hearingtagversion()
        data = {
            "hearing": "hearing",
            "tag": "tag",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingtagversion_update', args=[hearingtagversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingversion(self):
        url = reverse('casemgmt_hearingversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingversion(self):
        url = reverse('casemgmt_hearingversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "hearingdate": "hearingdate",
            "adjourned": "adjourned",
            "completed": "completed",
            "case": "case",
            "court": "court",
            "remandwarrant": "remandwarrant",
            "hearing_type": "hearing_type",
            "remanddays": "remanddays",
            "remanddate": "remanddate",
            "remandwarrantexpirydate": "remandwarrantexpirydate",
            "nexthearingdate": "nexthearingdate",
            "finalhearing": "finalhearing",
            "transcript": "transcript",
            "audio": "audio",
            "video": "video",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingversion(self):
        hearingversion = create_hearingversion()
        url = reverse('casemgmt_hearingversion_detail', args=[hearingversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingversion(self):
        hearingversion = create_hearingversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "hearingdate": "hearingdate",
            "adjourned": "adjourned",
            "completed": "completed",
            "case": "case",
            "court": "court",
            "remandwarrant": "remandwarrant",
            "hearing_type": "hearing_type",
            "remanddays": "remanddays",
            "remanddate": "remanddate",
            "remandwarrantexpirydate": "remandwarrantexpirydate",
            "nexthearingdate": "nexthearingdate",
            "finalhearing": "finalhearing",
            "transcript": "transcript",
            "audio": "audio",
            "video": "video",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingversion_update', args=[hearingversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingWitnessViewTest(unittest.TestCase):
    '''
    Tests for HearingWitness
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingwitness(self):
        url = reverse('casemgmt_hearingwitness_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingwitness(self):
        url = reverse('casemgmt_hearingwitness_create')
        data = {
            "hearing": create_hearing().pk,
            "witness": create_'witness'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingwitness(self):
        hearingwitness = create_hearingwitness()
        url = reverse('casemgmt_hearingwitness_detail', args=[hearingwitness.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingwitness(self):
        hearingwitness = create_hearingwitness()
        data = {
            "hearing": create_hearing().pk,
            "witness": create_'witness'().pk,
        }
        url = reverse('casemgmt_hearingwitness_update', args=[hearingwitness.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingWitnessVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingWitnessVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingwitnessversion(self):
        url = reverse('casemgmt_hearingwitnessversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingwitnessversion(self):
        url = reverse('casemgmt_hearingwitnessversion_create')
        data = {
            "hearing": "hearing",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingwitnessversion(self):
        hearingwitnessversion = create_hearingwitnessversion()
        url = reverse('casemgmt_hearingwitnessversion_detail', args=[hearingwitnessversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingwitnessversion(self):
        hearingwitnessversion = create_hearingwitnessversion()
        data = {
            "hearing": "hearing",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingwitnessversion_update', args=[hearingwitnessversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingtypeViewTest(unittest.TestCase):
    '''
    Tests for Hearingtype
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingtype(self):
        url = reverse('casemgmt_hearingtype_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingtype(self):
        url = reverse('casemgmt_hearingtype_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingtype(self):
        hearingtype = create_hearingtype()
        url = reverse('casemgmt_hearingtype_detail', args=[hearingtype.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingtype(self):
        hearingtype = create_hearingtype()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_hearingtype_update', args=[hearingtype.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class HearingtypeVersionViewTest(unittest.TestCase):
    '''
    Tests for HearingtypeVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_hearingtypeversion(self):
        url = reverse('casemgmt_hearingtypeversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_hearingtypeversion(self):
        url = reverse('casemgmt_hearingtypeversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_hearingtypeversion(self):
        hearingtypeversion = create_hearingtypeversion()
        url = reverse('casemgmt_hearingtypeversion_detail', args=[hearingtypeversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_hearingtypeversion(self):
        hearingtypeversion = create_hearingtypeversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_hearingtypeversion_update', args=[hearingtypeversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationViewTest(unittest.TestCase):
    '''
    Tests for Investigation
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigation(self):
        url = reverse('casemgmt_investigation_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigation(self):
        url = reverse('casemgmt_investigation_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "actiondate": "actiondate",
            "evidence": "evidence",
            "narrative": "narrative",
            "weather": "weather",
            "location": "location",
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigation(self):
        investigation = create_investigation()
        url = reverse('casemgmt_investigation_detail', args=[investigation.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigation(self):
        investigation = create_investigation()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "actiondate": "actiondate",
            "evidence": "evidence",
            "narrative": "narrative",
            "weather": "weather",
            "location": "location",
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_investigation_update', args=[investigation.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationPolofficerViewTest(unittest.TestCase):
    '''
    Tests for InvestigationPolofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigationpolofficer(self):
        url = reverse('casemgmt_investigationpolofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigationpolofficer(self):
        url = reverse('casemgmt_investigationpolofficer_create')
        data = {
            "investigation": create_investigation().pk,
            "polofficer": create_'polofficer'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigationpolofficer(self):
        investigationpolofficer = create_investigationpolofficer()
        url = reverse('casemgmt_investigationpolofficer_detail', args=[investigationpolofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigationpolofficer(self):
        investigationpolofficer = create_investigationpolofficer()
        data = {
            "investigation": create_investigation().pk,
            "polofficer": create_'polofficer'().pk,
        }
        url = reverse('casemgmt_investigationpolofficer_update', args=[investigationpolofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationPolofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for InvestigationPolofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigationpolofficerversion(self):
        url = reverse('casemgmt_investigationpolofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigationpolofficerversion(self):
        url = reverse('casemgmt_investigationpolofficerversion_create')
        data = {
            "investigation": "investigation",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigationpolofficerversion(self):
        investigationpolofficerversion = create_investigationpolofficerversion()
        url = reverse('casemgmt_investigationpolofficerversion_detail', args=[investigationpolofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigationpolofficerversion(self):
        investigationpolofficerversion = create_investigationpolofficerversion()
        data = {
            "investigation": "investigation",
            "polofficer": "polofficer",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_investigationpolofficerversion_update', args=[investigationpolofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationVersionViewTest(unittest.TestCase):
    '''
    Tests for InvestigationVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigationversion(self):
        url = reverse('casemgmt_investigationversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigationversion(self):
        url = reverse('casemgmt_investigationversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "case": "case",
            "actiondate": "actiondate",
            "evidence": "evidence",
            "narrative": "narrative",
            "weather": "weather",
            "location": "location",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigationversion(self):
        investigationversion = create_investigationversion()
        url = reverse('casemgmt_investigationversion_detail', args=[investigationversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigationversion(self):
        investigationversion = create_investigationversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "case": "case",
            "actiondate": "actiondate",
            "evidence": "evidence",
            "narrative": "narrative",
            "weather": "weather",
            "location": "location",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_investigationversion_update', args=[investigationversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationWitnessViewTest(unittest.TestCase):
    '''
    Tests for InvestigationWitness
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigationwitness(self):
        url = reverse('casemgmt_investigationwitness_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigationwitness(self):
        url = reverse('casemgmt_investigationwitness_create')
        data = {
            "investigation": create_investigation().pk,
            "witness": create_'witness'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigationwitness(self):
        investigationwitness = create_investigationwitness()
        url = reverse('casemgmt_investigationwitness_detail', args=[investigationwitness.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigationwitness(self):
        investigationwitness = create_investigationwitness()
        data = {
            "investigation": create_investigation().pk,
            "witness": create_'witness'().pk,
        }
        url = reverse('casemgmt_investigationwitness_update', args=[investigationwitness.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class InvestigationWitnessVersionViewTest(unittest.TestCase):
    '''
    Tests for InvestigationWitnessVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_investigationwitnessversion(self):
        url = reverse('casemgmt_investigationwitnessversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_investigationwitnessversion(self):
        url = reverse('casemgmt_investigationwitnessversion_create')
        data = {
            "investigation": "investigation",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_investigationwitnessversion(self):
        investigationwitnessversion = create_investigationwitnessversion()
        url = reverse('casemgmt_investigationwitnessversion_detail', args=[investigationwitnessversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_investigationwitnessversion(self):
        investigationwitnessversion = create_investigationwitnessversion()
        data = {
            "investigation": "investigation",
            "witness": "witness",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_investigationwitnessversion_update', args=[investigationwitnessversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class JoRankViewTest(unittest.TestCase):
    '''
    Tests for JoRank
    '''
    def setUp(self):
        self.client = Client()

    def test_list_jorank(self):
        url = reverse('casemgmt_jorank_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_jorank(self):
        url = reverse('casemgmt_jorank_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "appelation": "appelation",
            "informaladdress": "informaladdress",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_jorank(self):
        jorank = create_jorank()
        url = reverse('casemgmt_jorank_detail', args=[jorank.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_jorank(self):
        jorank = create_jorank()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "appelation": "appelation",
            "informaladdress": "informaladdress",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_jorank_update', args=[jorank.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class JoRankVersionViewTest(unittest.TestCase):
    '''
    Tests for JoRankVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_jorankversion(self):
        url = reverse('casemgmt_jorankversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_jorankversion(self):
        url = reverse('casemgmt_jorankversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "appelation": "appelation",
            "informaladdress": "informaladdress",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_jorankversion(self):
        jorankversion = create_jorankversion()
        url = reverse('casemgmt_jorankversion_detail', args=[jorankversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_jorankversion(self):
        jorankversion = create_jorankversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "appelation": "appelation",
            "informaladdress": "informaladdress",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_jorankversion_update', args=[jorankversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class JudicialofficerViewTest(unittest.TestCase):
    '''
    Tests for Judicialofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_judicialofficer(self):
        url = reverse('casemgmt_judicialofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_judicialofficer(self):
        url = reverse('casemgmt_judicialofficer_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "court": create_court().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_judicialofficer(self):
        judicialofficer = create_judicialofficer()
        url = reverse('casemgmt_judicialofficer_detail', args=[judicialofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_judicialofficer(self):
        judicialofficer = create_judicialofficer()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "court": create_court().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_judicialofficer_update', args=[judicialofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class JudicialofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for JudicialofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_judicialofficerversion(self):
        url = reverse('casemgmt_judicialofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_judicialofficerversion(self):
        url = reverse('casemgmt_judicialofficerversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "court": "court",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_judicialofficerversion(self):
        judicialofficerversion = create_judicialofficerversion()
        url = reverse('casemgmt_judicialofficerversion_detail', args=[judicialofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_judicialofficerversion(self):
        judicialofficerversion = create_judicialofficerversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "court": "court",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_judicialofficerversion_update', args=[judicialofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class LawfirmViewTest(unittest.TestCase):
    '''
    Tests for Lawfirm
    '''
    def setUp(self):
        self.client = Client()

    def test_list_lawfirm(self):
        url = reverse('casemgmt_lawfirm_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_lawfirm(self):
        url = reverse('casemgmt_lawfirm_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_lawfirm(self):
        lawfirm = create_lawfirm()
        url = reverse('casemgmt_lawfirm_detail', args=[lawfirm.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_lawfirm(self):
        lawfirm = create_lawfirm()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_lawfirm_update', args=[lawfirm.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class LawfirmVersionViewTest(unittest.TestCase):
    '''
    Tests for LawfirmVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_lawfirmversion(self):
        url = reverse('casemgmt_lawfirmversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_lawfirmversion(self):
        url = reverse('casemgmt_lawfirmversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_lawfirmversion(self):
        lawfirmversion = create_lawfirmversion()
        url = reverse('casemgmt_lawfirmversion_detail', args=[lawfirmversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_lawfirmversion(self):
        lawfirmversion = create_lawfirmversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_lawfirmversion_update', args=[lawfirmversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class LawyersViewTest(unittest.TestCase):
    '''
    Tests for Lawyers
    '''
    def setUp(self):
        self.client = Client()

    def test_list_lawyers(self):
        url = reverse('casemgmt_lawyers_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_lawyers(self):
        url = reverse('casemgmt_lawyers_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "barnumber": "barnumber",
            "admissiondate": "admissiondate",
            "gender": create_gender().pk,
            "law_firm": create_lawfirm().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_lawyers(self):
        lawyers = create_lawyers()
        url = reverse('casemgmt_lawyers_detail', args=[lawyers.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_lawyers(self):
        lawyers = create_lawyers()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "barnumber": "barnumber",
            "admissiondate": "admissiondate",
            "gender": create_gender().pk,
            "law_firm": create_lawfirm().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_lawyers_update', args=[lawyers.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class LawyersVersionViewTest(unittest.TestCase):
    '''
    Tests for LawyersVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_lawyersversion(self):
        url = reverse('casemgmt_lawyersversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_lawyersversion(self):
        url = reverse('casemgmt_lawyersversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "barnumber": "barnumber",
            "law_firm": "law_firm",
            "admissiondate": "admissiondate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_lawyersversion(self):
        lawyersversion = create_lawyersversion()
        url = reverse('casemgmt_lawyersversion_detail', args=[lawyersversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_lawyersversion(self):
        lawyersversion = create_lawyersversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "barnumber": "barnumber",
            "law_firm": "law_firm",
            "admissiondate": "admissiondate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_lawyersversion_update', args=[lawyersversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class MedeventViewTest(unittest.TestCase):
    '''
    Tests for Medevent
    '''
    def setUp(self):
        self.client = Client()

    def test_list_medevent(self):
        url = reverse('casemgmt_medevent_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_medevent(self):
        url = reverse('casemgmt_medevent_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_medevent(self):
        medevent = create_medevent()
        url = reverse('casemgmt_medevent_detail', args=[medevent.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_medevent(self):
        medevent = create_medevent()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_medevent_update', args=[medevent.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class MedeventVersionViewTest(unittest.TestCase):
    '''
    Tests for MedeventVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_medeventversion(self):
        url = reverse('casemgmt_medeventversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_medeventversion(self):
        url = reverse('casemgmt_medeventversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_medeventversion(self):
        medeventversion = create_medeventversion()
        url = reverse('casemgmt_medeventversion_detail', args=[medeventversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_medeventversion(self):
        medeventversion = create_medeventversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_medeventversion_update', args=[medeventversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class NatureofsuitViewTest(unittest.TestCase):
    '''
    Tests for Natureofsuit
    '''
    def setUp(self):
        self.client = Client()

    def test_list_natureofsuit(self):
        url = reverse('casemgmt_natureofsuit_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_natureofsuit(self):
        url = reverse('casemgmt_natureofsuit_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_natureofsuit(self):
        natureofsuit = create_natureofsuit()
        url = reverse('casemgmt_natureofsuit_detail', args=[natureofsuit.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_natureofsuit(self):
        natureofsuit = create_natureofsuit()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_natureofsuit_update', args=[natureofsuit.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class NatureofsuitVersionViewTest(unittest.TestCase):
    '''
    Tests for NatureofsuitVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_natureofsuitversion(self):
        url = reverse('casemgmt_natureofsuitversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_natureofsuitversion(self):
        url = reverse('casemgmt_natureofsuitversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_natureofsuitversion(self):
        natureofsuitversion = create_natureofsuitversion()
        url = reverse('casemgmt_natureofsuitversion_detail', args=[natureofsuitversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_natureofsuitversion(self):
        natureofsuitversion = create_natureofsuitversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_natureofsuitversion_update', args=[natureofsuitversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PaymentViewTest(unittest.TestCase):
    '''
    Tests for Payment
    '''
    def setUp(self):
        self.client = Client()

    def test_list_payment(self):
        url = reverse('casemgmt_payment_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_payment(self):
        url = reverse('casemgmt_payment_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "datepaid": "datepaid",
            "amount": "amount",
            "paymentreference": "paymentreference",
            "paymentconfirmed": "paymentconfirmed",
            "paidby": "paidby",
            "msisdn": "msisdn",
            "receiptnumber": "receiptnumber",
            "ispartial": "ispartial",
            "billrefnumber": "billrefnumber",
            "paymentdescription": "paymentdescription",
            "bail": create_bail().pk,
            "payment_method": create_'paymentmethod'().pk,
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_payment(self):
        payment = create_payment()
        url = reverse('casemgmt_payment_detail', args=[payment.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_payment(self):
        payment = create_payment()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "datepaid": "datepaid",
            "amount": "amount",
            "paymentreference": "paymentreference",
            "paymentconfirmed": "paymentconfirmed",
            "paidby": "paidby",
            "msisdn": "msisdn",
            "receiptnumber": "receiptnumber",
            "ispartial": "ispartial",
            "billrefnumber": "billrefnumber",
            "paymentdescription": "paymentdescription",
            "bail": create_bail().pk,
            "payment_method": create_'paymentmethod'().pk,
            "case": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_payment_update', args=[payment.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PaymentVersionViewTest(unittest.TestCase):
    '''
    Tests for PaymentVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_paymentversion(self):
        url = reverse('casemgmt_paymentversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_paymentversion(self):
        url = reverse('casemgmt_paymentversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "datepaid": "datepaid",
            "amount": "amount",
            "paymentreference": "paymentreference",
            "paymentconfirmed": "paymentconfirmed",
            "paidby": "paidby",
            "msisdn": "msisdn",
            "receiptnumber": "receiptnumber",
            "ispartial": "ispartial",
            "bail": "bail",
            "billrefnumber": "billrefnumber",
            "payment_method": "payment_method",
            "paymentdescription": "paymentdescription",
            "case": "case",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_paymentversion(self):
        paymentversion = create_paymentversion()
        url = reverse('casemgmt_paymentversion_detail', args=[paymentversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_paymentversion(self):
        paymentversion = create_paymentversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "datepaid": "datepaid",
            "amount": "amount",
            "paymentreference": "paymentreference",
            "paymentconfirmed": "paymentconfirmed",
            "paidby": "paidby",
            "msisdn": "msisdn",
            "receiptnumber": "receiptnumber",
            "ispartial": "ispartial",
            "bail": "bail",
            "billrefnumber": "billrefnumber",
            "payment_method": "payment_method",
            "paymentdescription": "paymentdescription",
            "case": "case",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_paymentversion_update', args=[paymentversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PaymentmethodViewTest(unittest.TestCase):
    '''
    Tests for Paymentmethod
    '''
    def setUp(self):
        self.client = Client()

    def test_list_paymentmethod(self):
        url = reverse('casemgmt_paymentmethod_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_paymentmethod(self):
        url = reverse('casemgmt_paymentmethod_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "key": "key",
            "secret": "secret",
            "portal": "portal",
            "tillnumber": "tillnumber",
            "shortcode": "shortcode",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_paymentmethod(self):
        paymentmethod = create_paymentmethod()
        url = reverse('casemgmt_paymentmethod_detail', args=[paymentmethod.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_paymentmethod(self):
        paymentmethod = create_paymentmethod()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "key": "key",
            "secret": "secret",
            "portal": "portal",
            "tillnumber": "tillnumber",
            "shortcode": "shortcode",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_paymentmethod_update', args=[paymentmethod.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PaymentmethodVersionViewTest(unittest.TestCase):
    '''
    Tests for PaymentmethodVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_paymentmethodversion(self):
        url = reverse('casemgmt_paymentmethodversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_paymentmethodversion(self):
        url = reverse('casemgmt_paymentmethodversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "key": "key",
            "secret": "secret",
            "portal": "portal",
            "tillnumber": "tillnumber",
            "shortcode": "shortcode",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_paymentmethodversion(self):
        paymentmethodversion = create_paymentmethodversion()
        url = reverse('casemgmt_paymentmethodversion_detail', args=[paymentmethodversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_paymentmethodversion(self):
        paymentmethodversion = create_paymentmethodversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "key": "key",
            "secret": "secret",
            "portal": "portal",
            "tillnumber": "tillnumber",
            "shortcode": "shortcode",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_paymentmethodversion_update', args=[paymentmethodversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PlaintiffViewTest(unittest.TestCase):
    '''
    Tests for Plaintiff
    '''
    def setUp(self):
        self.client = Client()

    def test_list_plaintiff(self):
        url = reverse('casemgmt_plaintiff_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_plaintiff(self):
        url = reverse('casemgmt_plaintiff_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "juvenile": "juvenile",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_plaintiff(self):
        plaintiff = create_plaintiff()
        url = reverse('casemgmt_plaintiff_detail', args=[plaintiff.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_plaintiff(self):
        plaintiff = create_plaintiff()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "juvenile": "juvenile",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_plaintiff_update', args=[plaintiff.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PlaintiffVersionViewTest(unittest.TestCase):
    '''
    Tests for PlaintiffVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_plaintiffversion(self):
        url = reverse('casemgmt_plaintiffversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_plaintiffversion(self):
        url = reverse('casemgmt_plaintiffversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "juvenile": "juvenile",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_plaintiffversion(self):
        plaintiffversion = create_plaintiffversion()
        url = reverse('casemgmt_plaintiffversion_detail', args=[plaintiffversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_plaintiffversion(self):
        plaintiffversion = create_plaintiffversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "juvenile": "juvenile",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_plaintiffversion_update', args=[plaintiffversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicerankViewTest(unittest.TestCase):
    '''
    Tests for Policerank
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policerank(self):
        url = reverse('casemgmt_policerank_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policerank(self):
        url = reverse('casemgmt_policerank_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policerank(self):
        policerank = create_policerank()
        url = reverse('casemgmt_policerank_detail', args=[policerank.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policerank(self):
        policerank = create_policerank()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_policerank_update', args=[policerank.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicerankVersionViewTest(unittest.TestCase):
    '''
    Tests for PolicerankVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policerankversion(self):
        url = reverse('casemgmt_policerankversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policerankversion(self):
        url = reverse('casemgmt_policerankversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policerankversion(self):
        policerankversion = create_policerankversion()
        url = reverse('casemgmt_policerankversion_detail', args=[policerankversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policerankversion(self):
        policerankversion = create_policerankversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_policerankversion_update', args=[policerankversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PoliceroleViewTest(unittest.TestCase):
    '''
    Tests for Policerole
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policerole(self):
        url = reverse('casemgmt_policerole_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policerole(self):
        url = reverse('casemgmt_policerole_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policerole(self):
        policerole = create_policerole()
        url = reverse('casemgmt_policerole_detail', args=[policerole.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policerole(self):
        policerole = create_policerole()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_policerole_update', args=[policerole.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PoliceroleVersionViewTest(unittest.TestCase):
    '''
    Tests for PoliceroleVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policeroleversion(self):
        url = reverse('casemgmt_policeroleversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policeroleversion(self):
        url = reverse('casemgmt_policeroleversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policeroleversion(self):
        policeroleversion = create_policeroleversion()
        url = reverse('casemgmt_policeroleversion_detail', args=[policeroleversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policeroleversion(self):
        policeroleversion = create_policeroleversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_policeroleversion_update', args=[policeroleversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicestationViewTest(unittest.TestCase):
    '''
    Tests for Policestation
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policestation(self):
        url = reverse('casemgmt_policestation_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policestation(self):
        url = reverse('casemgmt_policestation_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "has_forensic_lab": "has_forensic_lab",
            "officercommanding": "officercommanding",
            "town": create_'town'().pk,
            "police_station_type": create_'policestationtype'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policestation(self):
        policestation = create_policestation()
        url = reverse('casemgmt_policestation_detail', args=[policestation.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policestation(self):
        policestation = create_policestation()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "has_forensic_lab": "has_forensic_lab",
            "officercommanding": "officercommanding",
            "town": create_'town'().pk,
            "police_station_type": create_'policestationtype'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_policestation_update', args=[policestation.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicestationVersionViewTest(unittest.TestCase):
    '''
    Tests for PolicestationVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policestationversion(self):
        url = reverse('casemgmt_policestationversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policestationversion(self):
        url = reverse('casemgmt_policestationversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "town": "town",
            "has_forensic_lab": "has_forensic_lab",
            "officercommanding": "officercommanding",
            "police_station_type": "police_station_type",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policestationversion(self):
        policestationversion = create_policestationversion()
        url = reverse('casemgmt_policestationversion_detail', args=[policestationversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policestationversion(self):
        policestationversion = create_policestationversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "town": "town",
            "has_forensic_lab": "has_forensic_lab",
            "officercommanding": "officercommanding",
            "police_station_type": "police_station_type",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_policestationversion_update', args=[policestationversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicestationtypeViewTest(unittest.TestCase):
    '''
    Tests for Policestationtype
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policestationtype(self):
        url = reverse('casemgmt_policestationtype_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policestationtype(self):
        url = reverse('casemgmt_policestationtype_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policestationtype(self):
        policestationtype = create_policestationtype()
        url = reverse('casemgmt_policestationtype_detail', args=[policestationtype.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policestationtype(self):
        policestationtype = create_policestationtype()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_policestationtype_update', args=[policestationtype.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolicestationtypeVersionViewTest(unittest.TestCase):
    '''
    Tests for PolicestationtypeVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_policestationtypeversion(self):
        url = reverse('casemgmt_policestationtypeversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_policestationtypeversion(self):
        url = reverse('casemgmt_policestationtypeversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_policestationtypeversion(self):
        policestationtypeversion = create_policestationtypeversion()
        url = reverse('casemgmt_policestationtypeversion_detail', args=[policestationtypeversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_policestationtypeversion(self):
        policestationtypeversion = create_policestationtypeversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_policestationtypeversion_update', args=[policestationtypeversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolofficerViewTest(unittest.TestCase):
    '''
    Tests for Polofficer
    '''
    def setUp(self):
        self.client = Client()

    def test_list_polofficer(self):
        url = reverse('casemgmt_polofficer_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_polofficer(self):
        url = reverse('casemgmt_polofficer_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "servicenumber": "servicenumber",
            "postdate": "postdate",
            "police_rank": create_policerank().pk,
            "gender": create_gender().pk,
            "reports_to": create_'self'().pk,
            "pol_supervisor": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_polofficer(self):
        polofficer = create_polofficer()
        url = reverse('casemgmt_polofficer_detail', args=[polofficer.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_polofficer(self):
        polofficer = create_polofficer()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "servicenumber": "servicenumber",
            "postdate": "postdate",
            "police_rank": create_policerank().pk,
            "gender": create_gender().pk,
            "reports_to": create_'self'().pk,
            "pol_supervisor": create_case().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_polofficer_update', args=[polofficer.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolofficerPoliceroleViewTest(unittest.TestCase):
    '''
    Tests for PolofficerPolicerole
    '''
    def setUp(self):
        self.client = Client()

    def test_list_polofficerpolicerole(self):
        url = reverse('casemgmt_polofficerpolicerole_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_polofficerpolicerole(self):
        url = reverse('casemgmt_polofficerpolicerole_create')
        data = {
            "polofficer": create_polofficer().pk,
            "policerole": create_policerole().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_polofficerpolicerole(self):
        polofficerpolicerole = create_polofficerpolicerole()
        url = reverse('casemgmt_polofficerpolicerole_detail', args=[polofficerpolicerole.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_polofficerpolicerole(self):
        polofficerpolicerole = create_polofficerpolicerole()
        data = {
            "polofficer": create_polofficer().pk,
            "policerole": create_policerole().pk,
        }
        url = reverse('casemgmt_polofficerpolicerole_update', args=[polofficerpolicerole.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolofficerPoliceroleVersionViewTest(unittest.TestCase):
    '''
    Tests for PolofficerPoliceroleVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_polofficerpoliceroleversion(self):
        url = reverse('casemgmt_polofficerpoliceroleversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_polofficerpoliceroleversion(self):
        url = reverse('casemgmt_polofficerpoliceroleversion_create')
        data = {
            "polofficer": "polofficer",
            "policerole": "policerole",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_polofficerpoliceroleversion(self):
        polofficerpoliceroleversion = create_polofficerpoliceroleversion()
        url = reverse('casemgmt_polofficerpoliceroleversion_detail', args=[polofficerpoliceroleversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_polofficerpoliceroleversion(self):
        polofficerpoliceroleversion = create_polofficerpoliceroleversion()
        data = {
            "polofficer": "polofficer",
            "policerole": "policerole",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_polofficerpoliceroleversion_update', args=[polofficerpoliceroleversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PolofficerVersionViewTest(unittest.TestCase):
    '''
    Tests for PolofficerVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_polofficerversion(self):
        url = reverse('casemgmt_polofficerversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_polofficerversion(self):
        url = reverse('casemgmt_polofficerversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "police_rank": "police_rank",
            "gender": "gender",
            "servicenumber": "servicenumber",
            "reports_to": "reports_to",
            "pol_supervisor": "pol_supervisor",
            "postdate": "postdate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_polofficerversion(self):
        polofficerversion = create_polofficerversion()
        url = reverse('casemgmt_polofficerversion_detail', args=[polofficerversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_polofficerversion(self):
        polofficerversion = create_polofficerversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "police_rank": "police_rank",
            "gender": "gender",
            "servicenumber": "servicenumber",
            "reports_to": "reports_to",
            "pol_supervisor": "pol_supervisor",
            "postdate": "postdate",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_polofficerversion_update', args=[polofficerversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonViewTest(unittest.TestCase):
    '''
    Tests for Prison
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prison(self):
        url = reverse('casemgmt_prison_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prison(self):
        url = reverse('casemgmt_prison_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "warden": "warden",
            "capacity": "capacity",
            "population": "population",
            "cellcount": "cellcount",
            "gatecount": "gatecount",
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prison(self):
        prison = create_prison()
        url = reverse('casemgmt_prison_detail', args=[prison.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prison(self):
        prison = create_prison()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "warden": "warden",
            "capacity": "capacity",
            "population": "population",
            "cellcount": "cellcount",
            "gatecount": "gatecount",
            "town": create_'town'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prison_update', args=[prison.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonSecurityrankViewTest(unittest.TestCase):
    '''
    Tests for PrisonSecurityrank
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisonsecurityrank(self):
        url = reverse('casemgmt_prisonsecurityrank_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisonsecurityrank(self):
        url = reverse('casemgmt_prisonsecurityrank_create')
        data = {
            "prison": create_prison().pk,
            "securityrank": create_'securityrank'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisonsecurityrank(self):
        prisonsecurityrank = create_prisonsecurityrank()
        url = reverse('casemgmt_prisonsecurityrank_detail', args=[prisonsecurityrank.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisonsecurityrank(self):
        prisonsecurityrank = create_prisonsecurityrank()
        data = {
            "prison": create_prison().pk,
            "securityrank": create_'securityrank'().pk,
        }
        url = reverse('casemgmt_prisonsecurityrank_update', args=[prisonsecurityrank.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonSecurityrankVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisonSecurityrankVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisonsecurityrankversion(self):
        url = reverse('casemgmt_prisonsecurityrankversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisonsecurityrankversion(self):
        url = reverse('casemgmt_prisonsecurityrankversion_create')
        data = {
            "prison": "prison",
            "securityrank": "securityrank",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisonsecurityrankversion(self):
        prisonsecurityrankversion = create_prisonsecurityrankversion()
        url = reverse('casemgmt_prisonsecurityrankversion_detail', args=[prisonsecurityrankversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisonsecurityrankversion(self):
        prisonsecurityrankversion = create_prisonsecurityrankversion()
        data = {
            "prison": "prison",
            "securityrank": "securityrank",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisonsecurityrankversion_update', args=[prisonsecurityrankversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisonVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisonversion(self):
        url = reverse('casemgmt_prisonversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisonversion(self):
        url = reverse('casemgmt_prisonversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "town": "town",
            "warden": "warden",
            "capacity": "capacity",
            "population": "population",
            "cellcount": "cellcount",
            "gatecount": "gatecount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisonversion(self):
        prisonversion = create_prisonversion()
        url = reverse('casemgmt_prisonversion_detail', args=[prisonversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisonversion(self):
        prisonversion = create_prisonversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "place_name": "place_name",
            "lat": "lat",
            "lng": "lng",
            "alt": "alt",
            "map": "map",
            "info": "info",
            "pin": "pin",
            "pin_color": "pin_color",
            "pin_icon": "pin_icon",
            "centered": "centered",
            "nearest_feature": "nearest_feature",
            "id": "id",
            "town": "town",
            "warden": "warden",
            "capacity": "capacity",
            "population": "population",
            "cellcount": "cellcount",
            "gatecount": "gatecount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisonversion_update', args=[prisonversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncellViewTest(unittest.TestCase):
    '''
    Tests for Prisoncell
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncell(self):
        url = reverse('casemgmt_prisoncell_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncell(self):
        url = reverse('casemgmt_prisoncell_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "prison": create_prison().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncell(self):
        prisoncell = create_prisoncell()
        url = reverse('casemgmt_prisoncell_detail', args=[prisoncell.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncell(self):
        prisoncell = create_prisoncell()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "prison": create_prison().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prisoncell_update', args=[prisoncell.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncellVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisoncellVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncellversion(self):
        url = reverse('casemgmt_prisoncellversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncellversion(self):
        url = reverse('casemgmt_prisoncellversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison": "prison",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncellversion(self):
        prisoncellversion = create_prisoncellversion()
        url = reverse('casemgmt_prisoncellversion_detail', args=[prisoncellversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncellversion(self):
        prisoncellversion = create_prisoncellversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison": "prison",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisoncellversion_update', args=[prisoncellversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncommitalViewTest(unittest.TestCase):
    '''
    Tests for Prisoncommital
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncommital(self):
        url = reverse('casemgmt_prisoncommital_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncommital(self):
        url = reverse('casemgmt_prisoncommital_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "warrantno": "warrantno",
            "warrantdate": "warrantdate",
            "hascourtdate": "hascourtdate",
            "warrant": "warrant",
            "warrantduration": "warrantduration",
            "warrantexpiry": "warrantexpiry",
            "history": "history",
            "earliestrelease": "earliestrelease",
            "releasedate": "releasedate",
            "property": "property",
            "itemcount": "itemcount",
            "releasenotes": "releasenotes",
            "commitalnotes": "commitalnotes",
            "paroledate": "paroledate",
            "escaped": "escaped",
            "escapedate": "escapedate",
            "escapedetails": "escapedetails",
            "prison": create_prison().pk,
            "defendant": create_defendant().pk,
            "hearing": create_hearing().pk,
            "judicial_officer_warrant": create_judicialofficer().pk,
            "police_officer_commiting": create_polofficer().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncommital(self):
        prisoncommital = create_prisoncommital()
        url = reverse('casemgmt_prisoncommital_detail', args=[prisoncommital.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncommital(self):
        prisoncommital = create_prisoncommital()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "warrantno": "warrantno",
            "warrantdate": "warrantdate",
            "hascourtdate": "hascourtdate",
            "warrant": "warrant",
            "warrantduration": "warrantduration",
            "warrantexpiry": "warrantexpiry",
            "history": "history",
            "earliestrelease": "earliestrelease",
            "releasedate": "releasedate",
            "property": "property",
            "itemcount": "itemcount",
            "releasenotes": "releasenotes",
            "commitalnotes": "commitalnotes",
            "paroledate": "paroledate",
            "escaped": "escaped",
            "escapedate": "escapedate",
            "escapedetails": "escapedetails",
            "prison": create_prison().pk,
            "defendant": create_defendant().pk,
            "hearing": create_hearing().pk,
            "judicial_officer_warrant": create_judicialofficer().pk,
            "police_officer_commiting": create_polofficer().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prisoncommital_update', args=[prisoncommital.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncommitalVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisoncommitalVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncommitalversion(self):
        url = reverse('casemgmt_prisoncommitalversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncommitalversion(self):
        url = reverse('casemgmt_prisoncommitalversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "prison": "prison",
            "warrantno": "warrantno",
            "defendant": "defendant",
            "hearing": "hearing",
            "warrantdate": "warrantdate",
            "hascourtdate": "hascourtdate",
            "judicial_officer_warrant": "judicial_officer_warrant",
            "warrant": "warrant",
            "warrantduration": "warrantduration",
            "warrantexpiry": "warrantexpiry",
            "history": "history",
            "earliestrelease": "earliestrelease",
            "releasedate": "releasedate",
            "property": "property",
            "itemcount": "itemcount",
            "releasenotes": "releasenotes",
            "commitalnotes": "commitalnotes",
            "police_officer_commiting": "police_officer_commiting",
            "paroledate": "paroledate",
            "escaped": "escaped",
            "escapedate": "escapedate",
            "escapedetails": "escapedetails",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncommitalversion(self):
        prisoncommitalversion = create_prisoncommitalversion()
        url = reverse('casemgmt_prisoncommitalversion_detail', args=[prisoncommitalversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncommitalversion(self):
        prisoncommitalversion = create_prisoncommitalversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "prison": "prison",
            "warrantno": "warrantno",
            "defendant": "defendant",
            "hearing": "hearing",
            "warrantdate": "warrantdate",
            "hascourtdate": "hascourtdate",
            "judicial_officer_warrant": "judicial_officer_warrant",
            "warrant": "warrant",
            "warrantduration": "warrantduration",
            "warrantexpiry": "warrantexpiry",
            "history": "history",
            "earliestrelease": "earliestrelease",
            "releasedate": "releasedate",
            "property": "property",
            "itemcount": "itemcount",
            "releasenotes": "releasenotes",
            "commitalnotes": "commitalnotes",
            "police_officer_commiting": "police_officer_commiting",
            "paroledate": "paroledate",
            "escaped": "escaped",
            "escapedate": "escapedate",
            "escapedetails": "escapedetails",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisoncommitalversion_update', args=[prisoncommitalversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncommitalWarderViewTest(unittest.TestCase):
    '''
    Tests for PrisoncommitalWarder
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncommitalwarder(self):
        url = reverse('casemgmt_prisoncommitalwarder_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncommitalwarder(self):
        url = reverse('casemgmt_prisoncommitalwarder_create')
        data = {
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "prisoncommital_prison": create_prisoncommital().pk,
            "warder": create_'warder'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncommitalwarder(self):
        prisoncommitalwarder = create_prisoncommitalwarder()
        url = reverse('casemgmt_prisoncommitalwarder_detail', args=[prisoncommitalwarder.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncommitalwarder(self):
        prisoncommitalwarder = create_prisoncommitalwarder()
        data = {
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "prisoncommital_prison": create_prisoncommital().pk,
            "warder": create_'warder'().pk,
        }
        url = reverse('casemgmt_prisoncommitalwarder_update', args=[prisoncommitalwarder.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisoncommitalWarderVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisoncommitalWarderVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisoncommitalwarderversion(self):
        url = reverse('casemgmt_prisoncommitalwarderversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisoncommitalwarderversion(self):
        url = reverse('casemgmt_prisoncommitalwarderversion_create')
        data = {
            "prisoncommital_prison": "prisoncommital_prison",
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisoncommitalwarderversion(self):
        prisoncommitalwarderversion = create_prisoncommitalwarderversion()
        url = reverse('casemgmt_prisoncommitalwarderversion_detail', args=[prisoncommitalwarderversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisoncommitalwarderversion(self):
        prisoncommitalwarderversion = create_prisoncommitalwarderversion()
        data = {
            "prisoncommital_prison": "prisoncommital_prison",
            "prisoncommital_warrantno": "prisoncommital_warrantno",
            "warder": "warder",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisoncommitalwarderversion_update', args=[prisoncommitalwarderversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonerpropertyViewTest(unittest.TestCase):
    '''
    Tests for Prisonerproperty
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisonerproperty(self):
        url = reverse('casemgmt_prisonerproperty_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisonerproperty(self):
        url = reverse('casemgmt_prisonerproperty_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "receipted": "receipted",
            "prison_commital_prison": create_prisoncommital().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisonerproperty(self):
        prisonerproperty = create_prisonerproperty()
        url = reverse('casemgmt_prisonerproperty_detail', args=[prisonerproperty.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisonerproperty(self):
        prisonerproperty = create_prisonerproperty()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "receipted": "receipted",
            "prison_commital_prison": create_prisoncommital().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prisonerproperty_update', args=[prisonerproperty.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class PrisonerpropertyVersionViewTest(unittest.TestCase):
    '''
    Tests for PrisonerpropertyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prisonerpropertyversion(self):
        url = reverse('casemgmt_prisonerpropertyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prisonerpropertyversion(self):
        url = reverse('casemgmt_prisonerpropertyversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "prison_commital_prison": "prison_commital_prison",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "receipted": "receipted",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prisonerpropertyversion(self):
        prisonerpropertyversion = create_prisonerpropertyversion()
        url = reverse('casemgmt_prisonerpropertyversion_detail', args=[prisonerpropertyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prisonerpropertyversion(self):
        prisonerpropertyversion = create_prisonerpropertyversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "prison_commital_prison": "prison_commital_prison",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "receipted": "receipted",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prisonerpropertyversion_update', args=[prisonerpropertyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorViewTest(unittest.TestCase):
    '''
    Tests for Prosecutor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutor(self):
        url = reverse('casemgmt_prosecutor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutor(self):
        url = reverse('casemgmt_prosecutor_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutor(self):
        prosecutor = create_prosecutor()
        url = reverse('casemgmt_prosecutor_detail', args=[prosecutor.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutor(self):
        prosecutor = create_prosecutor()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prosecutor_update', args=[prosecutor.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorProsecutorteamViewTest(unittest.TestCase):
    '''
    Tests for ProsecutorProsecutorteam
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutorprosecutorteam(self):
        url = reverse('casemgmt_prosecutorprosecutorteam_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutorprosecutorteam(self):
        url = reverse('casemgmt_prosecutorprosecutorteam_create')
        data = {
            "prosecutor": create_prosecutor().pk,
            "prosecutorteam": create_'prosecutorteam'().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutorprosecutorteam(self):
        prosecutorprosecutorteam = create_prosecutorprosecutorteam()
        url = reverse('casemgmt_prosecutorprosecutorteam_detail', args=[prosecutorprosecutorteam.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutorprosecutorteam(self):
        prosecutorprosecutorteam = create_prosecutorprosecutorteam()
        data = {
            "prosecutor": create_prosecutor().pk,
            "prosecutorteam": create_'prosecutorteam'().pk,
        }
        url = reverse('casemgmt_prosecutorprosecutorteam_update', args=[prosecutorprosecutorteam.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorProsecutorteamVersionViewTest(unittest.TestCase):
    '''
    Tests for ProsecutorProsecutorteamVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutorprosecutorteamversion(self):
        url = reverse('casemgmt_prosecutorprosecutorteamversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutorprosecutorteamversion(self):
        url = reverse('casemgmt_prosecutorprosecutorteamversion_create')
        data = {
            "prosecutor": "prosecutor",
            "prosecutorteam": "prosecutorteam",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutorprosecutorteamversion(self):
        prosecutorprosecutorteamversion = create_prosecutorprosecutorteamversion()
        url = reverse('casemgmt_prosecutorprosecutorteamversion_detail', args=[prosecutorprosecutorteamversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutorprosecutorteamversion(self):
        prosecutorprosecutorteamversion = create_prosecutorprosecutorteamversion()
        data = {
            "prosecutor": "prosecutor",
            "prosecutorteam": "prosecutorteam",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prosecutorprosecutorteamversion_update', args=[prosecutorprosecutorteamversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorVersionViewTest(unittest.TestCase):
    '''
    Tests for ProsecutorVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutorversion(self):
        url = reverse('casemgmt_prosecutorversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutorversion(self):
        url = reverse('casemgmt_prosecutorversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutorversion(self):
        prosecutorversion = create_prosecutorversion()
        url = reverse('casemgmt_prosecutorversion_detail', args=[prosecutorversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutorversion(self):
        prosecutorversion = create_prosecutorversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prosecutorversion_update', args=[prosecutorversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorteamViewTest(unittest.TestCase):
    '''
    Tests for Prosecutorteam
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutorteam(self):
        url = reverse('casemgmt_prosecutorteam_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutorteam(self):
        url = reverse('casemgmt_prosecutorteam_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutorteam(self):
        prosecutorteam = create_prosecutorteam()
        url = reverse('casemgmt_prosecutorteam_detail', args=[prosecutorteam.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutorteam(self):
        prosecutorteam = create_prosecutorteam()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_prosecutorteam_update', args=[prosecutorteam.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class ProsecutorteamVersionViewTest(unittest.TestCase):
    '''
    Tests for ProsecutorteamVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_prosecutorteamversion(self):
        url = reverse('casemgmt_prosecutorteamversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_prosecutorteamversion(self):
        url = reverse('casemgmt_prosecutorteamversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_prosecutorteamversion(self):
        prosecutorteamversion = create_prosecutorteamversion()
        url = reverse('casemgmt_prosecutorteamversion_detail', args=[prosecutorteamversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_prosecutorteamversion(self):
        prosecutorteamversion = create_prosecutorteamversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_prosecutorteamversion_update', args=[prosecutorteamversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class RemissionViewTest(unittest.TestCase):
    '''
    Tests for Remission
    '''
    def setUp(self):
        self.client = Client()

    def test_list_remission(self):
        url = reverse('casemgmt_remission_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_remission(self):
        url = reverse('casemgmt_remission_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "daysearned": "daysearned",
            "dateearned": "dateearned",
            "amount": "amount",
            "prison_commital_prison": create_prisoncommital().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_remission(self):
        remission = create_remission()
        url = reverse('casemgmt_remission_detail', args=[remission.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_remission(self):
        remission = create_remission()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "daysearned": "daysearned",
            "dateearned": "dateearned",
            "amount": "amount",
            "prison_commital_prison": create_prisoncommital().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_remission_update', args=[remission.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class RemissionVersionViewTest(unittest.TestCase):
    '''
    Tests for RemissionVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_remissionversion(self):
        url = reverse('casemgmt_remissionversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_remissionversion(self):
        url = reverse('casemgmt_remissionversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison_commital_prison": "prison_commital_prison",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "daysearned": "daysearned",
            "dateearned": "dateearned",
            "amount": "amount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_remissionversion(self):
        remissionversion = create_remissionversion()
        url = reverse('casemgmt_remissionversion_detail', args=[remissionversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_remissionversion(self):
        remissionversion = create_remissionversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "id": "id",
            "prison_commital_prison": "prison_commital_prison",
            "prison_commital_warrantno": "prison_commital_warrantno",
            "daysearned": "daysearned",
            "dateearned": "dateearned",
            "amount": "amount",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_remissionversion_update', args=[remissionversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SecurityrankViewTest(unittest.TestCase):
    '''
    Tests for Securityrank
    '''
    def setUp(self):
        self.client = Client()

    def test_list_securityrank(self):
        url = reverse('casemgmt_securityrank_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_securityrank(self):
        url = reverse('casemgmt_securityrank_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_securityrank(self):
        securityrank = create_securityrank()
        url = reverse('casemgmt_securityrank_detail', args=[securityrank.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_securityrank(self):
        securityrank = create_securityrank()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_securityrank_update', args=[securityrank.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SecurityrankVersionViewTest(unittest.TestCase):
    '''
    Tests for SecurityrankVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_securityrankversion(self):
        url = reverse('casemgmt_securityrankversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_securityrankversion(self):
        url = reverse('casemgmt_securityrankversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_securityrankversion(self):
        securityrankversion = create_securityrankversion()
        url = reverse('casemgmt_securityrankversion_detail', args=[securityrankversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_securityrankversion(self):
        securityrankversion = create_securityrankversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_securityrankversion_update', args=[securityrankversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SubcountyViewTest(unittest.TestCase):
    '''
    Tests for Subcounty
    '''
    def setUp(self):
        self.client = Client()

    def test_list_subcounty(self):
        url = reverse('casemgmt_subcounty_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_subcounty(self):
        url = reverse('casemgmt_subcounty_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "county": create_county().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_subcounty(self):
        subcounty = create_subcounty()
        url = reverse('casemgmt_subcounty_detail', args=[subcounty.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_subcounty(self):
        subcounty = create_subcounty()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "county": create_county().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_subcounty_update', args=[subcounty.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SubcountyVersionViewTest(unittest.TestCase):
    '''
    Tests for SubcountyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_subcountyversion(self):
        url = reverse('casemgmt_subcountyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_subcountyversion(self):
        url = reverse('casemgmt_subcountyversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "county": "county",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_subcountyversion(self):
        subcountyversion = create_subcountyversion()
        url = reverse('casemgmt_subcountyversion_detail', args=[subcountyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_subcountyversion(self):
        subcountyversion = create_subcountyversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "county": "county",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_subcountyversion_update', args=[subcountyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SuretyViewTest(unittest.TestCase):
    '''
    Tests for Surety
    '''
    def setUp(self):
        self.client = Client()

    def test_list_surety(self):
        url = reverse('casemgmt_surety_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_surety(self):
        url = reverse('casemgmt_surety_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_surety(self):
        surety = create_surety()
        url = reverse('casemgmt_surety_detail', args=[surety.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_surety(self):
        surety = create_surety()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_surety_update', args=[surety.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class SuretyVersionViewTest(unittest.TestCase):
    '''
    Tests for SuretyVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_suretyversion(self):
        url = reverse('casemgmt_suretyversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_suretyversion(self):
        url = reverse('casemgmt_suretyversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_suretyversion(self):
        suretyversion = create_suretyversion()
        url = reverse('casemgmt_suretyversion_detail', args=[suretyversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_suretyversion(self):
        suretyversion = create_suretyversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_suretyversion_update', args=[suretyversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TagViewTest(unittest.TestCase):
    '''
    Tests for Tag
    '''
    def setUp(self):
        self.client = Client()

    def test_list_tag(self):
        url = reverse('casemgmt_tag_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_tag(self):
        url = reverse('casemgmt_tag_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_tag(self):
        tag = create_tag()
        url = reverse('casemgmt_tag_detail', args=[tag.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_tag(self):
        tag = create_tag()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_tag_update', args=[tag.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TagVersionViewTest(unittest.TestCase):
    '''
    Tests for TagVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_tagversion(self):
        url = reverse('casemgmt_tagversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_tagversion(self):
        url = reverse('casemgmt_tagversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_tagversion(self):
        tagversion = create_tagversion()
        url = reverse('casemgmt_tagversion_detail', args=[tagversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_tagversion(self):
        tagversion = create_tagversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_tagversion_update', args=[tagversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TownViewTest(unittest.TestCase):
    '''
    Tests for Town
    '''
    def setUp(self):
        self.client = Client()

    def test_list_town(self):
        url = reverse('casemgmt_town_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_town(self):
        url = reverse('casemgmt_town_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "subcounty": create_subcounty().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_town(self):
        town = create_town()
        url = reverse('casemgmt_town_detail', args=[town.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_town(self):
        town = create_town()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "subcounty": create_subcounty().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_town_update', args=[town.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TownVersionViewTest(unittest.TestCase):
    '''
    Tests for TownVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_townversion(self):
        url = reverse('casemgmt_townversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_townversion(self):
        url = reverse('casemgmt_townversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "subcounty": "subcounty",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_townversion(self):
        townversion = create_townversion()
        url = reverse('casemgmt_townversion_detail', args=[townversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_townversion(self):
        townversion = create_townversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "subcounty": "subcounty",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_townversion_update', args=[townversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class TransactionViewTest(unittest.TestCase):
    '''
    Tests for Transaction
    '''
    def setUp(self):
        self.client = Client()

    def test_list_transaction(self):
        url = reverse('casemgmt_transaction_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_transaction(self):
        url = reverse('casemgmt_transaction_create')
        data = {
            "issued_at": "issued_at",
            "id": "id",
            "remote_addr": "remote_addr",
            "user": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_transaction(self):
        transaction = create_transaction()
        url = reverse('casemgmt_transaction_detail', args=[transaction.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_transaction(self):
        transaction = create_transaction()
        data = {
            "issued_at": "issued_at",
            "id": "id",
            "remote_addr": "remote_addr",
            "user": create_abuser().pk,
        }
        url = reverse('casemgmt_transaction_update', args=[transaction.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class VisitViewTest(unittest.TestCase):
    '''
    Tests for Visit
    '''
    def setUp(self):
        self.client = Client()

    def test_list_visit(self):
        url = reverse('casemgmt_visit_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_visit(self):
        url = reverse('casemgmt_visit_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "visitdate": "visitdate",
            "visitnotes": "visitnotes",
            "vistors": create_'visitor'().pk,
            "defendants": create_defendant().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_visit(self):
        visit = create_visit()
        url = reverse('casemgmt_visit_detail', args=[visit.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_visit(self):
        visit = create_visit()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "visitdate": "visitdate",
            "visitnotes": "visitnotes",
            "vistors": create_'visitor'().pk,
            "defendants": create_defendant().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_visit_update', args=[visit.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class VisitVersionViewTest(unittest.TestCase):
    '''
    Tests for VisitVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_visitversion(self):
        url = reverse('casemgmt_visitversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_visitversion(self):
        url = reverse('casemgmt_visitversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "vistors": "vistors",
            "defendants": "defendants",
            "visitdate": "visitdate",
            "visitnotes": "visitnotes",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_visitversion(self):
        visitversion = create_visitversion()
        url = reverse('casemgmt_visitversion_detail', args=[visitversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_visitversion(self):
        visitversion = create_visitversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "priority": "priority",
            "segment": "segment",
            "task_group": "task_group",
            "sequence": "sequence",
            "action": "action",
            "activity_description": "activity_description",
            "goal": "goal",
            "status": "status",
            "planned_start": "planned_start",
            "actual_start": "actual_start",
            "start_notes": "start_notes",
            "planned_end": "planned_end",
            "actual_end": "actual_end",
            "end_notes": "end_notes",
            "deadline": "deadline",
            "not_started": "not_started",
            "early_start": "early_start",
            "late_start": "late_start",
            "completed": "completed",
            "early_end": "early_end",
            "late_end": "late_end",
            "deviation_expected": "deviation_expected",
            "contingency_plan": "contingency_plan",
            "budget": "budget",
            "spend_td": "spend_td",
            "balance_avail": "balance_avail",
            "over_budget": "over_budget",
            "under_budget": "under_budget",
            "vistors": "vistors",
            "defendants": "defendants",
            "visitdate": "visitdate",
            "visitnotes": "visitnotes",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_visitversion_update', args=[visitversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class VisitorViewTest(unittest.TestCase):
    '''
    Tests for Visitor
    '''
    def setUp(self):
        self.client = Client()

    def test_list_visitor(self):
        url = reverse('casemgmt_visitor_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_visitor(self):
        url = reverse('casemgmt_visitor_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_visitor(self):
        visitor = create_visitor()
        url = reverse('casemgmt_visitor_detail', args=[visitor.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_visitor(self):
        visitor = create_visitor()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_visitor_update', args=[visitor.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class VisitorVersionViewTest(unittest.TestCase):
    '''
    Tests for VisitorVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_visitorversion(self):
        url = reverse('casemgmt_visitorversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_visitorversion(self):
        url = reverse('casemgmt_visitorversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_visitorversion(self):
        visitorversion = create_visitorversion()
        url = reverse('casemgmt_visitorversion_detail', args=[visitorversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_visitorversion(self):
        visitorversion = create_visitorversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_visitorversion_update', args=[visitorversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WarderViewTest(unittest.TestCase):
    '''
    Tests for Warder
    '''
    def setUp(self):
        self.client = Client()

    def test_list_warder(self):
        url = reverse('casemgmt_warder_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_warder(self):
        url = reverse('casemgmt_warder_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "prison": create_prison().pk,
            "warder_rank": create_'warderrank'().pk,
            "reports_to": create_'self'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_warder(self):
        warder = create_warder()
        url = reverse('casemgmt_warder_detail', args=[warder.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_warder(self):
        warder = create_warder()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "prison": create_prison().pk,
            "warder_rank": create_'warderrank'().pk,
            "reports_to": create_'self'().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_warder_update', args=[warder.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WarderVersionViewTest(unittest.TestCase):
    '''
    Tests for WarderVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_warderversion(self):
        url = reverse('casemgmt_warderversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_warderversion(self):
        url = reverse('casemgmt_warderversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "prison": "prison",
            "warder_rank": "warder_rank",
            "reports_to": "reports_to",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_warderversion(self):
        warderversion = create_warderversion()
        url = reverse('casemgmt_warderversion_detail', args=[warderversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_warderversion(self):
        warderversion = create_warderversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "prison": "prison",
            "warder_rank": "warder_rank",
            "reports_to": "reports_to",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_warderversion_update', args=[warderversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WarderrankViewTest(unittest.TestCase):
    '''
    Tests for Warderrank
    '''
    def setUp(self):
        self.client = Client()

    def test_list_warderrank(self):
        url = reverse('casemgmt_warderrank_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_warderrank(self):
        url = reverse('casemgmt_warderrank_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_warderrank(self):
        warderrank = create_warderrank()
        url = reverse('casemgmt_warderrank_detail', args=[warderrank.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_warderrank(self):
        warderrank = create_warderrank()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_warderrank_update', args=[warderrank.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WarderrankVersionViewTest(unittest.TestCase):
    '''
    Tests for WarderrankVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_warderrankversion(self):
        url = reverse('casemgmt_warderrankversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_warderrankversion(self):
        url = reverse('casemgmt_warderrankversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_warderrankversion(self):
        warderrankversion = create_warderrankversion()
        url = reverse('casemgmt_warderrankversion_detail', args=[warderrankversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_warderrankversion(self):
        warderrankversion = create_warderrankversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "name": "name",
            "description": "description",
            "notes": "notes",
            "id": "id",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_warderrankversion_update', args=[warderrankversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WitnessViewTest(unittest.TestCase):
    '''
    Tests for Witness
    '''
    def setUp(self):
        self.client = Client()

    def test_list_witness(self):
        url = reverse('casemgmt_witness_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_witness(self):
        url = reverse('casemgmt_witness_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "fordefense": "fordefense",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_witness(self):
        witness = create_witness()
        url = reverse('casemgmt_witness_detail', args=[witness.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_witness(self):
        witness = create_witness()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "fordefense": "fordefense",
            "gender": create_gender().pk,
            "changed_by_fk": create_abuser().pk,
            "created_by_fk": create_abuser().pk,
        }
        url = reverse('casemgmt_witness_update', args=[witness.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


class WitnessVersionViewTest(unittest.TestCase):
    '''
    Tests for WitnessVersion
    '''
    def setUp(self):
        self.client = Client()

    def test_list_witnessversion(self):
        url = reverse('casemgmt_witnessversion_list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_witnessversion(self):
        url = reverse('casemgmt_witnessversion_create')
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "fordefense": "fordefense",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        response = self.client.post(url, data=data)
        self.assertEqual(response.status_code, 302)

    def test_detail_witnessversion(self):
        witnessversion = create_witnessversion()
        url = reverse('casemgmt_witnessversion_detail', args=[witnessversion.pk,])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_update_witnessversion(self):
        witnessversion = create_witnessversion()
        data = {
            "created_on": "created_on",
            "changed_on": "changed_on",
            "firstname": "firstname",
            "surname": "surname",
            "othernames": "othernames",
            "dob": "dob",
            "marital_status": "marital_status",
            "photo": "photo",
            "age_today": "age_today",
            "mobile": "mobile",
            "other_mobile": "other_mobile",
            "fixed_line": "fixed_line",
            "other_fixed_line": "other_fixed_line",
            "email": "email",
            "other_email": "other_email",
            "address_line_1": "address_line_1",
            "address_line_2": "address_line_2",
            "zipcode": "zipcode",
            "town": "town",
            "country": "country",
            "facebook": "facebook",
            "twitter": "twitter",
            "instagram": "instagram",
            "whatsapp": "whatsapp",
            "other_whatsapp": "other_whatsapp",
            "fax": "fax",
            "gcode": "gcode",
            "okhi": "okhi",
            "id": "id",
            "fordefense": "fordefense",
            "gender": "gender",
            "changed_by_fk": "changed_by_fk",
            "created_by_fk": "created_by_fk",
            "transaction_id": "transaction_id",
            "end_transaction_id": "end_transaction_id",
            "operation_type": "operation_type",
        }
        url = reverse('casemgmt_witnessversion_update', args=[witnessversion.pk,])
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)


