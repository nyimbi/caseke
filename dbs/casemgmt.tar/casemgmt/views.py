from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import Bail, BailSurety, BailSuretyVersion, BailVersion, Case, CaseCasecategory, CaseCasecategoryVersion, CaseCauseofaction, CaseCauseofactionVersion, CaseDefendant, CaseDefendantVersion, CaseNatureofsuit, CaseNatureofsuitVersion, CasePlaintiff, CasePlaintiffVersion, CasePolofficer, CasePolofficerVersion, CaseProsecutor, CaseProsecutor2, CaseProsecutor2Version, CaseProsecutorVersion, CaseTag, CaseTagVersion, CaseVersion, CaseWitness, CaseWitnessVersion, Casecategory, CasecategoryVersion, Caseinvestigation, CaseinvestigationVersion, Causeofaction, CauseofactionFiling, CauseofactionFilingVersion, CauseofactionHearing, CauseofactionHearingVersion, CauseofactionVersion, Commitaltype, CommitaltypePrisoncommital, CommitaltypePrisoncommitalVersion, CommitaltypeVersion, Constituency, ConstituencyVersion, County, CountyVersion, Court, CourtVersion, Courtlevel, CourtlevelVersion, Courtstation, CourtstationVersion, Defendant, DefendantGateregister, DefendantGateregisterVersion, DefendantHearing, DefendantHearingVersion, DefendantMedevent, DefendantMedeventVersion, DefendantVersion, Discipline, DisciplineVersion, DocStore, Docarchive, DocarchiveTag, DocarchiveTagVersion, DocarchiveVersion, Doctemplate, DoctemplateVersion, Document, DocumentTag, DocumentTagVersion, DocumentVersion, Eventlog, EventlogVersion, Filing, FilingFilingtype, FilingFilingtypeVersion, FilingPayment, FilingPaymentVersion, FilingVersion, Filingtype, FilingtypeVersion, Gateregister, GateregisterVersion, GateregisterWarder, GateregisterWarder2, GateregisterWarder2Version, GateregisterWarderVersion, Gender, GenderVersion, Hearing, HearingJudicialofficer, HearingJudicialofficerVersion, HearingLawyers, HearingLawyersVersion, HearingPolofficer, HearingPolofficerVersion, HearingProsecutor, HearingProsecutorVersion, HearingTag, HearingTagVersion, HearingVersion, HearingWitness, HearingWitnessVersion, Hearingtype, HearingtypeVersion, Investigation, InvestigationPolofficer, InvestigationPolofficerVersion, InvestigationVersion, InvestigationWitness, InvestigationWitnessVersion, JoRank, JoRankVersion, Judicialofficer, JudicialofficerVersion, Lawfirm, LawfirmVersion, Lawyers, LawyersVersion, Medevent, MedeventVersion, Natureofsuit, NatureofsuitVersion, Payment, PaymentVersion, Paymentmethod, PaymentmethodVersion, Plaintiff, PlaintiffVersion, Policerank, PolicerankVersion, Policerole, PoliceroleVersion, Policestation, PolicestationVersion, Policestationtype, PolicestationtypeVersion, Polofficer, PolofficerPolicerole, PolofficerPoliceroleVersion, PolofficerVersion, Prison, PrisonSecurityrank, PrisonSecurityrankVersion, PrisonVersion, Prisoncell, PrisoncellVersion, Prisoncommital, PrisoncommitalVersion, PrisoncommitalWarder, PrisoncommitalWarderVersion, Prisonerproperty, PrisonerpropertyVersion, Prosecutor, ProsecutorProsecutorteam, ProsecutorProsecutorteamVersion, ProsecutorVersion, Prosecutorteam, ProsecutorteamVersion, Remission, RemissionVersion, Securityrank, SecurityrankVersion, Subcounty, SubcountyVersion, Surety, SuretyVersion, Tag, TagVersion, Town, TownVersion, Transaction, Visit, VisitVersion, Visitor, VisitorVersion, Warder, WarderVersion, Warderrank, WarderrankVersion, Witness, WitnessVersion
from .forms import BailForm, BailSuretyForm, BailSuretyVersionForm, BailVersionForm, CaseForm, CaseCasecategoryForm, CaseCasecategoryVersionForm, CaseCauseofactionForm, CaseCauseofactionVersionForm, CaseDefendantForm, CaseDefendantVersionForm, CaseNatureofsuitForm, CaseNatureofsuitVersionForm, CasePlaintiffForm, CasePlaintiffVersionForm, CasePolofficerForm, CasePolofficerVersionForm, CaseProsecutorForm, CaseProsecutor2Form, CaseProsecutor2VersionForm, CaseProsecutorVersionForm, CaseTagForm, CaseTagVersionForm, CaseVersionForm, CaseWitnessForm, CaseWitnessVersionForm, CasecategoryForm, CasecategoryVersionForm, CaseinvestigationForm, CaseinvestigationVersionForm, CauseofactionForm, CauseofactionFilingForm, CauseofactionFilingVersionForm, CauseofactionHearingForm, CauseofactionHearingVersionForm, CauseofactionVersionForm, CommitaltypeForm, CommitaltypePrisoncommitalForm, CommitaltypePrisoncommitalVersionForm, CommitaltypeVersionForm, ConstituencyForm, ConstituencyVersionForm, CountyForm, CountyVersionForm, CourtForm, CourtVersionForm, CourtlevelForm, CourtlevelVersionForm, CourtstationForm, CourtstationVersionForm, DefendantForm, DefendantGateregisterForm, DefendantGateregisterVersionForm, DefendantHearingForm, DefendantHearingVersionForm, DefendantMedeventForm, DefendantMedeventVersionForm, DefendantVersionForm, DisciplineForm, DisciplineVersionForm, DocStoreForm, DocarchiveForm, DocarchiveTagForm, DocarchiveTagVersionForm, DocarchiveVersionForm, DoctemplateForm, DoctemplateVersionForm, DocumentForm, DocumentTagForm, DocumentTagVersionForm, DocumentVersionForm, EventlogForm, EventlogVersionForm, FilingForm, FilingFilingtypeForm, FilingFilingtypeVersionForm, FilingPaymentForm, FilingPaymentVersionForm, FilingVersionForm, FilingtypeForm, FilingtypeVersionForm, GateregisterForm, GateregisterVersionForm, GateregisterWarderForm, GateregisterWarder2Form, GateregisterWarder2VersionForm, GateregisterWarderVersionForm, GenderForm, GenderVersionForm, HearingForm, HearingJudicialofficerForm, HearingJudicialofficerVersionForm, HearingLawyersForm, HearingLawyersVersionForm, HearingPolofficerForm, HearingPolofficerVersionForm, HearingProsecutorForm, HearingProsecutorVersionForm, HearingTagForm, HearingTagVersionForm, HearingVersionForm, HearingWitnessForm, HearingWitnessVersionForm, HearingtypeForm, HearingtypeVersionForm, InvestigationForm, InvestigationPolofficerForm, InvestigationPolofficerVersionForm, InvestigationVersionForm, InvestigationWitnessForm, InvestigationWitnessVersionForm, JoRankForm, JoRankVersionForm, JudicialofficerForm, JudicialofficerVersionForm, LawfirmForm, LawfirmVersionForm, LawyersForm, LawyersVersionForm, MedeventForm, MedeventVersionForm, NatureofsuitForm, NatureofsuitVersionForm, PaymentForm, PaymentVersionForm, PaymentmethodForm, PaymentmethodVersionForm, PlaintiffForm, PlaintiffVersionForm, PolicerankForm, PolicerankVersionForm, PoliceroleForm, PoliceroleVersionForm, PolicestationForm, PolicestationVersionForm, PolicestationtypeForm, PolicestationtypeVersionForm, PolofficerForm, PolofficerPoliceroleForm, PolofficerPoliceroleVersionForm, PolofficerVersionForm, PrisonForm, PrisonSecurityrankForm, PrisonSecurityrankVersionForm, PrisonVersionForm, PrisoncellForm, PrisoncellVersionForm, PrisoncommitalForm, PrisoncommitalVersionForm, PrisoncommitalWarderForm, PrisoncommitalWarderVersionForm, PrisonerpropertyForm, PrisonerpropertyVersionForm, ProsecutorForm, ProsecutorProsecutorteamForm, ProsecutorProsecutorteamVersionForm, ProsecutorVersionForm, ProsecutorteamForm, ProsecutorteamVersionForm, RemissionForm, RemissionVersionForm, SecurityrankForm, SecurityrankVersionForm, SubcountyForm, SubcountyVersionForm, SuretyForm, SuretyVersionForm, TagForm, TagVersionForm, TownForm, TownVersionForm, TransactionForm, VisitForm, VisitVersionForm, VisitorForm, VisitorVersionForm, WarderForm, WarderVersionForm, WarderrankForm, WarderrankVersionForm, WitnessForm, WitnessVersionForm


class BailListView(ListView):
    model = Bail


class BailCreateView(CreateView):
    model = Bail
    form_class = BailForm


class BailDetailView(DetailView):
    model = Bail


class BailUpdateView(UpdateView):
    model = Bail
    form_class = BailForm


class BailSuretyListView(ListView):
    model = BailSurety


class BailSuretyCreateView(CreateView):
    model = BailSurety
    form_class = BailSuretyForm


class BailSuretyDetailView(DetailView):
    model = BailSurety


class BailSuretyUpdateView(UpdateView):
    model = BailSurety
    form_class = BailSuretyForm


class BailSuretyVersionListView(ListView):
    model = BailSuretyVersion


class BailSuretyVersionCreateView(CreateView):
    model = BailSuretyVersion
    form_class = BailSuretyVersionForm


class BailSuretyVersionDetailView(DetailView):
    model = BailSuretyVersion


class BailSuretyVersionUpdateView(UpdateView):
    model = BailSuretyVersion
    form_class = BailSuretyVersionForm


class BailVersionListView(ListView):
    model = BailVersion


class BailVersionCreateView(CreateView):
    model = BailVersion
    form_class = BailVersionForm


class BailVersionDetailView(DetailView):
    model = BailVersion


class BailVersionUpdateView(UpdateView):
    model = BailVersion
    form_class = BailVersionForm


class CaseListView(ListView):
    model = Case


class CaseCreateView(CreateView):
    model = Case
    form_class = CaseForm


class CaseDetailView(DetailView):
    model = Case


class CaseUpdateView(UpdateView):
    model = Case
    form_class = CaseForm


class CaseCasecategoryListView(ListView):
    model = CaseCasecategory


class CaseCasecategoryCreateView(CreateView):
    model = CaseCasecategory
    form_class = CaseCasecategoryForm


class CaseCasecategoryDetailView(DetailView):
    model = CaseCasecategory


class CaseCasecategoryUpdateView(UpdateView):
    model = CaseCasecategory
    form_class = CaseCasecategoryForm


class CaseCasecategoryVersionListView(ListView):
    model = CaseCasecategoryVersion


class CaseCasecategoryVersionCreateView(CreateView):
    model = CaseCasecategoryVersion
    form_class = CaseCasecategoryVersionForm


class CaseCasecategoryVersionDetailView(DetailView):
    model = CaseCasecategoryVersion


class CaseCasecategoryVersionUpdateView(UpdateView):
    model = CaseCasecategoryVersion
    form_class = CaseCasecategoryVersionForm


class CaseCauseofactionListView(ListView):
    model = CaseCauseofaction


class CaseCauseofactionCreateView(CreateView):
    model = CaseCauseofaction
    form_class = CaseCauseofactionForm


class CaseCauseofactionDetailView(DetailView):
    model = CaseCauseofaction


class CaseCauseofactionUpdateView(UpdateView):
    model = CaseCauseofaction
    form_class = CaseCauseofactionForm


class CaseCauseofactionVersionListView(ListView):
    model = CaseCauseofactionVersion


class CaseCauseofactionVersionCreateView(CreateView):
    model = CaseCauseofactionVersion
    form_class = CaseCauseofactionVersionForm


class CaseCauseofactionVersionDetailView(DetailView):
    model = CaseCauseofactionVersion


class CaseCauseofactionVersionUpdateView(UpdateView):
    model = CaseCauseofactionVersion
    form_class = CaseCauseofactionVersionForm


class CaseDefendantListView(ListView):
    model = CaseDefendant


class CaseDefendantCreateView(CreateView):
    model = CaseDefendant
    form_class = CaseDefendantForm


class CaseDefendantDetailView(DetailView):
    model = CaseDefendant


class CaseDefendantUpdateView(UpdateView):
    model = CaseDefendant
    form_class = CaseDefendantForm


class CaseDefendantVersionListView(ListView):
    model = CaseDefendantVersion


class CaseDefendantVersionCreateView(CreateView):
    model = CaseDefendantVersion
    form_class = CaseDefendantVersionForm


class CaseDefendantVersionDetailView(DetailView):
    model = CaseDefendantVersion


class CaseDefendantVersionUpdateView(UpdateView):
    model = CaseDefendantVersion
    form_class = CaseDefendantVersionForm


class CaseNatureofsuitListView(ListView):
    model = CaseNatureofsuit


class CaseNatureofsuitCreateView(CreateView):
    model = CaseNatureofsuit
    form_class = CaseNatureofsuitForm


class CaseNatureofsuitDetailView(DetailView):
    model = CaseNatureofsuit


class CaseNatureofsuitUpdateView(UpdateView):
    model = CaseNatureofsuit
    form_class = CaseNatureofsuitForm


class CaseNatureofsuitVersionListView(ListView):
    model = CaseNatureofsuitVersion


class CaseNatureofsuitVersionCreateView(CreateView):
    model = CaseNatureofsuitVersion
    form_class = CaseNatureofsuitVersionForm


class CaseNatureofsuitVersionDetailView(DetailView):
    model = CaseNatureofsuitVersion


class CaseNatureofsuitVersionUpdateView(UpdateView):
    model = CaseNatureofsuitVersion
    form_class = CaseNatureofsuitVersionForm


class CasePlaintiffListView(ListView):
    model = CasePlaintiff


class CasePlaintiffCreateView(CreateView):
    model = CasePlaintiff
    form_class = CasePlaintiffForm


class CasePlaintiffDetailView(DetailView):
    model = CasePlaintiff


class CasePlaintiffUpdateView(UpdateView):
    model = CasePlaintiff
    form_class = CasePlaintiffForm


class CasePlaintiffVersionListView(ListView):
    model = CasePlaintiffVersion


class CasePlaintiffVersionCreateView(CreateView):
    model = CasePlaintiffVersion
    form_class = CasePlaintiffVersionForm


class CasePlaintiffVersionDetailView(DetailView):
    model = CasePlaintiffVersion


class CasePlaintiffVersionUpdateView(UpdateView):
    model = CasePlaintiffVersion
    form_class = CasePlaintiffVersionForm


class CasePolofficerListView(ListView):
    model = CasePolofficer


class CasePolofficerCreateView(CreateView):
    model = CasePolofficer
    form_class = CasePolofficerForm


class CasePolofficerDetailView(DetailView):
    model = CasePolofficer


class CasePolofficerUpdateView(UpdateView):
    model = CasePolofficer
    form_class = CasePolofficerForm


class CasePolofficerVersionListView(ListView):
    model = CasePolofficerVersion


class CasePolofficerVersionCreateView(CreateView):
    model = CasePolofficerVersion
    form_class = CasePolofficerVersionForm


class CasePolofficerVersionDetailView(DetailView):
    model = CasePolofficerVersion


class CasePolofficerVersionUpdateView(UpdateView):
    model = CasePolofficerVersion
    form_class = CasePolofficerVersionForm


class CaseProsecutorListView(ListView):
    model = CaseProsecutor


class CaseProsecutorCreateView(CreateView):
    model = CaseProsecutor
    form_class = CaseProsecutorForm


class CaseProsecutorDetailView(DetailView):
    model = CaseProsecutor


class CaseProsecutorUpdateView(UpdateView):
    model = CaseProsecutor
    form_class = CaseProsecutorForm


class CaseProsecutor2ListView(ListView):
    model = CaseProsecutor2


class CaseProsecutor2CreateView(CreateView):
    model = CaseProsecutor2
    form_class = CaseProsecutor2Form


class CaseProsecutor2DetailView(DetailView):
    model = CaseProsecutor2


class CaseProsecutor2UpdateView(UpdateView):
    model = CaseProsecutor2
    form_class = CaseProsecutor2Form


class CaseProsecutor2VersionListView(ListView):
    model = CaseProsecutor2Version


class CaseProsecutor2VersionCreateView(CreateView):
    model = CaseProsecutor2Version
    form_class = CaseProsecutor2VersionForm


class CaseProsecutor2VersionDetailView(DetailView):
    model = CaseProsecutor2Version


class CaseProsecutor2VersionUpdateView(UpdateView):
    model = CaseProsecutor2Version
    form_class = CaseProsecutor2VersionForm


class CaseProsecutorVersionListView(ListView):
    model = CaseProsecutorVersion


class CaseProsecutorVersionCreateView(CreateView):
    model = CaseProsecutorVersion
    form_class = CaseProsecutorVersionForm


class CaseProsecutorVersionDetailView(DetailView):
    model = CaseProsecutorVersion


class CaseProsecutorVersionUpdateView(UpdateView):
    model = CaseProsecutorVersion
    form_class = CaseProsecutorVersionForm


class CaseTagListView(ListView):
    model = CaseTag


class CaseTagCreateView(CreateView):
    model = CaseTag
    form_class = CaseTagForm


class CaseTagDetailView(DetailView):
    model = CaseTag


class CaseTagUpdateView(UpdateView):
    model = CaseTag
    form_class = CaseTagForm


class CaseTagVersionListView(ListView):
    model = CaseTagVersion


class CaseTagVersionCreateView(CreateView):
    model = CaseTagVersion
    form_class = CaseTagVersionForm


class CaseTagVersionDetailView(DetailView):
    model = CaseTagVersion


class CaseTagVersionUpdateView(UpdateView):
    model = CaseTagVersion
    form_class = CaseTagVersionForm


class CaseVersionListView(ListView):
    model = CaseVersion


class CaseVersionCreateView(CreateView):
    model = CaseVersion
    form_class = CaseVersionForm


class CaseVersionDetailView(DetailView):
    model = CaseVersion


class CaseVersionUpdateView(UpdateView):
    model = CaseVersion
    form_class = CaseVersionForm


class CaseWitnessListView(ListView):
    model = CaseWitness


class CaseWitnessCreateView(CreateView):
    model = CaseWitness
    form_class = CaseWitnessForm


class CaseWitnessDetailView(DetailView):
    model = CaseWitness


class CaseWitnessUpdateView(UpdateView):
    model = CaseWitness
    form_class = CaseWitnessForm


class CaseWitnessVersionListView(ListView):
    model = CaseWitnessVersion


class CaseWitnessVersionCreateView(CreateView):
    model = CaseWitnessVersion
    form_class = CaseWitnessVersionForm


class CaseWitnessVersionDetailView(DetailView):
    model = CaseWitnessVersion


class CaseWitnessVersionUpdateView(UpdateView):
    model = CaseWitnessVersion
    form_class = CaseWitnessVersionForm


class CasecategoryListView(ListView):
    model = Casecategory


class CasecategoryCreateView(CreateView):
    model = Casecategory
    form_class = CasecategoryForm


class CasecategoryDetailView(DetailView):
    model = Casecategory


class CasecategoryUpdateView(UpdateView):
    model = Casecategory
    form_class = CasecategoryForm


class CasecategoryVersionListView(ListView):
    model = CasecategoryVersion


class CasecategoryVersionCreateView(CreateView):
    model = CasecategoryVersion
    form_class = CasecategoryVersionForm


class CasecategoryVersionDetailView(DetailView):
    model = CasecategoryVersion


class CasecategoryVersionUpdateView(UpdateView):
    model = CasecategoryVersion
    form_class = CasecategoryVersionForm


class CaseinvestigationListView(ListView):
    model = Caseinvestigation


class CaseinvestigationCreateView(CreateView):
    model = Caseinvestigation
    form_class = CaseinvestigationForm


class CaseinvestigationDetailView(DetailView):
    model = Caseinvestigation


class CaseinvestigationUpdateView(UpdateView):
    model = Caseinvestigation
    form_class = CaseinvestigationForm


class CaseinvestigationVersionListView(ListView):
    model = CaseinvestigationVersion


class CaseinvestigationVersionCreateView(CreateView):
    model = CaseinvestigationVersion
    form_class = CaseinvestigationVersionForm


class CaseinvestigationVersionDetailView(DetailView):
    model = CaseinvestigationVersion


class CaseinvestigationVersionUpdateView(UpdateView):
    model = CaseinvestigationVersion
    form_class = CaseinvestigationVersionForm


class CauseofactionListView(ListView):
    model = Causeofaction


class CauseofactionCreateView(CreateView):
    model = Causeofaction
    form_class = CauseofactionForm


class CauseofactionDetailView(DetailView):
    model = Causeofaction


class CauseofactionUpdateView(UpdateView):
    model = Causeofaction
    form_class = CauseofactionForm


class CauseofactionFilingListView(ListView):
    model = CauseofactionFiling


class CauseofactionFilingCreateView(CreateView):
    model = CauseofactionFiling
    form_class = CauseofactionFilingForm


class CauseofactionFilingDetailView(DetailView):
    model = CauseofactionFiling


class CauseofactionFilingUpdateView(UpdateView):
    model = CauseofactionFiling
    form_class = CauseofactionFilingForm


class CauseofactionFilingVersionListView(ListView):
    model = CauseofactionFilingVersion


class CauseofactionFilingVersionCreateView(CreateView):
    model = CauseofactionFilingVersion
    form_class = CauseofactionFilingVersionForm


class CauseofactionFilingVersionDetailView(DetailView):
    model = CauseofactionFilingVersion


class CauseofactionFilingVersionUpdateView(UpdateView):
    model = CauseofactionFilingVersion
    form_class = CauseofactionFilingVersionForm


class CauseofactionHearingListView(ListView):
    model = CauseofactionHearing


class CauseofactionHearingCreateView(CreateView):
    model = CauseofactionHearing
    form_class = CauseofactionHearingForm


class CauseofactionHearingDetailView(DetailView):
    model = CauseofactionHearing


class CauseofactionHearingUpdateView(UpdateView):
    model = CauseofactionHearing
    form_class = CauseofactionHearingForm


class CauseofactionHearingVersionListView(ListView):
    model = CauseofactionHearingVersion


class CauseofactionHearingVersionCreateView(CreateView):
    model = CauseofactionHearingVersion
    form_class = CauseofactionHearingVersionForm


class CauseofactionHearingVersionDetailView(DetailView):
    model = CauseofactionHearingVersion


class CauseofactionHearingVersionUpdateView(UpdateView):
    model = CauseofactionHearingVersion
    form_class = CauseofactionHearingVersionForm


class CauseofactionVersionListView(ListView):
    model = CauseofactionVersion


class CauseofactionVersionCreateView(CreateView):
    model = CauseofactionVersion
    form_class = CauseofactionVersionForm


class CauseofactionVersionDetailView(DetailView):
    model = CauseofactionVersion


class CauseofactionVersionUpdateView(UpdateView):
    model = CauseofactionVersion
    form_class = CauseofactionVersionForm


class CommitaltypeListView(ListView):
    model = Commitaltype


class CommitaltypeCreateView(CreateView):
    model = Commitaltype
    form_class = CommitaltypeForm


class CommitaltypeDetailView(DetailView):
    model = Commitaltype


class CommitaltypeUpdateView(UpdateView):
    model = Commitaltype
    form_class = CommitaltypeForm


class CommitaltypePrisoncommitalListView(ListView):
    model = CommitaltypePrisoncommital


class CommitaltypePrisoncommitalCreateView(CreateView):
    model = CommitaltypePrisoncommital
    form_class = CommitaltypePrisoncommitalForm


class CommitaltypePrisoncommitalDetailView(DetailView):
    model = CommitaltypePrisoncommital


class CommitaltypePrisoncommitalUpdateView(UpdateView):
    model = CommitaltypePrisoncommital
    form_class = CommitaltypePrisoncommitalForm


class CommitaltypePrisoncommitalVersionListView(ListView):
    model = CommitaltypePrisoncommitalVersion


class CommitaltypePrisoncommitalVersionCreateView(CreateView):
    model = CommitaltypePrisoncommitalVersion
    form_class = CommitaltypePrisoncommitalVersionForm


class CommitaltypePrisoncommitalVersionDetailView(DetailView):
    model = CommitaltypePrisoncommitalVersion


class CommitaltypePrisoncommitalVersionUpdateView(UpdateView):
    model = CommitaltypePrisoncommitalVersion
    form_class = CommitaltypePrisoncommitalVersionForm


class CommitaltypeVersionListView(ListView):
    model = CommitaltypeVersion


class CommitaltypeVersionCreateView(CreateView):
    model = CommitaltypeVersion
    form_class = CommitaltypeVersionForm


class CommitaltypeVersionDetailView(DetailView):
    model = CommitaltypeVersion


class CommitaltypeVersionUpdateView(UpdateView):
    model = CommitaltypeVersion
    form_class = CommitaltypeVersionForm


class ConstituencyListView(ListView):
    model = Constituency


class ConstituencyCreateView(CreateView):
    model = Constituency
    form_class = ConstituencyForm


class ConstituencyDetailView(DetailView):
    model = Constituency


class ConstituencyUpdateView(UpdateView):
    model = Constituency
    form_class = ConstituencyForm


class ConstituencyVersionListView(ListView):
    model = ConstituencyVersion


class ConstituencyVersionCreateView(CreateView):
    model = ConstituencyVersion
    form_class = ConstituencyVersionForm


class ConstituencyVersionDetailView(DetailView):
    model = ConstituencyVersion


class ConstituencyVersionUpdateView(UpdateView):
    model = ConstituencyVersion
    form_class = ConstituencyVersionForm


class CountyListView(ListView):
    model = County


class CountyCreateView(CreateView):
    model = County
    form_class = CountyForm


class CountyDetailView(DetailView):
    model = County


class CountyUpdateView(UpdateView):
    model = County
    form_class = CountyForm


class CountyVersionListView(ListView):
    model = CountyVersion


class CountyVersionCreateView(CreateView):
    model = CountyVersion
    form_class = CountyVersionForm


class CountyVersionDetailView(DetailView):
    model = CountyVersion


class CountyVersionUpdateView(UpdateView):
    model = CountyVersion
    form_class = CountyVersionForm


class CourtListView(ListView):
    model = Court


class CourtCreateView(CreateView):
    model = Court
    form_class = CourtForm


class CourtDetailView(DetailView):
    model = Court


class CourtUpdateView(UpdateView):
    model = Court
    form_class = CourtForm


class CourtVersionListView(ListView):
    model = CourtVersion


class CourtVersionCreateView(CreateView):
    model = CourtVersion
    form_class = CourtVersionForm


class CourtVersionDetailView(DetailView):
    model = CourtVersion


class CourtVersionUpdateView(UpdateView):
    model = CourtVersion
    form_class = CourtVersionForm


class CourtlevelListView(ListView):
    model = Courtlevel


class CourtlevelCreateView(CreateView):
    model = Courtlevel
    form_class = CourtlevelForm


class CourtlevelDetailView(DetailView):
    model = Courtlevel


class CourtlevelUpdateView(UpdateView):
    model = Courtlevel
    form_class = CourtlevelForm


class CourtlevelVersionListView(ListView):
    model = CourtlevelVersion


class CourtlevelVersionCreateView(CreateView):
    model = CourtlevelVersion
    form_class = CourtlevelVersionForm


class CourtlevelVersionDetailView(DetailView):
    model = CourtlevelVersion


class CourtlevelVersionUpdateView(UpdateView):
    model = CourtlevelVersion
    form_class = CourtlevelVersionForm


class CourtstationListView(ListView):
    model = Courtstation


class CourtstationCreateView(CreateView):
    model = Courtstation
    form_class = CourtstationForm


class CourtstationDetailView(DetailView):
    model = Courtstation


class CourtstationUpdateView(UpdateView):
    model = Courtstation
    form_class = CourtstationForm


class CourtstationVersionListView(ListView):
    model = CourtstationVersion


class CourtstationVersionCreateView(CreateView):
    model = CourtstationVersion
    form_class = CourtstationVersionForm


class CourtstationVersionDetailView(DetailView):
    model = CourtstationVersion


class CourtstationVersionUpdateView(UpdateView):
    model = CourtstationVersion
    form_class = CourtstationVersionForm


class DefendantListView(ListView):
    model = Defendant


class DefendantCreateView(CreateView):
    model = Defendant
    form_class = DefendantForm


class DefendantDetailView(DetailView):
    model = Defendant


class DefendantUpdateView(UpdateView):
    model = Defendant
    form_class = DefendantForm


class DefendantGateregisterListView(ListView):
    model = DefendantGateregister


class DefendantGateregisterCreateView(CreateView):
    model = DefendantGateregister
    form_class = DefendantGateregisterForm


class DefendantGateregisterDetailView(DetailView):
    model = DefendantGateregister


class DefendantGateregisterUpdateView(UpdateView):
    model = DefendantGateregister
    form_class = DefendantGateregisterForm


class DefendantGateregisterVersionListView(ListView):
    model = DefendantGateregisterVersion


class DefendantGateregisterVersionCreateView(CreateView):
    model = DefendantGateregisterVersion
    form_class = DefendantGateregisterVersionForm


class DefendantGateregisterVersionDetailView(DetailView):
    model = DefendantGateregisterVersion


class DefendantGateregisterVersionUpdateView(UpdateView):
    model = DefendantGateregisterVersion
    form_class = DefendantGateregisterVersionForm


class DefendantHearingListView(ListView):
    model = DefendantHearing


class DefendantHearingCreateView(CreateView):
    model = DefendantHearing
    form_class = DefendantHearingForm


class DefendantHearingDetailView(DetailView):
    model = DefendantHearing


class DefendantHearingUpdateView(UpdateView):
    model = DefendantHearing
    form_class = DefendantHearingForm


class DefendantHearingVersionListView(ListView):
    model = DefendantHearingVersion


class DefendantHearingVersionCreateView(CreateView):
    model = DefendantHearingVersion
    form_class = DefendantHearingVersionForm


class DefendantHearingVersionDetailView(DetailView):
    model = DefendantHearingVersion


class DefendantHearingVersionUpdateView(UpdateView):
    model = DefendantHearingVersion
    form_class = DefendantHearingVersionForm


class DefendantMedeventListView(ListView):
    model = DefendantMedevent


class DefendantMedeventCreateView(CreateView):
    model = DefendantMedevent
    form_class = DefendantMedeventForm


class DefendantMedeventDetailView(DetailView):
    model = DefendantMedevent


class DefendantMedeventUpdateView(UpdateView):
    model = DefendantMedevent
    form_class = DefendantMedeventForm


class DefendantMedeventVersionListView(ListView):
    model = DefendantMedeventVersion


class DefendantMedeventVersionCreateView(CreateView):
    model = DefendantMedeventVersion
    form_class = DefendantMedeventVersionForm


class DefendantMedeventVersionDetailView(DetailView):
    model = DefendantMedeventVersion


class DefendantMedeventVersionUpdateView(UpdateView):
    model = DefendantMedeventVersion
    form_class = DefendantMedeventVersionForm


class DefendantVersionListView(ListView):
    model = DefendantVersion


class DefendantVersionCreateView(CreateView):
    model = DefendantVersion
    form_class = DefendantVersionForm


class DefendantVersionDetailView(DetailView):
    model = DefendantVersion


class DefendantVersionUpdateView(UpdateView):
    model = DefendantVersion
    form_class = DefendantVersionForm


class DisciplineListView(ListView):
    model = Discipline


class DisciplineCreateView(CreateView):
    model = Discipline
    form_class = DisciplineForm


class DisciplineDetailView(DetailView):
    model = Discipline


class DisciplineUpdateView(UpdateView):
    model = Discipline
    form_class = DisciplineForm


class DisciplineVersionListView(ListView):
    model = DisciplineVersion


class DisciplineVersionCreateView(CreateView):
    model = DisciplineVersion
    form_class = DisciplineVersionForm


class DisciplineVersionDetailView(DetailView):
    model = DisciplineVersion


class DisciplineVersionUpdateView(UpdateView):
    model = DisciplineVersion
    form_class = DisciplineVersionForm


class DocStoreListView(ListView):
    model = DocStore


class DocStoreCreateView(CreateView):
    model = DocStore
    form_class = DocStoreForm


class DocStoreDetailView(DetailView):
    model = DocStore


class DocStoreUpdateView(UpdateView):
    model = DocStore
    form_class = DocStoreForm


class DocarchiveListView(ListView):
    model = Docarchive


class DocarchiveCreateView(CreateView):
    model = Docarchive
    form_class = DocarchiveForm


class DocarchiveDetailView(DetailView):
    model = Docarchive


class DocarchiveUpdateView(UpdateView):
    model = Docarchive
    form_class = DocarchiveForm


class DocarchiveTagListView(ListView):
    model = DocarchiveTag


class DocarchiveTagCreateView(CreateView):
    model = DocarchiveTag
    form_class = DocarchiveTagForm


class DocarchiveTagDetailView(DetailView):
    model = DocarchiveTag


class DocarchiveTagUpdateView(UpdateView):
    model = DocarchiveTag
    form_class = DocarchiveTagForm


class DocarchiveTagVersionListView(ListView):
    model = DocarchiveTagVersion


class DocarchiveTagVersionCreateView(CreateView):
    model = DocarchiveTagVersion
    form_class = DocarchiveTagVersionForm


class DocarchiveTagVersionDetailView(DetailView):
    model = DocarchiveTagVersion


class DocarchiveTagVersionUpdateView(UpdateView):
    model = DocarchiveTagVersion
    form_class = DocarchiveTagVersionForm


class DocarchiveVersionListView(ListView):
    model = DocarchiveVersion


class DocarchiveVersionCreateView(CreateView):
    model = DocarchiveVersion
    form_class = DocarchiveVersionForm


class DocarchiveVersionDetailView(DetailView):
    model = DocarchiveVersion


class DocarchiveVersionUpdateView(UpdateView):
    model = DocarchiveVersion
    form_class = DocarchiveVersionForm


class DoctemplateListView(ListView):
    model = Doctemplate


class DoctemplateCreateView(CreateView):
    model = Doctemplate
    form_class = DoctemplateForm


class DoctemplateDetailView(DetailView):
    model = Doctemplate


class DoctemplateUpdateView(UpdateView):
    model = Doctemplate
    form_class = DoctemplateForm


class DoctemplateVersionListView(ListView):
    model = DoctemplateVersion


class DoctemplateVersionCreateView(CreateView):
    model = DoctemplateVersion
    form_class = DoctemplateVersionForm


class DoctemplateVersionDetailView(DetailView):
    model = DoctemplateVersion


class DoctemplateVersionUpdateView(UpdateView):
    model = DoctemplateVersion
    form_class = DoctemplateVersionForm


class DocumentListView(ListView):
    model = Document


class DocumentCreateView(CreateView):
    model = Document
    form_class = DocumentForm


class DocumentDetailView(DetailView):
    model = Document


class DocumentUpdateView(UpdateView):
    model = Document
    form_class = DocumentForm


class DocumentTagListView(ListView):
    model = DocumentTag


class DocumentTagCreateView(CreateView):
    model = DocumentTag
    form_class = DocumentTagForm


class DocumentTagDetailView(DetailView):
    model = DocumentTag


class DocumentTagUpdateView(UpdateView):
    model = DocumentTag
    form_class = DocumentTagForm


class DocumentTagVersionListView(ListView):
    model = DocumentTagVersion


class DocumentTagVersionCreateView(CreateView):
    model = DocumentTagVersion
    form_class = DocumentTagVersionForm


class DocumentTagVersionDetailView(DetailView):
    model = DocumentTagVersion


class DocumentTagVersionUpdateView(UpdateView):
    model = DocumentTagVersion
    form_class = DocumentTagVersionForm


class DocumentVersionListView(ListView):
    model = DocumentVersion


class DocumentVersionCreateView(CreateView):
    model = DocumentVersion
    form_class = DocumentVersionForm


class DocumentVersionDetailView(DetailView):
    model = DocumentVersion


class DocumentVersionUpdateView(UpdateView):
    model = DocumentVersion
    form_class = DocumentVersionForm


class EventlogListView(ListView):
    model = Eventlog


class EventlogCreateView(CreateView):
    model = Eventlog
    form_class = EventlogForm


class EventlogDetailView(DetailView):
    model = Eventlog


class EventlogUpdateView(UpdateView):
    model = Eventlog
    form_class = EventlogForm


class EventlogVersionListView(ListView):
    model = EventlogVersion


class EventlogVersionCreateView(CreateView):
    model = EventlogVersion
    form_class = EventlogVersionForm


class EventlogVersionDetailView(DetailView):
    model = EventlogVersion


class EventlogVersionUpdateView(UpdateView):
    model = EventlogVersion
    form_class = EventlogVersionForm


class FilingListView(ListView):
    model = Filing


class FilingCreateView(CreateView):
    model = Filing
    form_class = FilingForm


class FilingDetailView(DetailView):
    model = Filing


class FilingUpdateView(UpdateView):
    model = Filing
    form_class = FilingForm


class FilingFilingtypeListView(ListView):
    model = FilingFilingtype


class FilingFilingtypeCreateView(CreateView):
    model = FilingFilingtype
    form_class = FilingFilingtypeForm


class FilingFilingtypeDetailView(DetailView):
    model = FilingFilingtype


class FilingFilingtypeUpdateView(UpdateView):
    model = FilingFilingtype
    form_class = FilingFilingtypeForm


class FilingFilingtypeVersionListView(ListView):
    model = FilingFilingtypeVersion


class FilingFilingtypeVersionCreateView(CreateView):
    model = FilingFilingtypeVersion
    form_class = FilingFilingtypeVersionForm


class FilingFilingtypeVersionDetailView(DetailView):
    model = FilingFilingtypeVersion


class FilingFilingtypeVersionUpdateView(UpdateView):
    model = FilingFilingtypeVersion
    form_class = FilingFilingtypeVersionForm


class FilingPaymentListView(ListView):
    model = FilingPayment


class FilingPaymentCreateView(CreateView):
    model = FilingPayment
    form_class = FilingPaymentForm


class FilingPaymentDetailView(DetailView):
    model = FilingPayment


class FilingPaymentUpdateView(UpdateView):
    model = FilingPayment
    form_class = FilingPaymentForm


class FilingPaymentVersionListView(ListView):
    model = FilingPaymentVersion


class FilingPaymentVersionCreateView(CreateView):
    model = FilingPaymentVersion
    form_class = FilingPaymentVersionForm


class FilingPaymentVersionDetailView(DetailView):
    model = FilingPaymentVersion


class FilingPaymentVersionUpdateView(UpdateView):
    model = FilingPaymentVersion
    form_class = FilingPaymentVersionForm


class FilingVersionListView(ListView):
    model = FilingVersion


class FilingVersionCreateView(CreateView):
    model = FilingVersion
    form_class = FilingVersionForm


class FilingVersionDetailView(DetailView):
    model = FilingVersion


class FilingVersionUpdateView(UpdateView):
    model = FilingVersion
    form_class = FilingVersionForm


class FilingtypeListView(ListView):
    model = Filingtype


class FilingtypeCreateView(CreateView):
    model = Filingtype
    form_class = FilingtypeForm


class FilingtypeDetailView(DetailView):
    model = Filingtype


class FilingtypeUpdateView(UpdateView):
    model = Filingtype
    form_class = FilingtypeForm


class FilingtypeVersionListView(ListView):
    model = FilingtypeVersion


class FilingtypeVersionCreateView(CreateView):
    model = FilingtypeVersion
    form_class = FilingtypeVersionForm


class FilingtypeVersionDetailView(DetailView):
    model = FilingtypeVersion


class FilingtypeVersionUpdateView(UpdateView):
    model = FilingtypeVersion
    form_class = FilingtypeVersionForm


class GateregisterListView(ListView):
    model = Gateregister


class GateregisterCreateView(CreateView):
    model = Gateregister
    form_class = GateregisterForm


class GateregisterDetailView(DetailView):
    model = Gateregister


class GateregisterUpdateView(UpdateView):
    model = Gateregister
    form_class = GateregisterForm


class GateregisterVersionListView(ListView):
    model = GateregisterVersion


class GateregisterVersionCreateView(CreateView):
    model = GateregisterVersion
    form_class = GateregisterVersionForm


class GateregisterVersionDetailView(DetailView):
    model = GateregisterVersion


class GateregisterVersionUpdateView(UpdateView):
    model = GateregisterVersion
    form_class = GateregisterVersionForm


class GateregisterWarderListView(ListView):
    model = GateregisterWarder


class GateregisterWarderCreateView(CreateView):
    model = GateregisterWarder
    form_class = GateregisterWarderForm


class GateregisterWarderDetailView(DetailView):
    model = GateregisterWarder


class GateregisterWarderUpdateView(UpdateView):
    model = GateregisterWarder
    form_class = GateregisterWarderForm


class GateregisterWarder2ListView(ListView):
    model = GateregisterWarder2


class GateregisterWarder2CreateView(CreateView):
    model = GateregisterWarder2
    form_class = GateregisterWarder2Form


class GateregisterWarder2DetailView(DetailView):
    model = GateregisterWarder2


class GateregisterWarder2UpdateView(UpdateView):
    model = GateregisterWarder2
    form_class = GateregisterWarder2Form


class GateregisterWarder2VersionListView(ListView):
    model = GateregisterWarder2Version


class GateregisterWarder2VersionCreateView(CreateView):
    model = GateregisterWarder2Version
    form_class = GateregisterWarder2VersionForm


class GateregisterWarder2VersionDetailView(DetailView):
    model = GateregisterWarder2Version


class GateregisterWarder2VersionUpdateView(UpdateView):
    model = GateregisterWarder2Version
    form_class = GateregisterWarder2VersionForm


class GateregisterWarderVersionListView(ListView):
    model = GateregisterWarderVersion


class GateregisterWarderVersionCreateView(CreateView):
    model = GateregisterWarderVersion
    form_class = GateregisterWarderVersionForm


class GateregisterWarderVersionDetailView(DetailView):
    model = GateregisterWarderVersion


class GateregisterWarderVersionUpdateView(UpdateView):
    model = GateregisterWarderVersion
    form_class = GateregisterWarderVersionForm


class GenderListView(ListView):
    model = Gender


class GenderCreateView(CreateView):
    model = Gender
    form_class = GenderForm


class GenderDetailView(DetailView):
    model = Gender


class GenderUpdateView(UpdateView):
    model = Gender
    form_class = GenderForm


class GenderVersionListView(ListView):
    model = GenderVersion


class GenderVersionCreateView(CreateView):
    model = GenderVersion
    form_class = GenderVersionForm


class GenderVersionDetailView(DetailView):
    model = GenderVersion


class GenderVersionUpdateView(UpdateView):
    model = GenderVersion
    form_class = GenderVersionForm


class HearingListView(ListView):
    model = Hearing


class HearingCreateView(CreateView):
    model = Hearing
    form_class = HearingForm


class HearingDetailView(DetailView):
    model = Hearing


class HearingUpdateView(UpdateView):
    model = Hearing
    form_class = HearingForm


class HearingJudicialofficerListView(ListView):
    model = HearingJudicialofficer


class HearingJudicialofficerCreateView(CreateView):
    model = HearingJudicialofficer
    form_class = HearingJudicialofficerForm


class HearingJudicialofficerDetailView(DetailView):
    model = HearingJudicialofficer


class HearingJudicialofficerUpdateView(UpdateView):
    model = HearingJudicialofficer
    form_class = HearingJudicialofficerForm


class HearingJudicialofficerVersionListView(ListView):
    model = HearingJudicialofficerVersion


class HearingJudicialofficerVersionCreateView(CreateView):
    model = HearingJudicialofficerVersion
    form_class = HearingJudicialofficerVersionForm


class HearingJudicialofficerVersionDetailView(DetailView):
    model = HearingJudicialofficerVersion


class HearingJudicialofficerVersionUpdateView(UpdateView):
    model = HearingJudicialofficerVersion
    form_class = HearingJudicialofficerVersionForm


class HearingLawyersListView(ListView):
    model = HearingLawyers


class HearingLawyersCreateView(CreateView):
    model = HearingLawyers
    form_class = HearingLawyersForm


class HearingLawyersDetailView(DetailView):
    model = HearingLawyers


class HearingLawyersUpdateView(UpdateView):
    model = HearingLawyers
    form_class = HearingLawyersForm


class HearingLawyersVersionListView(ListView):
    model = HearingLawyersVersion


class HearingLawyersVersionCreateView(CreateView):
    model = HearingLawyersVersion
    form_class = HearingLawyersVersionForm


class HearingLawyersVersionDetailView(DetailView):
    model = HearingLawyersVersion


class HearingLawyersVersionUpdateView(UpdateView):
    model = HearingLawyersVersion
    form_class = HearingLawyersVersionForm


class HearingPolofficerListView(ListView):
    model = HearingPolofficer


class HearingPolofficerCreateView(CreateView):
    model = HearingPolofficer
    form_class = HearingPolofficerForm


class HearingPolofficerDetailView(DetailView):
    model = HearingPolofficer


class HearingPolofficerUpdateView(UpdateView):
    model = HearingPolofficer
    form_class = HearingPolofficerForm


class HearingPolofficerVersionListView(ListView):
    model = HearingPolofficerVersion


class HearingPolofficerVersionCreateView(CreateView):
    model = HearingPolofficerVersion
    form_class = HearingPolofficerVersionForm


class HearingPolofficerVersionDetailView(DetailView):
    model = HearingPolofficerVersion


class HearingPolofficerVersionUpdateView(UpdateView):
    model = HearingPolofficerVersion
    form_class = HearingPolofficerVersionForm


class HearingProsecutorListView(ListView):
    model = HearingProsecutor


class HearingProsecutorCreateView(CreateView):
    model = HearingProsecutor
    form_class = HearingProsecutorForm


class HearingProsecutorDetailView(DetailView):
    model = HearingProsecutor


class HearingProsecutorUpdateView(UpdateView):
    model = HearingProsecutor
    form_class = HearingProsecutorForm


class HearingProsecutorVersionListView(ListView):
    model = HearingProsecutorVersion


class HearingProsecutorVersionCreateView(CreateView):
    model = HearingProsecutorVersion
    form_class = HearingProsecutorVersionForm


class HearingProsecutorVersionDetailView(DetailView):
    model = HearingProsecutorVersion


class HearingProsecutorVersionUpdateView(UpdateView):
    model = HearingProsecutorVersion
    form_class = HearingProsecutorVersionForm


class HearingTagListView(ListView):
    model = HearingTag


class HearingTagCreateView(CreateView):
    model = HearingTag
    form_class = HearingTagForm


class HearingTagDetailView(DetailView):
    model = HearingTag


class HearingTagUpdateView(UpdateView):
    model = HearingTag
    form_class = HearingTagForm


class HearingTagVersionListView(ListView):
    model = HearingTagVersion


class HearingTagVersionCreateView(CreateView):
    model = HearingTagVersion
    form_class = HearingTagVersionForm


class HearingTagVersionDetailView(DetailView):
    model = HearingTagVersion


class HearingTagVersionUpdateView(UpdateView):
    model = HearingTagVersion
    form_class = HearingTagVersionForm


class HearingVersionListView(ListView):
    model = HearingVersion


class HearingVersionCreateView(CreateView):
    model = HearingVersion
    form_class = HearingVersionForm


class HearingVersionDetailView(DetailView):
    model = HearingVersion


class HearingVersionUpdateView(UpdateView):
    model = HearingVersion
    form_class = HearingVersionForm


class HearingWitnessListView(ListView):
    model = HearingWitness


class HearingWitnessCreateView(CreateView):
    model = HearingWitness
    form_class = HearingWitnessForm


class HearingWitnessDetailView(DetailView):
    model = HearingWitness


class HearingWitnessUpdateView(UpdateView):
    model = HearingWitness
    form_class = HearingWitnessForm


class HearingWitnessVersionListView(ListView):
    model = HearingWitnessVersion


class HearingWitnessVersionCreateView(CreateView):
    model = HearingWitnessVersion
    form_class = HearingWitnessVersionForm


class HearingWitnessVersionDetailView(DetailView):
    model = HearingWitnessVersion


class HearingWitnessVersionUpdateView(UpdateView):
    model = HearingWitnessVersion
    form_class = HearingWitnessVersionForm


class HearingtypeListView(ListView):
    model = Hearingtype


class HearingtypeCreateView(CreateView):
    model = Hearingtype
    form_class = HearingtypeForm


class HearingtypeDetailView(DetailView):
    model = Hearingtype


class HearingtypeUpdateView(UpdateView):
    model = Hearingtype
    form_class = HearingtypeForm


class HearingtypeVersionListView(ListView):
    model = HearingtypeVersion


class HearingtypeVersionCreateView(CreateView):
    model = HearingtypeVersion
    form_class = HearingtypeVersionForm


class HearingtypeVersionDetailView(DetailView):
    model = HearingtypeVersion


class HearingtypeVersionUpdateView(UpdateView):
    model = HearingtypeVersion
    form_class = HearingtypeVersionForm


class InvestigationListView(ListView):
    model = Investigation


class InvestigationCreateView(CreateView):
    model = Investigation
    form_class = InvestigationForm


class InvestigationDetailView(DetailView):
    model = Investigation


class InvestigationUpdateView(UpdateView):
    model = Investigation
    form_class = InvestigationForm


class InvestigationPolofficerListView(ListView):
    model = InvestigationPolofficer


class InvestigationPolofficerCreateView(CreateView):
    model = InvestigationPolofficer
    form_class = InvestigationPolofficerForm


class InvestigationPolofficerDetailView(DetailView):
    model = InvestigationPolofficer


class InvestigationPolofficerUpdateView(UpdateView):
    model = InvestigationPolofficer
    form_class = InvestigationPolofficerForm


class InvestigationPolofficerVersionListView(ListView):
    model = InvestigationPolofficerVersion


class InvestigationPolofficerVersionCreateView(CreateView):
    model = InvestigationPolofficerVersion
    form_class = InvestigationPolofficerVersionForm


class InvestigationPolofficerVersionDetailView(DetailView):
    model = InvestigationPolofficerVersion


class InvestigationPolofficerVersionUpdateView(UpdateView):
    model = InvestigationPolofficerVersion
    form_class = InvestigationPolofficerVersionForm


class InvestigationVersionListView(ListView):
    model = InvestigationVersion


class InvestigationVersionCreateView(CreateView):
    model = InvestigationVersion
    form_class = InvestigationVersionForm


class InvestigationVersionDetailView(DetailView):
    model = InvestigationVersion


class InvestigationVersionUpdateView(UpdateView):
    model = InvestigationVersion
    form_class = InvestigationVersionForm


class InvestigationWitnessListView(ListView):
    model = InvestigationWitness


class InvestigationWitnessCreateView(CreateView):
    model = InvestigationWitness
    form_class = InvestigationWitnessForm


class InvestigationWitnessDetailView(DetailView):
    model = InvestigationWitness


class InvestigationWitnessUpdateView(UpdateView):
    model = InvestigationWitness
    form_class = InvestigationWitnessForm


class InvestigationWitnessVersionListView(ListView):
    model = InvestigationWitnessVersion


class InvestigationWitnessVersionCreateView(CreateView):
    model = InvestigationWitnessVersion
    form_class = InvestigationWitnessVersionForm


class InvestigationWitnessVersionDetailView(DetailView):
    model = InvestigationWitnessVersion


class InvestigationWitnessVersionUpdateView(UpdateView):
    model = InvestigationWitnessVersion
    form_class = InvestigationWitnessVersionForm


class JoRankListView(ListView):
    model = JoRank


class JoRankCreateView(CreateView):
    model = JoRank
    form_class = JoRankForm


class JoRankDetailView(DetailView):
    model = JoRank


class JoRankUpdateView(UpdateView):
    model = JoRank
    form_class = JoRankForm


class JoRankVersionListView(ListView):
    model = JoRankVersion


class JoRankVersionCreateView(CreateView):
    model = JoRankVersion
    form_class = JoRankVersionForm


class JoRankVersionDetailView(DetailView):
    model = JoRankVersion


class JoRankVersionUpdateView(UpdateView):
    model = JoRankVersion
    form_class = JoRankVersionForm


class JudicialofficerListView(ListView):
    model = Judicialofficer


class JudicialofficerCreateView(CreateView):
    model = Judicialofficer
    form_class = JudicialofficerForm


class JudicialofficerDetailView(DetailView):
    model = Judicialofficer


class JudicialofficerUpdateView(UpdateView):
    model = Judicialofficer
    form_class = JudicialofficerForm


class JudicialofficerVersionListView(ListView):
    model = JudicialofficerVersion


class JudicialofficerVersionCreateView(CreateView):
    model = JudicialofficerVersion
    form_class = JudicialofficerVersionForm


class JudicialofficerVersionDetailView(DetailView):
    model = JudicialofficerVersion


class JudicialofficerVersionUpdateView(UpdateView):
    model = JudicialofficerVersion
    form_class = JudicialofficerVersionForm


class LawfirmListView(ListView):
    model = Lawfirm


class LawfirmCreateView(CreateView):
    model = Lawfirm
    form_class = LawfirmForm


class LawfirmDetailView(DetailView):
    model = Lawfirm


class LawfirmUpdateView(UpdateView):
    model = Lawfirm
    form_class = LawfirmForm


class LawfirmVersionListView(ListView):
    model = LawfirmVersion


class LawfirmVersionCreateView(CreateView):
    model = LawfirmVersion
    form_class = LawfirmVersionForm


class LawfirmVersionDetailView(DetailView):
    model = LawfirmVersion


class LawfirmVersionUpdateView(UpdateView):
    model = LawfirmVersion
    form_class = LawfirmVersionForm


class LawyersListView(ListView):
    model = Lawyers


class LawyersCreateView(CreateView):
    model = Lawyers
    form_class = LawyersForm


class LawyersDetailView(DetailView):
    model = Lawyers


class LawyersUpdateView(UpdateView):
    model = Lawyers
    form_class = LawyersForm


class LawyersVersionListView(ListView):
    model = LawyersVersion


class LawyersVersionCreateView(CreateView):
    model = LawyersVersion
    form_class = LawyersVersionForm


class LawyersVersionDetailView(DetailView):
    model = LawyersVersion


class LawyersVersionUpdateView(UpdateView):
    model = LawyersVersion
    form_class = LawyersVersionForm


class MedeventListView(ListView):
    model = Medevent


class MedeventCreateView(CreateView):
    model = Medevent
    form_class = MedeventForm


class MedeventDetailView(DetailView):
    model = Medevent


class MedeventUpdateView(UpdateView):
    model = Medevent
    form_class = MedeventForm


class MedeventVersionListView(ListView):
    model = MedeventVersion


class MedeventVersionCreateView(CreateView):
    model = MedeventVersion
    form_class = MedeventVersionForm


class MedeventVersionDetailView(DetailView):
    model = MedeventVersion


class MedeventVersionUpdateView(UpdateView):
    model = MedeventVersion
    form_class = MedeventVersionForm


class NatureofsuitListView(ListView):
    model = Natureofsuit


class NatureofsuitCreateView(CreateView):
    model = Natureofsuit
    form_class = NatureofsuitForm


class NatureofsuitDetailView(DetailView):
    model = Natureofsuit


class NatureofsuitUpdateView(UpdateView):
    model = Natureofsuit
    form_class = NatureofsuitForm


class NatureofsuitVersionListView(ListView):
    model = NatureofsuitVersion


class NatureofsuitVersionCreateView(CreateView):
    model = NatureofsuitVersion
    form_class = NatureofsuitVersionForm


class NatureofsuitVersionDetailView(DetailView):
    model = NatureofsuitVersion


class NatureofsuitVersionUpdateView(UpdateView):
    model = NatureofsuitVersion
    form_class = NatureofsuitVersionForm


class PaymentListView(ListView):
    model = Payment


class PaymentCreateView(CreateView):
    model = Payment
    form_class = PaymentForm


class PaymentDetailView(DetailView):
    model = Payment


class PaymentUpdateView(UpdateView):
    model = Payment
    form_class = PaymentForm


class PaymentVersionListView(ListView):
    model = PaymentVersion


class PaymentVersionCreateView(CreateView):
    model = PaymentVersion
    form_class = PaymentVersionForm


class PaymentVersionDetailView(DetailView):
    model = PaymentVersion


class PaymentVersionUpdateView(UpdateView):
    model = PaymentVersion
    form_class = PaymentVersionForm


class PaymentmethodListView(ListView):
    model = Paymentmethod


class PaymentmethodCreateView(CreateView):
    model = Paymentmethod
    form_class = PaymentmethodForm


class PaymentmethodDetailView(DetailView):
    model = Paymentmethod


class PaymentmethodUpdateView(UpdateView):
    model = Paymentmethod
    form_class = PaymentmethodForm


class PaymentmethodVersionListView(ListView):
    model = PaymentmethodVersion


class PaymentmethodVersionCreateView(CreateView):
    model = PaymentmethodVersion
    form_class = PaymentmethodVersionForm


class PaymentmethodVersionDetailView(DetailView):
    model = PaymentmethodVersion


class PaymentmethodVersionUpdateView(UpdateView):
    model = PaymentmethodVersion
    form_class = PaymentmethodVersionForm


class PlaintiffListView(ListView):
    model = Plaintiff


class PlaintiffCreateView(CreateView):
    model = Plaintiff
    form_class = PlaintiffForm


class PlaintiffDetailView(DetailView):
    model = Plaintiff


class PlaintiffUpdateView(UpdateView):
    model = Plaintiff
    form_class = PlaintiffForm


class PlaintiffVersionListView(ListView):
    model = PlaintiffVersion


class PlaintiffVersionCreateView(CreateView):
    model = PlaintiffVersion
    form_class = PlaintiffVersionForm


class PlaintiffVersionDetailView(DetailView):
    model = PlaintiffVersion


class PlaintiffVersionUpdateView(UpdateView):
    model = PlaintiffVersion
    form_class = PlaintiffVersionForm


class PolicerankListView(ListView):
    model = Policerank


class PolicerankCreateView(CreateView):
    model = Policerank
    form_class = PolicerankForm


class PolicerankDetailView(DetailView):
    model = Policerank


class PolicerankUpdateView(UpdateView):
    model = Policerank
    form_class = PolicerankForm


class PolicerankVersionListView(ListView):
    model = PolicerankVersion


class PolicerankVersionCreateView(CreateView):
    model = PolicerankVersion
    form_class = PolicerankVersionForm


class PolicerankVersionDetailView(DetailView):
    model = PolicerankVersion


class PolicerankVersionUpdateView(UpdateView):
    model = PolicerankVersion
    form_class = PolicerankVersionForm


class PoliceroleListView(ListView):
    model = Policerole


class PoliceroleCreateView(CreateView):
    model = Policerole
    form_class = PoliceroleForm


class PoliceroleDetailView(DetailView):
    model = Policerole


class PoliceroleUpdateView(UpdateView):
    model = Policerole
    form_class = PoliceroleForm


class PoliceroleVersionListView(ListView):
    model = PoliceroleVersion


class PoliceroleVersionCreateView(CreateView):
    model = PoliceroleVersion
    form_class = PoliceroleVersionForm


class PoliceroleVersionDetailView(DetailView):
    model = PoliceroleVersion


class PoliceroleVersionUpdateView(UpdateView):
    model = PoliceroleVersion
    form_class = PoliceroleVersionForm


class PolicestationListView(ListView):
    model = Policestation


class PolicestationCreateView(CreateView):
    model = Policestation
    form_class = PolicestationForm


class PolicestationDetailView(DetailView):
    model = Policestation


class PolicestationUpdateView(UpdateView):
    model = Policestation
    form_class = PolicestationForm


class PolicestationVersionListView(ListView):
    model = PolicestationVersion


class PolicestationVersionCreateView(CreateView):
    model = PolicestationVersion
    form_class = PolicestationVersionForm


class PolicestationVersionDetailView(DetailView):
    model = PolicestationVersion


class PolicestationVersionUpdateView(UpdateView):
    model = PolicestationVersion
    form_class = PolicestationVersionForm


class PolicestationtypeListView(ListView):
    model = Policestationtype


class PolicestationtypeCreateView(CreateView):
    model = Policestationtype
    form_class = PolicestationtypeForm


class PolicestationtypeDetailView(DetailView):
    model = Policestationtype


class PolicestationtypeUpdateView(UpdateView):
    model = Policestationtype
    form_class = PolicestationtypeForm


class PolicestationtypeVersionListView(ListView):
    model = PolicestationtypeVersion


class PolicestationtypeVersionCreateView(CreateView):
    model = PolicestationtypeVersion
    form_class = PolicestationtypeVersionForm


class PolicestationtypeVersionDetailView(DetailView):
    model = PolicestationtypeVersion


class PolicestationtypeVersionUpdateView(UpdateView):
    model = PolicestationtypeVersion
    form_class = PolicestationtypeVersionForm


class PolofficerListView(ListView):
    model = Polofficer


class PolofficerCreateView(CreateView):
    model = Polofficer
    form_class = PolofficerForm


class PolofficerDetailView(DetailView):
    model = Polofficer


class PolofficerUpdateView(UpdateView):
    model = Polofficer
    form_class = PolofficerForm


class PolofficerPoliceroleListView(ListView):
    model = PolofficerPolicerole


class PolofficerPoliceroleCreateView(CreateView):
    model = PolofficerPolicerole
    form_class = PolofficerPoliceroleForm


class PolofficerPoliceroleDetailView(DetailView):
    model = PolofficerPolicerole


class PolofficerPoliceroleUpdateView(UpdateView):
    model = PolofficerPolicerole
    form_class = PolofficerPoliceroleForm


class PolofficerPoliceroleVersionListView(ListView):
    model = PolofficerPoliceroleVersion


class PolofficerPoliceroleVersionCreateView(CreateView):
    model = PolofficerPoliceroleVersion
    form_class = PolofficerPoliceroleVersionForm


class PolofficerPoliceroleVersionDetailView(DetailView):
    model = PolofficerPoliceroleVersion


class PolofficerPoliceroleVersionUpdateView(UpdateView):
    model = PolofficerPoliceroleVersion
    form_class = PolofficerPoliceroleVersionForm


class PolofficerVersionListView(ListView):
    model = PolofficerVersion


class PolofficerVersionCreateView(CreateView):
    model = PolofficerVersion
    form_class = PolofficerVersionForm


class PolofficerVersionDetailView(DetailView):
    model = PolofficerVersion


class PolofficerVersionUpdateView(UpdateView):
    model = PolofficerVersion
    form_class = PolofficerVersionForm


class PrisonListView(ListView):
    model = Prison


class PrisonCreateView(CreateView):
    model = Prison
    form_class = PrisonForm


class PrisonDetailView(DetailView):
    model = Prison


class PrisonUpdateView(UpdateView):
    model = Prison
    form_class = PrisonForm


class PrisonSecurityrankListView(ListView):
    model = PrisonSecurityrank


class PrisonSecurityrankCreateView(CreateView):
    model = PrisonSecurityrank
    form_class = PrisonSecurityrankForm


class PrisonSecurityrankDetailView(DetailView):
    model = PrisonSecurityrank


class PrisonSecurityrankUpdateView(UpdateView):
    model = PrisonSecurityrank
    form_class = PrisonSecurityrankForm


class PrisonSecurityrankVersionListView(ListView):
    model = PrisonSecurityrankVersion


class PrisonSecurityrankVersionCreateView(CreateView):
    model = PrisonSecurityrankVersion
    form_class = PrisonSecurityrankVersionForm


class PrisonSecurityrankVersionDetailView(DetailView):
    model = PrisonSecurityrankVersion


class PrisonSecurityrankVersionUpdateView(UpdateView):
    model = PrisonSecurityrankVersion
    form_class = PrisonSecurityrankVersionForm


class PrisonVersionListView(ListView):
    model = PrisonVersion


class PrisonVersionCreateView(CreateView):
    model = PrisonVersion
    form_class = PrisonVersionForm


class PrisonVersionDetailView(DetailView):
    model = PrisonVersion


class PrisonVersionUpdateView(UpdateView):
    model = PrisonVersion
    form_class = PrisonVersionForm


class PrisoncellListView(ListView):
    model = Prisoncell


class PrisoncellCreateView(CreateView):
    model = Prisoncell
    form_class = PrisoncellForm


class PrisoncellDetailView(DetailView):
    model = Prisoncell


class PrisoncellUpdateView(UpdateView):
    model = Prisoncell
    form_class = PrisoncellForm


class PrisoncellVersionListView(ListView):
    model = PrisoncellVersion


class PrisoncellVersionCreateView(CreateView):
    model = PrisoncellVersion
    form_class = PrisoncellVersionForm


class PrisoncellVersionDetailView(DetailView):
    model = PrisoncellVersion


class PrisoncellVersionUpdateView(UpdateView):
    model = PrisoncellVersion
    form_class = PrisoncellVersionForm


class PrisoncommitalListView(ListView):
    model = Prisoncommital


class PrisoncommitalCreateView(CreateView):
    model = Prisoncommital
    form_class = PrisoncommitalForm


class PrisoncommitalDetailView(DetailView):
    model = Prisoncommital


class PrisoncommitalUpdateView(UpdateView):
    model = Prisoncommital
    form_class = PrisoncommitalForm


class PrisoncommitalVersionListView(ListView):
    model = PrisoncommitalVersion


class PrisoncommitalVersionCreateView(CreateView):
    model = PrisoncommitalVersion
    form_class = PrisoncommitalVersionForm


class PrisoncommitalVersionDetailView(DetailView):
    model = PrisoncommitalVersion


class PrisoncommitalVersionUpdateView(UpdateView):
    model = PrisoncommitalVersion
    form_class = PrisoncommitalVersionForm


class PrisoncommitalWarderListView(ListView):
    model = PrisoncommitalWarder


class PrisoncommitalWarderCreateView(CreateView):
    model = PrisoncommitalWarder
    form_class = PrisoncommitalWarderForm


class PrisoncommitalWarderDetailView(DetailView):
    model = PrisoncommitalWarder


class PrisoncommitalWarderUpdateView(UpdateView):
    model = PrisoncommitalWarder
    form_class = PrisoncommitalWarderForm


class PrisoncommitalWarderVersionListView(ListView):
    model = PrisoncommitalWarderVersion


class PrisoncommitalWarderVersionCreateView(CreateView):
    model = PrisoncommitalWarderVersion
    form_class = PrisoncommitalWarderVersionForm


class PrisoncommitalWarderVersionDetailView(DetailView):
    model = PrisoncommitalWarderVersion


class PrisoncommitalWarderVersionUpdateView(UpdateView):
    model = PrisoncommitalWarderVersion
    form_class = PrisoncommitalWarderVersionForm


class PrisonerpropertyListView(ListView):
    model = Prisonerproperty


class PrisonerpropertyCreateView(CreateView):
    model = Prisonerproperty
    form_class = PrisonerpropertyForm


class PrisonerpropertyDetailView(DetailView):
    model = Prisonerproperty


class PrisonerpropertyUpdateView(UpdateView):
    model = Prisonerproperty
    form_class = PrisonerpropertyForm


class PrisonerpropertyVersionListView(ListView):
    model = PrisonerpropertyVersion


class PrisonerpropertyVersionCreateView(CreateView):
    model = PrisonerpropertyVersion
    form_class = PrisonerpropertyVersionForm


class PrisonerpropertyVersionDetailView(DetailView):
    model = PrisonerpropertyVersion


class PrisonerpropertyVersionUpdateView(UpdateView):
    model = PrisonerpropertyVersion
    form_class = PrisonerpropertyVersionForm


class ProsecutorListView(ListView):
    model = Prosecutor


class ProsecutorCreateView(CreateView):
    model = Prosecutor
    form_class = ProsecutorForm


class ProsecutorDetailView(DetailView):
    model = Prosecutor


class ProsecutorUpdateView(UpdateView):
    model = Prosecutor
    form_class = ProsecutorForm


class ProsecutorProsecutorteamListView(ListView):
    model = ProsecutorProsecutorteam


class ProsecutorProsecutorteamCreateView(CreateView):
    model = ProsecutorProsecutorteam
    form_class = ProsecutorProsecutorteamForm


class ProsecutorProsecutorteamDetailView(DetailView):
    model = ProsecutorProsecutorteam


class ProsecutorProsecutorteamUpdateView(UpdateView):
    model = ProsecutorProsecutorteam
    form_class = ProsecutorProsecutorteamForm


class ProsecutorProsecutorteamVersionListView(ListView):
    model = ProsecutorProsecutorteamVersion


class ProsecutorProsecutorteamVersionCreateView(CreateView):
    model = ProsecutorProsecutorteamVersion
    form_class = ProsecutorProsecutorteamVersionForm


class ProsecutorProsecutorteamVersionDetailView(DetailView):
    model = ProsecutorProsecutorteamVersion


class ProsecutorProsecutorteamVersionUpdateView(UpdateView):
    model = ProsecutorProsecutorteamVersion
    form_class = ProsecutorProsecutorteamVersionForm


class ProsecutorVersionListView(ListView):
    model = ProsecutorVersion


class ProsecutorVersionCreateView(CreateView):
    model = ProsecutorVersion
    form_class = ProsecutorVersionForm


class ProsecutorVersionDetailView(DetailView):
    model = ProsecutorVersion


class ProsecutorVersionUpdateView(UpdateView):
    model = ProsecutorVersion
    form_class = ProsecutorVersionForm


class ProsecutorteamListView(ListView):
    model = Prosecutorteam


class ProsecutorteamCreateView(CreateView):
    model = Prosecutorteam
    form_class = ProsecutorteamForm


class ProsecutorteamDetailView(DetailView):
    model = Prosecutorteam


class ProsecutorteamUpdateView(UpdateView):
    model = Prosecutorteam
    form_class = ProsecutorteamForm


class ProsecutorteamVersionListView(ListView):
    model = ProsecutorteamVersion


class ProsecutorteamVersionCreateView(CreateView):
    model = ProsecutorteamVersion
    form_class = ProsecutorteamVersionForm


class ProsecutorteamVersionDetailView(DetailView):
    model = ProsecutorteamVersion


class ProsecutorteamVersionUpdateView(UpdateView):
    model = ProsecutorteamVersion
    form_class = ProsecutorteamVersionForm


class RemissionListView(ListView):
    model = Remission


class RemissionCreateView(CreateView):
    model = Remission
    form_class = RemissionForm


class RemissionDetailView(DetailView):
    model = Remission


class RemissionUpdateView(UpdateView):
    model = Remission
    form_class = RemissionForm


class RemissionVersionListView(ListView):
    model = RemissionVersion


class RemissionVersionCreateView(CreateView):
    model = RemissionVersion
    form_class = RemissionVersionForm


class RemissionVersionDetailView(DetailView):
    model = RemissionVersion


class RemissionVersionUpdateView(UpdateView):
    model = RemissionVersion
    form_class = RemissionVersionForm


class SecurityrankListView(ListView):
    model = Securityrank


class SecurityrankCreateView(CreateView):
    model = Securityrank
    form_class = SecurityrankForm


class SecurityrankDetailView(DetailView):
    model = Securityrank


class SecurityrankUpdateView(UpdateView):
    model = Securityrank
    form_class = SecurityrankForm


class SecurityrankVersionListView(ListView):
    model = SecurityrankVersion


class SecurityrankVersionCreateView(CreateView):
    model = SecurityrankVersion
    form_class = SecurityrankVersionForm


class SecurityrankVersionDetailView(DetailView):
    model = SecurityrankVersion


class SecurityrankVersionUpdateView(UpdateView):
    model = SecurityrankVersion
    form_class = SecurityrankVersionForm


class SubcountyListView(ListView):
    model = Subcounty


class SubcountyCreateView(CreateView):
    model = Subcounty
    form_class = SubcountyForm


class SubcountyDetailView(DetailView):
    model = Subcounty


class SubcountyUpdateView(UpdateView):
    model = Subcounty
    form_class = SubcountyForm


class SubcountyVersionListView(ListView):
    model = SubcountyVersion


class SubcountyVersionCreateView(CreateView):
    model = SubcountyVersion
    form_class = SubcountyVersionForm


class SubcountyVersionDetailView(DetailView):
    model = SubcountyVersion


class SubcountyVersionUpdateView(UpdateView):
    model = SubcountyVersion
    form_class = SubcountyVersionForm


class SuretyListView(ListView):
    model = Surety


class SuretyCreateView(CreateView):
    model = Surety
    form_class = SuretyForm


class SuretyDetailView(DetailView):
    model = Surety


class SuretyUpdateView(UpdateView):
    model = Surety
    form_class = SuretyForm


class SuretyVersionListView(ListView):
    model = SuretyVersion


class SuretyVersionCreateView(CreateView):
    model = SuretyVersion
    form_class = SuretyVersionForm


class SuretyVersionDetailView(DetailView):
    model = SuretyVersion


class SuretyVersionUpdateView(UpdateView):
    model = SuretyVersion
    form_class = SuretyVersionForm


class TagListView(ListView):
    model = Tag


class TagCreateView(CreateView):
    model = Tag
    form_class = TagForm


class TagDetailView(DetailView):
    model = Tag


class TagUpdateView(UpdateView):
    model = Tag
    form_class = TagForm


class TagVersionListView(ListView):
    model = TagVersion


class TagVersionCreateView(CreateView):
    model = TagVersion
    form_class = TagVersionForm


class TagVersionDetailView(DetailView):
    model = TagVersion


class TagVersionUpdateView(UpdateView):
    model = TagVersion
    form_class = TagVersionForm


class TownListView(ListView):
    model = Town


class TownCreateView(CreateView):
    model = Town
    form_class = TownForm


class TownDetailView(DetailView):
    model = Town


class TownUpdateView(UpdateView):
    model = Town
    form_class = TownForm


class TownVersionListView(ListView):
    model = TownVersion


class TownVersionCreateView(CreateView):
    model = TownVersion
    form_class = TownVersionForm


class TownVersionDetailView(DetailView):
    model = TownVersion


class TownVersionUpdateView(UpdateView):
    model = TownVersion
    form_class = TownVersionForm


class TransactionListView(ListView):
    model = Transaction


class TransactionCreateView(CreateView):
    model = Transaction
    form_class = TransactionForm


class TransactionDetailView(DetailView):
    model = Transaction


class TransactionUpdateView(UpdateView):
    model = Transaction
    form_class = TransactionForm


class VisitListView(ListView):
    model = Visit


class VisitCreateView(CreateView):
    model = Visit
    form_class = VisitForm


class VisitDetailView(DetailView):
    model = Visit


class VisitUpdateView(UpdateView):
    model = Visit
    form_class = VisitForm


class VisitVersionListView(ListView):
    model = VisitVersion


class VisitVersionCreateView(CreateView):
    model = VisitVersion
    form_class = VisitVersionForm


class VisitVersionDetailView(DetailView):
    model = VisitVersion


class VisitVersionUpdateView(UpdateView):
    model = VisitVersion
    form_class = VisitVersionForm


class VisitorListView(ListView):
    model = Visitor


class VisitorCreateView(CreateView):
    model = Visitor
    form_class = VisitorForm


class VisitorDetailView(DetailView):
    model = Visitor


class VisitorUpdateView(UpdateView):
    model = Visitor
    form_class = VisitorForm


class VisitorVersionListView(ListView):
    model = VisitorVersion


class VisitorVersionCreateView(CreateView):
    model = VisitorVersion
    form_class = VisitorVersionForm


class VisitorVersionDetailView(DetailView):
    model = VisitorVersion


class VisitorVersionUpdateView(UpdateView):
    model = VisitorVersion
    form_class = VisitorVersionForm


class WarderListView(ListView):
    model = Warder


class WarderCreateView(CreateView):
    model = Warder
    form_class = WarderForm


class WarderDetailView(DetailView):
    model = Warder


class WarderUpdateView(UpdateView):
    model = Warder
    form_class = WarderForm


class WarderVersionListView(ListView):
    model = WarderVersion


class WarderVersionCreateView(CreateView):
    model = WarderVersion
    form_class = WarderVersionForm


class WarderVersionDetailView(DetailView):
    model = WarderVersion


class WarderVersionUpdateView(UpdateView):
    model = WarderVersion
    form_class = WarderVersionForm


class WarderrankListView(ListView):
    model = Warderrank


class WarderrankCreateView(CreateView):
    model = Warderrank
    form_class = WarderrankForm


class WarderrankDetailView(DetailView):
    model = Warderrank


class WarderrankUpdateView(UpdateView):
    model = Warderrank
    form_class = WarderrankForm


class WarderrankVersionListView(ListView):
    model = WarderrankVersion


class WarderrankVersionCreateView(CreateView):
    model = WarderrankVersion
    form_class = WarderrankVersionForm


class WarderrankVersionDetailView(DetailView):
    model = WarderrankVersion


class WarderrankVersionUpdateView(UpdateView):
    model = WarderrankVersion
    form_class = WarderrankVersionForm


class WitnessListView(ListView):
    model = Witness


class WitnessCreateView(CreateView):
    model = Witness
    form_class = WitnessForm


class WitnessDetailView(DetailView):
    model = Witness


class WitnessUpdateView(UpdateView):
    model = Witness
    form_class = WitnessForm


class WitnessVersionListView(ListView):
    model = WitnessVersion


class WitnessVersionCreateView(CreateView):
    model = WitnessVersion
    form_class = WitnessVersionForm


class WitnessVersionDetailView(DetailView):
    model = WitnessVersion


class WitnessVersionUpdateView(UpdateView):
    model = WitnessVersion
    form_class = WitnessVersionForm

