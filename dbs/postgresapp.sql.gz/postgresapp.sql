--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "nyimbi";
ALTER ROLE "nyimbi" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN NOREPLICATION NOBYPASSRLS;
CREATE ROLE "postgres";
ALTER ROLE "postgres" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;






--
-- Database creation
--

CREATE DATABASE "casegh" WITH TEMPLATE = template0 OWNER = "nyimbi";
CREATE DATABASE "caseke" WITH TEMPLATE = template0 OWNER = "nyimbi";
CREATE DATABASE "nyimbi" WITH TEMPLATE = template0 OWNER = "nyimbi";
REVOKE CONNECT,TEMPORARY ON DATABASE "template1" FROM PUBLIC;
GRANT CONNECT ON DATABASE "template1" TO PUBLIC;


\connect "casegh"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Districts; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "Districts" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "region" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "Districts" OWNER TO "nyimbi";

--
-- Name: Districts_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "Districts_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Districts_id_seq" OWNER TO "nyimbi";

--
-- Name: Districts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "Districts_id_seq" OWNED BY "Districts"."id";


--
-- Name: ab_permission; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL
);


ALTER TABLE "ab_permission" OWNER TO "nyimbi";

--
-- Name: ab_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_permission_view; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission_view" (
    "id" integer NOT NULL,
    "permission_id" integer,
    "view_menu_id" integer
);


ALTER TABLE "ab_permission_view" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_view_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_view_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission_view_role" (
    "id" integer NOT NULL,
    "permission_view_id" integer,
    "role_id" integer
);


ALTER TABLE "ab_permission_view_role" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_view_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_view_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_register_user; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_register_user" (
    "id" integer NOT NULL,
    "first_name" character varying(64) NOT NULL,
    "last_name" character varying(64) NOT NULL,
    "username" character varying(64) NOT NULL,
    "password" character varying(256),
    "email" character varying(64) NOT NULL,
    "registration_date" timestamp without time zone,
    "registration_hash" character varying(256)
);


ALTER TABLE "ab_register_user" OWNER TO "nyimbi";

--
-- Name: ab_register_user_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_register_user_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_register_user_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_role" (
    "id" integer NOT NULL,
    "name" character varying(64) NOT NULL
);


ALTER TABLE "ab_role" OWNER TO "nyimbi";

--
-- Name: ab_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_user; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_user" (
    "id" integer NOT NULL,
    "first_name" character varying(64) NOT NULL,
    "last_name" character varying(64) NOT NULL,
    "username" character varying(64) NOT NULL,
    "password" character varying(256),
    "active" boolean,
    "email" character varying(64) NOT NULL,
    "last_login" timestamp without time zone,
    "login_count" integer,
    "fail_login_count" integer,
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "created_by_fk" integer,
    "changed_by_fk" integer
);


ALTER TABLE "ab_user" OWNER TO "nyimbi";

--
-- Name: ab_user_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_user_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_user_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_user_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_user_role" (
    "id" integer NOT NULL,
    "user_id" integer,
    "role_id" integer
);


ALTER TABLE "ab_user_role" OWNER TO "nyimbi";

--
-- Name: ab_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_user_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_user_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_view_menu; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_view_menu" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL
);


ALTER TABLE "ab_view_menu" OWNER TO "nyimbi";

--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_view_menu_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_view_menu_id_seq" OWNER TO "nyimbi";

--
-- Name: attorney; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "attorney" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "law_firm" integer,
    "barnumber" character varying(20),
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "attorney" OWNER TO "nyimbi";

--
-- Name: attorney_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "attorney_hearing" (
    "attorney" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "attorney_hearing" OWNER TO "nyimbi";

--
-- Name: attorney_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "attorney_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "attorney_id_seq" OWNER TO "nyimbi";

--
-- Name: attorney_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "attorney_id_seq" OWNED BY "attorney"."id";


--
-- Name: bail; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "hearing" integer NOT NULL,
    "defendant" integer NOT NULL,
    "amount_granted" numeric(12,2),
    "no_of_sureties" integer,
    "paid" boolean NOT NULL,
    "pay_date" "date",
    "receipt_no" character varying(100),
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "bail" OWNER TO "nyimbi";

--
-- Name: bail_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "bail_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "bail_id_seq" OWNER TO "nyimbi";

--
-- Name: bail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "bail_id_seq" OWNED BY "bail"."id";


--
-- Name: bail_surety; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail_surety" (
    "bail" integer NOT NULL,
    "surety" integer NOT NULL
);


ALTER TABLE "bail_surety" OWNER TO "nyimbi";

--
-- Name: case; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "segment" integer,
    "task_group" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "actual_start" "date",
    "planned_start" "date",
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "delayed_start" boolean,
    "completed" boolean,
    "delayed_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "case_name" character varying(200),
    "ob_number" character varying(30),
    "initial_report" "text",
    "report_date" "date",
    "weather" character varying(100),
    "visibility" character varying(50),
    "location" character varying(100),
    "report_notes" "text",
    "injuries" boolean,
    "loss" boolean,
    "death" boolean,
    "vehicular" boolean,
    "drugs" boolean,
    "weapons" boolean,
    "investigation_assigment_date" timestamp without time zone,
    "investigation_assignment_note" "text",
    "investigation_plan" "text",
    "evaluation_conclusion" "text",
    "should_investigate_further" boolean,
    "priority" integer,
    "investigation_summary" "text",
    "ag_advice_requested" boolean,
    "ag_advice_req_date" "date",
    "docketnumber" character varying(100),
    "send_to_trial" boolean,
    "charge_date" timestamp without time zone,
    "ag_advice" "text",
    "ag_advice_date" "date",
    "take_to_trial" boolean,
    "case_closed" boolean,
    "judgement" "text",
    "judgement_date" "date",
    "closed_date" "date",
    "sentence_length" integer,
    "sentence_startdate" "date",
    "sentence_expirydate" "date",
    "fine_amount" numeric(10,2),
    "case_appealed" boolean,
    "appeal_date" timestamp without time zone,
    "appeal_granted" boolean,
    "prosecution_notes" "text",
    "defense_notes" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "case" OWNER TO "nyimbi";

--
-- Name: case_causeofaction; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_causeofaction" (
    "case" integer NOT NULL,
    "causeofaction" integer NOT NULL
);


ALTER TABLE "case_causeofaction" OWNER TO "nyimbi";

--
-- Name: case_defendant; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_defendant" (
    "case" integer NOT NULL,
    "defendant" integer NOT NULL
);


ALTER TABLE "case_defendant" OWNER TO "nyimbi";

--
-- Name: case_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "case_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "case_id_seq" OWNER TO "nyimbi";

--
-- Name: case_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "case_id_seq" OWNED BY "case"."id";


--
-- Name: case_natureofsuit; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_natureofsuit" (
    "case" integer NOT NULL,
    "natureofsuit" integer NOT NULL
);


ALTER TABLE "case_natureofsuit" OWNER TO "nyimbi";

--
-- Name: case_observer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_observer" (
    "case" integer NOT NULL,
    "observer" integer NOT NULL
);


ALTER TABLE "case_observer" OWNER TO "nyimbi";

--
-- Name: case_plaintiff; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_plaintiff" (
    "case" integer NOT NULL,
    "plaintiff" integer NOT NULL
);


ALTER TABLE "case_plaintiff" OWNER TO "nyimbi";

--
-- Name: case_policeman; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_policeman" (
    "case" integer NOT NULL,
    "policeman" integer NOT NULL
);


ALTER TABLE "case_policeman" OWNER TO "nyimbi";

--
-- Name: case_policeman_2; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_policeman_2" (
    "case" integer NOT NULL,
    "policeman" integer NOT NULL
);


ALTER TABLE "case_policeman_2" OWNER TO "nyimbi";

--
-- Name: case_policestation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_policestation" (
    "case" integer NOT NULL,
    "policestation" integer NOT NULL
);


ALTER TABLE "case_policestation" OWNER TO "nyimbi";

--
-- Name: case_prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_prosecutor" (
    "case" integer NOT NULL,
    "prosecutor" integer NOT NULL
);


ALTER TABLE "case_prosecutor" OWNER TO "nyimbi";

--
-- Name: causeofaction; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "criminal" boolean,
    "parent_coa" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "causeofaction" OWNER TO "nyimbi";

--
-- Name: causeofaction_filing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_filing" (
    "causeofaction" integer NOT NULL,
    "filing" integer NOT NULL
);


ALTER TABLE "causeofaction_filing" OWNER TO "nyimbi";

--
-- Name: causeofaction_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_hearing" (
    "causeofaction" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "causeofaction_hearing" OWNER TO "nyimbi";

--
-- Name: causeofaction_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "causeofaction_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "causeofaction_id_seq" OWNER TO "nyimbi";

--
-- Name: causeofaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "causeofaction_id_seq" OWNED BY "causeofaction"."id";


--
-- Name: constituency; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "constituency" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "region" integer NOT NULL,
    "town" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "constituency" OWNER TO "nyimbi";

--
-- Name: constituency_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "constituency_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "constituency_id_seq" OWNER TO "nyimbi";

--
-- Name: constituency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "constituency_id_seq" OWNED BY "constituency"."id";


--
-- Name: court; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "court" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "town" integer NOT NULL,
    "residentmagistrate" character varying(100),
    "registrar" character varying(100),
    "court_level" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "court" OWNER TO "nyimbi";

--
-- Name: court_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "court_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "court_id_seq" OWNER TO "nyimbi";

--
-- Name: court_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "court_id_seq" OWNED BY "court"."id";


--
-- Name: courtlevel; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "courtlevel" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "courtlevel" OWNER TO "nyimbi";

--
-- Name: courtlevel_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "courtlevel_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "courtlevel_id_seq" OWNER TO "nyimbi";

--
-- Name: courtlevel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "courtlevel_id_seq" OWNED BY "courtlevel"."id";


--
-- Name: defendant; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "blood_group" character varying(3),
    "striking_features" "text",
    "height_m" double precision,
    "weight_kg" double precision,
    "eye_colour" character varying(20),
    "hair_colour" character varying(20),
    "complexion" character varying(50),
    "religion" character varying(20),
    "ethnicity" character varying(40),
    "fp_lthumb" "text",
    "fp_left2" "text",
    "fp_left3" "text",
    "fp_left4" "text",
    "fp_left5" "text",
    "fp_rthumb" "text",
    "fp_right2" "text",
    "fp_right3" "text",
    "fp_right4" "text",
    "fp_right5" "text",
    "palm_left" "text",
    "palm_right" "text",
    "eye_left" "text",
    "eye_right" "text",
    "employed" boolean,
    "employer" character varying(60),
    "employer_contact" "text",
    "employment_date" "date",
    "termination_date" "date",
    "employ_role" character varying(50),
    "supervisor" character varying(50),
    "supervisor_contact" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "defendant" OWNER TO "nyimbi";

--
-- Name: defendant_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_hearing" (
    "defendant" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "defendant_hearing" OWNER TO "nyimbi";

--
-- Name: defendant_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "defendant_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "defendant_id_seq" OWNER TO "nyimbi";

--
-- Name: defendant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "defendant_id_seq" OWNED BY "defendant"."id";


--
-- Name: doctemplate; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "doctemplate" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doctitle" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "bin_hash" character varying(20),
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "doctemplate" OWNER TO "nyimbi";

--
-- Name: doctemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "doctemplate_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "doctemplate_id_seq" OWNER TO "nyimbi";

--
-- Name: doctemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "doctemplate_id_seq" OWNED BY "doctemplate"."id";


--
-- Name: document; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doctitle" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "bin_hash" character varying(20),
    "id" integer NOT NULL,
    "doc_template" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "document" OWNER TO "nyimbi";

--
-- Name: document_filing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document_filing" (
    "document" integer NOT NULL,
    "filing" integer NOT NULL
);


ALTER TABLE "document_filing" OWNER TO "nyimbi";

--
-- Name: document_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "document_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "document_id_seq" OWNER TO "nyimbi";

--
-- Name: document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "document_id_seq" OWNED BY "document"."id";


--
-- Name: filing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "file_date" timestamp without time zone NOT NULL,
    "total_fees" numeric(12,2) NOT NULL,
    "filing_attorney" integer NOT NULL,
    "filing_prosecutor" integer NOT NULL,
    "receipt_number" "text",
    "receipt_verified" boolean,
    "amount_paid" numeric(12,2),
    "fee_balance" numeric(12,2),
    "payment_history" "text",
    "defense_filing" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "filing" OWNER TO "nyimbi";

--
-- Name: filing_filingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_filingtype" (
    "filing" integer NOT NULL,
    "filingtype" integer NOT NULL
);


ALTER TABLE "filing_filingtype" OWNER TO "nyimbi";

--
-- Name: filing_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_hearing" (
    "filing" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "filing_hearing" OWNER TO "nyimbi";

--
-- Name: filing_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "filing_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "filing_id_seq" OWNER TO "nyimbi";

--
-- Name: filing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "filing_id_seq" OWNED BY "filing"."id";


--
-- Name: filingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filingtype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "cost" numeric(12,2) NOT NULL,
    "perpagecost" numeric(12,2),
    "paid_per_page" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "filingtype" OWNER TO "nyimbi";

--
-- Name: filingtype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "filingtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "filingtype_id_seq" OWNER TO "nyimbi";

--
-- Name: filingtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "filingtype_id_seq" OWNED BY "filingtype"."id";


--
-- Name: gender; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gender" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "name" character varying(20) NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "gender" OWNER TO "nyimbi";

--
-- Name: gender_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "gender_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "gender_id_seq" OWNER TO "nyimbi";

--
-- Name: gender_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "gender_id_seq" OWNED BY "gender"."id";


--
-- Name: hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "actual_start" "date",
    "planned_start" "date",
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "delayed_start" boolean,
    "completed" boolean,
    "delayed_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "hearing_date" timestamp without time zone,
    "adjourned" boolean,
    "case" integer NOT NULL,
    "court" integer NOT NULL,
    "hearingtype" integer NOT NULL,
    "remand_warrant" "text",
    "remand_length" integer,
    "remand_date" "date",
    "remand_warrant_expiry_date" "date",
    "nexthearingdate" "date",
    "final_hearing" boolean,
    "transcript" "text",
    "audio" "text",
    "video" "text",
    "witness_submissions" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "hearing" OWNER TO "nyimbi";

--
-- Name: hearing_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "hearing_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "hearing_id_seq" OWNER TO "nyimbi";

--
-- Name: hearing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "hearing_id_seq" OWNED BY "hearing"."id";


--
-- Name: hearing_judge; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_judge" (
    "hearing" integer NOT NULL,
    "judge" integer NOT NULL
);


ALTER TABLE "hearing_judge" OWNER TO "nyimbi";

--
-- Name: hearing_observer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_observer" (
    "hearing" integer NOT NULL,
    "observer" integer NOT NULL
);


ALTER TABLE "hearing_observer" OWNER TO "nyimbi";

--
-- Name: hearing_policeman; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_policeman" (
    "hearing" integer NOT NULL,
    "policeman" integer NOT NULL
);


ALTER TABLE "hearing_policeman" OWNER TO "nyimbi";

--
-- Name: hearing_prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_prosecutor" (
    "hearing" integer NOT NULL,
    "prosecutor" integer NOT NULL
);


ALTER TABLE "hearing_prosecutor" OWNER TO "nyimbi";

--
-- Name: hearingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearingtype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "hearingtype" OWNER TO "nyimbi";

--
-- Name: hearingtype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "hearingtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "hearingtype_id_seq" OWNER TO "nyimbi";

--
-- Name: hearingtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "hearingtype_id_seq" OWNED BY "hearingtype"."id";


--
-- Name: investigation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "actual_start" "date",
    "planned_start" "date",
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "delayed_start" boolean,
    "completed" boolean,
    "delayed_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "case" integer NOT NULL,
    "actiondate" timestamp without time zone NOT NULL,
    "evidence" "text",
    "narrative" "text",
    "weather" "text",
    "location" "text",
    "evidence_desc" "text",
    "pic1" "text",
    "pic2" "text",
    "pic3" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "investigation" OWNER TO "nyimbi";

--
-- Name: investigation_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "investigation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "investigation_id_seq" OWNER TO "nyimbi";

--
-- Name: investigation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "investigation_id_seq" OWNED BY "investigation"."id";


--
-- Name: investigation_observer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_observer" (
    "investigation" integer NOT NULL,
    "observer" integer NOT NULL
);


ALTER TABLE "investigation_observer" OWNER TO "nyimbi";

--
-- Name: investigation_policeman; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_policeman" (
    "investigation" integer NOT NULL,
    "policeman" integer NOT NULL
);


ALTER TABLE "investigation_policeman" OWNER TO "nyimbi";

--
-- Name: judge; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "judge" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "court" integer,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "judge" OWNER TO "nyimbi";

--
-- Name: judge_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "judge_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "judge_id_seq" OWNER TO "nyimbi";

--
-- Name: judge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "judge_id_seq" OWNED BY "judge"."id";


--
-- Name: lawfirm; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "lawfirm" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "lawfirm" OWNER TO "nyimbi";

--
-- Name: lawfirm_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "lawfirm_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "lawfirm_id_seq" OWNER TO "nyimbi";

--
-- Name: lawfirm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "lawfirm_id_seq" OWNED BY "lawfirm"."id";


--
-- Name: natureofsuit; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "natureofsuit" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "natureofsuit" OWNER TO "nyimbi";

--
-- Name: natureofsuit_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "natureofsuit_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "natureofsuit_id_seq" OWNER TO "nyimbi";

--
-- Name: natureofsuit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "natureofsuit_id_seq" OWNED BY "natureofsuit"."id";


--
-- Name: observer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "observer" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "for_defense" boolean NOT NULL,
    "gender" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "observer" OWNER TO "nyimbi";

--
-- Name: observer_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "observer_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "observer_id_seq" OWNER TO "nyimbi";

--
-- Name: observer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "observer_id_seq" OWNED BY "observer"."id";


--
-- Name: plaintiff; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "plaintiff" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "plaintiff" OWNER TO "nyimbi";

--
-- Name: plaintiff_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "plaintiff_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "plaintiff_id_seq" OWNER TO "nyimbi";

--
-- Name: plaintiff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "plaintiff_id_seq" OWNED BY "plaintiff"."id";


--
-- Name: policeman; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policeman" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer NOT NULL,
    "service_number" character varying(20) NOT NULL,
    "commission_date" "date",
    "rank" character varying(30),
    "rank_accession_date" "date",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policeman" OWNER TO "nyimbi";

--
-- Name: policeman_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policeman_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policeman_id_seq" OWNER TO "nyimbi";

--
-- Name: policeman_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policeman_id_seq" OWNED BY "policeman"."id";


--
-- Name: policerole; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerole" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policerole" OWNER TO "nyimbi";

--
-- Name: policerole_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policerole_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policerole_id_seq" OWNER TO "nyimbi";

--
-- Name: policerole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policerole_id_seq" OWNED BY "policerole"."id";


--
-- Name: policerole_policeman; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerole_policeman" (
    "policerole" integer NOT NULL,
    "policeman" integer NOT NULL
);


ALTER TABLE "policerole_policeman" OWNER TO "nyimbi";

--
-- Name: policestation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policestation" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "town" integer NOT NULL,
    "officercommanding" character varying(100),
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policestation" OWNER TO "nyimbi";

--
-- Name: policestation_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policestation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policestation_id_seq" OWNER TO "nyimbi";

--
-- Name: policestation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policestation_id_seq" OWNED BY "policestation"."id";


--
-- Name: prison; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prison" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "town" integer NOT NULL,
    "warden" character varying(100),
    "capacity" integer NOT NULL,
    "population" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prison" OWNER TO "nyimbi";

--
-- Name: prison_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prison_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prison_id_seq" OWNER TO "nyimbi";

--
-- Name: prison_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prison_id_seq" OWNED BY "prison"."id";


--
-- Name: prisonremand; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisonremand" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "prison" integer NOT NULL,
    "warrant_no" character varying(100) NOT NULL,
    "hearing" integer NOT NULL,
    "defendant" integer NOT NULL,
    "warrant_duration" integer NOT NULL,
    "warrantdate" timestamp without time zone NOT NULL,
    "warrant" "text",
    "warrant_expiry" timestamp without time zone,
    "history" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prisonremand" OWNER TO "nyimbi";

--
-- Name: prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prosecutor" OWNER TO "nyimbi";

--
-- Name: prosecutor_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prosecutor_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prosecutor_id_seq" OWNER TO "nyimbi";

--
-- Name: prosecutor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prosecutor_id_seq" OWNED BY "prosecutor"."id";


--
-- Name: prosecutor_prosecutorteam; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor_prosecutorteam" (
    "prosecutor" integer NOT NULL,
    "prosecutorteam" integer NOT NULL
);


ALTER TABLE "prosecutor_prosecutorteam" OWNER TO "nyimbi";

--
-- Name: prosecutorteam; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutorteam" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prosecutorteam" OWNER TO "nyimbi";

--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prosecutorteam_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prosecutorteam_id_seq" OWNER TO "nyimbi";

--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prosecutorteam_id_seq" OWNED BY "prosecutorteam"."id";


--
-- Name: region; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "region" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "region" OWNER TO "nyimbi";

--
-- Name: region_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "region_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "region_id_seq" OWNER TO "nyimbi";

--
-- Name: region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "region_id_seq" OWNED BY "region"."id";


--
-- Name: surety; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "surety" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "kin1_name" character varying(40),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(40),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "surety" OWNER TO "nyimbi";

--
-- Name: surety_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "surety_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "surety_id_seq" OWNER TO "nyimbi";

--
-- Name: surety_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "surety_id_seq" OWNED BY "surety"."id";


--
-- Name: town; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "town" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(60) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "district" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "town" OWNER TO "nyimbi";

--
-- Name: town_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "town_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "town_id_seq" OWNER TO "nyimbi";

--
-- Name: town_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "town_id_seq" OWNED BY "town"."id";


--
-- Name: Districts id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "Districts" ALTER COLUMN "id" SET DEFAULT "nextval"('"Districts_id_seq"'::"regclass");


--
-- Name: attorney id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney" ALTER COLUMN "id" SET DEFAULT "nextval"('"attorney_id_seq"'::"regclass");


--
-- Name: bail id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail" ALTER COLUMN "id" SET DEFAULT "nextval"('"bail_id_seq"'::"regclass");


--
-- Name: case id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case" ALTER COLUMN "id" SET DEFAULT "nextval"('"case_id_seq"'::"regclass");


--
-- Name: causeofaction id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction" ALTER COLUMN "id" SET DEFAULT "nextval"('"causeofaction_id_seq"'::"regclass");


--
-- Name: constituency id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency" ALTER COLUMN "id" SET DEFAULT "nextval"('"constituency_id_seq"'::"regclass");


--
-- Name: court id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court" ALTER COLUMN "id" SET DEFAULT "nextval"('"court_id_seq"'::"regclass");


--
-- Name: courtlevel id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel" ALTER COLUMN "id" SET DEFAULT "nextval"('"courtlevel_id_seq"'::"regclass");


--
-- Name: defendant id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant" ALTER COLUMN "id" SET DEFAULT "nextval"('"defendant_id_seq"'::"regclass");


--
-- Name: doctemplate id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate" ALTER COLUMN "id" SET DEFAULT "nextval"('"doctemplate_id_seq"'::"regclass");


--
-- Name: document id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document" ALTER COLUMN "id" SET DEFAULT "nextval"('"document_id_seq"'::"regclass");


--
-- Name: filing id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing" ALTER COLUMN "id" SET DEFAULT "nextval"('"filing_id_seq"'::"regclass");


--
-- Name: filingtype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype" ALTER COLUMN "id" SET DEFAULT "nextval"('"filingtype_id_seq"'::"regclass");


--
-- Name: gender id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender" ALTER COLUMN "id" SET DEFAULT "nextval"('"gender_id_seq"'::"regclass");


--
-- Name: hearing id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing" ALTER COLUMN "id" SET DEFAULT "nextval"('"hearing_id_seq"'::"regclass");


--
-- Name: hearingtype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype" ALTER COLUMN "id" SET DEFAULT "nextval"('"hearingtype_id_seq"'::"regclass");


--
-- Name: investigation id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation" ALTER COLUMN "id" SET DEFAULT "nextval"('"investigation_id_seq"'::"regclass");


--
-- Name: judge id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge" ALTER COLUMN "id" SET DEFAULT "nextval"('"judge_id_seq"'::"regclass");


--
-- Name: lawfirm id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm" ALTER COLUMN "id" SET DEFAULT "nextval"('"lawfirm_id_seq"'::"regclass");


--
-- Name: natureofsuit id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit" ALTER COLUMN "id" SET DEFAULT "nextval"('"natureofsuit_id_seq"'::"regclass");


--
-- Name: observer id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "observer" ALTER COLUMN "id" SET DEFAULT "nextval"('"observer_id_seq"'::"regclass");


--
-- Name: plaintiff id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff" ALTER COLUMN "id" SET DEFAULT "nextval"('"plaintiff_id_seq"'::"regclass");


--
-- Name: policeman id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policeman" ALTER COLUMN "id" SET DEFAULT "nextval"('"policeman_id_seq"'::"regclass");


--
-- Name: policerole id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole" ALTER COLUMN "id" SET DEFAULT "nextval"('"policerole_id_seq"'::"regclass");


--
-- Name: policestation id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation" ALTER COLUMN "id" SET DEFAULT "nextval"('"policestation_id_seq"'::"regclass");


--
-- Name: prison id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison" ALTER COLUMN "id" SET DEFAULT "nextval"('"prison_id_seq"'::"regclass");


--
-- Name: prosecutor id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor" ALTER COLUMN "id" SET DEFAULT "nextval"('"prosecutor_id_seq"'::"regclass");


--
-- Name: prosecutorteam id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam" ALTER COLUMN "id" SET DEFAULT "nextval"('"prosecutorteam_id_seq"'::"regclass");


--
-- Name: region id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "region" ALTER COLUMN "id" SET DEFAULT "nextval"('"region_id_seq"'::"regclass");


--
-- Name: surety id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety" ALTER COLUMN "id" SET DEFAULT "nextval"('"surety_id_seq"'::"regclass");


--
-- Name: town id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town" ALTER COLUMN "id" SET DEFAULT "nextval"('"town_id_seq"'::"regclass");


--
-- Data for Name: Districts; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "Districts" ("created_on", "changed_on", "name", "description", "notes", "id", "region", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: ab_permission; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission" ("id", "name") FROM stdin;
1	can_this_form_post
2	can_this_form_get
3	can_edit
4	can_userinfo
5	can_delete
6	can_download
7	can_list
8	can_add
9	can_show
10	resetmypassword
11	resetpasswords
12	userinfoedit
13	menu_access
14	Copy Role
15	can_chart
16	muldelete
\.


--
-- Data for Name: ab_permission_view; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission_view" ("id", "permission_id", "view_menu_id") FROM stdin;
1	1	5
2	2	5
3	1	6
4	2	6
5	1	7
6	2	7
7	3	9
8	4	9
9	5	9
10	6	9
11	7	9
12	8	9
13	9	9
14	10	9
15	11	9
16	12	9
17	13	10
18	13	11
19	3	12
20	5	12
21	6	12
22	7	12
23	8	12
24	9	12
25	14	12
26	13	13
27	15	14
28	13	15
29	7	16
30	9	16
31	5	16
32	7	17
33	13	18
34	7	19
35	13	20
36	7	21
37	13	22
38	3	23
39	5	23
40	6	23
41	7	23
42	8	23
43	9	23
44	16	23
45	13	24
46	13	25
47	3	26
48	5	26
49	6	26
50	7	26
51	8	26
52	9	26
53	16	26
54	13	27
55	3	28
56	5	28
57	6	28
58	7	28
59	8	28
60	9	28
61	16	28
62	13	29
63	3	30
64	5	30
65	6	30
66	7	30
67	8	30
68	9	30
69	16	30
70	13	31
71	3	32
72	5	32
73	6	32
74	7	32
75	8	32
76	9	32
77	16	32
78	13	33
79	3	34
80	5	34
81	6	34
82	7	34
83	8	34
84	9	34
85	16	34
86	13	35
87	3	36
88	5	36
89	6	36
90	7	36
91	8	36
92	9	36
93	16	36
94	13	37
95	3	38
96	5	38
97	6	38
98	7	38
99	8	38
100	9	38
101	16	38
102	13	39
103	3	40
104	5	40
105	6	40
106	7	40
107	8	40
108	9	40
109	16	40
110	13	41
111	3	42
112	5	42
113	6	42
114	7	42
115	8	42
116	9	42
117	16	42
118	13	43
119	3	44
120	5	44
121	6	44
122	7	44
123	8	44
124	9	44
125	16	44
126	13	45
127	3	46
128	5	46
129	6	46
130	7	46
131	8	46
132	9	46
133	16	46
134	13	47
135	3	48
136	5	48
137	6	48
138	7	48
139	8	48
140	9	48
141	16	48
142	13	49
143	3	50
144	5	50
145	6	50
146	7	50
147	8	50
148	9	50
149	16	50
150	13	51
151	3	52
152	5	52
153	6	52
154	7	52
155	8	52
156	9	52
157	16	52
158	13	53
159	13	54
160	3	55
161	5	55
162	6	55
163	7	55
164	8	55
165	9	55
166	16	55
167	13	56
168	3	57
169	5	57
170	6	57
171	7	57
172	8	57
173	9	57
174	16	57
175	13	58
176	3	59
177	5	59
178	6	59
179	7	59
180	8	59
181	9	59
182	16	59
183	13	60
184	3	61
185	5	61
186	6	61
187	7	61
188	8	61
189	9	61
190	16	61
192	3	63
193	5	63
194	6	63
195	7	63
196	8	63
197	9	63
198	16	63
200	3	65
201	5	65
202	6	65
203	7	65
204	8	65
205	9	65
206	16	65
208	13	67
216	13	69
224	13	71
232	13	73
240	13	75
248	13	77
256	13	79
264	13	81
272	13	83
191	13	62
199	13	64
207	13	66
209	3	68
210	5	68
211	6	68
212	7	68
213	8	68
214	9	68
215	16	68
217	3	70
218	5	70
219	6	70
220	7	70
221	8	70
222	9	70
223	16	70
225	3	72
226	5	72
227	6	72
228	7	72
229	8	72
230	9	72
231	16	72
233	3	74
234	5	74
235	6	74
236	7	74
237	8	74
238	9	74
239	16	74
241	3	76
242	5	76
243	6	76
244	7	76
245	8	76
246	9	76
247	16	76
249	3	78
250	5	78
251	6	78
252	7	78
253	8	78
254	9	78
255	16	78
257	3	80
258	5	80
259	6	80
260	7	80
261	8	80
262	9	80
263	16	80
265	3	82
266	5	82
267	6	82
268	7	82
269	8	82
270	9	82
271	16	82
273	3	84
274	5	84
275	6	84
276	7	84
277	8	84
278	9	84
279	16	84
280	13	85
281	13	86
282	3	87
283	5	87
284	6	87
285	7	87
286	8	87
287	9	87
288	16	87
289	3	88
290	5	88
291	6	88
292	7	88
293	8	88
294	9	88
295	16	88
296	13	89
297	15	90
298	13	91
299	13	92
300	15	93
301	13	94
302	15	95
303	13	96
304	15	97
305	13	98
306	15	99
307	13	100
308	15	101
309	13	102
310	15	103
311	13	104
312	15	105
313	13	106
314	15	107
315	13	108
316	15	109
317	13	110
318	15	111
319	13	112
320	15	113
321	13	114
322	15	115
323	13	116
324	15	117
325	13	118
326	15	119
327	13	120
328	15	121
329	13	122
330	15	123
331	13	124
\.


--
-- Data for Name: ab_permission_view_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission_view_role" ("id", "permission_view_id", "role_id") FROM stdin;
1	1	1
2	2	1
3	3	1
4	4	1
5	5	1
6	6	1
7	7	1
8	8	1
9	9	1
10	10	1
11	11	1
12	12	1
13	13	1
14	14	1
15	15	1
16	16	1
17	17	1
18	18	1
19	19	1
20	20	1
21	21	1
22	22	1
23	23	1
24	24	1
25	25	1
26	26	1
27	27	1
28	28	1
29	29	1
30	30	1
31	31	1
32	32	1
33	33	1
34	34	1
35	35	1
36	36	1
37	37	1
38	38	1
39	39	1
40	40	1
41	41	1
42	42	1
43	43	1
44	44	1
45	45	1
46	46	1
47	47	1
48	48	1
49	49	1
50	50	1
51	51	1
52	52	1
53	53	1
54	54	1
55	55	1
56	56	1
57	57	1
58	58	1
59	59	1
60	60	1
61	61	1
62	62	1
63	63	1
64	64	1
65	65	1
66	66	1
67	67	1
68	68	1
69	69	1
70	70	1
71	71	1
72	72	1
73	73	1
74	74	1
75	75	1
76	76	1
77	77	1
78	78	1
79	79	1
80	80	1
81	81	1
82	82	1
83	83	1
84	84	1
85	85	1
86	86	1
87	87	1
88	88	1
89	89	1
90	90	1
91	91	1
92	92	1
93	93	1
94	94	1
95	95	1
96	96	1
97	97	1
98	98	1
99	99	1
100	100	1
101	101	1
102	102	1
103	103	1
104	104	1
105	105	1
106	106	1
107	107	1
108	108	1
109	109	1
110	110	1
111	111	1
112	112	1
113	113	1
114	114	1
115	115	1
116	116	1
117	117	1
118	118	1
119	119	1
120	120	1
121	121	1
122	122	1
123	123	1
124	124	1
125	125	1
126	126	1
127	127	1
128	128	1
129	129	1
130	130	1
131	131	1
132	132	1
133	133	1
134	134	1
135	135	1
136	136	1
137	137	1
138	138	1
139	139	1
140	140	1
141	141	1
142	142	1
143	143	1
144	144	1
145	145	1
146	146	1
147	147	1
148	148	1
149	149	1
150	150	1
151	151	1
152	152	1
153	153	1
154	154	1
155	155	1
156	156	1
157	157	1
158	158	1
159	159	1
160	160	1
161	161	1
162	162	1
163	163	1
164	164	1
165	165	1
166	166	1
167	167	1
168	168	1
169	169	1
170	170	1
171	171	1
172	172	1
173	173	1
174	174	1
175	175	1
176	176	1
177	177	1
178	178	1
179	179	1
180	180	1
181	181	1
182	182	1
183	183	1
184	184	1
185	185	1
186	186	1
187	187	1
188	188	1
189	189	1
190	190	1
192	192	1
193	193	1
194	194	1
195	195	1
196	196	1
197	197	1
198	198	1
200	200	1
201	201	1
202	202	1
203	203	1
204	204	1
205	205	1
206	206	1
208	208	1
216	216	1
224	224	1
232	232	1
240	240	1
248	248	1
256	256	1
264	264	1
272	272	1
191	191	1
199	199	1
207	207	1
209	209	1
210	210	1
211	211	1
212	212	1
213	213	1
214	214	1
215	215	1
217	217	1
218	218	1
219	219	1
220	220	1
221	221	1
222	222	1
223	223	1
225	225	1
226	226	1
227	227	1
228	228	1
229	229	1
230	230	1
231	231	1
233	233	1
234	234	1
235	235	1
236	236	1
237	237	1
238	238	1
239	239	1
241	241	1
242	242	1
243	243	1
244	244	1
245	245	1
246	246	1
247	247	1
249	249	1
250	250	1
251	251	1
252	252	1
253	253	1
254	254	1
255	255	1
257	257	1
258	258	1
259	259	1
260	260	1
261	261	1
262	262	1
263	263	1
265	265	1
266	266	1
267	267	1
268	268	1
269	269	1
270	270	1
271	271	1
273	273	1
274	274	1
275	275	1
276	276	1
277	277	1
278	278	1
279	279	1
280	280	1
281	281	1
282	282	1
283	283	1
284	284	1
285	285	1
286	286	1
287	287	1
288	288	1
289	289	1
290	290	1
291	291	1
292	292	1
293	293	1
294	294	1
295	295	1
296	296	1
297	297	1
298	298	1
299	299	1
300	300	1
301	301	1
302	302	1
303	303	1
304	304	1
305	305	1
306	306	1
307	307	1
308	308	1
309	309	1
310	310	1
311	311	1
312	312	1
313	313	1
314	314	1
315	315	1
316	316	1
317	317	1
318	318	1
319	319	1
320	320	1
321	321	1
322	322	1
323	323	1
324	324	1
325	325	1
326	326	1
327	327	1
328	328	1
329	329	1
330	330	1
331	331	1
\.


--
-- Data for Name: ab_register_user; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_register_user" ("id", "first_name", "last_name", "username", "password", "email", "registration_date", "registration_hash") FROM stdin;
\.


--
-- Data for Name: ab_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_role" ("id", "name") FROM stdin;
1	Admin
2	Public
\.


--
-- Data for Name: ab_user; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_user" ("id", "first_name", "last_name", "username", "password", "active", "email", "last_login", "login_count", "fail_login_count", "created_on", "changed_on", "created_by_fk", "changed_by_fk") FROM stdin;
1	admin	user	admin	pbkdf2:sha256:50000$kJRADSGi$4d3485770f51912f22744c9280001bcbc7b6fc439173f35556467690172f577b	t	admin@fab.org	\N	\N	\N	2017-09-29 09:03:14.888693	2017-09-29 09:03:14.888704	\N	\N
\.


--
-- Data for Name: ab_user_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_user_role" ("id", "user_id", "role_id") FROM stdin;
1	1	1
\.


--
-- Data for Name: ab_view_menu; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_view_menu" ("id", "name") FROM stdin;
1	MyIndexView
2	UtilView
3	LocaleView
4	RegisterUserDBView
5	ResetPasswordView
6	ResetMyPasswordView
7	UserInfoEditView
8	AuthDBView
9	UserDBModelView
10	List Users
11	Security
12	RoleModelView
13	List Roles
14	UserStatsChartView
15	User's Statistics
16	RegisterUserModelView
17	PermissionModelView
18	Base Permissions
19	ViewMenuModelView
20	Views/Menus
21	PermissionViewModelView
22	Permission on Views/Menus
23	RegionView
24	Regions
25	Setup
26	DistrictView
27	Districts
28	ConstituencyView
29	Constituencies
30	GenderView
31	Genders
32	TownView
33	Towns
34	CourtlevelView
35	Courtlevels
36	CourtView
37	Courts
38	PolicestationView
39	Police Stations
40	PrisonView
41	Prisons
42	HearingtypeView
43	Hearing Types
44	CauseofactionView
45	Causes of Action
46	NatureofsuitView
47	Nature of Suit
48	FilingtypeView
49	Filing Types
50	PoliceroleView
51	Police Roles
52	JudgeView
53	Judicial Officers
54	Register
55	LawfirmView
56	Lawfirms
57	AttorneyView
58	Attorneys
59	PolicemanView
60	Police Officers
61	ProsecutorteamView
62	Prosecutor Teams
63	ProsecutorView
64	Prosecutors
65	CaseView
66	Manage Cases
67	Cases
68	PlaintiffView
69	Plaintiffs
70	DefendantView
71	Defendants
72	InvestigationView
73	Investigations
74	ObserverView
75	Witnesses
76	HearingView
77	Hearings
78	SuretyView
79	Sureties
80	PrisonremandView
81	Remand
82	BailView
83	Bail
84	DoctemplateView
85	Doc Templates
86	Filings
87	FilingView
88	DocumentView
89	Documents
90	AttorneyChartView
91	Attorney Age Chart
92	Reports
93	AttorneyTimeChartView
94	Attorney Time Chart
95	PlaintiffChartView
96	Plaintiff Age Chart
97	PlaintiffTimeChartView
98	Plaintiff Time Chart
99	ObserverChartView
100	Observer Age Chart
101	ObserverTimeChartView
102	Observer Time Chart
103	SuretyChartView
104	Surety Age Chart
105	SuretyTimeChartView
106	Surety Time Chart
107	ProsecutorChartView
108	Prosecutor Age Chart
109	ProsecutorTimeChartView
110	Prosecutor Time Chart
111	PolicemanChartView
112	Policeman Age Chart
113	PolicemanTimeChartView
114	Policeman Time Chart
115	JudgeChartView
116	Judge Age Chart
117	JudgeTimeChartView
118	Judge Time Chart
119	DefendantChartView
120	Defendant Age Chart
121	DefendantTimeChartView
122	Defendant Time Chart
123	CaseChartView
124	Case Charts
\.


--
-- Data for Name: attorney; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "attorney" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "law_firm", "barnumber", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: attorney_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "attorney_hearing" ("attorney", "hearing") FROM stdin;
\.


--
-- Data for Name: bail; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail" ("created_on", "changed_on", "id", "hearing", "defendant", "amount_granted", "no_of_sureties", "paid", "pay_date", "receipt_no", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: bail_surety; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail_surety" ("bail", "surety") FROM stdin;
\.


--
-- Data for Name: case; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case" ("created_on", "changed_on", "segment", "task_group", "action", "activity_description", "goal", "status", "actual_start", "planned_start", "start_notes", "planned_end", "actual_end", "end_notes", "deadline", "not_started", "delayed_start", "completed", "delayed_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "case_name", "ob_number", "initial_report", "report_date", "weather", "visibility", "location", "report_notes", "injuries", "loss", "death", "vehicular", "drugs", "weapons", "investigation_assigment_date", "investigation_assignment_note", "investigation_plan", "evaluation_conclusion", "should_investigate_further", "priority", "investigation_summary", "ag_advice_requested", "ag_advice_req_date", "docketnumber", "send_to_trial", "charge_date", "ag_advice", "ag_advice_date", "take_to_trial", "case_closed", "judgement", "judgement_date", "closed_date", "sentence_length", "sentence_startdate", "sentence_expirydate", "fine_amount", "case_appealed", "appeal_date", "appeal_granted", "prosecution_notes", "defense_notes", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: case_causeofaction; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_causeofaction" ("case", "causeofaction") FROM stdin;
\.


--
-- Data for Name: case_defendant; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_defendant" ("case", "defendant") FROM stdin;
\.


--
-- Data for Name: case_natureofsuit; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_natureofsuit" ("case", "natureofsuit") FROM stdin;
\.


--
-- Data for Name: case_observer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_observer" ("case", "observer") FROM stdin;
\.


--
-- Data for Name: case_plaintiff; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_plaintiff" ("case", "plaintiff") FROM stdin;
\.


--
-- Data for Name: case_policeman; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_policeman" ("case", "policeman") FROM stdin;
\.


--
-- Data for Name: case_policeman_2; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_policeman_2" ("case", "policeman") FROM stdin;
\.


--
-- Data for Name: case_policestation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_policestation" ("case", "policestation") FROM stdin;
\.


--
-- Data for Name: case_prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_prosecutor" ("case", "prosecutor") FROM stdin;
\.


--
-- Data for Name: causeofaction; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction" ("created_on", "changed_on", "name", "description", "notes", "id", "criminal", "parent_coa", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: causeofaction_filing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_filing" ("causeofaction", "filing") FROM stdin;
\.


--
-- Data for Name: causeofaction_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_hearing" ("causeofaction", "hearing") FROM stdin;
\.


--
-- Data for Name: constituency; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "constituency" ("created_on", "changed_on", "name", "description", "notes", "id", "region", "town", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: court; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "court" ("created_on", "changed_on", "name", "description", "notes", "id", "town", "residentmagistrate", "registrar", "court_level", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: courtlevel; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "courtlevel" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: defendant; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "blood_group", "striking_features", "height_m", "weight_kg", "eye_colour", "hair_colour", "complexion", "religion", "ethnicity", "fp_lthumb", "fp_left2", "fp_left3", "fp_left4", "fp_left5", "fp_rthumb", "fp_right2", "fp_right3", "fp_right4", "fp_right5", "palm_left", "palm_right", "eye_left", "eye_right", "employed", "employer", "employer_contact", "employment_date", "termination_date", "employ_role", "supervisor", "supervisor_contact", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: defendant_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_hearing" ("defendant", "hearing") FROM stdin;
\.


--
-- Data for Name: doctemplate; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "doctemplate" ("created_on", "changed_on", "mime_type", "doc", "doc_text", "doc_binary", "doctitle", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "audio_duration_secs", "audio_frame_rate", "audio_channels", "bin_hash", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document" ("created_on", "changed_on", "mime_type", "doc", "doc_text", "doc_binary", "doctitle", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "audio_duration_secs", "audio_frame_rate", "audio_channels", "bin_hash", "id", "doc_template", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: document_filing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document_filing" ("document", "filing") FROM stdin;
\.


--
-- Data for Name: filing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing" ("created_on", "changed_on", "id", "file_date", "total_fees", "filing_attorney", "filing_prosecutor", "receipt_number", "receipt_verified", "amount_paid", "fee_balance", "payment_history", "defense_filing", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: filing_filingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_filingtype" ("filing", "filingtype") FROM stdin;
\.


--
-- Data for Name: filing_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_hearing" ("filing", "hearing") FROM stdin;
\.


--
-- Data for Name: filingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filingtype" ("created_on", "changed_on", "name", "description", "notes", "id", "cost", "perpagecost", "paid_per_page", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: gender; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gender" ("created_on", "changed_on", "id", "name", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing" ("created_on", "changed_on", "priority", "segment", "task_group", "action", "activity_description", "goal", "status", "actual_start", "planned_start", "start_notes", "planned_end", "actual_end", "end_notes", "deadline", "not_started", "delayed_start", "completed", "delayed_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "hearing_date", "adjourned", "case", "court", "hearingtype", "remand_warrant", "remand_length", "remand_date", "remand_warrant_expiry_date", "nexthearingdate", "final_hearing", "transcript", "audio", "video", "witness_submissions", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: hearing_judge; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_judge" ("hearing", "judge") FROM stdin;
\.


--
-- Data for Name: hearing_observer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_observer" ("hearing", "observer") FROM stdin;
\.


--
-- Data for Name: hearing_policeman; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_policeman" ("hearing", "policeman") FROM stdin;
\.


--
-- Data for Name: hearing_prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_prosecutor" ("hearing", "prosecutor") FROM stdin;
\.


--
-- Data for Name: hearingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearingtype" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: investigation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation" ("created_on", "changed_on", "priority", "segment", "task_group", "action", "activity_description", "goal", "status", "actual_start", "planned_start", "start_notes", "planned_end", "actual_end", "end_notes", "deadline", "not_started", "delayed_start", "completed", "delayed_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "case", "actiondate", "evidence", "narrative", "weather", "location", "evidence_desc", "pic1", "pic2", "pic3", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: investigation_observer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_observer" ("investigation", "observer") FROM stdin;
\.


--
-- Data for Name: investigation_policeman; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_policeman" ("investigation", "policeman") FROM stdin;
\.


--
-- Data for Name: judge; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "judge" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "court", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: lawfirm; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "lawfirm" ("created_on", "changed_on", "name", "description", "notes", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: natureofsuit; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "natureofsuit" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: observer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "observer" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "for_defense", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: plaintiff; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "plaintiff" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policeman; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policeman" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "service_number", "commission_date", "rank", "rank_accession_date", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policerole; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerole" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policerole_policeman; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerole_policeman" ("policerole", "policeman") FROM stdin;
\.


--
-- Data for Name: policestation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policestation" ("created_on", "changed_on", "name", "description", "notes", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "town", "officercommanding", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prison; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prison" ("created_on", "changed_on", "name", "description", "notes", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "town", "warden", "capacity", "population", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prisonremand; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisonremand" ("created_on", "changed_on", "prison", "warrant_no", "hearing", "defendant", "warrant_duration", "warrantdate", "warrant", "warrant_expiry", "history", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prosecutor_prosecutorteam; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor_prosecutorteam" ("prosecutor", "prosecutorteam") FROM stdin;
\.


--
-- Data for Name: prosecutorteam; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutorteam" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "region" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: surety; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "surety" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin2_phone", "kin2_email", "kin2_addr", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: town; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "town" ("created_on", "changed_on", "name", "description", "notes", "id", "district", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Name: Districts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"Districts_id_seq"', 1, false);


--
-- Name: ab_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_id_seq"', 16, true);


--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_view_id_seq"', 331, true);


--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_view_role_id_seq"', 331, true);


--
-- Name: ab_register_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_register_user_id_seq"', 1, false);


--
-- Name: ab_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_role_id_seq"', 2, true);


--
-- Name: ab_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_user_id_seq"', 1, true);


--
-- Name: ab_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_user_role_id_seq"', 1, true);


--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_view_menu_id_seq"', 124, true);


--
-- Name: attorney_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"attorney_id_seq"', 1, false);


--
-- Name: bail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"bail_id_seq"', 1, false);


--
-- Name: case_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"case_id_seq"', 1, false);


--
-- Name: causeofaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"causeofaction_id_seq"', 1, false);


--
-- Name: constituency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"constituency_id_seq"', 1, false);


--
-- Name: court_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"court_id_seq"', 1, false);


--
-- Name: courtlevel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"courtlevel_id_seq"', 1, false);


--
-- Name: defendant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"defendant_id_seq"', 1, false);


--
-- Name: doctemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"doctemplate_id_seq"', 1, false);


--
-- Name: document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"document_id_seq"', 1, false);


--
-- Name: filing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"filing_id_seq"', 1, false);


--
-- Name: filingtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"filingtype_id_seq"', 1, false);


--
-- Name: gender_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"gender_id_seq"', 2, true);


--
-- Name: hearing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"hearing_id_seq"', 1, false);


--
-- Name: hearingtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"hearingtype_id_seq"', 1, false);


--
-- Name: investigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"investigation_id_seq"', 1, false);


--
-- Name: judge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"judge_id_seq"', 1, false);


--
-- Name: lawfirm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"lawfirm_id_seq"', 1, false);


--
-- Name: natureofsuit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"natureofsuit_id_seq"', 1, false);


--
-- Name: observer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"observer_id_seq"', 1, false);


--
-- Name: plaintiff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"plaintiff_id_seq"', 1, false);


--
-- Name: policeman_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policeman_id_seq"', 1, false);


--
-- Name: policerole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policerole_id_seq"', 1, false);


--
-- Name: policestation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policestation_id_seq"', 1, false);


--
-- Name: prison_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prison_id_seq"', 1, false);


--
-- Name: prosecutor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prosecutor_id_seq"', 1, false);


--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prosecutorteam_id_seq"', 1, false);


--
-- Name: region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"region_id_seq"', 1, false);


--
-- Name: surety_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"surety_id_seq"', 1, false);


--
-- Name: town_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"town_id_seq"', 1, false);


--
-- Name: Districts Districts_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "Districts"
    ADD CONSTRAINT "Districts_pkey" PRIMARY KEY ("id");


--
-- Name: ab_permission ab_permission_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission"
    ADD CONSTRAINT "ab_permission_name_key" UNIQUE ("name");


--
-- Name: ab_permission ab_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission"
    ADD CONSTRAINT "ab_permission_pkey" PRIMARY KEY ("id");


--
-- Name: ab_permission_view ab_permission_view_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_pkey" PRIMARY KEY ("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_register_user ab_register_user_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_register_user"
    ADD CONSTRAINT "ab_register_user_pkey" PRIMARY KEY ("id");


--
-- Name: ab_register_user ab_register_user_username_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_register_user"
    ADD CONSTRAINT "ab_register_user_username_key" UNIQUE ("username");


--
-- Name: ab_role ab_role_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_role"
    ADD CONSTRAINT "ab_role_name_key" UNIQUE ("name");


--
-- Name: ab_role ab_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_role"
    ADD CONSTRAINT "ab_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user ab_user_email_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_email_key" UNIQUE ("email");


--
-- Name: ab_user ab_user_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user_role ab_user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user ab_user_username_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_username_key" UNIQUE ("username");


--
-- Name: ab_view_menu ab_view_menu_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_view_menu"
    ADD CONSTRAINT "ab_view_menu_name_key" UNIQUE ("name");


--
-- Name: ab_view_menu ab_view_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_view_menu"
    ADD CONSTRAINT "ab_view_menu_pkey" PRIMARY KEY ("id");


--
-- Name: attorney_hearing attorney_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney_hearing"
    ADD CONSTRAINT "attorney_hearing_pkey" PRIMARY KEY ("attorney", "hearing");


--
-- Name: attorney attorney_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney"
    ADD CONSTRAINT "attorney_pkey" PRIMARY KEY ("id");


--
-- Name: bail bail_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_pkey" PRIMARY KEY ("id");


--
-- Name: bail_surety bail_surety_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_pkey" PRIMARY KEY ("bail", "surety");


--
-- Name: case_causeofaction case_causeofaction_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_pkey" PRIMARY KEY ("case", "causeofaction");


--
-- Name: case_defendant case_defendant_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_pkey" PRIMARY KEY ("case", "defendant");


--
-- Name: case_natureofsuit case_natureofsuit_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_pkey" PRIMARY KEY ("case", "natureofsuit");


--
-- Name: case_observer case_observer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_observer"
    ADD CONSTRAINT "case_observer_pkey" PRIMARY KEY ("case", "observer");


--
-- Name: case case_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_pkey" PRIMARY KEY ("id");


--
-- Name: case_plaintiff case_plaintiff_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_pkey" PRIMARY KEY ("case", "plaintiff");


--
-- Name: case_policeman_2 case_policeman_2_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman_2"
    ADD CONSTRAINT "case_policeman_2_pkey" PRIMARY KEY ("case", "policeman");


--
-- Name: case_policeman case_policeman_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman"
    ADD CONSTRAINT "case_policeman_pkey" PRIMARY KEY ("case", "policeman");


--
-- Name: case_policestation case_policestation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policestation"
    ADD CONSTRAINT "case_policestation_pkey" PRIMARY KEY ("case", "policestation");


--
-- Name: case_prosecutor case_prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_pkey" PRIMARY KEY ("case", "prosecutor");


--
-- Name: causeofaction_filing causeofaction_filing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_pkey" PRIMARY KEY ("causeofaction", "filing");


--
-- Name: causeofaction_hearing causeofaction_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_pkey" PRIMARY KEY ("causeofaction", "hearing");


--
-- Name: causeofaction causeofaction_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_pkey" PRIMARY KEY ("id");


--
-- Name: constituency constituency_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_pkey" PRIMARY KEY ("id");


--
-- Name: court court_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_pkey" PRIMARY KEY ("id");


--
-- Name: courtlevel courtlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_pkey" PRIMARY KEY ("id");


--
-- Name: defendant_hearing defendant_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_pkey" PRIMARY KEY ("defendant", "hearing");


--
-- Name: defendant defendant_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_pkey" PRIMARY KEY ("id");


--
-- Name: doctemplate doctemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_pkey" PRIMARY KEY ("id");


--
-- Name: document_filing document_filing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_filing"
    ADD CONSTRAINT "document_filing_pkey" PRIMARY KEY ("document", "filing");


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_pkey" PRIMARY KEY ("id");


--
-- Name: filing_filingtype filing_filingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_pkey" PRIMARY KEY ("filing", "filingtype");


--
-- Name: filing_hearing filing_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_hearing"
    ADD CONSTRAINT "filing_hearing_pkey" PRIMARY KEY ("filing", "hearing");


--
-- Name: filing filing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_pkey" PRIMARY KEY ("id");


--
-- Name: filingtype filingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_pkey" PRIMARY KEY ("id");


--
-- Name: gender gender_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_name_key" UNIQUE ("name");


--
-- Name: gender gender_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_pkey" PRIMARY KEY ("id");


--
-- Name: hearing_judge hearing_judge_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judge"
    ADD CONSTRAINT "hearing_judge_pkey" PRIMARY KEY ("hearing", "judge");


--
-- Name: hearing_observer hearing_observer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_observer"
    ADD CONSTRAINT "hearing_observer_pkey" PRIMARY KEY ("hearing", "observer");


--
-- Name: hearing hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_pkey" PRIMARY KEY ("id");


--
-- Name: hearing_policeman hearing_policeman_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_policeman"
    ADD CONSTRAINT "hearing_policeman_pkey" PRIMARY KEY ("hearing", "policeman");


--
-- Name: hearing_prosecutor hearing_prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_pkey" PRIMARY KEY ("hearing", "prosecutor");


--
-- Name: hearingtype hearingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_pkey" PRIMARY KEY ("id");


--
-- Name: investigation_observer investigation_observer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_observer"
    ADD CONSTRAINT "investigation_observer_pkey" PRIMARY KEY ("investigation", "observer");


--
-- Name: investigation investigation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_pkey" PRIMARY KEY ("id");


--
-- Name: investigation_policeman investigation_policeman_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_policeman"
    ADD CONSTRAINT "investigation_policeman_pkey" PRIMARY KEY ("investigation", "policeman");


--
-- Name: judge judge_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge"
    ADD CONSTRAINT "judge_pkey" PRIMARY KEY ("id");


--
-- Name: lawfirm lawfirm_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_pkey" PRIMARY KEY ("id");


--
-- Name: natureofsuit natureofsuit_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_pkey" PRIMARY KEY ("id");


--
-- Name: observer observer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "observer"
    ADD CONSTRAINT "observer_pkey" PRIMARY KEY ("id");


--
-- Name: plaintiff plaintiff_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_pkey" PRIMARY KEY ("id");


--
-- Name: policeman policeman_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policeman"
    ADD CONSTRAINT "policeman_pkey" PRIMARY KEY ("id");


--
-- Name: policerole policerole_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_pkey" PRIMARY KEY ("id");


--
-- Name: policerole_policeman policerole_policeman_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole_policeman"
    ADD CONSTRAINT "policerole_policeman_pkey" PRIMARY KEY ("policerole", "policeman");


--
-- Name: policestation policestation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_pkey" PRIMARY KEY ("id");


--
-- Name: prison prison_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_pkey" PRIMARY KEY ("id");


--
-- Name: prisonremand prisonremand_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_pkey" PRIMARY KEY ("prison", "warrant_no");


--
-- Name: prosecutor prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_pkey" PRIMARY KEY ("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_pkey" PRIMARY KEY ("prosecutor", "prosecutorteam");


--
-- Name: prosecutorteam prosecutorteam_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_pkey" PRIMARY KEY ("id");


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "region"
    ADD CONSTRAINT "region_pkey" PRIMARY KEY ("id");


--
-- Name: surety surety_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_pkey" PRIMARY KEY ("id");


--
-- Name: town town_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_pkey" PRIMARY KEY ("id");


--
-- Name: ix_Districts_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_Districts_name" ON "Districts" USING "btree" ("name");


--
-- Name: ix_Districts_region; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_Districts_region" ON "Districts" USING "btree" ("region");


--
-- Name: ix_attorney_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_firstname" ON "attorney" USING "btree" ("firstname");


--
-- Name: ix_attorney_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_gender" ON "attorney" USING "btree" ("gender");


--
-- Name: ix_attorney_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_hearing_hearing" ON "attorney_hearing" USING "btree" ("hearing");


--
-- Name: ix_attorney_law_firm; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_law_firm" ON "attorney" USING "btree" ("law_firm");


--
-- Name: ix_attorney_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_mobile" ON "attorney" USING "btree" ("mobile");


--
-- Name: ix_attorney_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_othernames" ON "attorney" USING "btree" ("othernames");


--
-- Name: ix_attorney_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_attorney_surname" ON "attorney" USING "btree" ("surname");


--
-- Name: ix_bail_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_defendant" ON "bail" USING "btree" ("defendant");


--
-- Name: ix_bail_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_hearing" ON "bail" USING "btree" ("hearing");


--
-- Name: ix_bail_surety_surety; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_surety" ON "bail_surety" USING "btree" ("surety");


--
-- Name: ix_case_causeofaction_causeofaction; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_causeofaction" ON "case_causeofaction" USING "btree" ("causeofaction");


--
-- Name: ix_case_defendant_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_defendant" ON "case_defendant" USING "btree" ("defendant");


--
-- Name: ix_case_natureofsuit_natureofsuit; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_natureofsuit" ON "case_natureofsuit" USING "btree" ("natureofsuit");


--
-- Name: ix_case_observer_observer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_observer_observer" ON "case_observer" USING "btree" ("observer");


--
-- Name: ix_case_plaintiff_plaintiff; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_plaintiff" ON "case_plaintiff" USING "btree" ("plaintiff");


--
-- Name: ix_case_policeman_2_policeman; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_policeman_2_policeman" ON "case_policeman_2" USING "btree" ("policeman");


--
-- Name: ix_case_policeman_policeman; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_policeman_policeman" ON "case_policeman" USING "btree" ("policeman");


--
-- Name: ix_case_policestation_policestation; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_policestation_policestation" ON "case_policestation" USING "btree" ("policestation");


--
-- Name: ix_case_prosecutor_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_prosecutor" ON "case_prosecutor" USING "btree" ("prosecutor");


--
-- Name: ix_causeofaction_filing_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_filing" ON "causeofaction_filing" USING "btree" ("filing");


--
-- Name: ix_causeofaction_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_hearing" ON "causeofaction_hearing" USING "btree" ("hearing");


--
-- Name: ix_causeofaction_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_causeofaction_name" ON "causeofaction" USING "btree" ("name");


--
-- Name: ix_causeofaction_parent_coa; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_parent_coa" ON "causeofaction" USING "btree" ("parent_coa");


--
-- Name: ix_constituency_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_constituency_name" ON "constituency" USING "btree" ("name");


--
-- Name: ix_constituency_region; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_region" ON "constituency" USING "btree" ("region");


--
-- Name: ix_constituency_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_town" ON "constituency" USING "btree" ("town");


--
-- Name: ix_court_court_level; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_court_level" ON "court" USING "btree" ("court_level");


--
-- Name: ix_court_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_court_name" ON "court" USING "btree" ("name");


--
-- Name: ix_court_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_town" ON "court" USING "btree" ("town");


--
-- Name: ix_courtlevel_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_courtlevel_name" ON "courtlevel" USING "btree" ("name");


--
-- Name: ix_defendant_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_firstname" ON "defendant" USING "btree" ("firstname");


--
-- Name: ix_defendant_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_hearing" ON "defendant_hearing" USING "btree" ("hearing");


--
-- Name: ix_defendant_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_mobile" ON "defendant" USING "btree" ("mobile");


--
-- Name: ix_defendant_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_othernames" ON "defendant" USING "btree" ("othernames");


--
-- Name: ix_defendant_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_surname" ON "defendant" USING "btree" ("surname");


--
-- Name: ix_document_doc_template; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_doc_template" ON "document" USING "btree" ("doc_template");


--
-- Name: ix_document_filing_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_filing_filing" ON "document_filing" USING "btree" ("filing");


--
-- Name: ix_filing_filing_attorney; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filing_attorney" ON "filing" USING "btree" ("filing_attorney");


--
-- Name: ix_filing_filing_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filing_prosecutor" ON "filing" USING "btree" ("filing_prosecutor");


--
-- Name: ix_filing_filingtype_filingtype; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_filingtype" ON "filing_filingtype" USING "btree" ("filingtype");


--
-- Name: ix_filing_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_hearing_hearing" ON "filing_hearing" USING "btree" ("hearing");


--
-- Name: ix_filingtype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_filingtype_name" ON "filingtype" USING "btree" ("name");


--
-- Name: ix_hearing_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_case" ON "hearing" USING "btree" ("case");


--
-- Name: ix_hearing_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_court" ON "hearing" USING "btree" ("court");


--
-- Name: ix_hearing_hearingtype; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_hearingtype" ON "hearing" USING "btree" ("hearingtype");


--
-- Name: ix_hearing_judge_judge; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judge_judge" ON "hearing_judge" USING "btree" ("judge");


--
-- Name: ix_hearing_observer_observer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_observer_observer" ON "hearing_observer" USING "btree" ("observer");


--
-- Name: ix_hearing_policeman_policeman; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_policeman_policeman" ON "hearing_policeman" USING "btree" ("policeman");


--
-- Name: ix_hearing_prosecutor_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_prosecutor" ON "hearing_prosecutor" USING "btree" ("prosecutor");


--
-- Name: ix_hearingtype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_hearingtype_name" ON "hearingtype" USING "btree" ("name");


--
-- Name: ix_investigation_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_case" ON "investigation" USING "btree" ("case");


--
-- Name: ix_investigation_observer_observer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_observer_observer" ON "investigation_observer" USING "btree" ("observer");


--
-- Name: ix_investigation_policeman_policeman; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_policeman_policeman" ON "investigation_policeman" USING "btree" ("policeman");


--
-- Name: ix_judge_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_court" ON "judge" USING "btree" ("court");


--
-- Name: ix_judge_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_firstname" ON "judge" USING "btree" ("firstname");


--
-- Name: ix_judge_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_gender" ON "judge" USING "btree" ("gender");


--
-- Name: ix_judge_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_mobile" ON "judge" USING "btree" ("mobile");


--
-- Name: ix_judge_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_othernames" ON "judge" USING "btree" ("othernames");


--
-- Name: ix_judge_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judge_surname" ON "judge" USING "btree" ("surname");


--
-- Name: ix_lawfirm_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawfirm_mobile" ON "lawfirm" USING "btree" ("mobile");


--
-- Name: ix_lawfirm_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_lawfirm_name" ON "lawfirm" USING "btree" ("name");


--
-- Name: ix_natureofsuit_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_natureofsuit_name" ON "natureofsuit" USING "btree" ("name");


--
-- Name: ix_observer_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_observer_firstname" ON "observer" USING "btree" ("firstname");


--
-- Name: ix_observer_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_observer_gender" ON "observer" USING "btree" ("gender");


--
-- Name: ix_observer_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_observer_mobile" ON "observer" USING "btree" ("mobile");


--
-- Name: ix_observer_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_observer_othernames" ON "observer" USING "btree" ("othernames");


--
-- Name: ix_observer_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_observer_surname" ON "observer" USING "btree" ("surname");


--
-- Name: ix_plaintiff_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_firstname" ON "plaintiff" USING "btree" ("firstname");


--
-- Name: ix_plaintiff_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_gender" ON "plaintiff" USING "btree" ("gender");


--
-- Name: ix_plaintiff_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_mobile" ON "plaintiff" USING "btree" ("mobile");


--
-- Name: ix_plaintiff_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_othernames" ON "plaintiff" USING "btree" ("othernames");


--
-- Name: ix_plaintiff_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_surname" ON "plaintiff" USING "btree" ("surname");


--
-- Name: ix_policeman_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policeman_firstname" ON "policeman" USING "btree" ("firstname");


--
-- Name: ix_policeman_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policeman_gender" ON "policeman" USING "btree" ("gender");


--
-- Name: ix_policeman_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policeman_mobile" ON "policeman" USING "btree" ("mobile");


--
-- Name: ix_policeman_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policeman_othernames" ON "policeman" USING "btree" ("othernames");


--
-- Name: ix_policeman_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policeman_surname" ON "policeman" USING "btree" ("surname");


--
-- Name: ix_policerole_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policerole_name" ON "policerole" USING "btree" ("name");


--
-- Name: ix_policerole_policeman_policeman; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerole_policeman_policeman" ON "policerole_policeman" USING "btree" ("policeman");


--
-- Name: ix_policestation_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_mobile" ON "policestation" USING "btree" ("mobile");


--
-- Name: ix_policestation_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policestation_name" ON "policestation" USING "btree" ("name");


--
-- Name: ix_policestation_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_town" ON "policestation" USING "btree" ("town");


--
-- Name: ix_prison_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_mobile" ON "prison" USING "btree" ("mobile");


--
-- Name: ix_prison_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_prison_name" ON "prison" USING "btree" ("name");


--
-- Name: ix_prison_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_town" ON "prison" USING "btree" ("town");


--
-- Name: ix_prisonremand_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonremand_defendant" ON "prisonremand" USING "btree" ("defendant");


--
-- Name: ix_prisonremand_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonremand_hearing" ON "prisonremand" USING "btree" ("hearing");


--
-- Name: ix_prosecutor_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_firstname" ON "prosecutor" USING "btree" ("firstname");


--
-- Name: ix_prosecutor_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_gender" ON "prosecutor" USING "btree" ("gender");


--
-- Name: ix_prosecutor_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_mobile" ON "prosecutor" USING "btree" ("mobile");


--
-- Name: ix_prosecutor_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_othernames" ON "prosecutor" USING "btree" ("othernames");


--
-- Name: ix_prosecutor_prosecutorteam_prosecutorteam; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_prosecutorteam" ON "prosecutor_prosecutorteam" USING "btree" ("prosecutorteam");


--
-- Name: ix_prosecutor_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_surname" ON "prosecutor" USING "btree" ("surname");


--
-- Name: ix_prosecutorteam_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_prosecutorteam_name" ON "prosecutorteam" USING "btree" ("name");


--
-- Name: ix_region_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_region_name" ON "region" USING "btree" ("name");


--
-- Name: ix_surety_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_firstname" ON "surety" USING "btree" ("firstname");


--
-- Name: ix_surety_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_gender" ON "surety" USING "btree" ("gender");


--
-- Name: ix_surety_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_mobile" ON "surety" USING "btree" ("mobile");


--
-- Name: ix_surety_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_othernames" ON "surety" USING "btree" ("othernames");


--
-- Name: ix_surety_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_surname" ON "surety" USING "btree" ("surname");


--
-- Name: ix_town_district; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_district" ON "town" USING "btree" ("district");


--
-- Name: ix_town_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_town_name" ON "town" USING "btree" ("name");


--
-- Name: Districts Districts_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "Districts"
    ADD CONSTRAINT "Districts_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: Districts Districts_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "Districts"
    ADD CONSTRAINT "Districts_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: Districts Districts_region_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "Districts"
    ADD CONSTRAINT "Districts_region_fkey" FOREIGN KEY ("region") REFERENCES "region"("id");


--
-- Name: ab_permission_view ab_permission_view_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "ab_permission"("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_permission_view_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_permission_view_id_fkey" FOREIGN KEY ("permission_view_id") REFERENCES "ab_permission_view"("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "ab_role"("id");


--
-- Name: ab_permission_view ab_permission_view_view_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_view_menu_id_fkey" FOREIGN KEY ("view_menu_id") REFERENCES "ab_view_menu"("id");


--
-- Name: ab_user ab_user_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: ab_user ab_user_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: ab_user_role ab_user_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "ab_role"("id");


--
-- Name: ab_user_role ab_user_role_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "ab_user"("id");


--
-- Name: attorney attorney_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney"
    ADD CONSTRAINT "attorney_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: attorney attorney_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney"
    ADD CONSTRAINT "attorney_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: attorney attorney_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney"
    ADD CONSTRAINT "attorney_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: attorney_hearing attorney_hearing_attorney_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney_hearing"
    ADD CONSTRAINT "attorney_hearing_attorney_fkey" FOREIGN KEY ("attorney") REFERENCES "attorney"("id");


--
-- Name: attorney_hearing attorney_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney_hearing"
    ADD CONSTRAINT "attorney_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: attorney attorney_law_firm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "attorney"
    ADD CONSTRAINT "attorney_law_firm_fkey" FOREIGN KEY ("law_firm") REFERENCES "lawfirm"("id");


--
-- Name: bail bail_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: bail bail_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: bail bail_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: bail bail_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: bail_surety bail_surety_bail_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_bail_fkey" FOREIGN KEY ("bail") REFERENCES "bail"("id");


--
-- Name: bail_surety bail_surety_surety_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_surety_fkey" FOREIGN KEY ("surety") REFERENCES "surety"("id");


--
-- Name: case_causeofaction case_causeofaction_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_causeofaction case_causeofaction_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: case case_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: case case_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: case_defendant case_defendant_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_defendant case_defendant_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: case_natureofsuit case_natureofsuit_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_natureofsuit case_natureofsuit_natureofsuit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_natureofsuit_fkey" FOREIGN KEY ("natureofsuit") REFERENCES "natureofsuit"("id");


--
-- Name: case_observer case_observer_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_observer"
    ADD CONSTRAINT "case_observer_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_observer case_observer_observer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_observer"
    ADD CONSTRAINT "case_observer_observer_fkey" FOREIGN KEY ("observer") REFERENCES "observer"("id");


--
-- Name: case_plaintiff case_plaintiff_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_plaintiff case_plaintiff_plaintiff_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_plaintiff_fkey" FOREIGN KEY ("plaintiff") REFERENCES "plaintiff"("id");


--
-- Name: case_policeman_2 case_policeman_2_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman_2"
    ADD CONSTRAINT "case_policeman_2_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_policeman_2 case_policeman_2_policeman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman_2"
    ADD CONSTRAINT "case_policeman_2_policeman_fkey" FOREIGN KEY ("policeman") REFERENCES "policeman"("id");


--
-- Name: case_policeman case_policeman_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman"
    ADD CONSTRAINT "case_policeman_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_policeman case_policeman_policeman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policeman"
    ADD CONSTRAINT "case_policeman_policeman_fkey" FOREIGN KEY ("policeman") REFERENCES "policeman"("id");


--
-- Name: case_policestation case_policestation_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policestation"
    ADD CONSTRAINT "case_policestation_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_policestation case_policestation_policestation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_policestation"
    ADD CONSTRAINT "case_policestation_policestation_fkey" FOREIGN KEY ("policestation") REFERENCES "policestation"("id");


--
-- Name: case_prosecutor case_prosecutor_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_prosecutor case_prosecutor_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: causeofaction causeofaction_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: causeofaction causeofaction_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: causeofaction_filing causeofaction_filing_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: causeofaction_filing causeofaction_filing_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: causeofaction_hearing causeofaction_hearing_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: causeofaction_hearing causeofaction_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: causeofaction causeofaction_parent_coa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_parent_coa_fkey" FOREIGN KEY ("parent_coa") REFERENCES "causeofaction"("id");


--
-- Name: constituency constituency_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: constituency constituency_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: constituency constituency_region_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_region_fkey" FOREIGN KEY ("region") REFERENCES "region"("id");


--
-- Name: constituency constituency_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: court court_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: court court_court_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_court_level_fkey" FOREIGN KEY ("court_level") REFERENCES "courtlevel"("id");


--
-- Name: court court_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: court court_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: courtlevel courtlevel_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtlevel courtlevel_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: defendant defendant_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: defendant defendant_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: defendant defendant_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: defendant_hearing defendant_hearing_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: defendant_hearing defendant_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: doctemplate doctemplate_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: doctemplate doctemplate_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_doc_template_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_doc_template_fkey" FOREIGN KEY ("doc_template") REFERENCES "doctemplate"("id");


--
-- Name: document_filing document_filing_document_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_filing"
    ADD CONSTRAINT "document_filing_document_fkey" FOREIGN KEY ("document") REFERENCES "document"("id");


--
-- Name: document_filing document_filing_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_filing"
    ADD CONSTRAINT "document_filing_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: filing filing_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filing filing_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filing filing_filing_attorney_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_filing_attorney_fkey" FOREIGN KEY ("filing_attorney") REFERENCES "attorney"("id");


--
-- Name: filing filing_filing_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_filing_prosecutor_fkey" FOREIGN KEY ("filing_prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: filing_filingtype filing_filingtype_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: filing_filingtype filing_filingtype_filingtype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_filingtype_fkey" FOREIGN KEY ("filingtype") REFERENCES "filingtype"("id");


--
-- Name: filing_hearing filing_hearing_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_hearing"
    ADD CONSTRAINT "filing_hearing_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: filing_hearing filing_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_hearing"
    ADD CONSTRAINT "filing_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: filingtype filingtype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filingtype filingtype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gender gender_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gender gender_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: hearing hearing_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_court_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_court_fkey" FOREIGN KEY ("court") REFERENCES "court"("id");


--
-- Name: hearing hearing_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_hearingtype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_hearingtype_fkey" FOREIGN KEY ("hearingtype") REFERENCES "hearingtype"("id");


--
-- Name: hearing_judge hearing_judge_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judge"
    ADD CONSTRAINT "hearing_judge_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_judge hearing_judge_judge_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judge"
    ADD CONSTRAINT "hearing_judge_judge_fkey" FOREIGN KEY ("judge") REFERENCES "judge"("id");


--
-- Name: hearing_observer hearing_observer_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_observer"
    ADD CONSTRAINT "hearing_observer_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_observer hearing_observer_observer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_observer"
    ADD CONSTRAINT "hearing_observer_observer_fkey" FOREIGN KEY ("observer") REFERENCES "observer"("id");


--
-- Name: hearing_policeman hearing_policeman_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_policeman"
    ADD CONSTRAINT "hearing_policeman_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_policeman hearing_policeman_policeman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_policeman"
    ADD CONSTRAINT "hearing_policeman_policeman_fkey" FOREIGN KEY ("policeman") REFERENCES "policeman"("id");


--
-- Name: hearing_prosecutor hearing_prosecutor_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_prosecutor hearing_prosecutor_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: hearingtype hearingtype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearingtype hearingtype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation investigation_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: investigation investigation_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation investigation_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation_observer investigation_observer_investigation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_observer"
    ADD CONSTRAINT "investigation_observer_investigation_fkey" FOREIGN KEY ("investigation") REFERENCES "investigation"("id");


--
-- Name: investigation_observer investigation_observer_observer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_observer"
    ADD CONSTRAINT "investigation_observer_observer_fkey" FOREIGN KEY ("observer") REFERENCES "observer"("id");


--
-- Name: investigation_policeman investigation_policeman_investigation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_policeman"
    ADD CONSTRAINT "investigation_policeman_investigation_fkey" FOREIGN KEY ("investigation") REFERENCES "investigation"("id");


--
-- Name: investigation_policeman investigation_policeman_policeman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_policeman"
    ADD CONSTRAINT "investigation_policeman_policeman_fkey" FOREIGN KEY ("policeman") REFERENCES "policeman"("id");


--
-- Name: judge judge_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge"
    ADD CONSTRAINT "judge_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: judge judge_court_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge"
    ADD CONSTRAINT "judge_court_fkey" FOREIGN KEY ("court") REFERENCES "court"("id");


--
-- Name: judge judge_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge"
    ADD CONSTRAINT "judge_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: judge judge_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judge"
    ADD CONSTRAINT "judge_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: lawfirm lawfirm_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: lawfirm lawfirm_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: natureofsuit natureofsuit_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: natureofsuit natureofsuit_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: observer observer_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "observer"
    ADD CONSTRAINT "observer_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: observer observer_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "observer"
    ADD CONSTRAINT "observer_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: observer observer_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "observer"
    ADD CONSTRAINT "observer_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: plaintiff plaintiff_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: plaintiff plaintiff_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: plaintiff plaintiff_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: policeman policeman_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policeman"
    ADD CONSTRAINT "policeman_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policeman policeman_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policeman"
    ADD CONSTRAINT "policeman_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policeman policeman_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policeman"
    ADD CONSTRAINT "policeman_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: policerole policerole_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policerole policerole_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policerole_policeman policerole_policeman_policeman_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole_policeman"
    ADD CONSTRAINT "policerole_policeman_policeman_fkey" FOREIGN KEY ("policeman") REFERENCES "policeman"("id");


--
-- Name: policerole_policeman policerole_policeman_policerole_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole_policeman"
    ADD CONSTRAINT "policerole_policeman_policerole_fkey" FOREIGN KEY ("policerole") REFERENCES "policerole"("id");


--
-- Name: policestation policestation_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestation policestation_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestation policestation_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: prison prison_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prison prison_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prison prison_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: prisonremand prisonremand_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisonremand prisonremand_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisonremand prisonremand_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: prisonremand prisonremand_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: prisonremand prisonremand_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonremand"
    ADD CONSTRAINT "prisonremand_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: prosecutor prosecutor_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutor prosecutor_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutor prosecutor_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_prosecutorteam_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_prosecutorteam_fkey" FOREIGN KEY ("prosecutorteam") REFERENCES "prosecutorteam"("id");


--
-- Name: prosecutorteam prosecutorteam_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutorteam prosecutorteam_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: region region_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "region"
    ADD CONSTRAINT "region_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: region region_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "region"
    ADD CONSTRAINT "region_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: town town_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: town town_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: town town_district_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_district_fkey" FOREIGN KEY ("district") REFERENCES "Districts"("id");


--
-- PostgreSQL database dump complete
--

\connect "caseke"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

--
-- Name: doctemplate_search_vector_update(); Type: FUNCTION; Schema: public; Owner: nyimbi
--

CREATE FUNCTION "doctemplate_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
            BEGIN
                NEW.search_vector = to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_text, ''), '[-@.]', ' ', 'g')) || to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_title, ''), '[-@.]', ' ', 'g'));
                RETURN NEW;
            END
            $$;


ALTER FUNCTION "public"."doctemplate_search_vector_update"() OWNER TO "nyimbi";

--
-- Name: doctemplate_version_search_vector_update(); Type: FUNCTION; Schema: public; Owner: nyimbi
--

CREATE FUNCTION "doctemplate_version_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
            BEGIN
                NEW.search_vector = to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_text, ''), '[-@.]', ' ', 'g')) || to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_title, ''), '[-@.]', ' ', 'g'));
                RETURN NEW;
            END
            $$;


ALTER FUNCTION "public"."doctemplate_version_search_vector_update"() OWNER TO "nyimbi";

--
-- Name: document_search_vector_update(); Type: FUNCTION; Schema: public; Owner: nyimbi
--

CREATE FUNCTION "document_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
            BEGIN
                NEW.search_vector = to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_text, ''), '[-@.]', ' ', 'g')) || to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_title, ''), '[-@.]', ' ', 'g'));
                RETURN NEW;
            END
            $$;


ALTER FUNCTION "public"."document_search_vector_update"() OWNER TO "nyimbi";

--
-- Name: document_version_search_vector_update(); Type: FUNCTION; Schema: public; Owner: nyimbi
--

CREATE FUNCTION "document_version_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
            BEGIN
                NEW.search_vector = to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_text, ''), '[-@.]', ' ', 'g')) || to_tsvector('pg_catalog.english', regexp_replace(coalesce(NEW.doc_title, ''), '[-@.]', ' ', 'g'));
                RETURN NEW;
            END
            $$;


ALTER FUNCTION "public"."document_version_search_vector_update"() OWNER TO "nyimbi";

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ab_permission; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL
);


ALTER TABLE "ab_permission" OWNER TO "nyimbi";

--
-- Name: ab_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_permission_view; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission_view" (
    "id" integer NOT NULL,
    "permission_id" integer,
    "view_menu_id" integer
);


ALTER TABLE "ab_permission_view" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_view_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_view_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_permission_view_role" (
    "id" integer NOT NULL,
    "permission_view_id" integer,
    "role_id" integer
);


ALTER TABLE "ab_permission_view_role" OWNER TO "nyimbi";

--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_permission_view_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_permission_view_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_register_user; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_register_user" (
    "id" integer NOT NULL,
    "first_name" character varying(64) NOT NULL,
    "last_name" character varying(64) NOT NULL,
    "username" character varying(64) NOT NULL,
    "password" character varying(256),
    "email" character varying(64) NOT NULL,
    "registration_date" timestamp without time zone,
    "registration_hash" character varying(256)
);


ALTER TABLE "ab_register_user" OWNER TO "nyimbi";

--
-- Name: ab_register_user_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_register_user_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_register_user_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_role" (
    "id" integer NOT NULL,
    "name" character varying(64) NOT NULL
);


ALTER TABLE "ab_role" OWNER TO "nyimbi";

--
-- Name: ab_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_user; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_user" (
    "id" integer NOT NULL,
    "first_name" character varying(64) NOT NULL,
    "last_name" character varying(64) NOT NULL,
    "username" character varying(64) NOT NULL,
    "password" character varying(256),
    "active" boolean,
    "email" character varying(64) NOT NULL,
    "last_login" timestamp without time zone,
    "login_count" integer,
    "fail_login_count" integer,
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "created_by_fk" integer,
    "changed_by_fk" integer
);


ALTER TABLE "ab_user" OWNER TO "nyimbi";

--
-- Name: ab_user_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_user_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_user_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_user_role; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_user_role" (
    "id" integer NOT NULL,
    "user_id" integer,
    "role_id" integer
);


ALTER TABLE "ab_user_role" OWNER TO "nyimbi";

--
-- Name: ab_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_user_role_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_user_role_id_seq" OWNER TO "nyimbi";

--
-- Name: ab_view_menu; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "ab_view_menu" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL
);


ALTER TABLE "ab_view_menu" OWNER TO "nyimbi";

--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "ab_view_menu_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "ab_view_menu_id_seq" OWNER TO "nyimbi";

--
-- Name: bail; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "hearing" integer NOT NULL,
    "defendant" integer NOT NULL,
    "amountgranted" numeric(12,2),
    "noofsureties" integer,
    "paid" boolean,
    "paydate" "date",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "bail" OWNER TO "nyimbi";

--
-- Name: bail_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "bail_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "bail_id_seq" OWNER TO "nyimbi";

--
-- Name: bail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "bail_id_seq" OWNED BY "bail"."id";


--
-- Name: bail_surety; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail_surety" (
    "bail" integer NOT NULL,
    "surety" integer NOT NULL
);


ALTER TABLE "bail_surety" OWNER TO "nyimbi";

--
-- Name: bail_surety_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail_surety_version" (
    "bail" integer NOT NULL,
    "surety" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "bail_surety_version" OWNER TO "nyimbi";

--
-- Name: bail_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "bail_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "hearing" integer,
    "defendant" integer,
    "amountgranted" numeric(12,2),
    "noofsureties" integer,
    "paid" boolean,
    "paydate" "date",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "bail_version" OWNER TO "nyimbi";

--
-- Name: case; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "born_digital" boolean,
    "ob_number" character varying(20) NOT NULL,
    "police_station_reported" integer NOT NULL,
    "report_date" timestamp without time zone,
    "complaint" "text" NOT NULL,
    "is_criminal" boolean,
    "priority" integer,
    "should_investigate_further" boolean,
    "evaluation_conclusion" "text",
    "investigation_assigment_date" timestamp without time zone,
    "investigation_assignment_note" "text",
    "investigation_plan" "text",
    "investigation_summary" "text",
    "investigation_review" "text",
    "investigation_complete" boolean,
    "dpp_advice_requested" boolean,
    "dpp_advice_request_date" "date",
    "dpp_advice_date" "date",
    "dpp_advice" "text",
    "send_to_trial" boolean,
    "case_name" character varying(400),
    "docketnumber" character varying(100),
    "charge_sheet" "text",
    "charge_date" timestamp without time zone,
    "prosecution_notes" "text",
    "defense_notes" "text",
    "judgement" "text",
    "judgement_date" timestamp without time zone,
    "sentence_length_years" integer,
    "sentence_length_months" integer,
    "senetence_length_days" integer,
    "sentence_start_date" "date",
    "sentence_end_date" "date",
    "fine_amount" numeric(12,2),
    "case_appealed" boolean,
    "appeal_date" timestamp without time zone,
    "appeal_granted" boolean,
    "appeal_expiry" "date",
    "case_closed" boolean,
    "close_date" "date",
    "reported_to" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "case" OWNER TO "nyimbi";

--
-- Name: case_casecategory; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_casecategory" (
    "case" integer NOT NULL,
    "casecategory" integer NOT NULL
);


ALTER TABLE "case_casecategory" OWNER TO "nyimbi";

--
-- Name: case_casecategory_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_casecategory_version" (
    "case" integer NOT NULL,
    "casecategory" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_casecategory_version" OWNER TO "nyimbi";

--
-- Name: case_causeofaction; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_causeofaction" (
    "case" integer NOT NULL,
    "causeofaction" integer NOT NULL
);


ALTER TABLE "case_causeofaction" OWNER TO "nyimbi";

--
-- Name: case_causeofaction_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_causeofaction_version" (
    "case" integer NOT NULL,
    "causeofaction" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_causeofaction_version" OWNER TO "nyimbi";

--
-- Name: case_defendant; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_defendant" (
    "case" integer NOT NULL,
    "defendant" integer NOT NULL
);


ALTER TABLE "case_defendant" OWNER TO "nyimbi";

--
-- Name: case_defendant_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_defendant_version" (
    "case" integer NOT NULL,
    "defendant" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_defendant_version" OWNER TO "nyimbi";

--
-- Name: case_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "case_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "case_id_seq" OWNER TO "nyimbi";

--
-- Name: case_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "case_id_seq" OWNED BY "case"."id";


--
-- Name: case_natureofsuit; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_natureofsuit" (
    "case" integer NOT NULL,
    "natureofsuit" integer NOT NULL
);


ALTER TABLE "case_natureofsuit" OWNER TO "nyimbi";

--
-- Name: case_natureofsuit_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_natureofsuit_version" (
    "case" integer NOT NULL,
    "natureofsuit" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_natureofsuit_version" OWNER TO "nyimbi";

--
-- Name: case_plaintiff; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_plaintiff" (
    "case" integer NOT NULL,
    "plaintiff" integer NOT NULL
);


ALTER TABLE "case_plaintiff" OWNER TO "nyimbi";

--
-- Name: case_plaintiff_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_plaintiff_version" (
    "case" integer NOT NULL,
    "plaintiff" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_plaintiff_version" OWNER TO "nyimbi";

--
-- Name: case_polofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_polofficer" (
    "case" integer NOT NULL,
    "polofficer" integer NOT NULL
);


ALTER TABLE "case_polofficer" OWNER TO "nyimbi";

--
-- Name: case_polofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_polofficer_version" (
    "case" integer NOT NULL,
    "polofficer" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_polofficer_version" OWNER TO "nyimbi";

--
-- Name: case_prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_prosecutor" (
    "case" integer NOT NULL,
    "prosecutor" integer NOT NULL
);


ALTER TABLE "case_prosecutor" OWNER TO "nyimbi";

--
-- Name: case_prosecutor_2; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_prosecutor_2" (
    "case" integer NOT NULL,
    "prosecutor" integer NOT NULL
);


ALTER TABLE "case_prosecutor_2" OWNER TO "nyimbi";

--
-- Name: case_prosecutor_2_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_prosecutor_2_version" (
    "case" integer NOT NULL,
    "prosecutor" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_prosecutor_2_version" OWNER TO "nyimbi";

--
-- Name: case_prosecutor_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_prosecutor_version" (
    "case" integer NOT NULL,
    "prosecutor" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_prosecutor_version" OWNER TO "nyimbi";

--
-- Name: case_tag; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_tag" (
    "case" integer NOT NULL,
    "tag" integer NOT NULL
);


ALTER TABLE "case_tag" OWNER TO "nyimbi";

--
-- Name: case_tag_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_tag_version" (
    "case" integer NOT NULL,
    "tag" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_tag_version" OWNER TO "nyimbi";

--
-- Name: case_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "born_digital" boolean,
    "ob_number" character varying(20),
    "police_station_reported" integer,
    "report_date" timestamp without time zone,
    "complaint" "text",
    "is_criminal" boolean,
    "priority" integer,
    "should_investigate_further" boolean,
    "evaluation_conclusion" "text",
    "investigation_assigment_date" timestamp without time zone,
    "investigation_assignment_note" "text",
    "investigation_plan" "text",
    "investigation_summary" "text",
    "investigation_review" "text",
    "investigation_complete" boolean,
    "dpp_advice_requested" boolean,
    "dpp_advice_request_date" "date",
    "dpp_advice_date" "date",
    "dpp_advice" "text",
    "send_to_trial" boolean,
    "case_name" character varying(400),
    "docketnumber" character varying(100),
    "charge_sheet" "text",
    "charge_date" timestamp without time zone,
    "prosecution_notes" "text",
    "defense_notes" "text",
    "judgement" "text",
    "judgement_date" timestamp without time zone,
    "sentence_length_years" integer,
    "sentence_length_months" integer,
    "senetence_length_days" integer,
    "sentence_start_date" "date",
    "sentence_end_date" "date",
    "fine_amount" numeric(12,2),
    "case_appealed" boolean,
    "appeal_date" timestamp without time zone,
    "appeal_granted" boolean,
    "appeal_expiry" "date",
    "case_closed" boolean,
    "close_date" "date",
    "reported_to" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_version" OWNER TO "nyimbi";

--
-- Name: case_witness; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_witness" (
    "case" integer NOT NULL,
    "witness" integer NOT NULL
);


ALTER TABLE "case_witness" OWNER TO "nyimbi";

--
-- Name: case_witness_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "case_witness_version" (
    "case" integer NOT NULL,
    "witness" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "case_witness_version" OWNER TO "nyimbi";

--
-- Name: casecategory; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "casecategory" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "indictable" boolean,
    "is_criminal" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "casecategory" OWNER TO "nyimbi";

--
-- Name: casecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "casecategory_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "casecategory_id_seq" OWNER TO "nyimbi";

--
-- Name: casecategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "casecategory_id_seq" OWNED BY "casecategory"."id";


--
-- Name: casecategory_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "casecategory_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "indictable" boolean,
    "is_criminal" boolean,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "casecategory_version" OWNER TO "nyimbi";

--
-- Name: caseinvestigation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "caseinvestigation" (
    "pol_officers" integer NOT NULL,
    "cases" integer NOT NULL
);


ALTER TABLE "caseinvestigation" OWNER TO "nyimbi";

--
-- Name: caseinvestigation_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "caseinvestigation_version" (
    "pol_officers" integer NOT NULL,
    "cases" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "caseinvestigation_version" OWNER TO "nyimbi";

--
-- Name: causeofaction; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "criminal" boolean NOT NULL,
    "parent_coa" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "causeofaction" OWNER TO "nyimbi";

--
-- Name: causeofaction_filing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_filing" (
    "causeofaction" integer NOT NULL,
    "filing" integer NOT NULL
);


ALTER TABLE "causeofaction_filing" OWNER TO "nyimbi";

--
-- Name: causeofaction_filing_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_filing_version" (
    "causeofaction" integer NOT NULL,
    "filing" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "causeofaction_filing_version" OWNER TO "nyimbi";

--
-- Name: causeofaction_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_hearing" (
    "causeofaction" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "causeofaction_hearing" OWNER TO "nyimbi";

--
-- Name: causeofaction_hearing_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_hearing_version" (
    "causeofaction" integer NOT NULL,
    "hearing" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "causeofaction_hearing_version" OWNER TO "nyimbi";

--
-- Name: causeofaction_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "causeofaction_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "causeofaction_id_seq" OWNER TO "nyimbi";

--
-- Name: causeofaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "causeofaction_id_seq" OWNED BY "causeofaction"."id";


--
-- Name: causeofaction_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "causeofaction_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "criminal" boolean,
    "parent_coa" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "causeofaction_version" OWNER TO "nyimbi";

--
-- Name: commitaltype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "commitaltype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "commitaltype" OWNER TO "nyimbi";

--
-- Name: commitaltype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "commitaltype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "commitaltype_id_seq" OWNER TO "nyimbi";

--
-- Name: commitaltype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "commitaltype_id_seq" OWNED BY "commitaltype"."id";


--
-- Name: commitaltype_prisoncommital; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "commitaltype_prisoncommital" (
    "commitaltype" integer NOT NULL,
    "prisoncommital_prison" integer NOT NULL,
    "prisoncommital_warrantno" character varying(100) NOT NULL
);


ALTER TABLE "commitaltype_prisoncommital" OWNER TO "nyimbi";

--
-- Name: commitaltype_prisoncommital_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "commitaltype_prisoncommital_version" (
    "commitaltype" integer NOT NULL,
    "prisoncommital_prison" integer NOT NULL,
    "prisoncommital_warrantno" character varying(100) NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "commitaltype_prisoncommital_version" OWNER TO "nyimbi";

--
-- Name: commitaltype_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "commitaltype_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "commitaltype_version" OWNER TO "nyimbi";

--
-- Name: constituency; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "constituency" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "county" integer NOT NULL,
    "town" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "constituency" OWNER TO "nyimbi";

--
-- Name: constituency_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "constituency_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "constituency_id_seq" OWNER TO "nyimbi";

--
-- Name: constituency_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "constituency_id_seq" OWNED BY "constituency"."id";


--
-- Name: constituency_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "constituency_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "county" integer,
    "town" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "constituency_version" OWNER TO "nyimbi";

--
-- Name: county; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "county" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "county" OWNER TO "nyimbi";

--
-- Name: county_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "county_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "county_id_seq" OWNER TO "nyimbi";

--
-- Name: county_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "county_id_seq" OWNED BY "county"."id";


--
-- Name: county_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "county_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "county_version" OWNER TO "nyimbi";

--
-- Name: court; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "court" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "court_station" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "court" OWNER TO "nyimbi";

--
-- Name: court_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "court_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "court_id_seq" OWNER TO "nyimbi";

--
-- Name: court_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "court_id_seq" OWNED BY "court"."id";


--
-- Name: court_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "court_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "court_station" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "court_version" OWNER TO "nyimbi";

--
-- Name: courtlevel; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "courtlevel" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "courtlevel" OWNER TO "nyimbi";

--
-- Name: courtlevel_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "courtlevel_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "courtlevel_id_seq" OWNER TO "nyimbi";

--
-- Name: courtlevel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "courtlevel_id_seq" OWNED BY "courtlevel"."id";


--
-- Name: courtlevel_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "courtlevel_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "courtlevel_version" OWNER TO "nyimbi";

--
-- Name: courtstation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "courtstation" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "residentmagistrate" character varying(100),
    "registrar" character varying(100) NOT NULL,
    "court_level" integer NOT NULL,
    "num_of_courts" integer,
    "town" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "courtstation" OWNER TO "nyimbi";

--
-- Name: courtstation_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "courtstation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "courtstation_id_seq" OWNER TO "nyimbi";

--
-- Name: courtstation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "courtstation_id_seq" OWNED BY "courtstation"."id";


--
-- Name: courtstation_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "courtstation_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "residentmagistrate" character varying(100),
    "registrar" character varying(100),
    "court_level" integer,
    "num_of_courts" integer,
    "town" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "courtstation_version" OWNER TO "nyimbi";

--
-- Name: defendant; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "allergies" "text",
    "chronic_conditions" "text",
    "chronic_medications" "text",
    "hbp" boolean,
    "diabetes" boolean,
    "hiv" boolean,
    "current_health_status" "text",
    "bc_id" character varying(20),
    "bc_number" character varying(20),
    "bc_serial" character varying(20),
    "bc_place" character varying(20),
    "bc_scan" "text",
    "citizenship" character varying(20),
    "nat_id_num" character varying(15),
    "nat_id_serial" character varying(30),
    "nat_id_scan" "text",
    "pp_no" character varying(20),
    "pp_issue_date" "date",
    "pp_issue_place" character varying(40),
    "pp_scan" "text",
    "pp_expiry_date" "date",
    "kin1_name" character varying(100),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(100),
    "kin1_relation" character varying(100),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "blood_group" character varying(3),
    "striking_features" "text",
    "height_m" double precision,
    "weight_kg" double precision,
    "eye_colour" character varying(20),
    "hair_colour" character varying(20),
    "complexion" character varying(50),
    "religion" character varying(20),
    "ethnicity" character varying(40),
    "fp_lthumb" "text",
    "pgm" "bytea",
    "wsq" "bytea",
    "xyt" "bytea",
    "fp_left2" "text",
    "fp_left3" "text",
    "fp_left4" "text",
    "fp_left5" "text",
    "fp_rthumb" "text",
    "fp_right2" "text",
    "fp_right3" "text",
    "fp_right4" "text",
    "fp_right5" "text",
    "palm_left" "text",
    "palm_right" "text",
    "eye_left" "text",
    "eye_right" "text",
    "employed" boolean,
    "employer" character varying(60),
    "employer_contact" "text",
    "employ_date" "date",
    "employ_duration" integer,
    "termination_date" "date",
    "employ_role" character varying(50),
    "supervisor" character varying(50),
    "supervisor_contact" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "juvenile" boolean,
    "gender" integer NOT NULL,
    "prisoncell" integer,
    "casecount" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "defendant" OWNER TO "nyimbi";

--
-- Name: defendant_gateregister; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_gateregister" (
    "defendant" integer NOT NULL,
    "gateregister" integer NOT NULL
);


ALTER TABLE "defendant_gateregister" OWNER TO "nyimbi";

--
-- Name: defendant_gateregister_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_gateregister_version" (
    "defendant" integer NOT NULL,
    "gateregister" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "defendant_gateregister_version" OWNER TO "nyimbi";

--
-- Name: defendant_hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_hearing" (
    "defendant" integer NOT NULL,
    "hearing" integer NOT NULL
);


ALTER TABLE "defendant_hearing" OWNER TO "nyimbi";

--
-- Name: defendant_hearing_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_hearing_version" (
    "defendant" integer NOT NULL,
    "hearing" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "defendant_hearing_version" OWNER TO "nyimbi";

--
-- Name: defendant_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "defendant_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "defendant_id_seq" OWNER TO "nyimbi";

--
-- Name: defendant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "defendant_id_seq" OWNED BY "defendant"."id";


--
-- Name: defendant_medevent; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_medevent" (
    "defendant" integer NOT NULL,
    "medevent" integer NOT NULL
);


ALTER TABLE "defendant_medevent" OWNER TO "nyimbi";

--
-- Name: defendant_medevent_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_medevent_version" (
    "defendant" integer NOT NULL,
    "medevent" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "defendant_medevent_version" OWNER TO "nyimbi";

--
-- Name: defendant_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "defendant_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "allergies" "text",
    "chronic_conditions" "text",
    "chronic_medications" "text",
    "hbp" boolean,
    "diabetes" boolean,
    "hiv" boolean,
    "current_health_status" "text",
    "bc_id" character varying(20),
    "bc_number" character varying(20),
    "bc_serial" character varying(20),
    "bc_place" character varying(20),
    "bc_scan" "text",
    "citizenship" character varying(20),
    "nat_id_num" character varying(15),
    "nat_id_serial" character varying(30),
    "nat_id_scan" "text",
    "pp_no" character varying(20),
    "pp_issue_date" "date",
    "pp_issue_place" character varying(40),
    "pp_scan" "text",
    "pp_expiry_date" "date",
    "kin1_name" character varying(100),
    "kin1_phone" character varying(50),
    "kin1_email" character varying(125),
    "kin1_addr" "text",
    "kin2_name" character varying(100),
    "kin1_relation" character varying(100),
    "kin2_phone" character varying(50),
    "kin2_email" character varying(125),
    "kin2_addr" "text",
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "blood_group" character varying(3),
    "striking_features" "text",
    "height_m" double precision,
    "weight_kg" double precision,
    "eye_colour" character varying(20),
    "hair_colour" character varying(20),
    "complexion" character varying(50),
    "religion" character varying(20),
    "ethnicity" character varying(40),
    "fp_lthumb" "text",
    "pgm" "bytea",
    "wsq" "bytea",
    "xyt" "bytea",
    "fp_left2" "text",
    "fp_left3" "text",
    "fp_left4" "text",
    "fp_left5" "text",
    "fp_rthumb" "text",
    "fp_right2" "text",
    "fp_right3" "text",
    "fp_right4" "text",
    "fp_right5" "text",
    "palm_left" "text",
    "palm_right" "text",
    "eye_left" "text",
    "eye_right" "text",
    "employed" boolean,
    "employer" character varying(60),
    "employer_contact" "text",
    "employ_date" "date",
    "employ_duration" integer,
    "termination_date" "date",
    "employ_role" character varying(50),
    "supervisor" character varying(50),
    "supervisor_contact" "text",
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "juvenile" boolean,
    "gender" integer,
    "prisoncell" integer,
    "casecount" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "defendant_version" OWNER TO "nyimbi";

--
-- Name: discipline; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "discipline" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "defendant" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "discipline" OWNER TO "nyimbi";

--
-- Name: discipline_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "discipline_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "discipline_id_seq" OWNER TO "nyimbi";

--
-- Name: discipline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "discipline_id_seq" OWNED BY "discipline"."id";


--
-- Name: discipline_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "discipline_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "defendant" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "discipline_version" OWNER TO "nyimbi";

--
-- Name: doc_store; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "doc_store" (
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "data" "bytea"
);


ALTER TABLE "doc_store" OWNER TO "nyimbi";

--
-- Name: doc_store_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "doc_store_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "doc_store_id_seq" OWNER TO "nyimbi";

--
-- Name: doc_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "doc_store_id_seq" OWNED BY "doc_store"."id";


--
-- Name: docarchive; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "docarchive" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "name" "text",
    "doc" "text",
    "scandate" timestamp without time zone,
    "archival" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "docarchive" OWNER TO "nyimbi";

--
-- Name: docarchive_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "docarchive_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "docarchive_id_seq" OWNER TO "nyimbi";

--
-- Name: docarchive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "docarchive_id_seq" OWNED BY "docarchive"."id";


--
-- Name: docarchive_tag; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "docarchive_tag" (
    "docarchive" integer NOT NULL,
    "tag" integer NOT NULL
);


ALTER TABLE "docarchive_tag" OWNER TO "nyimbi";

--
-- Name: docarchive_tag_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "docarchive_tag_version" (
    "docarchive" integer NOT NULL,
    "tag" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "docarchive_tag_version" OWNER TO "nyimbi";

--
-- Name: docarchive_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "docarchive_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "name" "text",
    "doc" "text",
    "scandate" timestamp without time zone,
    "archival" boolean,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "docarchive_version" OWNER TO "nyimbi";

--
-- Name: doctemplate; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "doctemplate" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doc_title" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "hashx" character varying(40),
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "search_vector" "tsvector",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "doctemplate" OWNER TO "nyimbi";

--
-- Name: doctemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "doctemplate_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "doctemplate_id_seq" OWNER TO "nyimbi";

--
-- Name: doctemplate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "doctemplate_id_seq" OWNED BY "doctemplate"."id";


--
-- Name: doctemplate_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "doctemplate_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doc_title" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "hashx" character varying(40),
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "search_vector" "tsvector",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "doctemplate_version" OWNER TO "nyimbi";

--
-- Name: document; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doc_title" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "hashx" character varying(40),
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "search_vector" "tsvector",
    "id" integer NOT NULL,
    "filing" integer NOT NULL,
    "doc_template" integer,
    "confidential" boolean,
    "pagecount" integer,
    "locked" boolean,
    "hash" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "document" OWNER TO "nyimbi";

--
-- Name: document_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "document_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "document_id_seq" OWNER TO "nyimbi";

--
-- Name: document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "document_id_seq" OWNED BY "document"."id";


--
-- Name: document_tag; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document_tag" (
    "document" integer NOT NULL,
    "tag" integer NOT NULL
);


ALTER TABLE "document_tag" OWNER TO "nyimbi";

--
-- Name: document_tag_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document_tag_version" (
    "document" integer NOT NULL,
    "tag" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "document_tag_version" OWNER TO "nyimbi";

--
-- Name: document_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "document_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "mime_type" character varying(60),
    "doc" "text",
    "doc_text" "text",
    "doc_binary" "text",
    "doc_title" character varying(200),
    "subject" character varying(100),
    "author" character varying(100),
    "keywords" character varying(200),
    "comments" "text",
    "doc_type" character varying(5),
    "char_count" integer,
    "word_count" integer,
    "lines" integer,
    "paragraphs" integer,
    "file_size_bytes" integer,
    "producer_prog" character varying(40),
    "immutable" boolean,
    "page_size" character varying(40),
    "page_count" integer,
    "hashx" character varying(40),
    "audio_duration_secs" integer,
    "audio_frame_rate" integer,
    "audio_channels" integer,
    "search_vector" "tsvector",
    "id" integer NOT NULL,
    "filing" integer,
    "doc_template" integer,
    "confidential" boolean,
    "pagecount" integer,
    "locked" boolean,
    "hash" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "document_version" OWNER TO "nyimbi";

--
-- Name: eventlog; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "eventlog" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "temporal" timestamp without time zone,
    "event" "text",
    "severity" integer,
    "alert" boolean,
    "notes" "text",
    "tbl" "text",
    "colname" "text",
    "colbefore" "text",
    "colafter" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "eventlog" OWNER TO "nyimbi";

--
-- Name: eventlog_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "eventlog_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "eventlog_id_seq" OWNER TO "nyimbi";

--
-- Name: eventlog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "eventlog_id_seq" OWNED BY "eventlog"."id";


--
-- Name: eventlog_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "eventlog_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "temporal" timestamp without time zone,
    "event" "text",
    "severity" integer,
    "alert" boolean,
    "notes" "text",
    "tbl" "text",
    "colname" "text",
    "colbefore" "text",
    "colafter" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "eventlog_version" OWNER TO "nyimbi";

--
-- Name: filing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "uploaddate" timestamp without time zone,
    "pagecount" integer,
    "totalfees" numeric(12,2),
    "filing_attorney" integer NOT NULL,
    "filing_prosecutor" integer NOT NULL,
    "assessedfees" numeric(12,2),
    "receiptverified" boolean,
    "amountpaid" numeric(12,2),
    "feebalance" numeric(12,2),
    "paymenthistory" "text" NOT NULL,
    "case" integer NOT NULL,
    "urgent" boolean,
    "urgentreason" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "filing" OWNER TO "nyimbi";

--
-- Name: filing_filingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_filingtype" (
    "filing" integer NOT NULL,
    "filingtype" integer NOT NULL
);


ALTER TABLE "filing_filingtype" OWNER TO "nyimbi";

--
-- Name: filing_filingtype_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_filingtype_version" (
    "filing" integer NOT NULL,
    "filingtype" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "filing_filingtype_version" OWNER TO "nyimbi";

--
-- Name: filing_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "filing_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "filing_id_seq" OWNER TO "nyimbi";

--
-- Name: filing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "filing_id_seq" OWNED BY "filing"."id";


--
-- Name: filing_payment; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_payment" (
    "filing" integer NOT NULL,
    "payment" integer NOT NULL
);


ALTER TABLE "filing_payment" OWNER TO "nyimbi";

--
-- Name: filing_payment_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_payment_version" (
    "filing" integer NOT NULL,
    "payment" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "filing_payment_version" OWNER TO "nyimbi";

--
-- Name: filing_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filing_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "uploaddate" timestamp without time zone,
    "pagecount" integer,
    "totalfees" numeric(12,2),
    "filing_attorney" integer,
    "filing_prosecutor" integer,
    "assessedfees" numeric(12,2),
    "receiptverified" boolean,
    "amountpaid" numeric(12,2),
    "feebalance" numeric(12,2),
    "paymenthistory" "text",
    "case" integer,
    "urgent" boolean,
    "urgentreason" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "filing_version" OWNER TO "nyimbi";

--
-- Name: filingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filingtype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "fees" numeric(12,2),
    "perpagecost" numeric(12,2),
    "paid_per_page" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "filingtype" OWNER TO "nyimbi";

--
-- Name: filingtype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "filingtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "filingtype_id_seq" OWNER TO "nyimbi";

--
-- Name: filingtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "filingtype_id_seq" OWNED BY "filingtype"."id";


--
-- Name: filingtype_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "filingtype_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "fees" numeric(12,2),
    "perpagecost" numeric(12,2),
    "paid_per_page" boolean,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "filingtype_version" OWNER TO "nyimbi";

--
-- Name: gateregister; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "prison" integer NOT NULL,
    "opentime" timestamp without time zone,
    "closedtime" timestamp without time zone,
    "openduration" interval,
    "movementdirection" boolean,
    "reason" "text",
    "staffmovement" boolean,
    "goodsmovement" "text" NOT NULL,
    "vehicle_reg" "text",
    "vehicle_color" "text" NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "gateregister" OWNER TO "nyimbi";

--
-- Name: gateregister_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "gateregister_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "gateregister_id_seq" OWNER TO "nyimbi";

--
-- Name: gateregister_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "gateregister_id_seq" OWNED BY "gateregister"."id";


--
-- Name: gateregister_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "prison" integer,
    "opentime" timestamp without time zone,
    "closedtime" timestamp without time zone,
    "openduration" interval,
    "movementdirection" boolean,
    "reason" "text",
    "staffmovement" boolean,
    "goodsmovement" "text",
    "vehicle_reg" "text",
    "vehicle_color" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "gateregister_version" OWNER TO "nyimbi";

--
-- Name: gateregister_warder; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister_warder" (
    "gateregister" integer NOT NULL,
    "warder" integer NOT NULL
);


ALTER TABLE "gateregister_warder" OWNER TO "nyimbi";

--
-- Name: gateregister_warder_2; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister_warder_2" (
    "gateregister" integer NOT NULL,
    "warder" integer NOT NULL
);


ALTER TABLE "gateregister_warder_2" OWNER TO "nyimbi";

--
-- Name: gateregister_warder_2_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister_warder_2_version" (
    "gateregister" integer NOT NULL,
    "warder" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "gateregister_warder_2_version" OWNER TO "nyimbi";

--
-- Name: gateregister_warder_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gateregister_warder_version" (
    "gateregister" integer NOT NULL,
    "warder" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "gateregister_warder_version" OWNER TO "nyimbi";

--
-- Name: gender; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gender" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "name" character varying(20) NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "gender" OWNER TO "nyimbi";

--
-- Name: gender_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "gender_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "gender_id_seq" OWNER TO "nyimbi";

--
-- Name: gender_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "gender_id_seq" OWNED BY "gender"."id";


--
-- Name: gender_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "gender_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "name" character varying(20),
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "gender_version" OWNER TO "nyimbi";

--
-- Name: hearing; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "hearingdate" timestamp without time zone NOT NULL,
    "adjourned" boolean,
    "completed" boolean,
    "case" integer NOT NULL,
    "court" integer NOT NULL,
    "remandwarrant" "text",
    "hearing_type" integer NOT NULL,
    "remanddays" integer,
    "remanddate" "date",
    "remandwarrantexpirydate" "date",
    "nexthearingdate" "date",
    "finalhearing" boolean NOT NULL,
    "transcript" "text",
    "audio" "text",
    "video" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "hearing" OWNER TO "nyimbi";

--
-- Name: hearing_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "hearing_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "hearing_id_seq" OWNER TO "nyimbi";

--
-- Name: hearing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "hearing_id_seq" OWNED BY "hearing"."id";


--
-- Name: hearing_judicialofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_judicialofficer" (
    "hearing" integer NOT NULL,
    "judicialofficer" integer NOT NULL
);


ALTER TABLE "hearing_judicialofficer" OWNER TO "nyimbi";

--
-- Name: hearing_judicialofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_judicialofficer_version" (
    "hearing" integer NOT NULL,
    "judicialofficer" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_judicialofficer_version" OWNER TO "nyimbi";

--
-- Name: hearing_lawyers; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_lawyers" (
    "hearing" integer NOT NULL,
    "lawyers" integer NOT NULL
);


ALTER TABLE "hearing_lawyers" OWNER TO "nyimbi";

--
-- Name: hearing_lawyers_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_lawyers_version" (
    "hearing" integer NOT NULL,
    "lawyers" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_lawyers_version" OWNER TO "nyimbi";

--
-- Name: hearing_polofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_polofficer" (
    "hearing" integer NOT NULL,
    "polofficer" integer NOT NULL
);


ALTER TABLE "hearing_polofficer" OWNER TO "nyimbi";

--
-- Name: hearing_polofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_polofficer_version" (
    "hearing" integer NOT NULL,
    "polofficer" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_polofficer_version" OWNER TO "nyimbi";

--
-- Name: hearing_prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_prosecutor" (
    "hearing" integer NOT NULL,
    "prosecutor" integer NOT NULL
);


ALTER TABLE "hearing_prosecutor" OWNER TO "nyimbi";

--
-- Name: hearing_prosecutor_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_prosecutor_version" (
    "hearing" integer NOT NULL,
    "prosecutor" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_prosecutor_version" OWNER TO "nyimbi";

--
-- Name: hearing_tag; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_tag" (
    "hearing" integer NOT NULL,
    "tag" integer NOT NULL
);


ALTER TABLE "hearing_tag" OWNER TO "nyimbi";

--
-- Name: hearing_tag_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_tag_version" (
    "hearing" integer NOT NULL,
    "tag" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_tag_version" OWNER TO "nyimbi";

--
-- Name: hearing_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "hearingdate" timestamp without time zone,
    "adjourned" boolean,
    "completed" boolean,
    "case" integer,
    "court" integer,
    "remandwarrant" "text",
    "hearing_type" integer,
    "remanddays" integer,
    "remanddate" "date",
    "remandwarrantexpirydate" "date",
    "nexthearingdate" "date",
    "finalhearing" boolean,
    "transcript" "text",
    "audio" "text",
    "video" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_version" OWNER TO "nyimbi";

--
-- Name: hearing_witness; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_witness" (
    "hearing" integer NOT NULL,
    "witness" integer NOT NULL
);


ALTER TABLE "hearing_witness" OWNER TO "nyimbi";

--
-- Name: hearing_witness_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearing_witness_version" (
    "hearing" integer NOT NULL,
    "witness" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearing_witness_version" OWNER TO "nyimbi";

--
-- Name: hearingtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearingtype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "hearingtype" OWNER TO "nyimbi";

--
-- Name: hearingtype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "hearingtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "hearingtype_id_seq" OWNER TO "nyimbi";

--
-- Name: hearingtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "hearingtype_id_seq" OWNED BY "hearingtype"."id";


--
-- Name: hearingtype_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "hearingtype_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "hearingtype_version" OWNER TO "nyimbi";

--
-- Name: investigation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "case" integer NOT NULL,
    "actiondate" timestamp without time zone,
    "evidence" "text" NOT NULL,
    "narrative" "text" NOT NULL,
    "weather" "text" NOT NULL,
    "location" "text" NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "investigation" OWNER TO "nyimbi";

--
-- Name: investigation_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "investigation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "investigation_id_seq" OWNER TO "nyimbi";

--
-- Name: investigation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "investigation_id_seq" OWNED BY "investigation"."id";


--
-- Name: investigation_polofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_polofficer" (
    "investigation" integer NOT NULL,
    "polofficer" integer NOT NULL
);


ALTER TABLE "investigation_polofficer" OWNER TO "nyimbi";

--
-- Name: investigation_polofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_polofficer_version" (
    "investigation" integer NOT NULL,
    "polofficer" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "investigation_polofficer_version" OWNER TO "nyimbi";

--
-- Name: investigation_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "case" integer,
    "actiondate" timestamp without time zone,
    "evidence" "text",
    "narrative" "text",
    "weather" "text",
    "location" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "investigation_version" OWNER TO "nyimbi";

--
-- Name: investigation_witness; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_witness" (
    "investigation" integer NOT NULL,
    "witness" integer NOT NULL
);


ALTER TABLE "investigation_witness" OWNER TO "nyimbi";

--
-- Name: investigation_witness_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "investigation_witness_version" (
    "investigation" integer NOT NULL,
    "witness" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "investigation_witness_version" OWNER TO "nyimbi";

--
-- Name: jo_rank; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "jo_rank" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "appelation" "text" NOT NULL,
    "informaladdress" "text" NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "jo_rank" OWNER TO "nyimbi";

--
-- Name: jo_rank_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "jo_rank_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "jo_rank_id_seq" OWNER TO "nyimbi";

--
-- Name: jo_rank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "jo_rank_id_seq" OWNED BY "jo_rank"."id";


--
-- Name: jo_rank_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "jo_rank_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "appelation" "text",
    "informaladdress" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "jo_rank_version" OWNER TO "nyimbi";

--
-- Name: judicialofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "judicialofficer" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "j_o__rank" integer NOT NULL,
    "gender" integer,
    "court" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "judicialofficer" OWNER TO "nyimbi";

--
-- Name: judicialofficer_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "judicialofficer_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "judicialofficer_id_seq" OWNER TO "nyimbi";

--
-- Name: judicialofficer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "judicialofficer_id_seq" OWNED BY "judicialofficer"."id";


--
-- Name: judicialofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "judicialofficer_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "j_o__rank" integer,
    "gender" integer,
    "court" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "judicialofficer_version" OWNER TO "nyimbi";

--
-- Name: lawfirm; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "lawfirm" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "lawfirm" OWNER TO "nyimbi";

--
-- Name: lawfirm_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "lawfirm_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "lawfirm_id_seq" OWNER TO "nyimbi";

--
-- Name: lawfirm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "lawfirm_id_seq" OWNED BY "lawfirm"."id";


--
-- Name: lawfirm_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "lawfirm_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "lawfirm_version" OWNER TO "nyimbi";

--
-- Name: lawyers; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "lawyers" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "barnumber" character varying(20),
    "law_firm" integer,
    "admissiondate" "date",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "lawyers" OWNER TO "nyimbi";

--
-- Name: lawyers_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "lawyers_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "lawyers_id_seq" OWNER TO "nyimbi";

--
-- Name: lawyers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "lawyers_id_seq" OWNED BY "lawyers"."id";


--
-- Name: lawyers_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "lawyers_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "barnumber" character varying(20),
    "law_firm" integer,
    "admissiondate" "date",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "lawyers_version" OWNER TO "nyimbi";

--
-- Name: medevent; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "medevent" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "medevent" OWNER TO "nyimbi";

--
-- Name: medevent_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "medevent_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "medevent_id_seq" OWNER TO "nyimbi";

--
-- Name: medevent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "medevent_id_seq" OWNED BY "medevent"."id";


--
-- Name: medevent_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "medevent_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "medevent_version" OWNER TO "nyimbi";

--
-- Name: natureofsuit; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "natureofsuit" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "natureofsuit" OWNER TO "nyimbi";

--
-- Name: natureofsuit_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "natureofsuit_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "natureofsuit_id_seq" OWNER TO "nyimbi";

--
-- Name: natureofsuit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "natureofsuit_id_seq" OWNED BY "natureofsuit"."id";


--
-- Name: natureofsuit_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "natureofsuit_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "natureofsuit_version" OWNER TO "nyimbi";

--
-- Name: payment; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "payment" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "datepaid" timestamp without time zone,
    "amount" numeric(12,2),
    "paymentreference" character varying(80) NOT NULL,
    "paymentconfirmed" boolean,
    "paidby" "text" NOT NULL,
    "msisdn" "text",
    "receiptnumber" character varying(100) NOT NULL,
    "ispartial" boolean,
    "bail" integer NOT NULL,
    "billrefnumber" "text" NOT NULL,
    "payment_method" integer NOT NULL,
    "paymentdescription" "text" NOT NULL,
    "case" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "payment" OWNER TO "nyimbi";

--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "payment_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "payment_id_seq" OWNER TO "nyimbi";

--
-- Name: payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "payment_id_seq" OWNED BY "payment"."id";


--
-- Name: payment_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "payment_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "datepaid" timestamp without time zone,
    "amount" numeric(12,2),
    "paymentreference" character varying(80),
    "paymentconfirmed" boolean,
    "paidby" "text",
    "msisdn" "text",
    "receiptnumber" character varying(100),
    "ispartial" boolean,
    "bail" integer,
    "billrefnumber" "text",
    "payment_method" integer,
    "paymentdescription" "text",
    "case" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "payment_version" OWNER TO "nyimbi";

--
-- Name: paymentmethod; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "paymentmethod" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "key" "text" NOT NULL,
    "secret" "text" NOT NULL,
    "portal" "text" NOT NULL,
    "tillnumber" "text" NOT NULL,
    "shortcode" "text" NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "paymentmethod" OWNER TO "nyimbi";

--
-- Name: paymentmethod_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "paymentmethod_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "paymentmethod_id_seq" OWNER TO "nyimbi";

--
-- Name: paymentmethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "paymentmethod_id_seq" OWNED BY "paymentmethod"."id";


--
-- Name: paymentmethod_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "paymentmethod_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "key" "text",
    "secret" "text",
    "portal" "text",
    "tillnumber" "text",
    "shortcode" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "paymentmethod_version" OWNER TO "nyimbi";

--
-- Name: plaintiff; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "plaintiff" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "juvenile" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "plaintiff" OWNER TO "nyimbi";

--
-- Name: plaintiff_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "plaintiff_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "plaintiff_id_seq" OWNER TO "nyimbi";

--
-- Name: plaintiff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "plaintiff_id_seq" OWNED BY "plaintiff"."id";


--
-- Name: plaintiff_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "plaintiff_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "juvenile" boolean,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "plaintiff_version" OWNER TO "nyimbi";

--
-- Name: policerank; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerank" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policerank" OWNER TO "nyimbi";

--
-- Name: policerank_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policerank_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policerank_id_seq" OWNER TO "nyimbi";

--
-- Name: policerank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policerank_id_seq" OWNED BY "policerank"."id";


--
-- Name: policerank_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerank_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "policerank_version" OWNER TO "nyimbi";

--
-- Name: policerole; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerole" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policerole" OWNER TO "nyimbi";

--
-- Name: policerole_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policerole_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policerole_id_seq" OWNER TO "nyimbi";

--
-- Name: policerole_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policerole_id_seq" OWNED BY "policerole"."id";


--
-- Name: policerole_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policerole_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "policerole_version" OWNER TO "nyimbi";

--
-- Name: policestation; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policestation" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "town" integer NOT NULL,
    "has_forensic_lab" boolean,
    "officercommanding" character varying(100),
    "police_station_type" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policestation" OWNER TO "nyimbi";

--
-- Name: policestation_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policestation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policestation_id_seq" OWNER TO "nyimbi";

--
-- Name: policestation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policestation_id_seq" OWNED BY "policestation"."id";


--
-- Name: policestation_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policestation_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "town" integer,
    "has_forensic_lab" boolean,
    "officercommanding" character varying(100),
    "police_station_type" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "policestation_version" OWNER TO "nyimbi";

--
-- Name: policestationtype; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policestationtype" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "policestationtype" OWNER TO "nyimbi";

--
-- Name: policestationtype_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "policestationtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "policestationtype_id_seq" OWNER TO "nyimbi";

--
-- Name: policestationtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "policestationtype_id_seq" OWNED BY "policestationtype"."id";


--
-- Name: policestationtype_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "policestationtype_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "policestationtype_version" OWNER TO "nyimbi";

--
-- Name: polofficer; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "polofficer" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "police_rank" integer NOT NULL,
    "gender" integer NOT NULL,
    "servicenumber" "text",
    "reports_to" integer,
    "pol_supervisor" integer NOT NULL,
    "postdate" "date",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "polofficer" OWNER TO "nyimbi";

--
-- Name: polofficer_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "polofficer_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "polofficer_id_seq" OWNER TO "nyimbi";

--
-- Name: polofficer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "polofficer_id_seq" OWNED BY "polofficer"."id";


--
-- Name: polofficer_policerole; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "polofficer_policerole" (
    "polofficer" integer NOT NULL,
    "policerole" integer NOT NULL
);


ALTER TABLE "polofficer_policerole" OWNER TO "nyimbi";

--
-- Name: polofficer_policerole_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "polofficer_policerole_version" (
    "polofficer" integer NOT NULL,
    "policerole" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "polofficer_policerole_version" OWNER TO "nyimbi";

--
-- Name: polofficer_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "polofficer_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "police_rank" integer,
    "gender" integer,
    "servicenumber" "text",
    "reports_to" integer,
    "pol_supervisor" integer,
    "postdate" "date",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "polofficer_version" OWNER TO "nyimbi";

--
-- Name: prison; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prison" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "town" integer NOT NULL,
    "warden" character varying(100),
    "capacity" integer,
    "population" integer,
    "cellcount" integer,
    "gatecount" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prison" OWNER TO "nyimbi";

--
-- Name: prison_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prison_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prison_id_seq" OWNER TO "nyimbi";

--
-- Name: prison_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prison_id_seq" OWNED BY "prison"."id";


--
-- Name: prison_securityrank; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prison_securityrank" (
    "prison" integer NOT NULL,
    "securityrank" integer NOT NULL
);


ALTER TABLE "prison_securityrank" OWNER TO "nyimbi";

--
-- Name: prison_securityrank_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prison_securityrank_version" (
    "prison" integer NOT NULL,
    "securityrank" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prison_securityrank_version" OWNER TO "nyimbi";

--
-- Name: prison_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prison_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "place_name" character varying(40),
    "lat" double precision,
    "lng" double precision,
    "alt" double precision,
    "map" "text",
    "info" "text",
    "pin" boolean,
    "pin_color" character varying(20),
    "pin_icon" character varying(50),
    "centered" boolean,
    "nearest_feature" character varying(100),
    "id" integer NOT NULL,
    "town" integer,
    "warden" character varying(100),
    "capacity" integer,
    "population" integer,
    "cellcount" integer,
    "gatecount" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prison_version" OWNER TO "nyimbi";

--
-- Name: prisoncell; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncell" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "prison" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prisoncell" OWNER TO "nyimbi";

--
-- Name: prisoncell_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prisoncell_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prisoncell_id_seq" OWNER TO "nyimbi";

--
-- Name: prisoncell_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prisoncell_id_seq" OWNED BY "prisoncell"."id";


--
-- Name: prisoncell_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncell_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "prison" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prisoncell_version" OWNER TO "nyimbi";

--
-- Name: prisoncommital; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncommital" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "prison" integer NOT NULL,
    "warrantno" character varying(100) NOT NULL,
    "defendant" integer NOT NULL,
    "hearing" integer NOT NULL,
    "warrantdate" timestamp without time zone,
    "hascourtdate" boolean,
    "judicial_officer_warrant" integer NOT NULL,
    "warrant" "text" NOT NULL,
    "warrantduration" integer NOT NULL,
    "warrantexpiry" timestamp without time zone,
    "history" "text" NOT NULL,
    "earliestrelease" "date",
    "releasedate" timestamp without time zone,
    "property" "text",
    "itemcount" integer,
    "releasenotes" "text",
    "commitalnotes" "text",
    "police_officer_commiting" integer NOT NULL,
    "paroledate" "date",
    "escaped" boolean,
    "escapedate" timestamp without time zone,
    "escapedetails" "text",
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prisoncommital" OWNER TO "nyimbi";

--
-- Name: prisoncommital_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncommital_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "prison" integer NOT NULL,
    "warrantno" character varying(100) NOT NULL,
    "defendant" integer,
    "hearing" integer,
    "warrantdate" timestamp without time zone,
    "hascourtdate" boolean,
    "judicial_officer_warrant" integer,
    "warrant" "text",
    "warrantduration" integer,
    "warrantexpiry" timestamp without time zone,
    "history" "text",
    "earliestrelease" "date",
    "releasedate" timestamp without time zone,
    "property" "text",
    "itemcount" integer,
    "releasenotes" "text",
    "commitalnotes" "text",
    "police_officer_commiting" integer,
    "paroledate" "date",
    "escaped" boolean,
    "escapedate" timestamp without time zone,
    "escapedetails" "text",
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prisoncommital_version" OWNER TO "nyimbi";

--
-- Name: prisoncommital_warder; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncommital_warder" (
    "prisoncommital_prison" integer NOT NULL,
    "prisoncommital_warrantno" character varying(100) NOT NULL,
    "warder" integer NOT NULL
);


ALTER TABLE "prisoncommital_warder" OWNER TO "nyimbi";

--
-- Name: prisoncommital_warder_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisoncommital_warder_version" (
    "prisoncommital_prison" integer NOT NULL,
    "prisoncommital_warrantno" character varying(100) NOT NULL,
    "warder" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prisoncommital_warder_version" OWNER TO "nyimbi";

--
-- Name: prisonerproperty; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisonerproperty" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "prison_commital_prison" integer NOT NULL,
    "prison_commital_warrantno" character varying(100) NOT NULL,
    "receipted" boolean,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prisonerproperty" OWNER TO "nyimbi";

--
-- Name: prisonerproperty_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prisonerproperty_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prisonerproperty_id_seq" OWNER TO "nyimbi";

--
-- Name: prisonerproperty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prisonerproperty_id_seq" OWNED BY "prisonerproperty"."id";


--
-- Name: prisonerproperty_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prisonerproperty_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "prison_commital_prison" integer,
    "prison_commital_warrantno" character varying(100),
    "receipted" boolean,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prisonerproperty_version" OWNER TO "nyimbi";

--
-- Name: prosecutor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prosecutor" OWNER TO "nyimbi";

--
-- Name: prosecutor_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prosecutor_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prosecutor_id_seq" OWNER TO "nyimbi";

--
-- Name: prosecutor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prosecutor_id_seq" OWNED BY "prosecutor"."id";


--
-- Name: prosecutor_prosecutorteam; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor_prosecutorteam" (
    "prosecutor" integer NOT NULL,
    "prosecutorteam" integer NOT NULL
);


ALTER TABLE "prosecutor_prosecutorteam" OWNER TO "nyimbi";

--
-- Name: prosecutor_prosecutorteam_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor_prosecutorteam_version" (
    "prosecutor" integer NOT NULL,
    "prosecutorteam" integer NOT NULL,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prosecutor_prosecutorteam_version" OWNER TO "nyimbi";

--
-- Name: prosecutor_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutor_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prosecutor_version" OWNER TO "nyimbi";

--
-- Name: prosecutorteam; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutorteam" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "prosecutorteam" OWNER TO "nyimbi";

--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "prosecutorteam_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "prosecutorteam_id_seq" OWNER TO "nyimbi";

--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "prosecutorteam_id_seq" OWNED BY "prosecutorteam"."id";


--
-- Name: prosecutorteam_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "prosecutorteam_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "prosecutorteam_version" OWNER TO "nyimbi";

--
-- Name: remission; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "remission" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "id" integer NOT NULL,
    "prison_commital_prison" integer NOT NULL,
    "prison_commital_warrantno" character varying(100) NOT NULL,
    "daysearned" integer,
    "dateearned" "date",
    "amount" numeric(12,2),
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "remission" OWNER TO "nyimbi";

--
-- Name: remission_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "remission_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "remission_id_seq" OWNER TO "nyimbi";

--
-- Name: remission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "remission_id_seq" OWNED BY "remission"."id";


--
-- Name: remission_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "remission_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "id" integer NOT NULL,
    "prison_commital_prison" integer,
    "prison_commital_warrantno" character varying(100),
    "daysearned" integer,
    "dateearned" "date",
    "amount" numeric(12,2),
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "remission_version" OWNER TO "nyimbi";

--
-- Name: securityrank; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "securityrank" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "securityrank" OWNER TO "nyimbi";

--
-- Name: securityrank_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "securityrank_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "securityrank_id_seq" OWNER TO "nyimbi";

--
-- Name: securityrank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "securityrank_id_seq" OWNED BY "securityrank"."id";


--
-- Name: securityrank_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "securityrank_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "securityrank_version" OWNER TO "nyimbi";

--
-- Name: subcounty; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "subcounty" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "county" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "subcounty" OWNER TO "nyimbi";

--
-- Name: subcounty_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "subcounty_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "subcounty_id_seq" OWNER TO "nyimbi";

--
-- Name: subcounty_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "subcounty_id_seq" OWNED BY "subcounty"."id";


--
-- Name: subcounty_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "subcounty_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "county" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "subcounty_version" OWNER TO "nyimbi";

--
-- Name: surety; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "surety" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "surety" OWNER TO "nyimbi";

--
-- Name: surety_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "surety_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "surety_id_seq" OWNER TO "nyimbi";

--
-- Name: surety_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "surety_id_seq" OWNED BY "surety"."id";


--
-- Name: surety_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "surety_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "surety_version" OWNER TO "nyimbi";

--
-- Name: tag; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "tag" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "tag" OWNER TO "nyimbi";

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "tag_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "tag_id_seq" OWNER TO "nyimbi";

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "tag_id_seq" OWNED BY "tag"."id";


--
-- Name: tag_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "tag_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "tag_version" OWNER TO "nyimbi";

--
-- Name: town; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "town" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "subcounty" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "town" OWNER TO "nyimbi";

--
-- Name: town_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "town_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "town_id_seq" OWNER TO "nyimbi";

--
-- Name: town_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "town_id_seq" OWNED BY "town"."id";


--
-- Name: town_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "town_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "subcounty" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "town_version" OWNER TO "nyimbi";

--
-- Name: transaction; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "transaction" (
    "issued_at" timestamp without time zone,
    "id" bigint NOT NULL,
    "remote_addr" character varying(50),
    "user_id" integer
);


ALTER TABLE "transaction" OWNER TO "nyimbi";

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "transaction_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "transaction_id_seq" OWNER TO "nyimbi";

--
-- Name: visit; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "visit" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "vistors" integer NOT NULL,
    "defendants" integer NOT NULL,
    "visitdate" timestamp without time zone,
    "visitnotes" "text",
    "visitduration" interval,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "visit" OWNER TO "nyimbi";

--
-- Name: visit_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "visit_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "priority" integer,
    "segment" integer,
    "task_group" integer,
    "sequence" integer,
    "action" character varying(40),
    "activity_description" "text",
    "goal" "text",
    "status" character varying(40),
    "planned_start" "date",
    "actual_start" "date",
    "start_delay" interval,
    "start_notes" character varying(100),
    "planned_end" "date",
    "actual_end" timestamp without time zone,
    "end_delay" interval,
    "end_notes" character varying(100),
    "deadline" "date",
    "not_started" boolean,
    "early_start" boolean,
    "late_start" boolean,
    "completed" boolean,
    "early_end" boolean,
    "late_end" boolean,
    "deviation_expected" boolean,
    "contingency_plan" "text",
    "budget" numeric(10,2),
    "spend_td" numeric(10,2),
    "balance_avail" numeric(10,2),
    "over_budget" boolean,
    "under_budget" boolean,
    "vistors" integer NOT NULL,
    "defendants" integer NOT NULL,
    "visitdate" timestamp without time zone,
    "visitnotes" "text",
    "visitduration" interval,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "visit_version" OWNER TO "nyimbi";

--
-- Name: visitor; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "visitor" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "visitor" OWNER TO "nyimbi";

--
-- Name: visitor_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "visitor_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "visitor_id_seq" OWNER TO "nyimbi";

--
-- Name: visitor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "visitor_id_seq" OWNED BY "visitor"."id";


--
-- Name: visitor_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "visitor_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "gender" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "visitor_version" OWNER TO "nyimbi";

--
-- Name: warder; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "warder" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "prison" integer NOT NULL,
    "warder_rank" integer NOT NULL,
    "reports_to" integer,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "warder" OWNER TO "nyimbi";

--
-- Name: warder_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "warder_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "warder_id_seq" OWNER TO "nyimbi";

--
-- Name: warder_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "warder_id_seq" OWNED BY "warder"."id";


--
-- Name: warder_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "warder_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "prison" integer,
    "warder_rank" integer,
    "reports_to" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "warder_version" OWNER TO "nyimbi";

--
-- Name: warderrank; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "warderrank" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "name" character varying(100) NOT NULL,
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "warderrank" OWNER TO "nyimbi";

--
-- Name: warderrank_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "warderrank_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "warderrank_id_seq" OWNER TO "nyimbi";

--
-- Name: warderrank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "warderrank_id_seq" OWNED BY "warderrank"."id";


--
-- Name: warderrank_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "warderrank_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "name" character varying(100),
    "description" character varying(100),
    "notes" "text",
    "id" integer NOT NULL,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "warderrank_version" OWNER TO "nyimbi";

--
-- Name: witness; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "witness" (
    "created_on" timestamp without time zone NOT NULL,
    "changed_on" timestamp without time zone NOT NULL,
    "firstname" character varying(40) NOT NULL,
    "surname" character varying(40) NOT NULL,
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "fordefense" boolean,
    "gender" integer NOT NULL,
    "changed_by_fk" integer NOT NULL,
    "created_by_fk" integer NOT NULL
);


ALTER TABLE "witness" OWNER TO "nyimbi";

--
-- Name: witness_id_seq; Type: SEQUENCE; Schema: public; Owner: nyimbi
--

CREATE SEQUENCE "witness_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "witness_id_seq" OWNER TO "nyimbi";

--
-- Name: witness_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nyimbi
--

ALTER SEQUENCE "witness_id_seq" OWNED BY "witness"."id";


--
-- Name: witness_version; Type: TABLE; Schema: public; Owner: nyimbi
--

CREATE TABLE "witness_version" (
    "created_on" timestamp without time zone,
    "changed_on" timestamp without time zone,
    "firstname" character varying(40),
    "surname" character varying(40),
    "othernames" character varying(40),
    "dob" "date",
    "marital_status" character varying(10),
    "photo" "text",
    "age_today" integer,
    "mobile" character varying(30),
    "other_mobile" character varying(30),
    "fixed_line" character varying(30),
    "other_fixed_line" character varying(20),
    "email" character varying(60),
    "other_email" character varying(60),
    "address_line_1" character varying(200),
    "address_line_2" character varying(200),
    "zipcode" character varying(30),
    "town" character varying(40),
    "country" character varying(50),
    "facebook" character varying(40),
    "twitter" character varying(40),
    "instagram" character varying(40),
    "whatsapp" boolean,
    "other_whatsapp" boolean,
    "fax" character varying(30),
    "gcode" character varying(40),
    "okhi" character varying(40),
    "id" integer NOT NULL,
    "fordefense" boolean,
    "gender" integer,
    "changed_by_fk" integer,
    "created_by_fk" integer,
    "transaction_id" bigint NOT NULL,
    "end_transaction_id" bigint,
    "operation_type" smallint NOT NULL
);


ALTER TABLE "witness_version" OWNER TO "nyimbi";

--
-- Name: bail id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail" ALTER COLUMN "id" SET DEFAULT "nextval"('"bail_id_seq"'::"regclass");


--
-- Name: case id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case" ALTER COLUMN "id" SET DEFAULT "nextval"('"case_id_seq"'::"regclass");


--
-- Name: casecategory id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "casecategory" ALTER COLUMN "id" SET DEFAULT "nextval"('"casecategory_id_seq"'::"regclass");


--
-- Name: causeofaction id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction" ALTER COLUMN "id" SET DEFAULT "nextval"('"causeofaction_id_seq"'::"regclass");


--
-- Name: commitaltype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype" ALTER COLUMN "id" SET DEFAULT "nextval"('"commitaltype_id_seq"'::"regclass");


--
-- Name: constituency id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency" ALTER COLUMN "id" SET DEFAULT "nextval"('"constituency_id_seq"'::"regclass");


--
-- Name: county id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "county" ALTER COLUMN "id" SET DEFAULT "nextval"('"county_id_seq"'::"regclass");


--
-- Name: court id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court" ALTER COLUMN "id" SET DEFAULT "nextval"('"court_id_seq"'::"regclass");


--
-- Name: courtlevel id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel" ALTER COLUMN "id" SET DEFAULT "nextval"('"courtlevel_id_seq"'::"regclass");


--
-- Name: courtstation id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation" ALTER COLUMN "id" SET DEFAULT "nextval"('"courtstation_id_seq"'::"regclass");


--
-- Name: defendant id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant" ALTER COLUMN "id" SET DEFAULT "nextval"('"defendant_id_seq"'::"regclass");


--
-- Name: discipline id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline" ALTER COLUMN "id" SET DEFAULT "nextval"('"discipline_id_seq"'::"regclass");


--
-- Name: doc_store id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doc_store" ALTER COLUMN "id" SET DEFAULT "nextval"('"doc_store_id_seq"'::"regclass");


--
-- Name: docarchive id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive" ALTER COLUMN "id" SET DEFAULT "nextval"('"docarchive_id_seq"'::"regclass");


--
-- Name: doctemplate id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate" ALTER COLUMN "id" SET DEFAULT "nextval"('"doctemplate_id_seq"'::"regclass");


--
-- Name: document id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document" ALTER COLUMN "id" SET DEFAULT "nextval"('"document_id_seq"'::"regclass");


--
-- Name: eventlog id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "eventlog" ALTER COLUMN "id" SET DEFAULT "nextval"('"eventlog_id_seq"'::"regclass");


--
-- Name: filing id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing" ALTER COLUMN "id" SET DEFAULT "nextval"('"filing_id_seq"'::"regclass");


--
-- Name: filingtype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype" ALTER COLUMN "id" SET DEFAULT "nextval"('"filingtype_id_seq"'::"regclass");


--
-- Name: gateregister id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister" ALTER COLUMN "id" SET DEFAULT "nextval"('"gateregister_id_seq"'::"regclass");


--
-- Name: gender id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender" ALTER COLUMN "id" SET DEFAULT "nextval"('"gender_id_seq"'::"regclass");


--
-- Name: hearing id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing" ALTER COLUMN "id" SET DEFAULT "nextval"('"hearing_id_seq"'::"regclass");


--
-- Name: hearingtype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype" ALTER COLUMN "id" SET DEFAULT "nextval"('"hearingtype_id_seq"'::"regclass");


--
-- Name: investigation id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation" ALTER COLUMN "id" SET DEFAULT "nextval"('"investigation_id_seq"'::"regclass");


--
-- Name: jo_rank id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "jo_rank" ALTER COLUMN "id" SET DEFAULT "nextval"('"jo_rank_id_seq"'::"regclass");


--
-- Name: judicialofficer id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer" ALTER COLUMN "id" SET DEFAULT "nextval"('"judicialofficer_id_seq"'::"regclass");


--
-- Name: lawfirm id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm" ALTER COLUMN "id" SET DEFAULT "nextval"('"lawfirm_id_seq"'::"regclass");


--
-- Name: lawyers id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers" ALTER COLUMN "id" SET DEFAULT "nextval"('"lawyers_id_seq"'::"regclass");


--
-- Name: medevent id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "medevent" ALTER COLUMN "id" SET DEFAULT "nextval"('"medevent_id_seq"'::"regclass");


--
-- Name: natureofsuit id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit" ALTER COLUMN "id" SET DEFAULT "nextval"('"natureofsuit_id_seq"'::"regclass");


--
-- Name: payment id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment" ALTER COLUMN "id" SET DEFAULT "nextval"('"payment_id_seq"'::"regclass");


--
-- Name: paymentmethod id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "paymentmethod" ALTER COLUMN "id" SET DEFAULT "nextval"('"paymentmethod_id_seq"'::"regclass");


--
-- Name: plaintiff id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff" ALTER COLUMN "id" SET DEFAULT "nextval"('"plaintiff_id_seq"'::"regclass");


--
-- Name: policerank id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerank" ALTER COLUMN "id" SET DEFAULT "nextval"('"policerank_id_seq"'::"regclass");


--
-- Name: policerole id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole" ALTER COLUMN "id" SET DEFAULT "nextval"('"policerole_id_seq"'::"regclass");


--
-- Name: policestation id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation" ALTER COLUMN "id" SET DEFAULT "nextval"('"policestation_id_seq"'::"regclass");


--
-- Name: policestationtype id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestationtype" ALTER COLUMN "id" SET DEFAULT "nextval"('"policestationtype_id_seq"'::"regclass");


--
-- Name: polofficer id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer" ALTER COLUMN "id" SET DEFAULT "nextval"('"polofficer_id_seq"'::"regclass");


--
-- Name: prison id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison" ALTER COLUMN "id" SET DEFAULT "nextval"('"prison_id_seq"'::"regclass");


--
-- Name: prisoncell id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell" ALTER COLUMN "id" SET DEFAULT "nextval"('"prisoncell_id_seq"'::"regclass");


--
-- Name: prisonerproperty id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty" ALTER COLUMN "id" SET DEFAULT "nextval"('"prisonerproperty_id_seq"'::"regclass");


--
-- Name: prosecutor id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor" ALTER COLUMN "id" SET DEFAULT "nextval"('"prosecutor_id_seq"'::"regclass");


--
-- Name: prosecutorteam id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam" ALTER COLUMN "id" SET DEFAULT "nextval"('"prosecutorteam_id_seq"'::"regclass");


--
-- Name: remission id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission" ALTER COLUMN "id" SET DEFAULT "nextval"('"remission_id_seq"'::"regclass");


--
-- Name: securityrank id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "securityrank" ALTER COLUMN "id" SET DEFAULT "nextval"('"securityrank_id_seq"'::"regclass");


--
-- Name: subcounty id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty" ALTER COLUMN "id" SET DEFAULT "nextval"('"subcounty_id_seq"'::"regclass");


--
-- Name: surety id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety" ALTER COLUMN "id" SET DEFAULT "nextval"('"surety_id_seq"'::"regclass");


--
-- Name: tag id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "tag" ALTER COLUMN "id" SET DEFAULT "nextval"('"tag_id_seq"'::"regclass");


--
-- Name: town id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town" ALTER COLUMN "id" SET DEFAULT "nextval"('"town_id_seq"'::"regclass");


--
-- Name: visitor id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor" ALTER COLUMN "id" SET DEFAULT "nextval"('"visitor_id_seq"'::"regclass");


--
-- Name: warder id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder" ALTER COLUMN "id" SET DEFAULT "nextval"('"warder_id_seq"'::"regclass");


--
-- Name: warderrank id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warderrank" ALTER COLUMN "id" SET DEFAULT "nextval"('"warderrank_id_seq"'::"regclass");


--
-- Name: witness id; Type: DEFAULT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness" ALTER COLUMN "id" SET DEFAULT "nextval"('"witness_id_seq"'::"regclass");


--
-- Data for Name: ab_permission; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission" ("id", "name") FROM stdin;
1	can_this_form_post
2	can_this_form_get
3	can_edit
4	can_userinfo
5	can_delete
6	can_download
7	can_list
8	can_add
9	can_show
10	resetmypassword
11	resetpasswords
12	userinfoedit
13	menu_access
14	Copy Role
15	can_chart
16	muldelete
\.


--
-- Data for Name: ab_permission_view; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission_view" ("id", "permission_id", "view_menu_id") FROM stdin;
1	1	5
2	2	5
3	1	6
4	2	6
5	1	7
6	2	7
7	3	9
8	4	9
9	5	9
10	6	9
11	7	9
12	8	9
13	9	9
14	10	9
15	11	9
16	12	9
17	13	10
18	13	11
19	3	12
20	5	12
21	6	12
22	7	12
23	8	12
24	9	12
25	14	12
26	13	13
27	15	14
28	13	15
29	7	16
30	9	16
31	5	16
32	7	17
33	13	18
34	7	19
35	13	20
36	7	21
37	13	22
38	3	23
39	5	23
40	6	23
41	7	23
42	8	23
43	9	23
44	16	23
45	13	24
46	13	25
47	3	26
48	5	26
49	6	26
50	7	26
51	8	26
52	9	26
53	16	26
54	13	27
55	3	28
56	5	28
57	6	28
58	7	28
59	8	28
60	9	28
61	16	28
62	13	29
63	3	30
64	5	30
65	6	30
66	7	30
67	8	30
68	9	30
69	16	30
70	13	31
71	3	32
72	5	32
73	6	32
74	7	32
75	8	32
76	9	32
77	16	32
78	13	33
79	3	34
80	5	34
81	6	34
82	7	34
83	8	34
84	9	34
85	16	34
86	13	35
87	3	36
88	5	36
89	6	36
90	7	36
91	8	36
92	9	36
93	16	36
94	13	37
95	3	38
96	5	38
97	6	38
98	7	38
99	8	38
100	9	38
101	16	38
102	13	39
103	3	40
104	5	40
105	6	40
106	7	40
107	8	40
108	9	40
109	16	40
110	13	41
111	3	42
112	5	42
113	6	42
114	7	42
115	8	42
116	9	42
117	16	42
118	13	43
119	3	44
120	5	44
121	6	44
122	7	44
123	8	44
124	9	44
125	16	44
126	13	45
127	3	46
128	5	46
129	6	46
130	7	46
131	8	46
132	9	46
133	16	46
134	13	47
135	13	48
136	3	49
137	5	49
138	6	49
139	7	49
140	8	49
141	9	49
142	16	49
143	13	50
144	3	51
145	5	51
146	6	51
147	7	51
148	8	51
149	9	51
150	16	51
151	13	52
152	3	53
153	5	53
154	6	53
155	7	53
156	8	53
157	9	53
158	16	53
159	13	54
160	3	55
161	5	55
162	6	55
163	7	55
164	8	55
165	9	55
166	16	55
167	13	56
168	3	57
169	5	57
170	6	57
171	7	57
172	8	57
173	9	57
174	16	57
175	13	58
176	3	59
177	5	59
178	6	59
179	7	59
180	8	59
181	9	59
182	16	59
183	13	60
184	3	61
185	5	61
186	6	61
187	7	61
188	8	61
189	9	61
190	16	61
192	3	63
193	5	63
194	6	63
195	7	63
196	8	63
197	9	63
198	16	63
200	3	65
201	5	65
202	6	65
203	7	65
204	8	65
205	9	65
206	16	65
208	3	67
209	5	67
210	6	67
211	7	67
212	8	67
213	9	67
214	16	67
216	3	69
217	5	69
218	6	69
219	7	69
220	8	69
221	9	69
222	16	69
224	3	71
225	5	71
226	6	71
227	7	71
228	8	71
229	9	71
230	16	71
232	3	73
233	5	73
234	6	73
235	7	73
236	8	73
237	9	73
238	16	73
240	3	75
241	5	75
242	6	75
243	7	75
244	8	75
245	9	75
246	16	75
248	3	77
249	5	77
250	6	77
251	7	77
252	8	77
253	9	77
254	16	77
256	3	79
257	5	79
258	6	79
259	7	79
260	8	79
261	9	79
262	16	79
264	3	81
265	5	81
266	6	81
267	7	81
268	8	81
269	9	81
270	16	81
272	13	83
280	13	85
288	13	87
296	13	89
304	13	91
312	13	93
320	13	95
328	13	97
336	13	99
344	13	101
351	13	103
353	3	105
354	5	105
355	6	105
356	7	105
357	8	105
358	9	105
359	16	105
361	3	107
362	5	107
363	6	107
364	7	107
365	8	107
366	9	107
367	16	107
369	7	109
370	16	109
372	3	111
373	5	111
374	6	111
375	7	111
376	8	111
377	9	111
378	16	111
380	3	113
381	5	113
382	6	113
383	7	113
384	8	113
385	9	113
386	16	113
388	3	115
389	5	115
390	6	115
391	7	115
392	8	115
393	9	115
394	16	115
396	3	117
397	5	117
398	6	117
399	7	117
400	8	117
401	9	117
402	16	117
404	3	119
405	5	119
406	6	119
407	7	119
408	8	119
409	9	119
410	16	119
412	3	121
413	5	121
414	6	121
415	7	121
416	8	121
417	9	121
418	16	121
420	3	123
421	5	123
422	6	123
423	7	123
424	8	123
425	9	123
426	16	123
428	3	125
429	5	125
430	6	125
431	7	125
432	8	125
433	9	125
434	16	125
436	3	127
437	5	127
438	6	127
439	7	127
440	8	127
441	9	127
442	16	127
444	3	129
445	5	129
446	6	129
447	7	129
448	8	129
449	9	129
450	16	129
452	3	131
453	5	131
454	6	131
455	7	131
456	8	131
457	9	131
458	16	131
460	3	133
461	5	133
462	6	133
463	7	133
464	8	133
465	9	133
191	13	62
199	13	64
207	13	66
215	13	68
223	13	70
231	13	72
239	13	74
247	13	76
255	13	78
263	13	80
271	13	82
273	3	84
274	5	84
275	6	84
276	7	84
277	8	84
278	9	84
279	16	84
281	3	86
282	5	86
283	6	86
284	7	86
285	8	86
286	9	86
287	16	86
289	3	88
290	5	88
291	6	88
292	7	88
293	8	88
294	9	88
295	16	88
297	3	90
298	5	90
299	6	90
300	7	90
301	8	90
302	9	90
303	16	90
305	3	92
306	5	92
307	6	92
308	7	92
309	8	92
310	9	92
311	16	92
313	3	94
314	5	94
315	6	94
316	7	94
317	8	94
318	9	94
319	16	94
321	3	96
322	5	96
323	6	96
324	7	96
325	8	96
326	9	96
327	16	96
329	3	98
330	5	98
331	6	98
332	7	98
333	8	98
334	9	98
335	16	98
337	3	100
338	5	100
339	6	100
340	7	100
341	8	100
342	9	100
343	16	100
345	3	102
346	5	102
347	6	102
348	7	102
349	8	102
350	9	102
352	13	104
360	13	106
368	13	108
371	13	110
379	13	112
387	13	114
395	13	116
403	13	118
411	13	120
419	13	122
427	13	124
435	13	126
443	13	128
451	13	130
459	13	132
467	13	134
475	13	136
477	15	138
479	15	140
481	15	142
483	15	144
485	15	146
487	15	148
489	15	150
491	15	152
493	15	154
495	15	156
497	15	158
499	15	160
501	15	162
503	15	164
505	15	166
507	15	168
509	15	170
511	15	172
513	15	174
515	15	176
517	15	178
519	15	180
521	15	182
523	15	184
525	15	186
527	15	188
529	15	190
531	15	192
533	15	194
535	15	196
537	15	198
539	15	200
466	16	133
468	3	135
469	5	135
470	6	135
471	7	135
472	8	135
473	9	135
474	16	135
476	13	137
478	13	139
480	13	141
482	13	143
484	13	145
486	13	147
488	13	149
490	13	151
492	13	153
494	13	155
496	13	157
498	13	159
500	13	161
502	13	163
504	13	165
506	13	167
508	13	169
510	13	171
512	13	173
514	13	175
516	13	177
518	13	179
520	13	181
522	13	183
524	13	185
526	13	187
528	13	189
530	13	191
532	13	193
534	13	195
536	13	197
538	13	199
540	13	201
\.


--
-- Data for Name: ab_permission_view_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_permission_view_role" ("id", "permission_view_id", "role_id") FROM stdin;
1	1	1
2	2	1
3	3	1
4	4	1
5	5	1
6	6	1
7	7	1
8	8	1
9	9	1
10	10	1
11	11	1
12	12	1
13	13	1
14	14	1
15	15	1
16	16	1
17	17	1
18	18	1
19	19	1
20	20	1
21	21	1
22	22	1
23	23	1
24	24	1
25	25	1
26	26	1
27	27	1
28	28	1
29	29	1
30	30	1
31	31	1
32	32	1
33	33	1
34	34	1
35	35	1
36	36	1
37	37	1
38	38	1
39	39	1
40	40	1
41	41	1
42	42	1
43	43	1
44	44	1
45	45	1
46	46	1
47	47	1
48	48	1
49	49	1
50	50	1
51	51	1
52	52	1
53	53	1
54	54	1
55	55	1
56	56	1
57	57	1
58	58	1
59	59	1
60	60	1
61	61	1
62	62	1
63	63	1
64	64	1
65	65	1
66	66	1
67	67	1
68	68	1
69	69	1
70	70	1
71	71	1
72	72	1
73	73	1
74	74	1
75	75	1
76	76	1
77	77	1
78	78	1
79	79	1
80	80	1
81	81	1
82	82	1
83	83	1
84	84	1
85	85	1
86	86	1
87	87	1
88	88	1
89	89	1
90	90	1
91	91	1
92	92	1
93	93	1
94	94	1
95	95	1
96	96	1
97	97	1
98	98	1
99	99	1
100	100	1
101	101	1
102	102	1
103	103	1
104	104	1
105	105	1
106	106	1
107	107	1
108	108	1
109	109	1
110	110	1
111	111	1
112	112	1
113	113	1
114	114	1
115	115	1
116	116	1
117	117	1
118	118	1
119	119	1
120	120	1
121	121	1
122	122	1
123	123	1
124	124	1
125	125	1
126	126	1
127	127	1
128	128	1
129	129	1
130	130	1
131	131	1
132	132	1
133	133	1
134	134	1
135	135	1
136	136	1
137	137	1
138	138	1
139	139	1
140	140	1
141	141	1
142	142	1
143	143	1
144	144	1
145	145	1
146	146	1
147	147	1
148	148	1
149	149	1
150	150	1
151	151	1
152	152	1
153	153	1
154	154	1
155	155	1
156	156	1
157	157	1
158	158	1
159	159	1
160	160	1
161	161	1
162	162	1
163	163	1
164	164	1
165	165	1
166	166	1
167	167	1
168	168	1
169	169	1
170	170	1
171	171	1
172	172	1
173	173	1
174	174	1
175	175	1
176	176	1
177	177	1
178	178	1
179	179	1
180	180	1
181	181	1
182	182	1
183	183	1
184	184	1
185	185	1
186	186	1
187	187	1
188	188	1
189	189	1
190	190	1
192	192	1
193	193	1
194	194	1
195	195	1
196	196	1
197	197	1
198	198	1
200	200	1
201	201	1
202	202	1
203	203	1
204	204	1
205	205	1
206	206	1
208	208	1
209	209	1
210	210	1
211	211	1
212	212	1
213	213	1
214	214	1
216	216	1
217	217	1
218	218	1
219	219	1
220	220	1
221	221	1
222	222	1
224	224	1
225	225	1
226	226	1
227	227	1
228	228	1
229	229	1
230	230	1
232	232	1
233	233	1
234	234	1
235	235	1
236	236	1
237	237	1
238	238	1
240	240	1
241	241	1
242	242	1
243	243	1
244	244	1
245	245	1
246	246	1
248	248	1
249	249	1
250	250	1
251	251	1
252	252	1
253	253	1
254	254	1
256	256	1
257	257	1
258	258	1
259	259	1
260	260	1
261	261	1
262	262	1
264	264	1
265	265	1
266	266	1
267	267	1
268	268	1
269	269	1
270	270	1
272	272	1
280	280	1
288	288	1
296	296	1
304	304	1
312	312	1
320	320	1
328	328	1
336	336	1
344	344	1
351	351	1
353	353	1
354	354	1
355	355	1
356	356	1
357	357	1
358	358	1
359	359	1
361	361	1
362	362	1
363	363	1
364	364	1
365	365	1
366	366	1
367	367	1
369	369	1
370	370	1
372	372	1
373	373	1
374	374	1
375	375	1
376	376	1
377	377	1
378	378	1
380	380	1
381	381	1
382	382	1
383	383	1
384	384	1
385	385	1
386	386	1
388	388	1
389	389	1
390	390	1
391	391	1
392	392	1
393	393	1
394	394	1
396	396	1
397	397	1
398	398	1
399	399	1
400	400	1
401	401	1
402	402	1
404	404	1
405	405	1
406	406	1
407	407	1
408	408	1
409	409	1
410	410	1
412	412	1
413	413	1
414	414	1
415	415	1
416	416	1
417	417	1
418	418	1
420	420	1
421	421	1
422	422	1
423	423	1
424	424	1
425	425	1
426	426	1
428	428	1
429	429	1
430	430	1
431	431	1
432	432	1
433	433	1
434	434	1
436	436	1
437	437	1
438	438	1
439	439	1
440	440	1
441	441	1
442	442	1
444	444	1
445	445	1
446	446	1
447	447	1
448	448	1
449	449	1
450	450	1
452	452	1
453	453	1
454	454	1
455	455	1
456	456	1
457	457	1
458	458	1
460	460	1
461	461	1
462	462	1
463	463	1
464	464	1
465	465	1
191	191	1
199	199	1
207	207	1
215	215	1
223	223	1
231	231	1
239	239	1
247	247	1
255	255	1
263	263	1
271	271	1
273	273	1
274	274	1
275	275	1
276	276	1
277	277	1
278	278	1
279	279	1
281	281	1
282	282	1
283	283	1
284	284	1
285	285	1
286	286	1
287	287	1
289	289	1
290	290	1
291	291	1
292	292	1
293	293	1
294	294	1
295	295	1
297	297	1
298	298	1
299	299	1
300	300	1
301	301	1
302	302	1
303	303	1
305	305	1
306	306	1
307	307	1
308	308	1
309	309	1
310	310	1
311	311	1
313	313	1
314	314	1
315	315	1
316	316	1
317	317	1
318	318	1
319	319	1
321	321	1
322	322	1
323	323	1
324	324	1
325	325	1
326	326	1
327	327	1
329	329	1
330	330	1
331	331	1
332	332	1
333	333	1
334	334	1
335	335	1
337	337	1
338	338	1
339	339	1
340	340	1
341	341	1
342	342	1
343	343	1
345	345	1
346	346	1
347	347	1
348	348	1
349	349	1
350	350	1
352	352	1
360	360	1
368	368	1
371	371	1
379	379	1
387	387	1
395	395	1
403	403	1
411	411	1
419	419	1
427	427	1
435	435	1
443	443	1
451	451	1
459	459	1
467	467	1
475	475	1
477	477	1
479	479	1
481	481	1
483	483	1
485	485	1
487	487	1
489	489	1
491	491	1
493	493	1
495	495	1
497	497	1
499	499	1
501	501	1
503	503	1
505	505	1
507	507	1
509	509	1
511	511	1
513	513	1
515	515	1
517	517	1
519	519	1
521	521	1
523	523	1
525	525	1
527	527	1
529	529	1
531	531	1
533	533	1
535	535	1
537	537	1
539	539	1
466	466	1
468	468	1
469	469	1
470	470	1
471	471	1
472	472	1
473	473	1
474	474	1
476	476	1
478	478	1
480	480	1
482	482	1
484	484	1
486	486	1
488	488	1
490	490	1
492	492	1
494	494	1
496	496	1
498	498	1
500	500	1
502	502	1
504	504	1
506	506	1
508	508	1
510	510	1
512	512	1
514	514	1
516	516	1
518	518	1
520	520	1
522	522	1
524	524	1
526	526	1
528	528	1
530	530	1
532	532	1
534	534	1
536	536	1
538	538	1
540	540	1
\.


--
-- Data for Name: ab_register_user; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_register_user" ("id", "first_name", "last_name", "username", "password", "email", "registration_date", "registration_hash") FROM stdin;
\.


--
-- Data for Name: ab_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_role" ("id", "name") FROM stdin;
1	Admin
2	Public
\.


--
-- Data for Name: ab_user; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_user" ("id", "first_name", "last_name", "username", "password", "active", "email", "last_login", "login_count", "fail_login_count", "created_on", "changed_on", "created_by_fk", "changed_by_fk") FROM stdin;
1	admin	user	admin	pbkdf2:sha256:50000$kIQ2dIKn$a5806668389e17c99833a0306bcee72ad546290f7940fb398664233f26d4edf9	t	admin@fab.org	2017-09-28 11:39:06.86368	1	0	2017-09-28 11:26:38.788622	2017-09-28 11:26:38.788632	\N	\N
\.


--
-- Data for Name: ab_user_role; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_user_role" ("id", "user_id", "role_id") FROM stdin;
1	1	1
\.


--
-- Data for Name: ab_view_menu; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "ab_view_menu" ("id", "name") FROM stdin;
1	MyIndexView
2	UtilView
3	LocaleView
4	RegisterUserDBView
5	ResetPasswordView
6	ResetMyPasswordView
7	UserInfoEditView
8	AuthDBView
9	UserDBModelView
10	List Users
11	Security
12	RoleModelView
13	List Roles
14	UserStatsChartView
15	User's Statistics
16	RegisterUserModelView
17	PermissionModelView
18	Base Permissions
19	ViewMenuModelView
20	Views/Menus
21	PermissionViewModelView
22	Permission on Views/Menus
23	CountyView
24	Counties
25	Setup
26	SubcountyView
27	Sub Counties
28	ConstituencyView
29	Constituencies
30	TownView
31	Towns
32	CourtstationView
33	Court Stations
34	CourtView
35	Courts
36	PaymentmethodView
37	Payment Methods
38	LawfirmView
39	Law Firms
40	PolicestationView
41	Police Stations
42	PrisonView
43	Prisons
44	PrisoncellView
45	Prison Cells
46	CourtlevelView
47	Court Levels
48	Categories
49	CauseofactionView
50	Causes of Action
51	CasecategoryView
52	Case Categories
53	NatureofsuitView
54	Nature of Suit
55	CommitaltypeView
56	Commital Types
57	FilingtypeView
58	Filing Types
59	GenderView
60	Genders
61	HearingtypeView
62	Hearing Types
63	JoRankView
64	Judicial Ranks
65	PolicerankView
66	Police Ranks
67	WarderrankView
68	Warder Ranks
69	PoliceroleView
70	Police Roles
71	PolicestationtypeView
72	Police Station Types
73	ProsecutorteamView
74	Prosecutor Teams
75	SecurityrankView
76	Prison Security Ranks
77	TagView
78	Tags
79	DoctemplateView
80	Doc Templates
81	PlaintiffView
82	Plaintiffs
83	People
84	DefendantView
85	Defendants
86	WitnesView
87	Witnesses
88	JudicialofficerView
89	Judicial Officers
90	LawyerView
91	Lawyers
92	PolofficerView
93	Police Officers
94	ProsecutorView
95	Prosecutors
96	VisitorView
97	Visitors
98	WarderView
99	Warders
100	SuretyView
101	Sureties
102	CaseView
103	Cases
104	Process
105	InvestigationView
106	Investigations
107	FilingView
108	Filings
109	FilingMultiView
110	File & Docs
111	HearingView
112	Hearings
113	BailView
114	Bail
115	DocumentView
116	Documents
117	DocarchiveView
118	Doc Archives
119	PrisoncommitalView
120	Prison Commital
121	GateregisterView
122	Gate Registers
123	DisciplineView
124	Disciplinary
125	MedeventView
126	Medical Events
127	PaymentView
128	Payments
129	PrisonerpropertyView
130	Prisoner Property
131	RemissionView
132	Remissions
133	VisitView
134	Visits
135	EventlogView
136	Eventlogs
137	Reports
138	LawyerChartView
139	Lawyer Age Chart
140	LawyerTimeChartView
141	Lawyer Time Chart
142	PlaintiffChartView
143	Plaintiff Age Chart
144	PlaintiffTimeChartView
145	Plaintiff Time Chart
146	WitnesChartView
147	Witnes Age Chart
148	WitnesTimeChartView
149	Witnes Time Chart
150	SuretyChartView
151	Surety Age Chart
152	SuretyTimeChartView
153	Surety Time Chart
154	ProsecutorChartView
155	Prosecutor Age Chart
156	ProsecutorTimeChartView
157	Prosecutor Time Chart
158	PoliceofficerChartView
159	Policeofficer Age Chart
160	PoliceofficerTimeChartView
161	Policeofficer Time Chart
162	JudicialofficerChartView
163	Judicialofficer Age Chart
164	JudicialofficerTimeChartView
166	DefendantChartView
168	DefendantTimeChartView
170	VisitorChartView
172	VisitorTimeChartView
174	WarderChartView
176	WarderTimeChartView
178	VisitChartView
180	VisitTimeChartView
182	DisciplineChartView
184	DisciplineTimeChartView
186	MedeventChartView
188	MedeventTimeChartView
190	HearingChartView
192	HearingTimeChartView
194	PrisoncommitalChartView
196	PrisoncommitalTimeChartView
198	CaseChartView
200	CaseTimeChartView
165	Judicialofficer Time Chart
167	Defendant Age Chart
169	Defendant Time Chart
171	Visitor Age Chart
173	Visitor Time Chart
175	Warder Age Chart
177	Warder Time Chart
179	Visit Age Chart
181	Visit Time Chart
183	Discipline Age Chart
185	Discipline Time Chart
187	Medevent Age Chart
189	Medevent Time Chart
191	Hearing Age Chart
193	Hearing Time Chart
195	Prisoncommital Age Chart
197	Prisoncommital Time Chart
199	Case Age Chart
201	Case Time Chart
\.


--
-- Data for Name: bail; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail" ("created_on", "changed_on", "id", "hearing", "defendant", "amountgranted", "noofsureties", "paid", "paydate", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: bail_surety; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail_surety" ("bail", "surety") FROM stdin;
\.


--
-- Data for Name: bail_surety_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail_surety_version" ("bail", "surety", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: bail_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "bail_version" ("created_on", "changed_on", "id", "hearing", "defendant", "amountgranted", "noofsureties", "paid", "paydate", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case" ("created_on", "changed_on", "name", "description", "notes", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "born_digital", "ob_number", "police_station_reported", "report_date", "complaint", "is_criminal", "priority", "should_investigate_further", "evaluation_conclusion", "investigation_assigment_date", "investigation_assignment_note", "investigation_plan", "investigation_summary", "investigation_review", "investigation_complete", "dpp_advice_requested", "dpp_advice_request_date", "dpp_advice_date", "dpp_advice", "send_to_trial", "case_name", "docketnumber", "charge_sheet", "charge_date", "prosecution_notes", "defense_notes", "judgement", "judgement_date", "sentence_length_years", "sentence_length_months", "senetence_length_days", "sentence_start_date", "sentence_end_date", "fine_amount", "case_appealed", "appeal_date", "appeal_granted", "appeal_expiry", "case_closed", "close_date", "reported_to", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: case_casecategory; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_casecategory" ("case", "casecategory") FROM stdin;
\.


--
-- Data for Name: case_casecategory_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_casecategory_version" ("case", "casecategory", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_causeofaction; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_causeofaction" ("case", "causeofaction") FROM stdin;
\.


--
-- Data for Name: case_causeofaction_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_causeofaction_version" ("case", "causeofaction", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_defendant; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_defendant" ("case", "defendant") FROM stdin;
\.


--
-- Data for Name: case_defendant_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_defendant_version" ("case", "defendant", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_natureofsuit; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_natureofsuit" ("case", "natureofsuit") FROM stdin;
\.


--
-- Data for Name: case_natureofsuit_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_natureofsuit_version" ("case", "natureofsuit", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_plaintiff; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_plaintiff" ("case", "plaintiff") FROM stdin;
\.


--
-- Data for Name: case_plaintiff_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_plaintiff_version" ("case", "plaintiff", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_polofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_polofficer" ("case", "polofficer") FROM stdin;
\.


--
-- Data for Name: case_polofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_polofficer_version" ("case", "polofficer", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_prosecutor" ("case", "prosecutor") FROM stdin;
\.


--
-- Data for Name: case_prosecutor_2; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_prosecutor_2" ("case", "prosecutor") FROM stdin;
\.


--
-- Data for Name: case_prosecutor_2_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_prosecutor_2_version" ("case", "prosecutor", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_prosecutor_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_prosecutor_version" ("case", "prosecutor", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_tag; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_tag" ("case", "tag") FROM stdin;
\.


--
-- Data for Name: case_tag_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_tag_version" ("case", "tag", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_version" ("created_on", "changed_on", "name", "description", "notes", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "born_digital", "ob_number", "police_station_reported", "report_date", "complaint", "is_criminal", "priority", "should_investigate_further", "evaluation_conclusion", "investigation_assigment_date", "investigation_assignment_note", "investigation_plan", "investigation_summary", "investigation_review", "investigation_complete", "dpp_advice_requested", "dpp_advice_request_date", "dpp_advice_date", "dpp_advice", "send_to_trial", "case_name", "docketnumber", "charge_sheet", "charge_date", "prosecution_notes", "defense_notes", "judgement", "judgement_date", "sentence_length_years", "sentence_length_months", "senetence_length_days", "sentence_start_date", "sentence_end_date", "fine_amount", "case_appealed", "appeal_date", "appeal_granted", "appeal_expiry", "case_closed", "close_date", "reported_to", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: case_witness; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_witness" ("case", "witness") FROM stdin;
\.


--
-- Data for Name: case_witness_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "case_witness_version" ("case", "witness", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: casecategory; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "casecategory" ("created_on", "changed_on", "name", "description", "notes", "id", "indictable", "is_criminal", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: casecategory_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "casecategory_version" ("created_on", "changed_on", "name", "description", "notes", "id", "indictable", "is_criminal", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: caseinvestigation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "caseinvestigation" ("pol_officers", "cases") FROM stdin;
\.


--
-- Data for Name: caseinvestigation_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "caseinvestigation_version" ("pol_officers", "cases", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: causeofaction; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction" ("created_on", "changed_on", "name", "description", "notes", "id", "criminal", "parent_coa", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: causeofaction_filing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_filing" ("causeofaction", "filing") FROM stdin;
\.


--
-- Data for Name: causeofaction_filing_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_filing_version" ("causeofaction", "filing", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: causeofaction_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_hearing" ("causeofaction", "hearing") FROM stdin;
\.


--
-- Data for Name: causeofaction_hearing_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_hearing_version" ("causeofaction", "hearing", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: causeofaction_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "causeofaction_version" ("created_on", "changed_on", "name", "description", "notes", "id", "criminal", "parent_coa", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: commitaltype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "commitaltype" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: commitaltype_prisoncommital; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "commitaltype_prisoncommital" ("commitaltype", "prisoncommital_prison", "prisoncommital_warrantno") FROM stdin;
\.


--
-- Data for Name: commitaltype_prisoncommital_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "commitaltype_prisoncommital_version" ("commitaltype", "prisoncommital_prison", "prisoncommital_warrantno", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: commitaltype_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "commitaltype_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: constituency; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "constituency" ("created_on", "changed_on", "name", "description", "notes", "id", "county", "town", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: constituency_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "constituency_version" ("created_on", "changed_on", "name", "description", "notes", "id", "county", "town", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: county; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "county" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: county_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "county_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: court; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "court" ("created_on", "changed_on", "name", "description", "notes", "id", "court_station", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: court_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "court_version" ("created_on", "changed_on", "name", "description", "notes", "id", "court_station", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: courtlevel; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "courtlevel" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: courtlevel_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "courtlevel_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: courtstation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "courtstation" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "residentmagistrate", "registrar", "court_level", "num_of_courts", "town", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: courtstation_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "courtstation_version" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "residentmagistrate", "registrar", "court_level", "num_of_courts", "town", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: defendant; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant" ("created_on", "changed_on", "allergies", "chronic_conditions", "chronic_medications", "hbp", "diabetes", "hiv", "current_health_status", "bc_id", "bc_number", "bc_serial", "bc_place", "bc_scan", "citizenship", "nat_id_num", "nat_id_serial", "nat_id_scan", "pp_no", "pp_issue_date", "pp_issue_place", "pp_scan", "pp_expiry_date", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin1_relation", "kin2_phone", "kin2_email", "kin2_addr", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "blood_group", "striking_features", "height_m", "weight_kg", "eye_colour", "hair_colour", "complexion", "religion", "ethnicity", "fp_lthumb", "pgm", "wsq", "xyt", "fp_left2", "fp_left3", "fp_left4", "fp_left5", "fp_rthumb", "fp_right2", "fp_right3", "fp_right4", "fp_right5", "palm_left", "palm_right", "eye_left", "eye_right", "employed", "employer", "employer_contact", "employ_date", "employ_duration", "termination_date", "employ_role", "supervisor", "supervisor_contact", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "juvenile", "gender", "prisoncell", "casecount", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: defendant_gateregister; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_gateregister" ("defendant", "gateregister") FROM stdin;
\.


--
-- Data for Name: defendant_gateregister_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_gateregister_version" ("defendant", "gateregister", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: defendant_hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_hearing" ("defendant", "hearing") FROM stdin;
\.


--
-- Data for Name: defendant_hearing_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_hearing_version" ("defendant", "hearing", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: defendant_medevent; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_medevent" ("defendant", "medevent") FROM stdin;
\.


--
-- Data for Name: defendant_medevent_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_medevent_version" ("defendant", "medevent", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: defendant_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "defendant_version" ("created_on", "changed_on", "allergies", "chronic_conditions", "chronic_medications", "hbp", "diabetes", "hiv", "current_health_status", "bc_id", "bc_number", "bc_serial", "bc_place", "bc_scan", "citizenship", "nat_id_num", "nat_id_serial", "nat_id_scan", "pp_no", "pp_issue_date", "pp_issue_place", "pp_scan", "pp_expiry_date", "kin1_name", "kin1_phone", "kin1_email", "kin1_addr", "kin2_name", "kin1_relation", "kin2_phone", "kin2_email", "kin2_addr", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "blood_group", "striking_features", "height_m", "weight_kg", "eye_colour", "hair_colour", "complexion", "religion", "ethnicity", "fp_lthumb", "pgm", "wsq", "xyt", "fp_left2", "fp_left3", "fp_left4", "fp_left5", "fp_rthumb", "fp_right2", "fp_right3", "fp_right4", "fp_right5", "palm_left", "palm_right", "eye_left", "eye_right", "employed", "employer", "employer_contact", "employ_date", "employ_duration", "termination_date", "employ_role", "supervisor", "supervisor_contact", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "juvenile", "gender", "prisoncell", "casecount", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: discipline; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "discipline" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "defendant", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: discipline_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "discipline_version" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "defendant", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: doc_store; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "doc_store" ("name", "description", "notes", "id", "data") FROM stdin;
\.


--
-- Data for Name: docarchive; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "docarchive" ("created_on", "changed_on", "id", "name", "doc", "scandate", "archival", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: docarchive_tag; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "docarchive_tag" ("docarchive", "tag") FROM stdin;
\.


--
-- Data for Name: docarchive_tag_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "docarchive_tag_version" ("docarchive", "tag", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: docarchive_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "docarchive_version" ("created_on", "changed_on", "id", "name", "doc", "scandate", "archival", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: doctemplate; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "doctemplate" ("created_on", "changed_on", "name", "description", "notes", "mime_type", "doc", "doc_text", "doc_binary", "doc_title", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "hashx", "audio_duration_secs", "audio_frame_rate", "audio_channels", "search_vector", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: doctemplate_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "doctemplate_version" ("created_on", "changed_on", "name", "description", "notes", "mime_type", "doc", "doc_text", "doc_binary", "doc_title", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "hashx", "audio_duration_secs", "audio_frame_rate", "audio_channels", "search_vector", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document" ("created_on", "changed_on", "mime_type", "doc", "doc_text", "doc_binary", "doc_title", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "hashx", "audio_duration_secs", "audio_frame_rate", "audio_channels", "search_vector", "id", "filing", "doc_template", "confidential", "pagecount", "locked", "hash", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: document_tag; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document_tag" ("document", "tag") FROM stdin;
\.


--
-- Data for Name: document_tag_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document_tag_version" ("document", "tag", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: document_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "document_version" ("created_on", "changed_on", "mime_type", "doc", "doc_text", "doc_binary", "doc_title", "subject", "author", "keywords", "comments", "doc_type", "char_count", "word_count", "lines", "paragraphs", "file_size_bytes", "producer_prog", "immutable", "page_size", "page_count", "hashx", "audio_duration_secs", "audio_frame_rate", "audio_channels", "search_vector", "id", "filing", "doc_template", "confidential", "pagecount", "locked", "hash", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: eventlog; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "eventlog" ("created_on", "changed_on", "id", "temporal", "event", "severity", "alert", "notes", "tbl", "colname", "colbefore", "colafter", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: eventlog_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "eventlog_version" ("created_on", "changed_on", "id", "temporal", "event", "severity", "alert", "notes", "tbl", "colname", "colbefore", "colafter", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: filing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing" ("created_on", "changed_on", "id", "uploaddate", "pagecount", "totalfees", "filing_attorney", "filing_prosecutor", "assessedfees", "receiptverified", "amountpaid", "feebalance", "paymenthistory", "case", "urgent", "urgentreason", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: filing_filingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_filingtype" ("filing", "filingtype") FROM stdin;
\.


--
-- Data for Name: filing_filingtype_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_filingtype_version" ("filing", "filingtype", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: filing_payment; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_payment" ("filing", "payment") FROM stdin;
\.


--
-- Data for Name: filing_payment_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_payment_version" ("filing", "payment", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: filing_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filing_version" ("created_on", "changed_on", "id", "uploaddate", "pagecount", "totalfees", "filing_attorney", "filing_prosecutor", "assessedfees", "receiptverified", "amountpaid", "feebalance", "paymenthistory", "case", "urgent", "urgentreason", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: filingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filingtype" ("created_on", "changed_on", "name", "description", "notes", "id", "fees", "perpagecost", "paid_per_page", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: filingtype_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "filingtype_version" ("created_on", "changed_on", "name", "description", "notes", "id", "fees", "perpagecost", "paid_per_page", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: gateregister; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister" ("created_on", "changed_on", "id", "prison", "opentime", "closedtime", "openduration", "movementdirection", "reason", "staffmovement", "goodsmovement", "vehicle_reg", "vehicle_color", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: gateregister_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister_version" ("created_on", "changed_on", "id", "prison", "opentime", "closedtime", "openduration", "movementdirection", "reason", "staffmovement", "goodsmovement", "vehicle_reg", "vehicle_color", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: gateregister_warder; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister_warder" ("gateregister", "warder") FROM stdin;
\.


--
-- Data for Name: gateregister_warder_2; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister_warder_2" ("gateregister", "warder") FROM stdin;
\.


--
-- Data for Name: gateregister_warder_2_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister_warder_2_version" ("gateregister", "warder", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: gateregister_warder_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gateregister_warder_version" ("gateregister", "warder", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: gender; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gender" ("created_on", "changed_on", "description", "notes", "id", "name", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: gender_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "gender_version" ("created_on", "changed_on", "description", "notes", "id", "name", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "hearingdate", "adjourned", "completed", "case", "court", "remandwarrant", "hearing_type", "remanddays", "remanddate", "remandwarrantexpirydate", "nexthearingdate", "finalhearing", "transcript", "audio", "video", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: hearing_judicialofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_judicialofficer" ("hearing", "judicialofficer") FROM stdin;
\.


--
-- Data for Name: hearing_judicialofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_judicialofficer_version" ("hearing", "judicialofficer", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_lawyers; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_lawyers" ("hearing", "lawyers") FROM stdin;
\.


--
-- Data for Name: hearing_lawyers_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_lawyers_version" ("hearing", "lawyers", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_polofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_polofficer" ("hearing", "polofficer") FROM stdin;
\.


--
-- Data for Name: hearing_polofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_polofficer_version" ("hearing", "polofficer", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_prosecutor" ("hearing", "prosecutor") FROM stdin;
\.


--
-- Data for Name: hearing_prosecutor_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_prosecutor_version" ("hearing", "prosecutor", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_tag; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_tag" ("hearing", "tag") FROM stdin;
\.


--
-- Data for Name: hearing_tag_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_tag_version" ("hearing", "tag", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_version" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "hearingdate", "adjourned", "completed", "case", "court", "remandwarrant", "hearing_type", "remanddays", "remanddate", "remandwarrantexpirydate", "nexthearingdate", "finalhearing", "transcript", "audio", "video", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearing_witness; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_witness" ("hearing", "witness") FROM stdin;
\.


--
-- Data for Name: hearing_witness_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearing_witness_version" ("hearing", "witness", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: hearingtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearingtype" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: hearingtype_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "hearingtype_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: investigation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "case", "actiondate", "evidence", "narrative", "weather", "location", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: investigation_polofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_polofficer" ("investigation", "polofficer") FROM stdin;
\.


--
-- Data for Name: investigation_polofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_polofficer_version" ("investigation", "polofficer", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: investigation_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_version" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "case", "actiondate", "evidence", "narrative", "weather", "location", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: investigation_witness; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_witness" ("investigation", "witness") FROM stdin;
\.


--
-- Data for Name: investigation_witness_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "investigation_witness_version" ("investigation", "witness", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: jo_rank; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "jo_rank" ("created_on", "changed_on", "name", "description", "notes", "id", "appelation", "informaladdress", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: jo_rank_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "jo_rank_version" ("created_on", "changed_on", "name", "description", "notes", "id", "appelation", "informaladdress", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: judicialofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "judicialofficer" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "j_o__rank", "gender", "court", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: judicialofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "judicialofficer_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "j_o__rank", "gender", "court", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: lawfirm; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "lawfirm" ("created_on", "changed_on", "name", "description", "notes", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: lawfirm_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "lawfirm_version" ("created_on", "changed_on", "name", "description", "notes", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: lawyers; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "lawyers" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "barnumber", "law_firm", "admissiondate", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: lawyers_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "lawyers_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "barnumber", "law_firm", "admissiondate", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: medevent; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "medevent" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: medevent_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "medevent_version" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: natureofsuit; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "natureofsuit" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: natureofsuit_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "natureofsuit_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "payment" ("created_on", "changed_on", "id", "datepaid", "amount", "paymentreference", "paymentconfirmed", "paidby", "msisdn", "receiptnumber", "ispartial", "bail", "billrefnumber", "payment_method", "paymentdescription", "case", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: payment_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "payment_version" ("created_on", "changed_on", "id", "datepaid", "amount", "paymentreference", "paymentconfirmed", "paidby", "msisdn", "receiptnumber", "ispartial", "bail", "billrefnumber", "payment_method", "paymentdescription", "case", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: paymentmethod; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "paymentmethod" ("created_on", "changed_on", "name", "description", "notes", "id", "key", "secret", "portal", "tillnumber", "shortcode", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: paymentmethod_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "paymentmethod_version" ("created_on", "changed_on", "name", "description", "notes", "id", "key", "secret", "portal", "tillnumber", "shortcode", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: plaintiff; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "plaintiff" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "juvenile", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: plaintiff_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "plaintiff_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "juvenile", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: policerank; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerank" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policerank_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerank_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: policerole; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerole" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policerole_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policerole_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: policestation; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policestation" ("created_on", "changed_on", "name", "description", "notes", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "town", "has_forensic_lab", "officercommanding", "police_station_type", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policestation_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policestation_version" ("created_on", "changed_on", "name", "description", "notes", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "town", "has_forensic_lab", "officercommanding", "police_station_type", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: policestationtype; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policestationtype" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: policestationtype_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "policestationtype_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: polofficer; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "polofficer" ("created_on", "changed_on", "id", "police_rank", "gender", "servicenumber", "reports_to", "pol_supervisor", "postdate", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: polofficer_policerole; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "polofficer_policerole" ("polofficer", "policerole") FROM stdin;
\.


--
-- Data for Name: polofficer_policerole_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "polofficer_policerole_version" ("polofficer", "policerole", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: polofficer_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "polofficer_version" ("created_on", "changed_on", "id", "police_rank", "gender", "servicenumber", "reports_to", "pol_supervisor", "postdate", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prison; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prison" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "town", "warden", "capacity", "population", "cellcount", "gatecount", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prison_securityrank; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prison_securityrank" ("prison", "securityrank") FROM stdin;
\.


--
-- Data for Name: prison_securityrank_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prison_securityrank_version" ("prison", "securityrank", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prison_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prison_version" ("created_on", "changed_on", "place_name", "lat", "lng", "alt", "map", "info", "pin", "pin_color", "pin_icon", "centered", "nearest_feature", "id", "town", "warden", "capacity", "population", "cellcount", "gatecount", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prisoncell; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncell" ("created_on", "changed_on", "id", "prison", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prisoncell_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncell_version" ("created_on", "changed_on", "id", "prison", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prisoncommital; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncommital" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "prison", "warrantno", "defendant", "hearing", "warrantdate", "hascourtdate", "judicial_officer_warrant", "warrant", "warrantduration", "warrantexpiry", "history", "earliestrelease", "releasedate", "property", "itemcount", "releasenotes", "commitalnotes", "police_officer_commiting", "paroledate", "escaped", "escapedate", "escapedetails", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prisoncommital_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncommital_version" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "prison", "warrantno", "defendant", "hearing", "warrantdate", "hascourtdate", "judicial_officer_warrant", "warrant", "warrantduration", "warrantexpiry", "history", "earliestrelease", "releasedate", "property", "itemcount", "releasenotes", "commitalnotes", "police_officer_commiting", "paroledate", "escaped", "escapedate", "escapedetails", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prisoncommital_warder; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncommital_warder" ("prisoncommital_prison", "prisoncommital_warrantno", "warder") FROM stdin;
\.


--
-- Data for Name: prisoncommital_warder_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisoncommital_warder_version" ("prisoncommital_prison", "prisoncommital_warrantno", "warder", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prisonerproperty; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisonerproperty" ("created_on", "changed_on", "name", "description", "notes", "id", "prison_commital_prison", "prison_commital_warrantno", "receipted", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prisonerproperty_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prisonerproperty_version" ("created_on", "changed_on", "name", "description", "notes", "id", "prison_commital_prison", "prison_commital_warrantno", "receipted", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prosecutor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prosecutor_prosecutorteam; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor_prosecutorteam" ("prosecutor", "prosecutorteam") FROM stdin;
\.


--
-- Data for Name: prosecutor_prosecutorteam_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor_prosecutorteam_version" ("prosecutor", "prosecutorteam", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prosecutor_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutor_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: prosecutorteam; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutorteam" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: prosecutorteam_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "prosecutorteam_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: remission; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "remission" ("created_on", "changed_on", "id", "prison_commital_prison", "prison_commital_warrantno", "daysearned", "dateearned", "amount", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: remission_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "remission_version" ("created_on", "changed_on", "id", "prison_commital_prison", "prison_commital_warrantno", "daysearned", "dateearned", "amount", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: securityrank; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "securityrank" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: securityrank_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "securityrank_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: subcounty; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "subcounty" ("created_on", "changed_on", "name", "description", "notes", "id", "county", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: subcounty_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "subcounty_version" ("created_on", "changed_on", "name", "description", "notes", "id", "county", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: surety; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "surety" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: surety_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "surety_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "tag" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
2017-09-28 11:40:23.156337	2017-09-28 11:40:23.156346	Serious Crime	Serious Crime		1	1	1
2017-09-28 11:40:35.455123	2017-09-28 11:40:35.455135	Felony	Felony		2	1	1
2017-09-28 11:41:16.883083	2017-09-28 11:41:16.8831	Misdemeanor	Misdemeanor		3	1	1
\.


--
-- Data for Name: tag_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "tag_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
2017-09-28 11:40:23.156337	2017-09-28 11:40:23.156346	Serious Crime	Serious Crime		1	1	1	17	\N	0
2017-09-28 11:40:35.455123	2017-09-28 11:40:35.455135	Felony	Felony		2	1	1	18	\N	0
2017-09-28 11:41:16.883083	2017-09-28 11:41:16.8831	Misdemeanor	Misdemeanor		3	1	1	19	\N	0
\.


--
-- Data for Name: town; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "town" ("created_on", "changed_on", "name", "description", "notes", "id", "subcounty", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: town_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "town_version" ("created_on", "changed_on", "name", "description", "notes", "id", "subcounty", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "transaction" ("issued_at", "id", "remote_addr", "user_id") FROM stdin;
2017-09-28 08:40:23.154203	17	\N	\N
2017-09-28 08:40:35.453497	18	\N	\N
2017-09-28 08:41:16.881029	19	\N	\N
\.


--
-- Data for Name: visit; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "visit" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "vistors", "defendants", "visitdate", "visitnotes", "visitduration", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: visit_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "visit_version" ("created_on", "changed_on", "priority", "segment", "task_group", "sequence", "action", "activity_description", "goal", "status", "planned_start", "actual_start", "start_delay", "start_notes", "planned_end", "actual_end", "end_delay", "end_notes", "deadline", "not_started", "early_start", "late_start", "completed", "early_end", "late_end", "deviation_expected", "contingency_plan", "budget", "spend_td", "balance_avail", "over_budget", "under_budget", "vistors", "defendants", "visitdate", "visitnotes", "visitduration", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: visitor; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "visitor" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: visitor_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "visitor_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "gender", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: warder; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "warder" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "prison", "warder_rank", "reports_to", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: warder_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "warder_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "prison", "warder_rank", "reports_to", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: warderrank; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "warderrank" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: warderrank_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "warderrank_version" ("created_on", "changed_on", "name", "description", "notes", "id", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Data for Name: witness; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "witness" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "fordefense", "gender", "changed_by_fk", "created_by_fk") FROM stdin;
\.


--
-- Data for Name: witness_version; Type: TABLE DATA; Schema: public; Owner: nyimbi
--

COPY "witness_version" ("created_on", "changed_on", "firstname", "surname", "othernames", "dob", "marital_status", "photo", "age_today", "mobile", "other_mobile", "fixed_line", "other_fixed_line", "email", "other_email", "address_line_1", "address_line_2", "zipcode", "town", "country", "facebook", "twitter", "instagram", "whatsapp", "other_whatsapp", "fax", "gcode", "okhi", "id", "fordefense", "gender", "changed_by_fk", "created_by_fk", "transaction_id", "end_transaction_id", "operation_type") FROM stdin;
\.


--
-- Name: ab_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_id_seq"', 16, true);


--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_view_id_seq"', 540, true);


--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_permission_view_role_id_seq"', 540, true);


--
-- Name: ab_register_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_register_user_id_seq"', 1, false);


--
-- Name: ab_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_role_id_seq"', 2, true);


--
-- Name: ab_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_user_id_seq"', 1, true);


--
-- Name: ab_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_user_role_id_seq"', 1, true);


--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"ab_view_menu_id_seq"', 201, true);


--
-- Name: bail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"bail_id_seq"', 1, false);


--
-- Name: case_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"case_id_seq"', 1, false);


--
-- Name: casecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"casecategory_id_seq"', 1, false);


--
-- Name: causeofaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"causeofaction_id_seq"', 1, false);


--
-- Name: commitaltype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"commitaltype_id_seq"', 1, false);


--
-- Name: constituency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"constituency_id_seq"', 1, false);


--
-- Name: county_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"county_id_seq"', 1, false);


--
-- Name: court_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"court_id_seq"', 1, false);


--
-- Name: courtlevel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"courtlevel_id_seq"', 1, false);


--
-- Name: courtstation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"courtstation_id_seq"', 1, false);


--
-- Name: defendant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"defendant_id_seq"', 1, false);


--
-- Name: discipline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"discipline_id_seq"', 1, false);


--
-- Name: doc_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"doc_store_id_seq"', 1, false);


--
-- Name: docarchive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"docarchive_id_seq"', 1, false);


--
-- Name: doctemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"doctemplate_id_seq"', 1, false);


--
-- Name: document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"document_id_seq"', 1, false);


--
-- Name: eventlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"eventlog_id_seq"', 1, false);


--
-- Name: filing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"filing_id_seq"', 1, false);


--
-- Name: filingtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"filingtype_id_seq"', 1, false);


--
-- Name: gateregister_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"gateregister_id_seq"', 1, false);


--
-- Name: gender_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"gender_id_seq"', 26, true);


--
-- Name: hearing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"hearing_id_seq"', 1, false);


--
-- Name: hearingtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"hearingtype_id_seq"', 1, false);


--
-- Name: investigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"investigation_id_seq"', 1, false);


--
-- Name: jo_rank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"jo_rank_id_seq"', 1, false);


--
-- Name: judicialofficer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"judicialofficer_id_seq"', 1, false);


--
-- Name: lawfirm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"lawfirm_id_seq"', 1, false);


--
-- Name: lawyers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"lawyers_id_seq"', 1, false);


--
-- Name: medevent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"medevent_id_seq"', 1, false);


--
-- Name: natureofsuit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"natureofsuit_id_seq"', 1, false);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"payment_id_seq"', 1, false);


--
-- Name: paymentmethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"paymentmethod_id_seq"', 1, false);


--
-- Name: plaintiff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"plaintiff_id_seq"', 1, false);


--
-- Name: policerank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policerank_id_seq"', 1, false);


--
-- Name: policerole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policerole_id_seq"', 1, false);


--
-- Name: policestation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policestation_id_seq"', 1, false);


--
-- Name: policestationtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"policestationtype_id_seq"', 1, false);


--
-- Name: polofficer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"polofficer_id_seq"', 1, false);


--
-- Name: prison_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prison_id_seq"', 1, false);


--
-- Name: prisoncell_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prisoncell_id_seq"', 1, false);


--
-- Name: prisonerproperty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prisonerproperty_id_seq"', 1, false);


--
-- Name: prosecutor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prosecutor_id_seq"', 1, false);


--
-- Name: prosecutorteam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"prosecutorteam_id_seq"', 1, false);


--
-- Name: remission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"remission_id_seq"', 1, false);


--
-- Name: securityrank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"securityrank_id_seq"', 1, false);


--
-- Name: subcounty_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"subcounty_id_seq"', 1, false);


--
-- Name: surety_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"surety_id_seq"', 1, false);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"tag_id_seq"', 3, true);


--
-- Name: town_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"town_id_seq"', 1, false);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"transaction_id_seq"', 29, true);


--
-- Name: visitor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"visitor_id_seq"', 1, false);


--
-- Name: warder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"warder_id_seq"', 1, false);


--
-- Name: warderrank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"warderrank_id_seq"', 1, false);


--
-- Name: witness_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nyimbi
--

SELECT pg_catalog.setval('"witness_id_seq"', 1, false);


--
-- Name: ab_permission ab_permission_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission"
    ADD CONSTRAINT "ab_permission_name_key" UNIQUE ("name");


--
-- Name: ab_permission ab_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission"
    ADD CONSTRAINT "ab_permission_pkey" PRIMARY KEY ("id");


--
-- Name: ab_permission_view ab_permission_view_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_pkey" PRIMARY KEY ("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_register_user ab_register_user_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_register_user"
    ADD CONSTRAINT "ab_register_user_pkey" PRIMARY KEY ("id");


--
-- Name: ab_register_user ab_register_user_username_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_register_user"
    ADD CONSTRAINT "ab_register_user_username_key" UNIQUE ("username");


--
-- Name: ab_role ab_role_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_role"
    ADD CONSTRAINT "ab_role_name_key" UNIQUE ("name");


--
-- Name: ab_role ab_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_role"
    ADD CONSTRAINT "ab_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user ab_user_email_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_email_key" UNIQUE ("email");


--
-- Name: ab_user ab_user_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user_role ab_user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_pkey" PRIMARY KEY ("id");


--
-- Name: ab_user ab_user_username_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_username_key" UNIQUE ("username");


--
-- Name: ab_view_menu ab_view_menu_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_view_menu"
    ADD CONSTRAINT "ab_view_menu_name_key" UNIQUE ("name");


--
-- Name: ab_view_menu ab_view_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_view_menu"
    ADD CONSTRAINT "ab_view_menu_pkey" PRIMARY KEY ("id");


--
-- Name: bail bail_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_pkey" PRIMARY KEY ("id");


--
-- Name: bail_surety bail_surety_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_pkey" PRIMARY KEY ("bail", "surety");


--
-- Name: bail_surety_version bail_surety_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety_version"
    ADD CONSTRAINT "bail_surety_version_pkey" PRIMARY KEY ("bail", "surety", "transaction_id");


--
-- Name: bail_version bail_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_version"
    ADD CONSTRAINT "bail_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: case_casecategory case_casecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_casecategory"
    ADD CONSTRAINT "case_casecategory_pkey" PRIMARY KEY ("case", "casecategory");


--
-- Name: case_casecategory_version case_casecategory_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_casecategory_version"
    ADD CONSTRAINT "case_casecategory_version_pkey" PRIMARY KEY ("case", "casecategory", "transaction_id");


--
-- Name: case_causeofaction case_causeofaction_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_pkey" PRIMARY KEY ("case", "causeofaction");


--
-- Name: case_causeofaction_version case_causeofaction_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction_version"
    ADD CONSTRAINT "case_causeofaction_version_pkey" PRIMARY KEY ("case", "causeofaction", "transaction_id");


--
-- Name: case_defendant case_defendant_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_pkey" PRIMARY KEY ("case", "defendant");


--
-- Name: case_defendant_version case_defendant_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant_version"
    ADD CONSTRAINT "case_defendant_version_pkey" PRIMARY KEY ("case", "defendant", "transaction_id");


--
-- Name: case_natureofsuit case_natureofsuit_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_pkey" PRIMARY KEY ("case", "natureofsuit");


--
-- Name: case_natureofsuit_version case_natureofsuit_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit_version"
    ADD CONSTRAINT "case_natureofsuit_version_pkey" PRIMARY KEY ("case", "natureofsuit", "transaction_id");


--
-- Name: case case_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_pkey" PRIMARY KEY ("id");


--
-- Name: case_plaintiff case_plaintiff_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_pkey" PRIMARY KEY ("case", "plaintiff");


--
-- Name: case_plaintiff_version case_plaintiff_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff_version"
    ADD CONSTRAINT "case_plaintiff_version_pkey" PRIMARY KEY ("case", "plaintiff", "transaction_id");


--
-- Name: case_polofficer case_polofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_polofficer"
    ADD CONSTRAINT "case_polofficer_pkey" PRIMARY KEY ("case", "polofficer");


--
-- Name: case_polofficer_version case_polofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_polofficer_version"
    ADD CONSTRAINT "case_polofficer_version_pkey" PRIMARY KEY ("case", "polofficer", "transaction_id");


--
-- Name: case_prosecutor_2 case_prosecutor_2_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor_2"
    ADD CONSTRAINT "case_prosecutor_2_pkey" PRIMARY KEY ("case", "prosecutor");


--
-- Name: case_prosecutor_2_version case_prosecutor_2_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor_2_version"
    ADD CONSTRAINT "case_prosecutor_2_version_pkey" PRIMARY KEY ("case", "prosecutor", "transaction_id");


--
-- Name: case_prosecutor case_prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_pkey" PRIMARY KEY ("case", "prosecutor");


--
-- Name: case_prosecutor_version case_prosecutor_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor_version"
    ADD CONSTRAINT "case_prosecutor_version_pkey" PRIMARY KEY ("case", "prosecutor", "transaction_id");


--
-- Name: case_tag case_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_tag"
    ADD CONSTRAINT "case_tag_pkey" PRIMARY KEY ("case", "tag");


--
-- Name: case_tag_version case_tag_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_tag_version"
    ADD CONSTRAINT "case_tag_version_pkey" PRIMARY KEY ("case", "tag", "transaction_id");


--
-- Name: case_version case_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_version"
    ADD CONSTRAINT "case_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: case_witness case_witness_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_witness"
    ADD CONSTRAINT "case_witness_pkey" PRIMARY KEY ("case", "witness");


--
-- Name: case_witness_version case_witness_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_witness_version"
    ADD CONSTRAINT "case_witness_version_pkey" PRIMARY KEY ("case", "witness", "transaction_id");


--
-- Name: casecategory casecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "casecategory"
    ADD CONSTRAINT "casecategory_pkey" PRIMARY KEY ("id");


--
-- Name: casecategory_version casecategory_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "casecategory_version"
    ADD CONSTRAINT "casecategory_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: caseinvestigation caseinvestigation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "caseinvestigation"
    ADD CONSTRAINT "caseinvestigation_pkey" PRIMARY KEY ("pol_officers", "cases");


--
-- Name: caseinvestigation_version caseinvestigation_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "caseinvestigation_version"
    ADD CONSTRAINT "caseinvestigation_version_pkey" PRIMARY KEY ("pol_officers", "cases", "transaction_id");


--
-- Name: causeofaction_filing causeofaction_filing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_pkey" PRIMARY KEY ("causeofaction", "filing");


--
-- Name: causeofaction_filing_version causeofaction_filing_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing_version"
    ADD CONSTRAINT "causeofaction_filing_version_pkey" PRIMARY KEY ("causeofaction", "filing", "transaction_id");


--
-- Name: causeofaction_hearing causeofaction_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_pkey" PRIMARY KEY ("causeofaction", "hearing");


--
-- Name: causeofaction_hearing_version causeofaction_hearing_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing_version"
    ADD CONSTRAINT "causeofaction_hearing_version_pkey" PRIMARY KEY ("causeofaction", "hearing", "transaction_id");


--
-- Name: causeofaction causeofaction_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_pkey" PRIMARY KEY ("id");


--
-- Name: causeofaction_version causeofaction_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_version"
    ADD CONSTRAINT "causeofaction_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: commitaltype commitaltype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype"
    ADD CONSTRAINT "commitaltype_pkey" PRIMARY KEY ("id");


--
-- Name: commitaltype_prisoncommital commitaltype_prisoncommital_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype_prisoncommital"
    ADD CONSTRAINT "commitaltype_prisoncommital_pkey" PRIMARY KEY ("commitaltype", "prisoncommital_prison", "prisoncommital_warrantno");


--
-- Name: commitaltype_prisoncommital_version commitaltype_prisoncommital_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype_prisoncommital_version"
    ADD CONSTRAINT "commitaltype_prisoncommital_version_pkey" PRIMARY KEY ("commitaltype", "prisoncommital_prison", "prisoncommital_warrantno", "transaction_id");


--
-- Name: commitaltype_version commitaltype_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype_version"
    ADD CONSTRAINT "commitaltype_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: constituency constituency_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_pkey" PRIMARY KEY ("id");


--
-- Name: constituency_version constituency_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency_version"
    ADD CONSTRAINT "constituency_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: county county_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "county"
    ADD CONSTRAINT "county_pkey" PRIMARY KEY ("id");


--
-- Name: county_version county_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "county_version"
    ADD CONSTRAINT "county_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: court court_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_pkey" PRIMARY KEY ("id");


--
-- Name: court_version court_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court_version"
    ADD CONSTRAINT "court_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: courtlevel courtlevel_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_pkey" PRIMARY KEY ("id");


--
-- Name: courtlevel_version courtlevel_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel_version"
    ADD CONSTRAINT "courtlevel_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: courtstation courtstation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation"
    ADD CONSTRAINT "courtstation_pkey" PRIMARY KEY ("id");


--
-- Name: courtstation_version courtstation_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation_version"
    ADD CONSTRAINT "courtstation_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: defendant_gateregister defendant_gateregister_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_gateregister"
    ADD CONSTRAINT "defendant_gateregister_pkey" PRIMARY KEY ("defendant", "gateregister");


--
-- Name: defendant_gateregister_version defendant_gateregister_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_gateregister_version"
    ADD CONSTRAINT "defendant_gateregister_version_pkey" PRIMARY KEY ("defendant", "gateregister", "transaction_id");


--
-- Name: defendant_hearing defendant_hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_pkey" PRIMARY KEY ("defendant", "hearing");


--
-- Name: defendant_hearing_version defendant_hearing_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing_version"
    ADD CONSTRAINT "defendant_hearing_version_pkey" PRIMARY KEY ("defendant", "hearing", "transaction_id");


--
-- Name: defendant_medevent defendant_medevent_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_medevent"
    ADD CONSTRAINT "defendant_medevent_pkey" PRIMARY KEY ("defendant", "medevent");


--
-- Name: defendant_medevent_version defendant_medevent_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_medevent_version"
    ADD CONSTRAINT "defendant_medevent_version_pkey" PRIMARY KEY ("defendant", "medevent", "transaction_id");


--
-- Name: defendant defendant_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_pkey" PRIMARY KEY ("id");


--
-- Name: defendant_version defendant_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_version"
    ADD CONSTRAINT "defendant_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: discipline discipline_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline"
    ADD CONSTRAINT "discipline_pkey" PRIMARY KEY ("id");


--
-- Name: discipline_version discipline_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline_version"
    ADD CONSTRAINT "discipline_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: doc_store doc_store_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doc_store"
    ADD CONSTRAINT "doc_store_pkey" PRIMARY KEY ("id");


--
-- Name: docarchive docarchive_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive"
    ADD CONSTRAINT "docarchive_pkey" PRIMARY KEY ("id");


--
-- Name: docarchive_tag docarchive_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive_tag"
    ADD CONSTRAINT "docarchive_tag_pkey" PRIMARY KEY ("docarchive", "tag");


--
-- Name: docarchive_tag_version docarchive_tag_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive_tag_version"
    ADD CONSTRAINT "docarchive_tag_version_pkey" PRIMARY KEY ("docarchive", "tag", "transaction_id");


--
-- Name: docarchive_version docarchive_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive_version"
    ADD CONSTRAINT "docarchive_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: doctemplate doctemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_pkey" PRIMARY KEY ("id");


--
-- Name: doctemplate_version doctemplate_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate_version"
    ADD CONSTRAINT "doctemplate_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_pkey" PRIMARY KEY ("id");


--
-- Name: document_tag document_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_tag"
    ADD CONSTRAINT "document_tag_pkey" PRIMARY KEY ("document", "tag");


--
-- Name: document_tag_version document_tag_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_tag_version"
    ADD CONSTRAINT "document_tag_version_pkey" PRIMARY KEY ("document", "tag", "transaction_id");


--
-- Name: document_version document_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_version"
    ADD CONSTRAINT "document_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: eventlog eventlog_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "eventlog"
    ADD CONSTRAINT "eventlog_pkey" PRIMARY KEY ("id");


--
-- Name: eventlog_version eventlog_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "eventlog_version"
    ADD CONSTRAINT "eventlog_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: filing_filingtype filing_filingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_pkey" PRIMARY KEY ("filing", "filingtype");


--
-- Name: filing_filingtype_version filing_filingtype_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype_version"
    ADD CONSTRAINT "filing_filingtype_version_pkey" PRIMARY KEY ("filing", "filingtype", "transaction_id");


--
-- Name: filing_payment filing_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_payment"
    ADD CONSTRAINT "filing_payment_pkey" PRIMARY KEY ("filing", "payment");


--
-- Name: filing_payment_version filing_payment_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_payment_version"
    ADD CONSTRAINT "filing_payment_version_pkey" PRIMARY KEY ("filing", "payment", "transaction_id");


--
-- Name: filing filing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_pkey" PRIMARY KEY ("id");


--
-- Name: filing_version filing_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_version"
    ADD CONSTRAINT "filing_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: filingtype filingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_pkey" PRIMARY KEY ("id");


--
-- Name: filingtype_version filingtype_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype_version"
    ADD CONSTRAINT "filingtype_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: gateregister gateregister_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister"
    ADD CONSTRAINT "gateregister_pkey" PRIMARY KEY ("id");


--
-- Name: gateregister_version gateregister_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_version"
    ADD CONSTRAINT "gateregister_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: gateregister_warder_2 gateregister_warder_2_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder_2"
    ADD CONSTRAINT "gateregister_warder_2_pkey" PRIMARY KEY ("gateregister", "warder");


--
-- Name: gateregister_warder_2_version gateregister_warder_2_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder_2_version"
    ADD CONSTRAINT "gateregister_warder_2_version_pkey" PRIMARY KEY ("gateregister", "warder", "transaction_id");


--
-- Name: gateregister_warder gateregister_warder_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder"
    ADD CONSTRAINT "gateregister_warder_pkey" PRIMARY KEY ("gateregister", "warder");


--
-- Name: gateregister_warder_version gateregister_warder_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder_version"
    ADD CONSTRAINT "gateregister_warder_version_pkey" PRIMARY KEY ("gateregister", "warder", "transaction_id");


--
-- Name: gender gender_name_key; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_name_key" UNIQUE ("name");


--
-- Name: gender gender_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_pkey" PRIMARY KEY ("id");


--
-- Name: gender_version gender_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender_version"
    ADD CONSTRAINT "gender_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: hearing_judicialofficer hearing_judicialofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judicialofficer"
    ADD CONSTRAINT "hearing_judicialofficer_pkey" PRIMARY KEY ("hearing", "judicialofficer");


--
-- Name: hearing_judicialofficer_version hearing_judicialofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judicialofficer_version"
    ADD CONSTRAINT "hearing_judicialofficer_version_pkey" PRIMARY KEY ("hearing", "judicialofficer", "transaction_id");


--
-- Name: hearing_lawyers hearing_lawyers_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_lawyers"
    ADD CONSTRAINT "hearing_lawyers_pkey" PRIMARY KEY ("hearing", "lawyers");


--
-- Name: hearing_lawyers_version hearing_lawyers_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_lawyers_version"
    ADD CONSTRAINT "hearing_lawyers_version_pkey" PRIMARY KEY ("hearing", "lawyers", "transaction_id");


--
-- Name: hearing hearing_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_pkey" PRIMARY KEY ("id");


--
-- Name: hearing_polofficer hearing_polofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_polofficer"
    ADD CONSTRAINT "hearing_polofficer_pkey" PRIMARY KEY ("hearing", "polofficer");


--
-- Name: hearing_polofficer_version hearing_polofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_polofficer_version"
    ADD CONSTRAINT "hearing_polofficer_version_pkey" PRIMARY KEY ("hearing", "polofficer", "transaction_id");


--
-- Name: hearing_prosecutor hearing_prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_pkey" PRIMARY KEY ("hearing", "prosecutor");


--
-- Name: hearing_prosecutor_version hearing_prosecutor_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor_version"
    ADD CONSTRAINT "hearing_prosecutor_version_pkey" PRIMARY KEY ("hearing", "prosecutor", "transaction_id");


--
-- Name: hearing_tag hearing_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_tag"
    ADD CONSTRAINT "hearing_tag_pkey" PRIMARY KEY ("hearing", "tag");


--
-- Name: hearing_tag_version hearing_tag_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_tag_version"
    ADD CONSTRAINT "hearing_tag_version_pkey" PRIMARY KEY ("hearing", "tag", "transaction_id");


--
-- Name: hearing_version hearing_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_version"
    ADD CONSTRAINT "hearing_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: hearing_witness hearing_witness_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_witness"
    ADD CONSTRAINT "hearing_witness_pkey" PRIMARY KEY ("hearing", "witness");


--
-- Name: hearing_witness_version hearing_witness_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_witness_version"
    ADD CONSTRAINT "hearing_witness_version_pkey" PRIMARY KEY ("hearing", "witness", "transaction_id");


--
-- Name: hearingtype hearingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_pkey" PRIMARY KEY ("id");


--
-- Name: hearingtype_version hearingtype_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype_version"
    ADD CONSTRAINT "hearingtype_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: investigation investigation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_pkey" PRIMARY KEY ("id");


--
-- Name: investigation_polofficer investigation_polofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_polofficer"
    ADD CONSTRAINT "investigation_polofficer_pkey" PRIMARY KEY ("investigation", "polofficer");


--
-- Name: investigation_polofficer_version investigation_polofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_polofficer_version"
    ADD CONSTRAINT "investigation_polofficer_version_pkey" PRIMARY KEY ("investigation", "polofficer", "transaction_id");


--
-- Name: investigation_version investigation_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_version"
    ADD CONSTRAINT "investigation_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: investigation_witness investigation_witness_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_witness"
    ADD CONSTRAINT "investigation_witness_pkey" PRIMARY KEY ("investigation", "witness");


--
-- Name: investigation_witness_version investigation_witness_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_witness_version"
    ADD CONSTRAINT "investigation_witness_version_pkey" PRIMARY KEY ("investigation", "witness", "transaction_id");


--
-- Name: jo_rank jo_rank_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "jo_rank"
    ADD CONSTRAINT "jo_rank_pkey" PRIMARY KEY ("id");


--
-- Name: jo_rank_version jo_rank_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "jo_rank_version"
    ADD CONSTRAINT "jo_rank_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: judicialofficer judicialofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_pkey" PRIMARY KEY ("id");


--
-- Name: judicialofficer_version judicialofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer_version"
    ADD CONSTRAINT "judicialofficer_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: lawfirm lawfirm_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_pkey" PRIMARY KEY ("id");


--
-- Name: lawfirm_version lawfirm_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm_version"
    ADD CONSTRAINT "lawfirm_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: lawyers lawyers_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers"
    ADD CONSTRAINT "lawyers_pkey" PRIMARY KEY ("id");


--
-- Name: lawyers_version lawyers_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers_version"
    ADD CONSTRAINT "lawyers_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: medevent medevent_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "medevent"
    ADD CONSTRAINT "medevent_pkey" PRIMARY KEY ("id");


--
-- Name: medevent_version medevent_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "medevent_version"
    ADD CONSTRAINT "medevent_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: natureofsuit natureofsuit_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_pkey" PRIMARY KEY ("id");


--
-- Name: natureofsuit_version natureofsuit_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit_version"
    ADD CONSTRAINT "natureofsuit_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_pkey" PRIMARY KEY ("id");


--
-- Name: payment_version payment_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment_version"
    ADD CONSTRAINT "payment_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: paymentmethod paymentmethod_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "paymentmethod"
    ADD CONSTRAINT "paymentmethod_pkey" PRIMARY KEY ("id");


--
-- Name: paymentmethod_version paymentmethod_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "paymentmethod_version"
    ADD CONSTRAINT "paymentmethod_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: plaintiff plaintiff_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_pkey" PRIMARY KEY ("id");


--
-- Name: plaintiff_version plaintiff_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff_version"
    ADD CONSTRAINT "plaintiff_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: policerank policerank_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerank"
    ADD CONSTRAINT "policerank_pkey" PRIMARY KEY ("id");


--
-- Name: policerank_version policerank_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerank_version"
    ADD CONSTRAINT "policerank_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: policerole policerole_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_pkey" PRIMARY KEY ("id");


--
-- Name: policerole_version policerole_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole_version"
    ADD CONSTRAINT "policerole_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: policestation policestation_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_pkey" PRIMARY KEY ("id");


--
-- Name: policestation_version policestation_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation_version"
    ADD CONSTRAINT "policestation_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: policestationtype policestationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestationtype"
    ADD CONSTRAINT "policestationtype_pkey" PRIMARY KEY ("id");


--
-- Name: policestationtype_version policestationtype_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestationtype_version"
    ADD CONSTRAINT "policestationtype_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: polofficer polofficer_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_pkey" PRIMARY KEY ("id");


--
-- Name: polofficer_policerole polofficer_policerole_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer_policerole"
    ADD CONSTRAINT "polofficer_policerole_pkey" PRIMARY KEY ("polofficer", "policerole");


--
-- Name: polofficer_policerole_version polofficer_policerole_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer_policerole_version"
    ADD CONSTRAINT "polofficer_policerole_version_pkey" PRIMARY KEY ("polofficer", "policerole", "transaction_id");


--
-- Name: polofficer_version polofficer_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer_version"
    ADD CONSTRAINT "polofficer_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: prison prison_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_pkey" PRIMARY KEY ("id");


--
-- Name: prison_securityrank prison_securityrank_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison_securityrank"
    ADD CONSTRAINT "prison_securityrank_pkey" PRIMARY KEY ("prison", "securityrank");


--
-- Name: prison_securityrank_version prison_securityrank_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison_securityrank_version"
    ADD CONSTRAINT "prison_securityrank_version_pkey" PRIMARY KEY ("prison", "securityrank", "transaction_id");


--
-- Name: prison_version prison_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison_version"
    ADD CONSTRAINT "prison_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: prisoncell prisoncell_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell"
    ADD CONSTRAINT "prisoncell_pkey" PRIMARY KEY ("id");


--
-- Name: prisoncell_version prisoncell_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell_version"
    ADD CONSTRAINT "prisoncell_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: prisoncommital prisoncommital_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_pkey" PRIMARY KEY ("prison", "warrantno");


--
-- Name: prisoncommital_version prisoncommital_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital_version"
    ADD CONSTRAINT "prisoncommital_version_pkey" PRIMARY KEY ("prison", "warrantno", "transaction_id");


--
-- Name: prisoncommital_warder prisoncommital_warder_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital_warder"
    ADD CONSTRAINT "prisoncommital_warder_pkey" PRIMARY KEY ("prisoncommital_prison", "prisoncommital_warrantno", "warder");


--
-- Name: prisoncommital_warder_version prisoncommital_warder_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital_warder_version"
    ADD CONSTRAINT "prisoncommital_warder_version_pkey" PRIMARY KEY ("prisoncommital_prison", "prisoncommital_warrantno", "warder", "transaction_id");


--
-- Name: prisonerproperty prisonerproperty_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty"
    ADD CONSTRAINT "prisonerproperty_pkey" PRIMARY KEY ("id");


--
-- Name: prisonerproperty_version prisonerproperty_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty_version"
    ADD CONSTRAINT "prisonerproperty_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: prosecutor prosecutor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_pkey" PRIMARY KEY ("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_pkey" PRIMARY KEY ("prosecutor", "prosecutorteam");


--
-- Name: prosecutor_prosecutorteam_version prosecutor_prosecutorteam_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam_version"
    ADD CONSTRAINT "prosecutor_prosecutorteam_version_pkey" PRIMARY KEY ("prosecutor", "prosecutorteam", "transaction_id");


--
-- Name: prosecutor_version prosecutor_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_version"
    ADD CONSTRAINT "prosecutor_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: prosecutorteam prosecutorteam_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_pkey" PRIMARY KEY ("id");


--
-- Name: prosecutorteam_version prosecutorteam_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam_version"
    ADD CONSTRAINT "prosecutorteam_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: remission remission_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission"
    ADD CONSTRAINT "remission_pkey" PRIMARY KEY ("id");


--
-- Name: remission_version remission_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission_version"
    ADD CONSTRAINT "remission_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: securityrank securityrank_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "securityrank"
    ADD CONSTRAINT "securityrank_pkey" PRIMARY KEY ("id");


--
-- Name: securityrank_version securityrank_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "securityrank_version"
    ADD CONSTRAINT "securityrank_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: subcounty subcounty_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty"
    ADD CONSTRAINT "subcounty_pkey" PRIMARY KEY ("id");


--
-- Name: subcounty_version subcounty_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty_version"
    ADD CONSTRAINT "subcounty_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: surety surety_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_pkey" PRIMARY KEY ("id");


--
-- Name: surety_version surety_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety_version"
    ADD CONSTRAINT "surety_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: tag tag_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "tag"
    ADD CONSTRAINT "tag_pkey" PRIMARY KEY ("id");


--
-- Name: tag_version tag_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "tag_version"
    ADD CONSTRAINT "tag_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: town town_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_pkey" PRIMARY KEY ("id");


--
-- Name: town_version town_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town_version"
    ADD CONSTRAINT "town_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "transaction"
    ADD CONSTRAINT "transaction_pkey" PRIMARY KEY ("id");


--
-- Name: visit visit_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit"
    ADD CONSTRAINT "visit_pkey" PRIMARY KEY ("vistors", "defendants");


--
-- Name: visit_version visit_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit_version"
    ADD CONSTRAINT "visit_version_pkey" PRIMARY KEY ("vistors", "defendants", "transaction_id");


--
-- Name: visitor visitor_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor"
    ADD CONSTRAINT "visitor_pkey" PRIMARY KEY ("id");


--
-- Name: visitor_version visitor_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor_version"
    ADD CONSTRAINT "visitor_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: warder warder_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_pkey" PRIMARY KEY ("id");


--
-- Name: warder_version warder_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder_version"
    ADD CONSTRAINT "warder_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: warderrank warderrank_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warderrank"
    ADD CONSTRAINT "warderrank_pkey" PRIMARY KEY ("id");


--
-- Name: warderrank_version warderrank_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warderrank_version"
    ADD CONSTRAINT "warderrank_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: witness witness_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness"
    ADD CONSTRAINT "witness_pkey" PRIMARY KEY ("id");


--
-- Name: witness_version witness_version_pkey; Type: CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness_version"
    ADD CONSTRAINT "witness_version_pkey" PRIMARY KEY ("id", "transaction_id");


--
-- Name: idx_commitaltype_prisoncommital; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "idx_commitaltype_prisoncommital" ON "commitaltype_prisoncommital" USING "btree" ("prisoncommital_prison", "prisoncommital_warrantno");


--
-- Name: idx_prisonerproperty__prison_commital_prison_prison_commital_wa; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "idx_prisonerproperty__prison_commital_prison_prison_commital_wa" ON "prisonerproperty" USING "btree" ("prison_commital_prison", "prison_commital_warrantno");


--
-- Name: idx_remission__prison_commital_prison_prison_commital_warrantno; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "idx_remission__prison_commital_prison_prison_commital_warrantno" ON "remission" USING "btree" ("prison_commital_prison", "prison_commital_warrantno");


--
-- Name: ix_bail_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_defendant" ON "bail" USING "btree" ("defendant");


--
-- Name: ix_bail_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_hearing" ON "bail" USING "btree" ("hearing");


--
-- Name: ix_bail_surety_surety; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_surety" ON "bail_surety" USING "btree" ("surety");


--
-- Name: ix_bail_surety_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_version_end_transaction_id" ON "bail_surety_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_bail_surety_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_version_operation_type" ON "bail_surety_version" USING "btree" ("operation_type");


--
-- Name: ix_bail_surety_version_surety; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_version_surety" ON "bail_surety_version" USING "btree" ("surety");


--
-- Name: ix_bail_surety_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_surety_version_transaction_id" ON "bail_surety_version" USING "btree" ("transaction_id");


--
-- Name: ix_bail_version_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_version_defendant" ON "bail_version" USING "btree" ("defendant");


--
-- Name: ix_bail_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_version_end_transaction_id" ON "bail_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_bail_version_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_version_hearing" ON "bail_version" USING "btree" ("hearing");


--
-- Name: ix_bail_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_version_operation_type" ON "bail_version" USING "btree" ("operation_type");


--
-- Name: ix_bail_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_bail_version_transaction_id" ON "bail_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_casecategory_casecategory; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_casecategory_casecategory" ON "case_casecategory" USING "btree" ("casecategory");


--
-- Name: ix_case_casecategory_version_casecategory; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_casecategory_version_casecategory" ON "case_casecategory_version" USING "btree" ("casecategory");


--
-- Name: ix_case_casecategory_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_casecategory_version_end_transaction_id" ON "case_casecategory_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_casecategory_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_casecategory_version_operation_type" ON "case_casecategory_version" USING "btree" ("operation_type");


--
-- Name: ix_case_casecategory_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_casecategory_version_transaction_id" ON "case_casecategory_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_causeofaction_causeofaction; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_causeofaction" ON "case_causeofaction" USING "btree" ("causeofaction");


--
-- Name: ix_case_causeofaction_version_causeofaction; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_version_causeofaction" ON "case_causeofaction_version" USING "btree" ("causeofaction");


--
-- Name: ix_case_causeofaction_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_version_end_transaction_id" ON "case_causeofaction_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_causeofaction_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_version_operation_type" ON "case_causeofaction_version" USING "btree" ("operation_type");


--
-- Name: ix_case_causeofaction_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_causeofaction_version_transaction_id" ON "case_causeofaction_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_defendant_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_defendant" ON "case_defendant" USING "btree" ("defendant");


--
-- Name: ix_case_defendant_version_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_version_defendant" ON "case_defendant_version" USING "btree" ("defendant");


--
-- Name: ix_case_defendant_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_version_end_transaction_id" ON "case_defendant_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_defendant_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_version_operation_type" ON "case_defendant_version" USING "btree" ("operation_type");


--
-- Name: ix_case_defendant_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_defendant_version_transaction_id" ON "case_defendant_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_natureofsuit_natureofsuit; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_natureofsuit" ON "case_natureofsuit" USING "btree" ("natureofsuit");


--
-- Name: ix_case_natureofsuit_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_version_end_transaction_id" ON "case_natureofsuit_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_natureofsuit_version_natureofsuit; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_version_natureofsuit" ON "case_natureofsuit_version" USING "btree" ("natureofsuit");


--
-- Name: ix_case_natureofsuit_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_version_operation_type" ON "case_natureofsuit_version" USING "btree" ("operation_type");


--
-- Name: ix_case_natureofsuit_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_natureofsuit_version_transaction_id" ON "case_natureofsuit_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_plaintiff_plaintiff; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_plaintiff" ON "case_plaintiff" USING "btree" ("plaintiff");


--
-- Name: ix_case_plaintiff_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_version_end_transaction_id" ON "case_plaintiff_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_plaintiff_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_version_operation_type" ON "case_plaintiff_version" USING "btree" ("operation_type");


--
-- Name: ix_case_plaintiff_version_plaintiff; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_version_plaintiff" ON "case_plaintiff_version" USING "btree" ("plaintiff");


--
-- Name: ix_case_plaintiff_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_plaintiff_version_transaction_id" ON "case_plaintiff_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_police_station_reported; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_police_station_reported" ON "case" USING "btree" ("police_station_reported");


--
-- Name: ix_case_polofficer_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_polofficer_polofficer" ON "case_polofficer" USING "btree" ("polofficer");


--
-- Name: ix_case_polofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_polofficer_version_end_transaction_id" ON "case_polofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_polofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_polofficer_version_operation_type" ON "case_polofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_case_polofficer_version_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_polofficer_version_polofficer" ON "case_polofficer_version" USING "btree" ("polofficer");


--
-- Name: ix_case_polofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_polofficer_version_transaction_id" ON "case_polofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_prosecutor_2_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_2_prosecutor" ON "case_prosecutor_2" USING "btree" ("prosecutor");


--
-- Name: ix_case_prosecutor_2_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_2_version_end_transaction_id" ON "case_prosecutor_2_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_prosecutor_2_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_2_version_operation_type" ON "case_prosecutor_2_version" USING "btree" ("operation_type");


--
-- Name: ix_case_prosecutor_2_version_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_2_version_prosecutor" ON "case_prosecutor_2_version" USING "btree" ("prosecutor");


--
-- Name: ix_case_prosecutor_2_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_2_version_transaction_id" ON "case_prosecutor_2_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_prosecutor_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_prosecutor" ON "case_prosecutor" USING "btree" ("prosecutor");


--
-- Name: ix_case_prosecutor_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_version_end_transaction_id" ON "case_prosecutor_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_prosecutor_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_version_operation_type" ON "case_prosecutor_version" USING "btree" ("operation_type");


--
-- Name: ix_case_prosecutor_version_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_version_prosecutor" ON "case_prosecutor_version" USING "btree" ("prosecutor");


--
-- Name: ix_case_prosecutor_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_prosecutor_version_transaction_id" ON "case_prosecutor_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_reported_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_reported_to" ON "case" USING "btree" ("reported_to");


--
-- Name: ix_case_tag_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_tag_tag" ON "case_tag" USING "btree" ("tag");


--
-- Name: ix_case_tag_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_tag_version_end_transaction_id" ON "case_tag_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_tag_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_tag_version_operation_type" ON "case_tag_version" USING "btree" ("operation_type");


--
-- Name: ix_case_tag_version_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_tag_version_tag" ON "case_tag_version" USING "btree" ("tag");


--
-- Name: ix_case_tag_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_tag_version_transaction_id" ON "case_tag_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_version_end_transaction_id" ON "case_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_version_operation_type" ON "case_version" USING "btree" ("operation_type");


--
-- Name: ix_case_version_police_station_reported; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_version_police_station_reported" ON "case_version" USING "btree" ("police_station_reported");


--
-- Name: ix_case_version_reported_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_version_reported_to" ON "case_version" USING "btree" ("reported_to");


--
-- Name: ix_case_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_version_transaction_id" ON "case_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_witness_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_witness_version_end_transaction_id" ON "case_witness_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_case_witness_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_witness_version_operation_type" ON "case_witness_version" USING "btree" ("operation_type");


--
-- Name: ix_case_witness_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_witness_version_transaction_id" ON "case_witness_version" USING "btree" ("transaction_id");


--
-- Name: ix_case_witness_version_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_witness_version_witness" ON "case_witness_version" USING "btree" ("witness");


--
-- Name: ix_case_witness_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_case_witness_witness" ON "case_witness" USING "btree" ("witness");


--
-- Name: ix_casecategory_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_casecategory_name" ON "casecategory" USING "btree" ("name");


--
-- Name: ix_casecategory_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_casecategory_version_end_transaction_id" ON "casecategory_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_casecategory_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_casecategory_version_name" ON "casecategory_version" USING "btree" ("name");


--
-- Name: ix_casecategory_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_casecategory_version_operation_type" ON "casecategory_version" USING "btree" ("operation_type");


--
-- Name: ix_casecategory_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_casecategory_version_transaction_id" ON "casecategory_version" USING "btree" ("transaction_id");


--
-- Name: ix_caseinvestigation_cases; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_caseinvestigation_cases" ON "caseinvestigation" USING "btree" ("cases");


--
-- Name: ix_caseinvestigation_version_cases; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_caseinvestigation_version_cases" ON "caseinvestigation_version" USING "btree" ("cases");


--
-- Name: ix_caseinvestigation_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_caseinvestigation_version_end_transaction_id" ON "caseinvestigation_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_caseinvestigation_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_caseinvestigation_version_operation_type" ON "caseinvestigation_version" USING "btree" ("operation_type");


--
-- Name: ix_caseinvestigation_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_caseinvestigation_version_transaction_id" ON "caseinvestigation_version" USING "btree" ("transaction_id");


--
-- Name: ix_causeofaction_filing_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_filing" ON "causeofaction_filing" USING "btree" ("filing");


--
-- Name: ix_causeofaction_filing_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_version_end_transaction_id" ON "causeofaction_filing_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_causeofaction_filing_version_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_version_filing" ON "causeofaction_filing_version" USING "btree" ("filing");


--
-- Name: ix_causeofaction_filing_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_version_operation_type" ON "causeofaction_filing_version" USING "btree" ("operation_type");


--
-- Name: ix_causeofaction_filing_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_filing_version_transaction_id" ON "causeofaction_filing_version" USING "btree" ("transaction_id");


--
-- Name: ix_causeofaction_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_hearing" ON "causeofaction_hearing" USING "btree" ("hearing");


--
-- Name: ix_causeofaction_hearing_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_version_end_transaction_id" ON "causeofaction_hearing_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_causeofaction_hearing_version_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_version_hearing" ON "causeofaction_hearing_version" USING "btree" ("hearing");


--
-- Name: ix_causeofaction_hearing_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_version_operation_type" ON "causeofaction_hearing_version" USING "btree" ("operation_type");


--
-- Name: ix_causeofaction_hearing_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_hearing_version_transaction_id" ON "causeofaction_hearing_version" USING "btree" ("transaction_id");


--
-- Name: ix_causeofaction_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_causeofaction_name" ON "causeofaction" USING "btree" ("name");


--
-- Name: ix_causeofaction_parent_coa; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_parent_coa" ON "causeofaction" USING "btree" ("parent_coa");


--
-- Name: ix_causeofaction_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_version_end_transaction_id" ON "causeofaction_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_causeofaction_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_version_name" ON "causeofaction_version" USING "btree" ("name");


--
-- Name: ix_causeofaction_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_version_operation_type" ON "causeofaction_version" USING "btree" ("operation_type");


--
-- Name: ix_causeofaction_version_parent_coa; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_version_parent_coa" ON "causeofaction_version" USING "btree" ("parent_coa");


--
-- Name: ix_causeofaction_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_causeofaction_version_transaction_id" ON "causeofaction_version" USING "btree" ("transaction_id");


--
-- Name: ix_commitaltype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_commitaltype_name" ON "commitaltype" USING "btree" ("name");


--
-- Name: ix_commitaltype_prisoncommital_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_prisoncommital_version_end_transaction_id" ON "commitaltype_prisoncommital_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_commitaltype_prisoncommital_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_prisoncommital_version_operation_type" ON "commitaltype_prisoncommital_version" USING "btree" ("operation_type");


--
-- Name: ix_commitaltype_prisoncommital_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_prisoncommital_version_transaction_id" ON "commitaltype_prisoncommital_version" USING "btree" ("transaction_id");


--
-- Name: ix_commitaltype_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_version_end_transaction_id" ON "commitaltype_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_commitaltype_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_version_name" ON "commitaltype_version" USING "btree" ("name");


--
-- Name: ix_commitaltype_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_version_operation_type" ON "commitaltype_version" USING "btree" ("operation_type");


--
-- Name: ix_commitaltype_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_commitaltype_version_transaction_id" ON "commitaltype_version" USING "btree" ("transaction_id");


--
-- Name: ix_constituency_county; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_county" ON "constituency" USING "btree" ("county");


--
-- Name: ix_constituency_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_constituency_name" ON "constituency" USING "btree" ("name");


--
-- Name: ix_constituency_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_town" ON "constituency" USING "btree" ("town");


--
-- Name: ix_constituency_version_county; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_county" ON "constituency_version" USING "btree" ("county");


--
-- Name: ix_constituency_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_end_transaction_id" ON "constituency_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_constituency_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_name" ON "constituency_version" USING "btree" ("name");


--
-- Name: ix_constituency_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_operation_type" ON "constituency_version" USING "btree" ("operation_type");


--
-- Name: ix_constituency_version_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_town" ON "constituency_version" USING "btree" ("town");


--
-- Name: ix_constituency_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_constituency_version_transaction_id" ON "constituency_version" USING "btree" ("transaction_id");


--
-- Name: ix_county_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_county_name" ON "county" USING "btree" ("name");


--
-- Name: ix_county_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_county_version_end_transaction_id" ON "county_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_county_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_county_version_name" ON "county_version" USING "btree" ("name");


--
-- Name: ix_county_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_county_version_operation_type" ON "county_version" USING "btree" ("operation_type");


--
-- Name: ix_county_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_county_version_transaction_id" ON "county_version" USING "btree" ("transaction_id");


--
-- Name: ix_court_court_station; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_court_station" ON "court" USING "btree" ("court_station");


--
-- Name: ix_court_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_court_name" ON "court" USING "btree" ("name");


--
-- Name: ix_court_version_court_station; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_version_court_station" ON "court_version" USING "btree" ("court_station");


--
-- Name: ix_court_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_version_end_transaction_id" ON "court_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_court_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_version_name" ON "court_version" USING "btree" ("name");


--
-- Name: ix_court_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_version_operation_type" ON "court_version" USING "btree" ("operation_type");


--
-- Name: ix_court_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_court_version_transaction_id" ON "court_version" USING "btree" ("transaction_id");


--
-- Name: ix_courtlevel_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_courtlevel_name" ON "courtlevel" USING "btree" ("name");


--
-- Name: ix_courtlevel_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtlevel_version_end_transaction_id" ON "courtlevel_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_courtlevel_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtlevel_version_name" ON "courtlevel_version" USING "btree" ("name");


--
-- Name: ix_courtlevel_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtlevel_version_operation_type" ON "courtlevel_version" USING "btree" ("operation_type");


--
-- Name: ix_courtlevel_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtlevel_version_transaction_id" ON "courtlevel_version" USING "btree" ("transaction_id");


--
-- Name: ix_courtstation_court_level; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_court_level" ON "courtstation" USING "btree" ("court_level");


--
-- Name: ix_courtstation_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_town" ON "courtstation" USING "btree" ("town");


--
-- Name: ix_courtstation_version_court_level; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_version_court_level" ON "courtstation_version" USING "btree" ("court_level");


--
-- Name: ix_courtstation_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_version_end_transaction_id" ON "courtstation_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_courtstation_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_version_operation_type" ON "courtstation_version" USING "btree" ("operation_type");


--
-- Name: ix_courtstation_version_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_version_town" ON "courtstation_version" USING "btree" ("town");


--
-- Name: ix_courtstation_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_courtstation_version_transaction_id" ON "courtstation_version" USING "btree" ("transaction_id");


--
-- Name: ix_defendant_bc_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_bc_id" ON "defendant" USING "btree" ("bc_id");


--
-- Name: ix_defendant_bc_number; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_bc_number" ON "defendant" USING "btree" ("bc_number");


--
-- Name: ix_defendant_bc_place; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_bc_place" ON "defendant" USING "btree" ("bc_place");


--
-- Name: ix_defendant_bc_serial; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_bc_serial" ON "defendant" USING "btree" ("bc_serial");


--
-- Name: ix_defendant_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_firstname" ON "defendant" USING "btree" ("firstname");


--
-- Name: ix_defendant_gateregister_gateregister; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gateregister_gateregister" ON "defendant_gateregister" USING "btree" ("gateregister");


--
-- Name: ix_defendant_gateregister_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gateregister_version_end_transaction_id" ON "defendant_gateregister_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_defendant_gateregister_version_gateregister; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gateregister_version_gateregister" ON "defendant_gateregister_version" USING "btree" ("gateregister");


--
-- Name: ix_defendant_gateregister_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gateregister_version_operation_type" ON "defendant_gateregister_version" USING "btree" ("operation_type");


--
-- Name: ix_defendant_gateregister_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gateregister_version_transaction_id" ON "defendant_gateregister_version" USING "btree" ("transaction_id");


--
-- Name: ix_defendant_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_gender" ON "defendant" USING "btree" ("gender");


--
-- Name: ix_defendant_hearing_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_hearing" ON "defendant_hearing" USING "btree" ("hearing");


--
-- Name: ix_defendant_hearing_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_version_end_transaction_id" ON "defendant_hearing_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_defendant_hearing_version_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_version_hearing" ON "defendant_hearing_version" USING "btree" ("hearing");


--
-- Name: ix_defendant_hearing_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_version_operation_type" ON "defendant_hearing_version" USING "btree" ("operation_type");


--
-- Name: ix_defendant_hearing_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_hearing_version_transaction_id" ON "defendant_hearing_version" USING "btree" ("transaction_id");


--
-- Name: ix_defendant_medevent_medevent; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_medevent_medevent" ON "defendant_medevent" USING "btree" ("medevent");


--
-- Name: ix_defendant_medevent_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_medevent_version_end_transaction_id" ON "defendant_medevent_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_defendant_medevent_version_medevent; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_medevent_version_medevent" ON "defendant_medevent_version" USING "btree" ("medevent");


--
-- Name: ix_defendant_medevent_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_medevent_version_operation_type" ON "defendant_medevent_version" USING "btree" ("operation_type");


--
-- Name: ix_defendant_medevent_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_medevent_version_transaction_id" ON "defendant_medevent_version" USING "btree" ("transaction_id");


--
-- Name: ix_defendant_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_mobile" ON "defendant" USING "btree" ("mobile");


--
-- Name: ix_defendant_nat_id_num; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_nat_id_num" ON "defendant" USING "btree" ("nat_id_num");


--
-- Name: ix_defendant_nat_id_serial; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_nat_id_serial" ON "defendant" USING "btree" ("nat_id_serial");


--
-- Name: ix_defendant_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_othernames" ON "defendant" USING "btree" ("othernames");


--
-- Name: ix_defendant_pp_no; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_pp_no" ON "defendant" USING "btree" ("pp_no");


--
-- Name: ix_defendant_prisoncell; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_prisoncell" ON "defendant" USING "btree" ("prisoncell");


--
-- Name: ix_defendant_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_surname" ON "defendant" USING "btree" ("surname");


--
-- Name: ix_defendant_version_bc_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_bc_id" ON "defendant_version" USING "btree" ("bc_id");


--
-- Name: ix_defendant_version_bc_number; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_bc_number" ON "defendant_version" USING "btree" ("bc_number");


--
-- Name: ix_defendant_version_bc_place; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_bc_place" ON "defendant_version" USING "btree" ("bc_place");


--
-- Name: ix_defendant_version_bc_serial; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_bc_serial" ON "defendant_version" USING "btree" ("bc_serial");


--
-- Name: ix_defendant_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_end_transaction_id" ON "defendant_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_defendant_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_firstname" ON "defendant_version" USING "btree" ("firstname");


--
-- Name: ix_defendant_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_gender" ON "defendant_version" USING "btree" ("gender");


--
-- Name: ix_defendant_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_mobile" ON "defendant_version" USING "btree" ("mobile");


--
-- Name: ix_defendant_version_nat_id_num; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_nat_id_num" ON "defendant_version" USING "btree" ("nat_id_num");


--
-- Name: ix_defendant_version_nat_id_serial; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_nat_id_serial" ON "defendant_version" USING "btree" ("nat_id_serial");


--
-- Name: ix_defendant_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_operation_type" ON "defendant_version" USING "btree" ("operation_type");


--
-- Name: ix_defendant_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_othernames" ON "defendant_version" USING "btree" ("othernames");


--
-- Name: ix_defendant_version_pp_no; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_pp_no" ON "defendant_version" USING "btree" ("pp_no");


--
-- Name: ix_defendant_version_prisoncell; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_prisoncell" ON "defendant_version" USING "btree" ("prisoncell");


--
-- Name: ix_defendant_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_surname" ON "defendant_version" USING "btree" ("surname");


--
-- Name: ix_defendant_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_defendant_version_transaction_id" ON "defendant_version" USING "btree" ("transaction_id");


--
-- Name: ix_discipline_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_discipline_defendant" ON "discipline" USING "btree" ("defendant");


--
-- Name: ix_discipline_version_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_discipline_version_defendant" ON "discipline_version" USING "btree" ("defendant");


--
-- Name: ix_discipline_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_discipline_version_end_transaction_id" ON "discipline_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_discipline_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_discipline_version_operation_type" ON "discipline_version" USING "btree" ("operation_type");


--
-- Name: ix_discipline_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_discipline_version_transaction_id" ON "discipline_version" USING "btree" ("transaction_id");


--
-- Name: ix_docarchive_tag_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_tag_tag" ON "docarchive_tag" USING "btree" ("tag");


--
-- Name: ix_docarchive_tag_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_tag_version_end_transaction_id" ON "docarchive_tag_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_docarchive_tag_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_tag_version_operation_type" ON "docarchive_tag_version" USING "btree" ("operation_type");


--
-- Name: ix_docarchive_tag_version_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_tag_version_tag" ON "docarchive_tag_version" USING "btree" ("tag");


--
-- Name: ix_docarchive_tag_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_tag_version_transaction_id" ON "docarchive_tag_version" USING "btree" ("transaction_id");


--
-- Name: ix_docarchive_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_version_end_transaction_id" ON "docarchive_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_docarchive_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_version_operation_type" ON "docarchive_version" USING "btree" ("operation_type");


--
-- Name: ix_docarchive_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_docarchive_version_transaction_id" ON "docarchive_version" USING "btree" ("transaction_id");


--
-- Name: ix_doctemplate_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_doctemplate_name" ON "doctemplate" USING "btree" ("name");


--
-- Name: ix_doctemplate_search_vector; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_search_vector" ON "doctemplate" USING "gin" ("search_vector");


--
-- Name: ix_doctemplate_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_version_end_transaction_id" ON "doctemplate_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_doctemplate_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_version_name" ON "doctemplate_version" USING "btree" ("name");


--
-- Name: ix_doctemplate_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_version_operation_type" ON "doctemplate_version" USING "btree" ("operation_type");


--
-- Name: ix_doctemplate_version_search_vector; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_version_search_vector" ON "doctemplate_version" USING "gin" ("search_vector");


--
-- Name: ix_doctemplate_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_doctemplate_version_transaction_id" ON "doctemplate_version" USING "btree" ("transaction_id");


--
-- Name: ix_document_doc_template; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_doc_template" ON "document" USING "btree" ("doc_template");


--
-- Name: ix_document_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_filing" ON "document" USING "btree" ("filing");


--
-- Name: ix_document_search_vector; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_search_vector" ON "document" USING "gin" ("search_vector");


--
-- Name: ix_document_tag_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_tag_tag" ON "document_tag" USING "btree" ("tag");


--
-- Name: ix_document_tag_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_tag_version_end_transaction_id" ON "document_tag_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_document_tag_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_tag_version_operation_type" ON "document_tag_version" USING "btree" ("operation_type");


--
-- Name: ix_document_tag_version_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_tag_version_tag" ON "document_tag_version" USING "btree" ("tag");


--
-- Name: ix_document_tag_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_tag_version_transaction_id" ON "document_tag_version" USING "btree" ("transaction_id");


--
-- Name: ix_document_version_doc_template; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_doc_template" ON "document_version" USING "btree" ("doc_template");


--
-- Name: ix_document_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_end_transaction_id" ON "document_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_document_version_filing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_filing" ON "document_version" USING "btree" ("filing");


--
-- Name: ix_document_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_operation_type" ON "document_version" USING "btree" ("operation_type");


--
-- Name: ix_document_version_search_vector; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_search_vector" ON "document_version" USING "gin" ("search_vector");


--
-- Name: ix_document_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_document_version_transaction_id" ON "document_version" USING "btree" ("transaction_id");


--
-- Name: ix_eventlog_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_eventlog_version_end_transaction_id" ON "eventlog_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_eventlog_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_eventlog_version_operation_type" ON "eventlog_version" USING "btree" ("operation_type");


--
-- Name: ix_eventlog_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_eventlog_version_transaction_id" ON "eventlog_version" USING "btree" ("transaction_id");


--
-- Name: ix_filing_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_case" ON "filing" USING "btree" ("case");


--
-- Name: ix_filing_filing_attorney; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filing_attorney" ON "filing" USING "btree" ("filing_attorney");


--
-- Name: ix_filing_filing_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filing_prosecutor" ON "filing" USING "btree" ("filing_prosecutor");


--
-- Name: ix_filing_filingtype_filingtype; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_filingtype" ON "filing_filingtype" USING "btree" ("filingtype");


--
-- Name: ix_filing_filingtype_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_version_end_transaction_id" ON "filing_filingtype_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_filing_filingtype_version_filingtype; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_version_filingtype" ON "filing_filingtype_version" USING "btree" ("filingtype");


--
-- Name: ix_filing_filingtype_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_version_operation_type" ON "filing_filingtype_version" USING "btree" ("operation_type");


--
-- Name: ix_filing_filingtype_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_filingtype_version_transaction_id" ON "filing_filingtype_version" USING "btree" ("transaction_id");


--
-- Name: ix_filing_payment_payment; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_payment_payment" ON "filing_payment" USING "btree" ("payment");


--
-- Name: ix_filing_payment_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_payment_version_end_transaction_id" ON "filing_payment_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_filing_payment_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_payment_version_operation_type" ON "filing_payment_version" USING "btree" ("operation_type");


--
-- Name: ix_filing_payment_version_payment; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_payment_version_payment" ON "filing_payment_version" USING "btree" ("payment");


--
-- Name: ix_filing_payment_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_payment_version_transaction_id" ON "filing_payment_version" USING "btree" ("transaction_id");


--
-- Name: ix_filing_version_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_case" ON "filing_version" USING "btree" ("case");


--
-- Name: ix_filing_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_end_transaction_id" ON "filing_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_filing_version_filing_attorney; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_filing_attorney" ON "filing_version" USING "btree" ("filing_attorney");


--
-- Name: ix_filing_version_filing_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_filing_prosecutor" ON "filing_version" USING "btree" ("filing_prosecutor");


--
-- Name: ix_filing_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_operation_type" ON "filing_version" USING "btree" ("operation_type");


--
-- Name: ix_filing_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filing_version_transaction_id" ON "filing_version" USING "btree" ("transaction_id");


--
-- Name: ix_filingtype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_filingtype_name" ON "filingtype" USING "btree" ("name");


--
-- Name: ix_filingtype_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filingtype_version_end_transaction_id" ON "filingtype_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_filingtype_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filingtype_version_name" ON "filingtype_version" USING "btree" ("name");


--
-- Name: ix_filingtype_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filingtype_version_operation_type" ON "filingtype_version" USING "btree" ("operation_type");


--
-- Name: ix_filingtype_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_filingtype_version_transaction_id" ON "filingtype_version" USING "btree" ("transaction_id");


--
-- Name: ix_gateregister_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_prison" ON "gateregister" USING "btree" ("prison");


--
-- Name: ix_gateregister_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_version_end_transaction_id" ON "gateregister_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_gateregister_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_version_operation_type" ON "gateregister_version" USING "btree" ("operation_type");


--
-- Name: ix_gateregister_version_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_version_prison" ON "gateregister_version" USING "btree" ("prison");


--
-- Name: ix_gateregister_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_version_transaction_id" ON "gateregister_version" USING "btree" ("transaction_id");


--
-- Name: ix_gateregister_warder_2_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_2_version_end_transaction_id" ON "gateregister_warder_2_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_gateregister_warder_2_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_2_version_operation_type" ON "gateregister_warder_2_version" USING "btree" ("operation_type");


--
-- Name: ix_gateregister_warder_2_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_2_version_transaction_id" ON "gateregister_warder_2_version" USING "btree" ("transaction_id");


--
-- Name: ix_gateregister_warder_2_version_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_2_version_warder" ON "gateregister_warder_2_version" USING "btree" ("warder");


--
-- Name: ix_gateregister_warder_2_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_2_warder" ON "gateregister_warder_2" USING "btree" ("warder");


--
-- Name: ix_gateregister_warder_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_version_end_transaction_id" ON "gateregister_warder_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_gateregister_warder_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_version_operation_type" ON "gateregister_warder_version" USING "btree" ("operation_type");


--
-- Name: ix_gateregister_warder_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_version_transaction_id" ON "gateregister_warder_version" USING "btree" ("transaction_id");


--
-- Name: ix_gateregister_warder_version_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_version_warder" ON "gateregister_warder_version" USING "btree" ("warder");


--
-- Name: ix_gateregister_warder_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gateregister_warder_warder" ON "gateregister_warder" USING "btree" ("warder");


--
-- Name: ix_gender_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gender_version_end_transaction_id" ON "gender_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_gender_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gender_version_operation_type" ON "gender_version" USING "btree" ("operation_type");


--
-- Name: ix_gender_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_gender_version_transaction_id" ON "gender_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_case" ON "hearing" USING "btree" ("case");


--
-- Name: ix_hearing_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_court" ON "hearing" USING "btree" ("court");


--
-- Name: ix_hearing_hearing_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_hearing_type" ON "hearing" USING "btree" ("hearing_type");


--
-- Name: ix_hearing_judicialofficer_judicialofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judicialofficer_judicialofficer" ON "hearing_judicialofficer" USING "btree" ("judicialofficer");


--
-- Name: ix_hearing_judicialofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judicialofficer_version_end_transaction_id" ON "hearing_judicialofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_judicialofficer_version_judicialofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judicialofficer_version_judicialofficer" ON "hearing_judicialofficer_version" USING "btree" ("judicialofficer");


--
-- Name: ix_hearing_judicialofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judicialofficer_version_operation_type" ON "hearing_judicialofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_judicialofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_judicialofficer_version_transaction_id" ON "hearing_judicialofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_lawyers_lawyers; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_lawyers_lawyers" ON "hearing_lawyers" USING "btree" ("lawyers");


--
-- Name: ix_hearing_lawyers_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_lawyers_version_end_transaction_id" ON "hearing_lawyers_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_lawyers_version_lawyers; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_lawyers_version_lawyers" ON "hearing_lawyers_version" USING "btree" ("lawyers");


--
-- Name: ix_hearing_lawyers_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_lawyers_version_operation_type" ON "hearing_lawyers_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_lawyers_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_lawyers_version_transaction_id" ON "hearing_lawyers_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_polofficer_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_polofficer_polofficer" ON "hearing_polofficer" USING "btree" ("polofficer");


--
-- Name: ix_hearing_polofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_polofficer_version_end_transaction_id" ON "hearing_polofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_polofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_polofficer_version_operation_type" ON "hearing_polofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_polofficer_version_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_polofficer_version_polofficer" ON "hearing_polofficer_version" USING "btree" ("polofficer");


--
-- Name: ix_hearing_polofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_polofficer_version_transaction_id" ON "hearing_polofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_prosecutor_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_prosecutor" ON "hearing_prosecutor" USING "btree" ("prosecutor");


--
-- Name: ix_hearing_prosecutor_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_version_end_transaction_id" ON "hearing_prosecutor_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_prosecutor_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_version_operation_type" ON "hearing_prosecutor_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_prosecutor_version_prosecutor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_version_prosecutor" ON "hearing_prosecutor_version" USING "btree" ("prosecutor");


--
-- Name: ix_hearing_prosecutor_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_prosecutor_version_transaction_id" ON "hearing_prosecutor_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_tag_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_tag_tag" ON "hearing_tag" USING "btree" ("tag");


--
-- Name: ix_hearing_tag_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_tag_version_end_transaction_id" ON "hearing_tag_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_tag_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_tag_version_operation_type" ON "hearing_tag_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_tag_version_tag; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_tag_version_tag" ON "hearing_tag_version" USING "btree" ("tag");


--
-- Name: ix_hearing_tag_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_tag_version_transaction_id" ON "hearing_tag_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_version_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_case" ON "hearing_version" USING "btree" ("case");


--
-- Name: ix_hearing_version_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_court" ON "hearing_version" USING "btree" ("court");


--
-- Name: ix_hearing_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_end_transaction_id" ON "hearing_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_version_hearing_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_hearing_type" ON "hearing_version" USING "btree" ("hearing_type");


--
-- Name: ix_hearing_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_operation_type" ON "hearing_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_version_transaction_id" ON "hearing_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_witness_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_witness_version_end_transaction_id" ON "hearing_witness_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearing_witness_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_witness_version_operation_type" ON "hearing_witness_version" USING "btree" ("operation_type");


--
-- Name: ix_hearing_witness_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_witness_version_transaction_id" ON "hearing_witness_version" USING "btree" ("transaction_id");


--
-- Name: ix_hearing_witness_version_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_witness_version_witness" ON "hearing_witness_version" USING "btree" ("witness");


--
-- Name: ix_hearing_witness_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearing_witness_witness" ON "hearing_witness" USING "btree" ("witness");


--
-- Name: ix_hearingtype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_hearingtype_name" ON "hearingtype" USING "btree" ("name");


--
-- Name: ix_hearingtype_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearingtype_version_end_transaction_id" ON "hearingtype_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_hearingtype_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearingtype_version_name" ON "hearingtype_version" USING "btree" ("name");


--
-- Name: ix_hearingtype_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearingtype_version_operation_type" ON "hearingtype_version" USING "btree" ("operation_type");


--
-- Name: ix_hearingtype_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_hearingtype_version_transaction_id" ON "hearingtype_version" USING "btree" ("transaction_id");


--
-- Name: ix_investigation_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_case" ON "investigation" USING "btree" ("case");


--
-- Name: ix_investigation_polofficer_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_polofficer_polofficer" ON "investigation_polofficer" USING "btree" ("polofficer");


--
-- Name: ix_investigation_polofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_polofficer_version_end_transaction_id" ON "investigation_polofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_investigation_polofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_polofficer_version_operation_type" ON "investigation_polofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_investigation_polofficer_version_polofficer; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_polofficer_version_polofficer" ON "investigation_polofficer_version" USING "btree" ("polofficer");


--
-- Name: ix_investigation_polofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_polofficer_version_transaction_id" ON "investigation_polofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_investigation_version_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_version_case" ON "investigation_version" USING "btree" ("case");


--
-- Name: ix_investigation_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_version_end_transaction_id" ON "investigation_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_investigation_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_version_operation_type" ON "investigation_version" USING "btree" ("operation_type");


--
-- Name: ix_investigation_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_version_transaction_id" ON "investigation_version" USING "btree" ("transaction_id");


--
-- Name: ix_investigation_witness_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_witness_version_end_transaction_id" ON "investigation_witness_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_investigation_witness_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_witness_version_operation_type" ON "investigation_witness_version" USING "btree" ("operation_type");


--
-- Name: ix_investigation_witness_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_witness_version_transaction_id" ON "investigation_witness_version" USING "btree" ("transaction_id");


--
-- Name: ix_investigation_witness_version_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_witness_version_witness" ON "investigation_witness_version" USING "btree" ("witness");


--
-- Name: ix_investigation_witness_witness; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_investigation_witness_witness" ON "investigation_witness" USING "btree" ("witness");


--
-- Name: ix_jo_rank_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_jo_rank_name" ON "jo_rank" USING "btree" ("name");


--
-- Name: ix_jo_rank_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_jo_rank_version_end_transaction_id" ON "jo_rank_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_jo_rank_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_jo_rank_version_name" ON "jo_rank_version" USING "btree" ("name");


--
-- Name: ix_jo_rank_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_jo_rank_version_operation_type" ON "jo_rank_version" USING "btree" ("operation_type");


--
-- Name: ix_jo_rank_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_jo_rank_version_transaction_id" ON "jo_rank_version" USING "btree" ("transaction_id");


--
-- Name: ix_judicialofficer_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_court" ON "judicialofficer" USING "btree" ("court");


--
-- Name: ix_judicialofficer_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_firstname" ON "judicialofficer" USING "btree" ("firstname");


--
-- Name: ix_judicialofficer_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_gender" ON "judicialofficer" USING "btree" ("gender");


--
-- Name: ix_judicialofficer_j_o__rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_j_o__rank" ON "judicialofficer" USING "btree" ("j_o__rank");


--
-- Name: ix_judicialofficer_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_mobile" ON "judicialofficer" USING "btree" ("mobile");


--
-- Name: ix_judicialofficer_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_othernames" ON "judicialofficer" USING "btree" ("othernames");


--
-- Name: ix_judicialofficer_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_surname" ON "judicialofficer" USING "btree" ("surname");


--
-- Name: ix_judicialofficer_version_court; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_court" ON "judicialofficer_version" USING "btree" ("court");


--
-- Name: ix_judicialofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_end_transaction_id" ON "judicialofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_judicialofficer_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_firstname" ON "judicialofficer_version" USING "btree" ("firstname");


--
-- Name: ix_judicialofficer_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_gender" ON "judicialofficer_version" USING "btree" ("gender");


--
-- Name: ix_judicialofficer_version_j_o__rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_j_o__rank" ON "judicialofficer_version" USING "btree" ("j_o__rank");


--
-- Name: ix_judicialofficer_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_mobile" ON "judicialofficer_version" USING "btree" ("mobile");


--
-- Name: ix_judicialofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_operation_type" ON "judicialofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_judicialofficer_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_othernames" ON "judicialofficer_version" USING "btree" ("othernames");


--
-- Name: ix_judicialofficer_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_surname" ON "judicialofficer_version" USING "btree" ("surname");


--
-- Name: ix_judicialofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_judicialofficer_version_transaction_id" ON "judicialofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_lawfirm_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_lawfirm_name" ON "lawfirm" USING "btree" ("name");


--
-- Name: ix_lawfirm_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawfirm_version_end_transaction_id" ON "lawfirm_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_lawfirm_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawfirm_version_name" ON "lawfirm_version" USING "btree" ("name");


--
-- Name: ix_lawfirm_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawfirm_version_operation_type" ON "lawfirm_version" USING "btree" ("operation_type");


--
-- Name: ix_lawfirm_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawfirm_version_transaction_id" ON "lawfirm_version" USING "btree" ("transaction_id");


--
-- Name: ix_lawyers_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_firstname" ON "lawyers" USING "btree" ("firstname");


--
-- Name: ix_lawyers_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_gender" ON "lawyers" USING "btree" ("gender");


--
-- Name: ix_lawyers_law_firm; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_law_firm" ON "lawyers" USING "btree" ("law_firm");


--
-- Name: ix_lawyers_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_mobile" ON "lawyers" USING "btree" ("mobile");


--
-- Name: ix_lawyers_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_othernames" ON "lawyers" USING "btree" ("othernames");


--
-- Name: ix_lawyers_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_surname" ON "lawyers" USING "btree" ("surname");


--
-- Name: ix_lawyers_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_end_transaction_id" ON "lawyers_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_lawyers_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_firstname" ON "lawyers_version" USING "btree" ("firstname");


--
-- Name: ix_lawyers_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_gender" ON "lawyers_version" USING "btree" ("gender");


--
-- Name: ix_lawyers_version_law_firm; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_law_firm" ON "lawyers_version" USING "btree" ("law_firm");


--
-- Name: ix_lawyers_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_mobile" ON "lawyers_version" USING "btree" ("mobile");


--
-- Name: ix_lawyers_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_operation_type" ON "lawyers_version" USING "btree" ("operation_type");


--
-- Name: ix_lawyers_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_othernames" ON "lawyers_version" USING "btree" ("othernames");


--
-- Name: ix_lawyers_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_surname" ON "lawyers_version" USING "btree" ("surname");


--
-- Name: ix_lawyers_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_lawyers_version_transaction_id" ON "lawyers_version" USING "btree" ("transaction_id");


--
-- Name: ix_medevent_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_medevent_version_end_transaction_id" ON "medevent_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_medevent_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_medevent_version_operation_type" ON "medevent_version" USING "btree" ("operation_type");


--
-- Name: ix_medevent_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_medevent_version_transaction_id" ON "medevent_version" USING "btree" ("transaction_id");


--
-- Name: ix_natureofsuit_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_natureofsuit_name" ON "natureofsuit" USING "btree" ("name");


--
-- Name: ix_natureofsuit_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_natureofsuit_version_end_transaction_id" ON "natureofsuit_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_natureofsuit_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_natureofsuit_version_name" ON "natureofsuit_version" USING "btree" ("name");


--
-- Name: ix_natureofsuit_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_natureofsuit_version_operation_type" ON "natureofsuit_version" USING "btree" ("operation_type");


--
-- Name: ix_natureofsuit_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_natureofsuit_version_transaction_id" ON "natureofsuit_version" USING "btree" ("transaction_id");


--
-- Name: ix_payment_bail; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_bail" ON "payment" USING "btree" ("bail");


--
-- Name: ix_payment_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_case" ON "payment" USING "btree" ("case");


--
-- Name: ix_payment_payment_method; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_payment_method" ON "payment" USING "btree" ("payment_method");


--
-- Name: ix_payment_version_bail; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_bail" ON "payment_version" USING "btree" ("bail");


--
-- Name: ix_payment_version_case; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_case" ON "payment_version" USING "btree" ("case");


--
-- Name: ix_payment_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_end_transaction_id" ON "payment_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_payment_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_operation_type" ON "payment_version" USING "btree" ("operation_type");


--
-- Name: ix_payment_version_payment_method; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_payment_method" ON "payment_version" USING "btree" ("payment_method");


--
-- Name: ix_payment_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_payment_version_transaction_id" ON "payment_version" USING "btree" ("transaction_id");


--
-- Name: ix_paymentmethod_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_paymentmethod_name" ON "paymentmethod" USING "btree" ("name");


--
-- Name: ix_paymentmethod_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_paymentmethod_version_end_transaction_id" ON "paymentmethod_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_paymentmethod_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_paymentmethod_version_name" ON "paymentmethod_version" USING "btree" ("name");


--
-- Name: ix_paymentmethod_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_paymentmethod_version_operation_type" ON "paymentmethod_version" USING "btree" ("operation_type");


--
-- Name: ix_paymentmethod_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_paymentmethod_version_transaction_id" ON "paymentmethod_version" USING "btree" ("transaction_id");


--
-- Name: ix_plaintiff_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_firstname" ON "plaintiff" USING "btree" ("firstname");


--
-- Name: ix_plaintiff_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_gender" ON "plaintiff" USING "btree" ("gender");


--
-- Name: ix_plaintiff_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_mobile" ON "plaintiff" USING "btree" ("mobile");


--
-- Name: ix_plaintiff_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_othernames" ON "plaintiff" USING "btree" ("othernames");


--
-- Name: ix_plaintiff_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_surname" ON "plaintiff" USING "btree" ("surname");


--
-- Name: ix_plaintiff_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_end_transaction_id" ON "plaintiff_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_plaintiff_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_firstname" ON "plaintiff_version" USING "btree" ("firstname");


--
-- Name: ix_plaintiff_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_gender" ON "plaintiff_version" USING "btree" ("gender");


--
-- Name: ix_plaintiff_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_mobile" ON "plaintiff_version" USING "btree" ("mobile");


--
-- Name: ix_plaintiff_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_operation_type" ON "plaintiff_version" USING "btree" ("operation_type");


--
-- Name: ix_plaintiff_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_othernames" ON "plaintiff_version" USING "btree" ("othernames");


--
-- Name: ix_plaintiff_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_surname" ON "plaintiff_version" USING "btree" ("surname");


--
-- Name: ix_plaintiff_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_plaintiff_version_transaction_id" ON "plaintiff_version" USING "btree" ("transaction_id");


--
-- Name: ix_policerank_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policerank_name" ON "policerank" USING "btree" ("name");


--
-- Name: ix_policerank_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerank_version_end_transaction_id" ON "policerank_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_policerank_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerank_version_name" ON "policerank_version" USING "btree" ("name");


--
-- Name: ix_policerank_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerank_version_operation_type" ON "policerank_version" USING "btree" ("operation_type");


--
-- Name: ix_policerank_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerank_version_transaction_id" ON "policerank_version" USING "btree" ("transaction_id");


--
-- Name: ix_policerole_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policerole_name" ON "policerole" USING "btree" ("name");


--
-- Name: ix_policerole_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerole_version_end_transaction_id" ON "policerole_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_policerole_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerole_version_name" ON "policerole_version" USING "btree" ("name");


--
-- Name: ix_policerole_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerole_version_operation_type" ON "policerole_version" USING "btree" ("operation_type");


--
-- Name: ix_policerole_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policerole_version_transaction_id" ON "policerole_version" USING "btree" ("transaction_id");


--
-- Name: ix_policestation_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policestation_name" ON "policestation" USING "btree" ("name");


--
-- Name: ix_policestation_police_station_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_police_station_type" ON "policestation" USING "btree" ("police_station_type");


--
-- Name: ix_policestation_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_town" ON "policestation" USING "btree" ("town");


--
-- Name: ix_policestation_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_end_transaction_id" ON "policestation_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_policestation_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_name" ON "policestation_version" USING "btree" ("name");


--
-- Name: ix_policestation_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_operation_type" ON "policestation_version" USING "btree" ("operation_type");


--
-- Name: ix_policestation_version_police_station_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_police_station_type" ON "policestation_version" USING "btree" ("police_station_type");


--
-- Name: ix_policestation_version_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_town" ON "policestation_version" USING "btree" ("town");


--
-- Name: ix_policestation_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestation_version_transaction_id" ON "policestation_version" USING "btree" ("transaction_id");


--
-- Name: ix_policestationtype_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_policestationtype_name" ON "policestationtype" USING "btree" ("name");


--
-- Name: ix_policestationtype_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestationtype_version_end_transaction_id" ON "policestationtype_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_policestationtype_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestationtype_version_name" ON "policestationtype_version" USING "btree" ("name");


--
-- Name: ix_policestationtype_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestationtype_version_operation_type" ON "policestationtype_version" USING "btree" ("operation_type");


--
-- Name: ix_policestationtype_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_policestationtype_version_transaction_id" ON "policestationtype_version" USING "btree" ("transaction_id");


--
-- Name: ix_polofficer_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_gender" ON "polofficer" USING "btree" ("gender");


--
-- Name: ix_polofficer_pol_supervisor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_pol_supervisor" ON "polofficer" USING "btree" ("pol_supervisor");


--
-- Name: ix_polofficer_police_rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_police_rank" ON "polofficer" USING "btree" ("police_rank");


--
-- Name: ix_polofficer_policerole_policerole; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_policerole_policerole" ON "polofficer_policerole" USING "btree" ("policerole");


--
-- Name: ix_polofficer_policerole_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_policerole_version_end_transaction_id" ON "polofficer_policerole_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_polofficer_policerole_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_policerole_version_operation_type" ON "polofficer_policerole_version" USING "btree" ("operation_type");


--
-- Name: ix_polofficer_policerole_version_policerole; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_policerole_version_policerole" ON "polofficer_policerole_version" USING "btree" ("policerole");


--
-- Name: ix_polofficer_policerole_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_policerole_version_transaction_id" ON "polofficer_policerole_version" USING "btree" ("transaction_id");


--
-- Name: ix_polofficer_reports_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_reports_to" ON "polofficer" USING "btree" ("reports_to");


--
-- Name: ix_polofficer_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_end_transaction_id" ON "polofficer_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_polofficer_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_gender" ON "polofficer_version" USING "btree" ("gender");


--
-- Name: ix_polofficer_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_operation_type" ON "polofficer_version" USING "btree" ("operation_type");


--
-- Name: ix_polofficer_version_pol_supervisor; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_pol_supervisor" ON "polofficer_version" USING "btree" ("pol_supervisor");


--
-- Name: ix_polofficer_version_police_rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_police_rank" ON "polofficer_version" USING "btree" ("police_rank");


--
-- Name: ix_polofficer_version_reports_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_reports_to" ON "polofficer_version" USING "btree" ("reports_to");


--
-- Name: ix_polofficer_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_polofficer_version_transaction_id" ON "polofficer_version" USING "btree" ("transaction_id");


--
-- Name: ix_prison_securityrank_securityrank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_securityrank_securityrank" ON "prison_securityrank" USING "btree" ("securityrank");


--
-- Name: ix_prison_securityrank_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_securityrank_version_end_transaction_id" ON "prison_securityrank_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prison_securityrank_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_securityrank_version_operation_type" ON "prison_securityrank_version" USING "btree" ("operation_type");


--
-- Name: ix_prison_securityrank_version_securityrank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_securityrank_version_securityrank" ON "prison_securityrank_version" USING "btree" ("securityrank");


--
-- Name: ix_prison_securityrank_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_securityrank_version_transaction_id" ON "prison_securityrank_version" USING "btree" ("transaction_id");


--
-- Name: ix_prison_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_town" ON "prison" USING "btree" ("town");


--
-- Name: ix_prison_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_version_end_transaction_id" ON "prison_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prison_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_version_operation_type" ON "prison_version" USING "btree" ("operation_type");


--
-- Name: ix_prison_version_town; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_version_town" ON "prison_version" USING "btree" ("town");


--
-- Name: ix_prison_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prison_version_transaction_id" ON "prison_version" USING "btree" ("transaction_id");


--
-- Name: ix_prisoncell_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncell_prison" ON "prisoncell" USING "btree" ("prison");


--
-- Name: ix_prisoncell_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncell_version_end_transaction_id" ON "prisoncell_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prisoncell_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncell_version_operation_type" ON "prisoncell_version" USING "btree" ("operation_type");


--
-- Name: ix_prisoncell_version_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncell_version_prison" ON "prisoncell_version" USING "btree" ("prison");


--
-- Name: ix_prisoncell_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncell_version_transaction_id" ON "prisoncell_version" USING "btree" ("transaction_id");


--
-- Name: ix_prisoncommital_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_defendant" ON "prisoncommital" USING "btree" ("defendant");


--
-- Name: ix_prisoncommital_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_hearing" ON "prisoncommital" USING "btree" ("hearing");


--
-- Name: ix_prisoncommital_judicial_officer_warrant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_judicial_officer_warrant" ON "prisoncommital" USING "btree" ("judicial_officer_warrant");


--
-- Name: ix_prisoncommital_police_officer_commiting; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_police_officer_commiting" ON "prisoncommital" USING "btree" ("police_officer_commiting");


--
-- Name: ix_prisoncommital_version_defendant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_defendant" ON "prisoncommital_version" USING "btree" ("defendant");


--
-- Name: ix_prisoncommital_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_end_transaction_id" ON "prisoncommital_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prisoncommital_version_hearing; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_hearing" ON "prisoncommital_version" USING "btree" ("hearing");


--
-- Name: ix_prisoncommital_version_judicial_officer_warrant; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_judicial_officer_warrant" ON "prisoncommital_version" USING "btree" ("judicial_officer_warrant");


--
-- Name: ix_prisoncommital_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_operation_type" ON "prisoncommital_version" USING "btree" ("operation_type");


--
-- Name: ix_prisoncommital_version_police_officer_commiting; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_police_officer_commiting" ON "prisoncommital_version" USING "btree" ("police_officer_commiting");


--
-- Name: ix_prisoncommital_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_version_transaction_id" ON "prisoncommital_version" USING "btree" ("transaction_id");


--
-- Name: ix_prisoncommital_warder_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_warder_version_end_transaction_id" ON "prisoncommital_warder_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prisoncommital_warder_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_warder_version_operation_type" ON "prisoncommital_warder_version" USING "btree" ("operation_type");


--
-- Name: ix_prisoncommital_warder_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_warder_version_transaction_id" ON "prisoncommital_warder_version" USING "btree" ("transaction_id");


--
-- Name: ix_prisoncommital_warder_version_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_warder_version_warder" ON "prisoncommital_warder_version" USING "btree" ("warder");


--
-- Name: ix_prisoncommital_warder_warder; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisoncommital_warder_warder" ON "prisoncommital_warder" USING "btree" ("warder");


--
-- Name: ix_prisonerproperty_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_prisonerproperty_name" ON "prisonerproperty" USING "btree" ("name");


--
-- Name: ix_prisonerproperty_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonerproperty_version_end_transaction_id" ON "prisonerproperty_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prisonerproperty_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonerproperty_version_name" ON "prisonerproperty_version" USING "btree" ("name");


--
-- Name: ix_prisonerproperty_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonerproperty_version_operation_type" ON "prisonerproperty_version" USING "btree" ("operation_type");


--
-- Name: ix_prisonerproperty_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prisonerproperty_version_transaction_id" ON "prisonerproperty_version" USING "btree" ("transaction_id");


--
-- Name: ix_prosecutor_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_firstname" ON "prosecutor" USING "btree" ("firstname");


--
-- Name: ix_prosecutor_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_gender" ON "prosecutor" USING "btree" ("gender");


--
-- Name: ix_prosecutor_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_mobile" ON "prosecutor" USING "btree" ("mobile");


--
-- Name: ix_prosecutor_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_othernames" ON "prosecutor" USING "btree" ("othernames");


--
-- Name: ix_prosecutor_prosecutorteam_prosecutorteam; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_prosecutorteam" ON "prosecutor_prosecutorteam" USING "btree" ("prosecutorteam");


--
-- Name: ix_prosecutor_prosecutorteam_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_version_end_transaction_id" ON "prosecutor_prosecutorteam_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prosecutor_prosecutorteam_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_version_operation_type" ON "prosecutor_prosecutorteam_version" USING "btree" ("operation_type");


--
-- Name: ix_prosecutor_prosecutorteam_version_prosecutorteam; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_version_prosecutorteam" ON "prosecutor_prosecutorteam_version" USING "btree" ("prosecutorteam");


--
-- Name: ix_prosecutor_prosecutorteam_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_prosecutorteam_version_transaction_id" ON "prosecutor_prosecutorteam_version" USING "btree" ("transaction_id");


--
-- Name: ix_prosecutor_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_surname" ON "prosecutor" USING "btree" ("surname");


--
-- Name: ix_prosecutor_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_end_transaction_id" ON "prosecutor_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prosecutor_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_firstname" ON "prosecutor_version" USING "btree" ("firstname");


--
-- Name: ix_prosecutor_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_gender" ON "prosecutor_version" USING "btree" ("gender");


--
-- Name: ix_prosecutor_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_mobile" ON "prosecutor_version" USING "btree" ("mobile");


--
-- Name: ix_prosecutor_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_operation_type" ON "prosecutor_version" USING "btree" ("operation_type");


--
-- Name: ix_prosecutor_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_othernames" ON "prosecutor_version" USING "btree" ("othernames");


--
-- Name: ix_prosecutor_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_surname" ON "prosecutor_version" USING "btree" ("surname");


--
-- Name: ix_prosecutor_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutor_version_transaction_id" ON "prosecutor_version" USING "btree" ("transaction_id");


--
-- Name: ix_prosecutorteam_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_prosecutorteam_name" ON "prosecutorteam" USING "btree" ("name");


--
-- Name: ix_prosecutorteam_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutorteam_version_end_transaction_id" ON "prosecutorteam_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_prosecutorteam_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutorteam_version_name" ON "prosecutorteam_version" USING "btree" ("name");


--
-- Name: ix_prosecutorteam_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutorteam_version_operation_type" ON "prosecutorteam_version" USING "btree" ("operation_type");


--
-- Name: ix_prosecutorteam_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_prosecutorteam_version_transaction_id" ON "prosecutorteam_version" USING "btree" ("transaction_id");


--
-- Name: ix_remission_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_remission_version_end_transaction_id" ON "remission_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_remission_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_remission_version_operation_type" ON "remission_version" USING "btree" ("operation_type");


--
-- Name: ix_remission_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_remission_version_transaction_id" ON "remission_version" USING "btree" ("transaction_id");


--
-- Name: ix_securityrank_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_securityrank_name" ON "securityrank" USING "btree" ("name");


--
-- Name: ix_securityrank_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_securityrank_version_end_transaction_id" ON "securityrank_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_securityrank_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_securityrank_version_name" ON "securityrank_version" USING "btree" ("name");


--
-- Name: ix_securityrank_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_securityrank_version_operation_type" ON "securityrank_version" USING "btree" ("operation_type");


--
-- Name: ix_securityrank_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_securityrank_version_transaction_id" ON "securityrank_version" USING "btree" ("transaction_id");


--
-- Name: ix_subcounty_county; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_county" ON "subcounty" USING "btree" ("county");


--
-- Name: ix_subcounty_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_subcounty_name" ON "subcounty" USING "btree" ("name");


--
-- Name: ix_subcounty_version_county; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_version_county" ON "subcounty_version" USING "btree" ("county");


--
-- Name: ix_subcounty_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_version_end_transaction_id" ON "subcounty_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_subcounty_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_version_name" ON "subcounty_version" USING "btree" ("name");


--
-- Name: ix_subcounty_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_version_operation_type" ON "subcounty_version" USING "btree" ("operation_type");


--
-- Name: ix_subcounty_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_subcounty_version_transaction_id" ON "subcounty_version" USING "btree" ("transaction_id");


--
-- Name: ix_surety_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_firstname" ON "surety" USING "btree" ("firstname");


--
-- Name: ix_surety_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_gender" ON "surety" USING "btree" ("gender");


--
-- Name: ix_surety_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_mobile" ON "surety" USING "btree" ("mobile");


--
-- Name: ix_surety_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_othernames" ON "surety" USING "btree" ("othernames");


--
-- Name: ix_surety_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_surname" ON "surety" USING "btree" ("surname");


--
-- Name: ix_surety_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_end_transaction_id" ON "surety_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_surety_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_firstname" ON "surety_version" USING "btree" ("firstname");


--
-- Name: ix_surety_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_gender" ON "surety_version" USING "btree" ("gender");


--
-- Name: ix_surety_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_mobile" ON "surety_version" USING "btree" ("mobile");


--
-- Name: ix_surety_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_operation_type" ON "surety_version" USING "btree" ("operation_type");


--
-- Name: ix_surety_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_othernames" ON "surety_version" USING "btree" ("othernames");


--
-- Name: ix_surety_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_surname" ON "surety_version" USING "btree" ("surname");


--
-- Name: ix_surety_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_surety_version_transaction_id" ON "surety_version" USING "btree" ("transaction_id");


--
-- Name: ix_tag_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_tag_name" ON "tag" USING "btree" ("name");


--
-- Name: ix_tag_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_tag_version_end_transaction_id" ON "tag_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_tag_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_tag_version_name" ON "tag_version" USING "btree" ("name");


--
-- Name: ix_tag_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_tag_version_operation_type" ON "tag_version" USING "btree" ("operation_type");


--
-- Name: ix_tag_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_tag_version_transaction_id" ON "tag_version" USING "btree" ("transaction_id");


--
-- Name: ix_town_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_town_name" ON "town" USING "btree" ("name");


--
-- Name: ix_town_subcounty; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_subcounty" ON "town" USING "btree" ("subcounty");


--
-- Name: ix_town_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_version_end_transaction_id" ON "town_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_town_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_version_name" ON "town_version" USING "btree" ("name");


--
-- Name: ix_town_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_version_operation_type" ON "town_version" USING "btree" ("operation_type");


--
-- Name: ix_town_version_subcounty; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_version_subcounty" ON "town_version" USING "btree" ("subcounty");


--
-- Name: ix_town_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_town_version_transaction_id" ON "town_version" USING "btree" ("transaction_id");


--
-- Name: ix_transaction_user_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_transaction_user_id" ON "transaction" USING "btree" ("user_id");


--
-- Name: ix_visit_defendants; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visit_defendants" ON "visit" USING "btree" ("defendants");


--
-- Name: ix_visit_version_defendants; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visit_version_defendants" ON "visit_version" USING "btree" ("defendants");


--
-- Name: ix_visit_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visit_version_end_transaction_id" ON "visit_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_visit_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visit_version_operation_type" ON "visit_version" USING "btree" ("operation_type");


--
-- Name: ix_visit_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visit_version_transaction_id" ON "visit_version" USING "btree" ("transaction_id");


--
-- Name: ix_visitor_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_firstname" ON "visitor" USING "btree" ("firstname");


--
-- Name: ix_visitor_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_gender" ON "visitor" USING "btree" ("gender");


--
-- Name: ix_visitor_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_mobile" ON "visitor" USING "btree" ("mobile");


--
-- Name: ix_visitor_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_othernames" ON "visitor" USING "btree" ("othernames");


--
-- Name: ix_visitor_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_surname" ON "visitor" USING "btree" ("surname");


--
-- Name: ix_visitor_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_end_transaction_id" ON "visitor_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_visitor_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_firstname" ON "visitor_version" USING "btree" ("firstname");


--
-- Name: ix_visitor_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_gender" ON "visitor_version" USING "btree" ("gender");


--
-- Name: ix_visitor_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_mobile" ON "visitor_version" USING "btree" ("mobile");


--
-- Name: ix_visitor_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_operation_type" ON "visitor_version" USING "btree" ("operation_type");


--
-- Name: ix_visitor_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_othernames" ON "visitor_version" USING "btree" ("othernames");


--
-- Name: ix_visitor_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_surname" ON "visitor_version" USING "btree" ("surname");


--
-- Name: ix_visitor_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_visitor_version_transaction_id" ON "visitor_version" USING "btree" ("transaction_id");


--
-- Name: ix_warder_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_firstname" ON "warder" USING "btree" ("firstname");


--
-- Name: ix_warder_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_mobile" ON "warder" USING "btree" ("mobile");


--
-- Name: ix_warder_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_othernames" ON "warder" USING "btree" ("othernames");


--
-- Name: ix_warder_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_prison" ON "warder" USING "btree" ("prison");


--
-- Name: ix_warder_reports_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_reports_to" ON "warder" USING "btree" ("reports_to");


--
-- Name: ix_warder_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_surname" ON "warder" USING "btree" ("surname");


--
-- Name: ix_warder_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_end_transaction_id" ON "warder_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_warder_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_firstname" ON "warder_version" USING "btree" ("firstname");


--
-- Name: ix_warder_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_mobile" ON "warder_version" USING "btree" ("mobile");


--
-- Name: ix_warder_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_operation_type" ON "warder_version" USING "btree" ("operation_type");


--
-- Name: ix_warder_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_othernames" ON "warder_version" USING "btree" ("othernames");


--
-- Name: ix_warder_version_prison; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_prison" ON "warder_version" USING "btree" ("prison");


--
-- Name: ix_warder_version_reports_to; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_reports_to" ON "warder_version" USING "btree" ("reports_to");


--
-- Name: ix_warder_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_surname" ON "warder_version" USING "btree" ("surname");


--
-- Name: ix_warder_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_transaction_id" ON "warder_version" USING "btree" ("transaction_id");


--
-- Name: ix_warder_version_warder_rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_version_warder_rank" ON "warder_version" USING "btree" ("warder_rank");


--
-- Name: ix_warder_warder_rank; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warder_warder_rank" ON "warder" USING "btree" ("warder_rank");


--
-- Name: ix_warderrank_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE UNIQUE INDEX "ix_warderrank_name" ON "warderrank" USING "btree" ("name");


--
-- Name: ix_warderrank_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warderrank_version_end_transaction_id" ON "warderrank_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_warderrank_version_name; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warderrank_version_name" ON "warderrank_version" USING "btree" ("name");


--
-- Name: ix_warderrank_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warderrank_version_operation_type" ON "warderrank_version" USING "btree" ("operation_type");


--
-- Name: ix_warderrank_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_warderrank_version_transaction_id" ON "warderrank_version" USING "btree" ("transaction_id");


--
-- Name: ix_witness_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_firstname" ON "witness" USING "btree" ("firstname");


--
-- Name: ix_witness_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_gender" ON "witness" USING "btree" ("gender");


--
-- Name: ix_witness_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_mobile" ON "witness" USING "btree" ("mobile");


--
-- Name: ix_witness_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_othernames" ON "witness" USING "btree" ("othernames");


--
-- Name: ix_witness_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_surname" ON "witness" USING "btree" ("surname");


--
-- Name: ix_witness_version_end_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_end_transaction_id" ON "witness_version" USING "btree" ("end_transaction_id");


--
-- Name: ix_witness_version_firstname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_firstname" ON "witness_version" USING "btree" ("firstname");


--
-- Name: ix_witness_version_gender; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_gender" ON "witness_version" USING "btree" ("gender");


--
-- Name: ix_witness_version_mobile; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_mobile" ON "witness_version" USING "btree" ("mobile");


--
-- Name: ix_witness_version_operation_type; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_operation_type" ON "witness_version" USING "btree" ("operation_type");


--
-- Name: ix_witness_version_othernames; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_othernames" ON "witness_version" USING "btree" ("othernames");


--
-- Name: ix_witness_version_surname; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_surname" ON "witness_version" USING "btree" ("surname");


--
-- Name: ix_witness_version_transaction_id; Type: INDEX; Schema: public; Owner: nyimbi
--

CREATE INDEX "ix_witness_version_transaction_id" ON "witness_version" USING "btree" ("transaction_id");


--
-- Name: doctemplate doctemplate_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: nyimbi
--

CREATE TRIGGER "doctemplate_search_vector_trigger" BEFORE INSERT OR UPDATE ON "doctemplate" FOR EACH ROW EXECUTE PROCEDURE "doctemplate_search_vector_update"();


--
-- Name: doctemplate_version doctemplate_version_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: nyimbi
--

CREATE TRIGGER "doctemplate_version_search_vector_trigger" BEFORE INSERT OR UPDATE ON "doctemplate_version" FOR EACH ROW EXECUTE PROCEDURE "doctemplate_version_search_vector_update"();


--
-- Name: document document_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: nyimbi
--

CREATE TRIGGER "document_search_vector_trigger" BEFORE INSERT OR UPDATE ON "document" FOR EACH ROW EXECUTE PROCEDURE "document_search_vector_update"();


--
-- Name: document_version document_version_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: nyimbi
--

CREATE TRIGGER "document_version_search_vector_trigger" BEFORE INSERT OR UPDATE ON "document_version" FOR EACH ROW EXECUTE PROCEDURE "document_version_search_vector_update"();


--
-- Name: ab_permission_view ab_permission_view_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "ab_permission"("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_permission_view_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_permission_view_id_fkey" FOREIGN KEY ("permission_view_id") REFERENCES "ab_permission_view"("id");


--
-- Name: ab_permission_view_role ab_permission_view_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view_role"
    ADD CONSTRAINT "ab_permission_view_role_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "ab_role"("id");


--
-- Name: ab_permission_view ab_permission_view_view_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_permission_view"
    ADD CONSTRAINT "ab_permission_view_view_menu_id_fkey" FOREIGN KEY ("view_menu_id") REFERENCES "ab_view_menu"("id");


--
-- Name: ab_user ab_user_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: ab_user ab_user_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user"
    ADD CONSTRAINT "ab_user_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: ab_user_role ab_user_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "ab_role"("id");


--
-- Name: ab_user_role ab_user_role_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "ab_user_role"
    ADD CONSTRAINT "ab_user_role_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "ab_user"("id");


--
-- Name: bail bail_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: bail bail_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: bail bail_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: bail bail_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail"
    ADD CONSTRAINT "bail_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: bail_surety bail_surety_bail_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_bail_fkey" FOREIGN KEY ("bail") REFERENCES "bail"("id");


--
-- Name: bail_surety bail_surety_surety_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "bail_surety"
    ADD CONSTRAINT "bail_surety_surety_fkey" FOREIGN KEY ("surety") REFERENCES "surety"("id");


--
-- Name: case_casecategory case_casecategory_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_casecategory"
    ADD CONSTRAINT "case_casecategory_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_casecategory case_casecategory_casecategory_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_casecategory"
    ADD CONSTRAINT "case_casecategory_casecategory_fkey" FOREIGN KEY ("casecategory") REFERENCES "casecategory"("id");


--
-- Name: case_causeofaction case_causeofaction_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_causeofaction case_causeofaction_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_causeofaction"
    ADD CONSTRAINT "case_causeofaction_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: case case_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: case case_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: case_defendant case_defendant_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_defendant case_defendant_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_defendant"
    ADD CONSTRAINT "case_defendant_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: case_natureofsuit case_natureofsuit_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_natureofsuit case_natureofsuit_natureofsuit_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_natureofsuit"
    ADD CONSTRAINT "case_natureofsuit_natureofsuit_fkey" FOREIGN KEY ("natureofsuit") REFERENCES "natureofsuit"("id");


--
-- Name: case_plaintiff case_plaintiff_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_plaintiff case_plaintiff_plaintiff_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_plaintiff"
    ADD CONSTRAINT "case_plaintiff_plaintiff_fkey" FOREIGN KEY ("plaintiff") REFERENCES "plaintiff"("id");


--
-- Name: case case_police_station_reported_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_police_station_reported_fkey" FOREIGN KEY ("police_station_reported") REFERENCES "policestation"("id");


--
-- Name: case_polofficer case_polofficer_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_polofficer"
    ADD CONSTRAINT "case_polofficer_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_polofficer case_polofficer_polofficer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_polofficer"
    ADD CONSTRAINT "case_polofficer_polofficer_fkey" FOREIGN KEY ("polofficer") REFERENCES "polofficer"("id");


--
-- Name: case_prosecutor_2 case_prosecutor_2_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor_2"
    ADD CONSTRAINT "case_prosecutor_2_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_prosecutor_2 case_prosecutor_2_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor_2"
    ADD CONSTRAINT "case_prosecutor_2_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: case_prosecutor case_prosecutor_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_prosecutor case_prosecutor_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_prosecutor"
    ADD CONSTRAINT "case_prosecutor_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: case case_reported_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case"
    ADD CONSTRAINT "case_reported_to_fkey" FOREIGN KEY ("reported_to") REFERENCES "polofficer"("id");


--
-- Name: case_tag case_tag_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_tag"
    ADD CONSTRAINT "case_tag_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_tag case_tag_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_tag"
    ADD CONSTRAINT "case_tag_tag_fkey" FOREIGN KEY ("tag") REFERENCES "tag"("id");


--
-- Name: case_witness case_witness_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_witness"
    ADD CONSTRAINT "case_witness_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: case_witness case_witness_witness_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "case_witness"
    ADD CONSTRAINT "case_witness_witness_fkey" FOREIGN KEY ("witness") REFERENCES "witness"("id");


--
-- Name: casecategory casecategory_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "casecategory"
    ADD CONSTRAINT "casecategory_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: casecategory casecategory_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "casecategory"
    ADD CONSTRAINT "casecategory_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: caseinvestigation caseinvestigation_cases_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "caseinvestigation"
    ADD CONSTRAINT "caseinvestigation_cases_fkey" FOREIGN KEY ("cases") REFERENCES "case"("id");


--
-- Name: caseinvestigation caseinvestigation_pol_officers_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "caseinvestigation"
    ADD CONSTRAINT "caseinvestigation_pol_officers_fkey" FOREIGN KEY ("pol_officers") REFERENCES "polofficer"("id");


--
-- Name: causeofaction causeofaction_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: causeofaction causeofaction_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: causeofaction_filing causeofaction_filing_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: causeofaction_filing causeofaction_filing_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_filing"
    ADD CONSTRAINT "causeofaction_filing_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: causeofaction_hearing causeofaction_hearing_causeofaction_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_causeofaction_fkey" FOREIGN KEY ("causeofaction") REFERENCES "causeofaction"("id");


--
-- Name: causeofaction_hearing causeofaction_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction_hearing"
    ADD CONSTRAINT "causeofaction_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: causeofaction causeofaction_parent_coa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "causeofaction"
    ADD CONSTRAINT "causeofaction_parent_coa_fkey" FOREIGN KEY ("parent_coa") REFERENCES "causeofaction"("id");


--
-- Name: commitaltype commitaltype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype"
    ADD CONSTRAINT "commitaltype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: commitaltype commitaltype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype"
    ADD CONSTRAINT "commitaltype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: commitaltype_prisoncommital commitaltype_prisoncommital_commitaltype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype_prisoncommital"
    ADD CONSTRAINT "commitaltype_prisoncommital_commitaltype_fkey" FOREIGN KEY ("commitaltype") REFERENCES "commitaltype"("id");


--
-- Name: commitaltype_prisoncommital commitaltype_prisoncommital_prisoncommital_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "commitaltype_prisoncommital"
    ADD CONSTRAINT "commitaltype_prisoncommital_prisoncommital_prison_fkey" FOREIGN KEY ("prisoncommital_prison", "prisoncommital_warrantno") REFERENCES "prisoncommital"("prison", "warrantno");


--
-- Name: constituency constituency_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: constituency constituency_county_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_county_fkey" FOREIGN KEY ("county") REFERENCES "county"("id");


--
-- Name: constituency constituency_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: constituency constituency_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "constituency"
    ADD CONSTRAINT "constituency_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: county county_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "county"
    ADD CONSTRAINT "county_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: county county_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "county"
    ADD CONSTRAINT "county_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: court court_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: court court_court_station_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_court_station_fkey" FOREIGN KEY ("court_station") REFERENCES "courtstation"("id");


--
-- Name: court court_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "court"
    ADD CONSTRAINT "court_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtlevel courtlevel_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtlevel courtlevel_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtlevel"
    ADD CONSTRAINT "courtlevel_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtstation courtstation_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation"
    ADD CONSTRAINT "courtstation_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtstation courtstation_court_level_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation"
    ADD CONSTRAINT "courtstation_court_level_fkey" FOREIGN KEY ("court_level") REFERENCES "courtlevel"("id");


--
-- Name: courtstation courtstation_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation"
    ADD CONSTRAINT "courtstation_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: courtstation courtstation_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "courtstation"
    ADD CONSTRAINT "courtstation_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: defendant defendant_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: defendant defendant_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: defendant_gateregister defendant_gateregister_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_gateregister"
    ADD CONSTRAINT "defendant_gateregister_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: defendant_gateregister defendant_gateregister_gateregister_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_gateregister"
    ADD CONSTRAINT "defendant_gateregister_gateregister_fkey" FOREIGN KEY ("gateregister") REFERENCES "gateregister"("id");


--
-- Name: defendant defendant_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: defendant_hearing defendant_hearing_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: defendant_hearing defendant_hearing_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_hearing"
    ADD CONSTRAINT "defendant_hearing_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: defendant_medevent defendant_medevent_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_medevent"
    ADD CONSTRAINT "defendant_medevent_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: defendant_medevent defendant_medevent_medevent_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant_medevent"
    ADD CONSTRAINT "defendant_medevent_medevent_fkey" FOREIGN KEY ("medevent") REFERENCES "medevent"("id");


--
-- Name: defendant defendant_prisoncell_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "defendant"
    ADD CONSTRAINT "defendant_prisoncell_fkey" FOREIGN KEY ("prisoncell") REFERENCES "prisoncell"("id");


--
-- Name: discipline discipline_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline"
    ADD CONSTRAINT "discipline_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: discipline discipline_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline"
    ADD CONSTRAINT "discipline_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: discipline discipline_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "discipline"
    ADD CONSTRAINT "discipline_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: docarchive docarchive_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive"
    ADD CONSTRAINT "docarchive_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: docarchive docarchive_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive"
    ADD CONSTRAINT "docarchive_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: docarchive_tag docarchive_tag_docarchive_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive_tag"
    ADD CONSTRAINT "docarchive_tag_docarchive_fkey" FOREIGN KEY ("docarchive") REFERENCES "docarchive"("id");


--
-- Name: docarchive_tag docarchive_tag_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "docarchive_tag"
    ADD CONSTRAINT "docarchive_tag_tag_fkey" FOREIGN KEY ("tag") REFERENCES "tag"("id");


--
-- Name: doctemplate doctemplate_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: doctemplate doctemplate_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "doctemplate"
    ADD CONSTRAINT "doctemplate_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: document document_doc_template_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_doc_template_fkey" FOREIGN KEY ("doc_template") REFERENCES "doctemplate"("id");


--
-- Name: document document_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document"
    ADD CONSTRAINT "document_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: document_tag document_tag_document_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_tag"
    ADD CONSTRAINT "document_tag_document_fkey" FOREIGN KEY ("document") REFERENCES "document"("id");


--
-- Name: document_tag document_tag_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "document_tag"
    ADD CONSTRAINT "document_tag_tag_fkey" FOREIGN KEY ("tag") REFERENCES "tag"("id");


--
-- Name: eventlog eventlog_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "eventlog"
    ADD CONSTRAINT "eventlog_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: eventlog eventlog_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "eventlog"
    ADD CONSTRAINT "eventlog_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filing filing_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: filing filing_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filing filing_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filing filing_filing_attorney_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_filing_attorney_fkey" FOREIGN KEY ("filing_attorney") REFERENCES "lawyers"("id");


--
-- Name: filing filing_filing_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing"
    ADD CONSTRAINT "filing_filing_prosecutor_fkey" FOREIGN KEY ("filing_prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: filing_filingtype filing_filingtype_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: filing_filingtype filing_filingtype_filingtype_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_filingtype"
    ADD CONSTRAINT "filing_filingtype_filingtype_fkey" FOREIGN KEY ("filingtype") REFERENCES "filingtype"("id");


--
-- Name: filing_payment filing_payment_filing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_payment"
    ADD CONSTRAINT "filing_payment_filing_fkey" FOREIGN KEY ("filing") REFERENCES "filing"("id");


--
-- Name: filing_payment filing_payment_payment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filing_payment"
    ADD CONSTRAINT "filing_payment_payment_fkey" FOREIGN KEY ("payment") REFERENCES "payment"("id");


--
-- Name: filingtype filingtype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: filingtype filingtype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "filingtype"
    ADD CONSTRAINT "filingtype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gateregister gateregister_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister"
    ADD CONSTRAINT "gateregister_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gateregister gateregister_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister"
    ADD CONSTRAINT "gateregister_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gateregister gateregister_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister"
    ADD CONSTRAINT "gateregister_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: gateregister_warder_2 gateregister_warder_2_gateregister_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder_2"
    ADD CONSTRAINT "gateregister_warder_2_gateregister_fkey" FOREIGN KEY ("gateregister") REFERENCES "gateregister"("id");


--
-- Name: gateregister_warder_2 gateregister_warder_2_warder_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder_2"
    ADD CONSTRAINT "gateregister_warder_2_warder_fkey" FOREIGN KEY ("warder") REFERENCES "warder"("id");


--
-- Name: gateregister_warder gateregister_warder_gateregister_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder"
    ADD CONSTRAINT "gateregister_warder_gateregister_fkey" FOREIGN KEY ("gateregister") REFERENCES "gateregister"("id");


--
-- Name: gateregister_warder gateregister_warder_warder_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gateregister_warder"
    ADD CONSTRAINT "gateregister_warder_warder_fkey" FOREIGN KEY ("warder") REFERENCES "warder"("id");


--
-- Name: gender gender_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: gender gender_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "gender"
    ADD CONSTRAINT "gender_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: hearing hearing_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_court_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_court_fkey" FOREIGN KEY ("court") REFERENCES "court"("id");


--
-- Name: hearing hearing_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearing hearing_hearing_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing"
    ADD CONSTRAINT "hearing_hearing_type_fkey" FOREIGN KEY ("hearing_type") REFERENCES "hearingtype"("id");


--
-- Name: hearing_judicialofficer hearing_judicialofficer_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judicialofficer"
    ADD CONSTRAINT "hearing_judicialofficer_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_judicialofficer hearing_judicialofficer_judicialofficer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_judicialofficer"
    ADD CONSTRAINT "hearing_judicialofficer_judicialofficer_fkey" FOREIGN KEY ("judicialofficer") REFERENCES "judicialofficer"("id");


--
-- Name: hearing_lawyers hearing_lawyers_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_lawyers"
    ADD CONSTRAINT "hearing_lawyers_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_lawyers hearing_lawyers_lawyers_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_lawyers"
    ADD CONSTRAINT "hearing_lawyers_lawyers_fkey" FOREIGN KEY ("lawyers") REFERENCES "lawyers"("id");


--
-- Name: hearing_polofficer hearing_polofficer_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_polofficer"
    ADD CONSTRAINT "hearing_polofficer_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_polofficer hearing_polofficer_polofficer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_polofficer"
    ADD CONSTRAINT "hearing_polofficer_polofficer_fkey" FOREIGN KEY ("polofficer") REFERENCES "polofficer"("id");


--
-- Name: hearing_prosecutor hearing_prosecutor_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_prosecutor hearing_prosecutor_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_prosecutor"
    ADD CONSTRAINT "hearing_prosecutor_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: hearing_tag hearing_tag_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_tag"
    ADD CONSTRAINT "hearing_tag_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_tag hearing_tag_tag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_tag"
    ADD CONSTRAINT "hearing_tag_tag_fkey" FOREIGN KEY ("tag") REFERENCES "tag"("id");


--
-- Name: hearing_witness hearing_witness_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_witness"
    ADD CONSTRAINT "hearing_witness_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: hearing_witness hearing_witness_witness_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearing_witness"
    ADD CONSTRAINT "hearing_witness_witness_fkey" FOREIGN KEY ("witness") REFERENCES "witness"("id");


--
-- Name: hearingtype hearingtype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: hearingtype hearingtype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "hearingtype"
    ADD CONSTRAINT "hearingtype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation investigation_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: investigation investigation_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation investigation_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation"
    ADD CONSTRAINT "investigation_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: investigation_polofficer investigation_polofficer_investigation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_polofficer"
    ADD CONSTRAINT "investigation_polofficer_investigation_fkey" FOREIGN KEY ("investigation") REFERENCES "investigation"("id");


--
-- Name: investigation_polofficer investigation_polofficer_polofficer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_polofficer"
    ADD CONSTRAINT "investigation_polofficer_polofficer_fkey" FOREIGN KEY ("polofficer") REFERENCES "polofficer"("id");


--
-- Name: investigation_witness investigation_witness_investigation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_witness"
    ADD CONSTRAINT "investigation_witness_investigation_fkey" FOREIGN KEY ("investigation") REFERENCES "investigation"("id");


--
-- Name: investigation_witness investigation_witness_witness_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "investigation_witness"
    ADD CONSTRAINT "investigation_witness_witness_fkey" FOREIGN KEY ("witness") REFERENCES "witness"("id");


--
-- Name: jo_rank jo_rank_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "jo_rank"
    ADD CONSTRAINT "jo_rank_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: jo_rank jo_rank_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "jo_rank"
    ADD CONSTRAINT "jo_rank_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: judicialofficer judicialofficer_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: judicialofficer judicialofficer_court_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_court_fkey" FOREIGN KEY ("court") REFERENCES "court"("id");


--
-- Name: judicialofficer judicialofficer_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: judicialofficer judicialofficer_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: judicialofficer judicialofficer_j_o__rank_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "judicialofficer"
    ADD CONSTRAINT "judicialofficer_j_o__rank_fkey" FOREIGN KEY ("j_o__rank") REFERENCES "jo_rank"("id");


--
-- Name: lawfirm lawfirm_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: lawfirm lawfirm_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawfirm"
    ADD CONSTRAINT "lawfirm_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: lawyers lawyers_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers"
    ADD CONSTRAINT "lawyers_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: lawyers lawyers_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers"
    ADD CONSTRAINT "lawyers_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: lawyers lawyers_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers"
    ADD CONSTRAINT "lawyers_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: lawyers lawyers_law_firm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "lawyers"
    ADD CONSTRAINT "lawyers_law_firm_fkey" FOREIGN KEY ("law_firm") REFERENCES "lawfirm"("id");


--
-- Name: medevent medevent_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "medevent"
    ADD CONSTRAINT "medevent_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: medevent medevent_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "medevent"
    ADD CONSTRAINT "medevent_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: natureofsuit natureofsuit_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: natureofsuit natureofsuit_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "natureofsuit"
    ADD CONSTRAINT "natureofsuit_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: payment payment_bail_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_bail_fkey" FOREIGN KEY ("bail") REFERENCES "bail"("id");


--
-- Name: payment payment_case_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_case_fkey" FOREIGN KEY ("case") REFERENCES "case"("id");


--
-- Name: payment payment_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: payment payment_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: payment payment_payment_method_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "payment"
    ADD CONSTRAINT "payment_payment_method_fkey" FOREIGN KEY ("payment_method") REFERENCES "paymentmethod"("id");


--
-- Name: paymentmethod paymentmethod_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "paymentmethod"
    ADD CONSTRAINT "paymentmethod_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: paymentmethod paymentmethod_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "paymentmethod"
    ADD CONSTRAINT "paymentmethod_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: plaintiff plaintiff_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: plaintiff plaintiff_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: plaintiff plaintiff_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "plaintiff"
    ADD CONSTRAINT "plaintiff_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: policerank policerank_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerank"
    ADD CONSTRAINT "policerank_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policerank policerank_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerank"
    ADD CONSTRAINT "policerank_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policerole policerole_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policerole policerole_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policerole"
    ADD CONSTRAINT "policerole_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestation policestation_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestation policestation_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestation policestation_police_station_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_police_station_type_fkey" FOREIGN KEY ("police_station_type") REFERENCES "policestationtype"("id");


--
-- Name: policestation policestation_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestation"
    ADD CONSTRAINT "policestation_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: policestationtype policestationtype_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestationtype"
    ADD CONSTRAINT "policestationtype_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: policestationtype policestationtype_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "policestationtype"
    ADD CONSTRAINT "policestationtype_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: polofficer polofficer_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: polofficer polofficer_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: polofficer polofficer_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: polofficer polofficer_pol_supervisor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_pol_supervisor_fkey" FOREIGN KEY ("pol_supervisor") REFERENCES "case"("id");


--
-- Name: polofficer polofficer_police_rank_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_police_rank_fkey" FOREIGN KEY ("police_rank") REFERENCES "policerank"("id");


--
-- Name: polofficer_policerole polofficer_policerole_policerole_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer_policerole"
    ADD CONSTRAINT "polofficer_policerole_policerole_fkey" FOREIGN KEY ("policerole") REFERENCES "policerole"("id");


--
-- Name: polofficer_policerole polofficer_policerole_polofficer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer_policerole"
    ADD CONSTRAINT "polofficer_policerole_polofficer_fkey" FOREIGN KEY ("polofficer") REFERENCES "polofficer"("id");


--
-- Name: polofficer polofficer_reports_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "polofficer"
    ADD CONSTRAINT "polofficer_reports_to_fkey" FOREIGN KEY ("reports_to") REFERENCES "polofficer"("id");


--
-- Name: prison prison_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prison prison_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prison_securityrank prison_securityrank_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison_securityrank"
    ADD CONSTRAINT "prison_securityrank_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: prison_securityrank prison_securityrank_securityrank_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison_securityrank"
    ADD CONSTRAINT "prison_securityrank_securityrank_fkey" FOREIGN KEY ("securityrank") REFERENCES "securityrank"("id");


--
-- Name: prison prison_town_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prison"
    ADD CONSTRAINT "prison_town_fkey" FOREIGN KEY ("town") REFERENCES "town"("id");


--
-- Name: prisoncell prisoncell_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell"
    ADD CONSTRAINT "prisoncell_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisoncell prisoncell_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell"
    ADD CONSTRAINT "prisoncell_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisoncell prisoncell_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncell"
    ADD CONSTRAINT "prisoncell_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: prisoncommital prisoncommital_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisoncommital prisoncommital_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisoncommital prisoncommital_defendant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_defendant_fkey" FOREIGN KEY ("defendant") REFERENCES "defendant"("id");


--
-- Name: prisoncommital prisoncommital_hearing_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_hearing_fkey" FOREIGN KEY ("hearing") REFERENCES "hearing"("id");


--
-- Name: prisoncommital prisoncommital_judicial_officer_warrant_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_judicial_officer_warrant_fkey" FOREIGN KEY ("judicial_officer_warrant") REFERENCES "judicialofficer"("id");


--
-- Name: prisoncommital prisoncommital_police_officer_commiting_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_police_officer_commiting_fkey" FOREIGN KEY ("police_officer_commiting") REFERENCES "polofficer"("id");


--
-- Name: prisoncommital prisoncommital_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital"
    ADD CONSTRAINT "prisoncommital_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: prisoncommital_warder prisoncommital_warder_prisoncommital_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital_warder"
    ADD CONSTRAINT "prisoncommital_warder_prisoncommital_prison_fkey" FOREIGN KEY ("prisoncommital_prison", "prisoncommital_warrantno") REFERENCES "prisoncommital"("prison", "warrantno");


--
-- Name: prisoncommital_warder prisoncommital_warder_warder_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisoncommital_warder"
    ADD CONSTRAINT "prisoncommital_warder_warder_fkey" FOREIGN KEY ("warder") REFERENCES "warder"("id");


--
-- Name: prisonerproperty prisonerproperty_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty"
    ADD CONSTRAINT "prisonerproperty_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisonerproperty prisonerproperty_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty"
    ADD CONSTRAINT "prisonerproperty_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prisonerproperty prisonerproperty_prison_commital_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prisonerproperty"
    ADD CONSTRAINT "prisonerproperty_prison_commital_prison_fkey" FOREIGN KEY ("prison_commital_prison", "prison_commital_warrantno") REFERENCES "prisoncommital"("prison", "warrantno");


--
-- Name: prosecutor prosecutor_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutor prosecutor_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutor prosecutor_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor"
    ADD CONSTRAINT "prosecutor_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_prosecutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_prosecutor_fkey" FOREIGN KEY ("prosecutor") REFERENCES "prosecutor"("id");


--
-- Name: prosecutor_prosecutorteam prosecutor_prosecutorteam_prosecutorteam_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutor_prosecutorteam"
    ADD CONSTRAINT "prosecutor_prosecutorteam_prosecutorteam_fkey" FOREIGN KEY ("prosecutorteam") REFERENCES "prosecutorteam"("id");


--
-- Name: prosecutorteam prosecutorteam_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: prosecutorteam prosecutorteam_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "prosecutorteam"
    ADD CONSTRAINT "prosecutorteam_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: remission remission_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission"
    ADD CONSTRAINT "remission_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: remission remission_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission"
    ADD CONSTRAINT "remission_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: remission remission_prison_commital_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "remission"
    ADD CONSTRAINT "remission_prison_commital_prison_fkey" FOREIGN KEY ("prison_commital_prison", "prison_commital_warrantno") REFERENCES "prisoncommital"("prison", "warrantno");


--
-- Name: securityrank securityrank_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "securityrank"
    ADD CONSTRAINT "securityrank_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: securityrank securityrank_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "securityrank"
    ADD CONSTRAINT "securityrank_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: subcounty subcounty_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty"
    ADD CONSTRAINT "subcounty_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: subcounty subcounty_county_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty"
    ADD CONSTRAINT "subcounty_county_fkey" FOREIGN KEY ("county") REFERENCES "county"("id");


--
-- Name: subcounty subcounty_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "subcounty"
    ADD CONSTRAINT "subcounty_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: surety surety_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "surety"
    ADD CONSTRAINT "surety_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: tag tag_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "tag"
    ADD CONSTRAINT "tag_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: tag tag_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "tag"
    ADD CONSTRAINT "tag_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: town town_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: town town_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: town town_subcounty_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "town"
    ADD CONSTRAINT "town_subcounty_fkey" FOREIGN KEY ("subcounty") REFERENCES "subcounty"("id");


--
-- Name: transaction transaction_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "transaction"
    ADD CONSTRAINT "transaction_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "ab_user"("id");


--
-- Name: visit visit_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit"
    ADD CONSTRAINT "visit_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: visit visit_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit"
    ADD CONSTRAINT "visit_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: visit visit_defendants_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit"
    ADD CONSTRAINT "visit_defendants_fkey" FOREIGN KEY ("defendants") REFERENCES "defendant"("id");


--
-- Name: visit visit_vistors_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visit"
    ADD CONSTRAINT "visit_vistors_fkey" FOREIGN KEY ("vistors") REFERENCES "visitor"("id");


--
-- Name: visitor visitor_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor"
    ADD CONSTRAINT "visitor_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: visitor visitor_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor"
    ADD CONSTRAINT "visitor_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: visitor visitor_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "visitor"
    ADD CONSTRAINT "visitor_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- Name: warder warder_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: warder warder_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: warder warder_prison_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_prison_fkey" FOREIGN KEY ("prison") REFERENCES "prison"("id");


--
-- Name: warder warder_reports_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_reports_to_fkey" FOREIGN KEY ("reports_to") REFERENCES "warder"("id");


--
-- Name: warder warder_warder_rank_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warder"
    ADD CONSTRAINT "warder_warder_rank_fkey" FOREIGN KEY ("warder_rank") REFERENCES "warderrank"("id");


--
-- Name: warderrank warderrank_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warderrank"
    ADD CONSTRAINT "warderrank_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: warderrank warderrank_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "warderrank"
    ADD CONSTRAINT "warderrank_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: witness witness_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness"
    ADD CONSTRAINT "witness_changed_by_fk_fkey" FOREIGN KEY ("changed_by_fk") REFERENCES "ab_user"("id");


--
-- Name: witness witness_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness"
    ADD CONSTRAINT "witness_created_by_fk_fkey" FOREIGN KEY ("created_by_fk") REFERENCES "ab_user"("id");


--
-- Name: witness witness_gender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nyimbi
--

ALTER TABLE ONLY "witness"
    ADD CONSTRAINT "witness_gender_fkey" FOREIGN KEY ("gender") REFERENCES "gender"("id");


--
-- PostgreSQL database dump complete
--

\connect "nyimbi"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

\connect "postgres"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "postgres" IS 'default administrative connection database';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

\connect "template1"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "template1" IS 'default template for new databases';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

