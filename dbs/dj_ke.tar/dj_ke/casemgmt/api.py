from . import models
from . import serializers
from rest_framework import viewsets, permissions


class BailViewSet(viewsets.ModelViewSet):
    """ViewSet for the Bail class"""

    queryset = models.Bail.objects.all()
    serializer_class = serializers.BailSerializer
    permission_classes = [permissions.IsAuthenticated]


class BailSuretyViewSet(viewsets.ModelViewSet):
    """ViewSet for the BailSurety class"""

    queryset = models.BailSurety.objects.all()
    serializer_class = serializers.BailSuretySerializer
    permission_classes = [permissions.IsAuthenticated]


class BailSuretyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the BailSuretyVersion class"""

    queryset = models.BailSuretyVersion.objects.all()
    serializer_class = serializers.BailSuretyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class BailVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the BailVersion class"""

    queryset = models.BailVersion.objects.all()
    serializer_class = serializers.BailVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseViewSet(viewsets.ModelViewSet):
    """ViewSet for the Case class"""

    queryset = models.Case.objects.all()
    serializer_class = serializers.CaseSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseCasecategoryViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseCasecategory class"""

    queryset = models.CaseCasecategory.objects.all()
    serializer_class = serializers.CaseCasecategorySerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseCasecategoryVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseCasecategoryVersion class"""

    queryset = models.CaseCasecategoryVersion.objects.all()
    serializer_class = serializers.CaseCasecategoryVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseCauseofactionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseCauseofaction class"""

    queryset = models.CaseCauseofaction.objects.all()
    serializer_class = serializers.CaseCauseofactionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseCauseofactionVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseCauseofactionVersion class"""

    queryset = models.CaseCauseofactionVersion.objects.all()
    serializer_class = serializers.CaseCauseofactionVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseDefendantViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseDefendant class"""

    queryset = models.CaseDefendant.objects.all()
    serializer_class = serializers.CaseDefendantSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseDefendantVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseDefendantVersion class"""

    queryset = models.CaseDefendantVersion.objects.all()
    serializer_class = serializers.CaseDefendantVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseNatureofsuitViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseNatureofsuit class"""

    queryset = models.CaseNatureofsuit.objects.all()
    serializer_class = serializers.CaseNatureofsuitSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseNatureofsuitVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseNatureofsuitVersion class"""

    queryset = models.CaseNatureofsuitVersion.objects.all()
    serializer_class = serializers.CaseNatureofsuitVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CasePlaintiffViewSet(viewsets.ModelViewSet):
    """ViewSet for the CasePlaintiff class"""

    queryset = models.CasePlaintiff.objects.all()
    serializer_class = serializers.CasePlaintiffSerializer
    permission_classes = [permissions.IsAuthenticated]


class CasePlaintiffVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CasePlaintiffVersion class"""

    queryset = models.CasePlaintiffVersion.objects.all()
    serializer_class = serializers.CasePlaintiffVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CasePolofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the CasePolofficer class"""

    queryset = models.CasePolofficer.objects.all()
    serializer_class = serializers.CasePolofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class CasePolofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CasePolofficerVersion class"""

    queryset = models.CasePolofficerVersion.objects.all()
    serializer_class = serializers.CasePolofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseProsecutorViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseProsecutor class"""

    queryset = models.CaseProsecutor.objects.all()
    serializer_class = serializers.CaseProsecutorSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseProsecutor2ViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseProsecutor2 class"""

    queryset = models.CaseProsecutor2.objects.all()
    serializer_class = serializers.CaseProsecutor2Serializer
    permission_classes = [permissions.IsAuthenticated]


class CaseProsecutor2VersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseProsecutor2Version class"""

    queryset = models.CaseProsecutor2Version.objects.all()
    serializer_class = serializers.CaseProsecutor2VersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseProsecutorVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseProsecutorVersion class"""

    queryset = models.CaseProsecutorVersion.objects.all()
    serializer_class = serializers.CaseProsecutorVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseTagViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseTag class"""

    queryset = models.CaseTag.objects.all()
    serializer_class = serializers.CaseTagSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseTagVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseTagVersion class"""

    queryset = models.CaseTagVersion.objects.all()
    serializer_class = serializers.CaseTagVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseVersion class"""

    queryset = models.CaseVersion.objects.all()
    serializer_class = serializers.CaseVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseWitnessViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseWitness class"""

    queryset = models.CaseWitness.objects.all()
    serializer_class = serializers.CaseWitnessSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseWitnessVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseWitnessVersion class"""

    queryset = models.CaseWitnessVersion.objects.all()
    serializer_class = serializers.CaseWitnessVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CasecategoryViewSet(viewsets.ModelViewSet):
    """ViewSet for the Casecategory class"""

    queryset = models.Casecategory.objects.all()
    serializer_class = serializers.CasecategorySerializer
    permission_classes = [permissions.IsAuthenticated]


class CasecategoryVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CasecategoryVersion class"""

    queryset = models.CasecategoryVersion.objects.all()
    serializer_class = serializers.CasecategoryVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseinvestigationViewSet(viewsets.ModelViewSet):
    """ViewSet for the Caseinvestigation class"""

    queryset = models.Caseinvestigation.objects.all()
    serializer_class = serializers.CaseinvestigationSerializer
    permission_classes = [permissions.IsAuthenticated]


class CaseinvestigationVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CaseinvestigationVersion class"""

    queryset = models.CaseinvestigationVersion.objects.all()
    serializer_class = serializers.CaseinvestigationVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionViewSet(viewsets.ModelViewSet):
    """ViewSet for the Causeofaction class"""

    queryset = models.Causeofaction.objects.all()
    serializer_class = serializers.CauseofactionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionFilingViewSet(viewsets.ModelViewSet):
    """ViewSet for the CauseofactionFiling class"""

    queryset = models.CauseofactionFiling.objects.all()
    serializer_class = serializers.CauseofactionFilingSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionFilingVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CauseofactionFilingVersion class"""

    queryset = models.CauseofactionFilingVersion.objects.all()
    serializer_class = serializers.CauseofactionFilingVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionHearingViewSet(viewsets.ModelViewSet):
    """ViewSet for the CauseofactionHearing class"""

    queryset = models.CauseofactionHearing.objects.all()
    serializer_class = serializers.CauseofactionHearingSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionHearingVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CauseofactionHearingVersion class"""

    queryset = models.CauseofactionHearingVersion.objects.all()
    serializer_class = serializers.CauseofactionHearingVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CauseofactionVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CauseofactionVersion class"""

    queryset = models.CauseofactionVersion.objects.all()
    serializer_class = serializers.CauseofactionVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CommitaltypeViewSet(viewsets.ModelViewSet):
    """ViewSet for the Commitaltype class"""

    queryset = models.Commitaltype.objects.all()
    serializer_class = serializers.CommitaltypeSerializer
    permission_classes = [permissions.IsAuthenticated]


class CommitaltypePrisoncommitalViewSet(viewsets.ModelViewSet):
    """ViewSet for the CommitaltypePrisoncommital class"""

    queryset = models.CommitaltypePrisoncommital.objects.all()
    serializer_class = serializers.CommitaltypePrisoncommitalSerializer
    permission_classes = [permissions.IsAuthenticated]


class CommitaltypePrisoncommitalVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CommitaltypePrisoncommitalVersion class"""

    queryset = models.CommitaltypePrisoncommitalVersion.objects.all()
    serializer_class = serializers.CommitaltypePrisoncommitalVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CommitaltypeVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CommitaltypeVersion class"""

    queryset = models.CommitaltypeVersion.objects.all()
    serializer_class = serializers.CommitaltypeVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class ConstituencyViewSet(viewsets.ModelViewSet):
    """ViewSet for the Constituency class"""

    queryset = models.Constituency.objects.all()
    serializer_class = serializers.ConstituencySerializer
    permission_classes = [permissions.IsAuthenticated]


class ConstituencyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the ConstituencyVersion class"""

    queryset = models.ConstituencyVersion.objects.all()
    serializer_class = serializers.ConstituencyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CountyViewSet(viewsets.ModelViewSet):
    """ViewSet for the County class"""

    queryset = models.County.objects.all()
    serializer_class = serializers.CountySerializer
    permission_classes = [permissions.IsAuthenticated]


class CountyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CountyVersion class"""

    queryset = models.CountyVersion.objects.all()
    serializer_class = serializers.CountyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtViewSet(viewsets.ModelViewSet):
    """ViewSet for the Court class"""

    queryset = models.Court.objects.all()
    serializer_class = serializers.CourtSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CourtVersion class"""

    queryset = models.CourtVersion.objects.all()
    serializer_class = serializers.CourtVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtlevelViewSet(viewsets.ModelViewSet):
    """ViewSet for the Courtlevel class"""

    queryset = models.Courtlevel.objects.all()
    serializer_class = serializers.CourtlevelSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtlevelVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CourtlevelVersion class"""

    queryset = models.CourtlevelVersion.objects.all()
    serializer_class = serializers.CourtlevelVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtstationViewSet(viewsets.ModelViewSet):
    """ViewSet for the Courtstation class"""

    queryset = models.Courtstation.objects.all()
    serializer_class = serializers.CourtstationSerializer
    permission_classes = [permissions.IsAuthenticated]


class CourtstationVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the CourtstationVersion class"""

    queryset = models.CourtstationVersion.objects.all()
    serializer_class = serializers.CourtstationVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantViewSet(viewsets.ModelViewSet):
    """ViewSet for the Defendant class"""

    queryset = models.Defendant.objects.all()
    serializer_class = serializers.DefendantSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantGateregisterViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantGateregister class"""

    queryset = models.DefendantGateregister.objects.all()
    serializer_class = serializers.DefendantGateregisterSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantGateregisterVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantGateregisterVersion class"""

    queryset = models.DefendantGateregisterVersion.objects.all()
    serializer_class = serializers.DefendantGateregisterVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantHearingViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantHearing class"""

    queryset = models.DefendantHearing.objects.all()
    serializer_class = serializers.DefendantHearingSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantHearingVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantHearingVersion class"""

    queryset = models.DefendantHearingVersion.objects.all()
    serializer_class = serializers.DefendantHearingVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantMedeventViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantMedevent class"""

    queryset = models.DefendantMedevent.objects.all()
    serializer_class = serializers.DefendantMedeventSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantMedeventVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantMedeventVersion class"""

    queryset = models.DefendantMedeventVersion.objects.all()
    serializer_class = serializers.DefendantMedeventVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DefendantVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DefendantVersion class"""

    queryset = models.DefendantVersion.objects.all()
    serializer_class = serializers.DefendantVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DisciplineViewSet(viewsets.ModelViewSet):
    """ViewSet for the Discipline class"""

    queryset = models.Discipline.objects.all()
    serializer_class = serializers.DisciplineSerializer
    permission_classes = [permissions.IsAuthenticated]


class DisciplineVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DisciplineVersion class"""

    queryset = models.DisciplineVersion.objects.all()
    serializer_class = serializers.DisciplineVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocStoreViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocStore class"""

    queryset = models.DocStore.objects.all()
    serializer_class = serializers.DocStoreSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocarchiveViewSet(viewsets.ModelViewSet):
    """ViewSet for the Docarchive class"""

    queryset = models.Docarchive.objects.all()
    serializer_class = serializers.DocarchiveSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocarchiveTagViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocarchiveTag class"""

    queryset = models.DocarchiveTag.objects.all()
    serializer_class = serializers.DocarchiveTagSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocarchiveTagVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocarchiveTagVersion class"""

    queryset = models.DocarchiveTagVersion.objects.all()
    serializer_class = serializers.DocarchiveTagVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocarchiveVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocarchiveVersion class"""

    queryset = models.DocarchiveVersion.objects.all()
    serializer_class = serializers.DocarchiveVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DoctemplateViewSet(viewsets.ModelViewSet):
    """ViewSet for the Doctemplate class"""

    queryset = models.Doctemplate.objects.all()
    serializer_class = serializers.DoctemplateSerializer
    permission_classes = [permissions.IsAuthenticated]


class DoctemplateVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DoctemplateVersion class"""

    queryset = models.DoctemplateVersion.objects.all()
    serializer_class = serializers.DoctemplateVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocumentViewSet(viewsets.ModelViewSet):
    """ViewSet for the Document class"""

    queryset = models.Document.objects.all()
    serializer_class = serializers.DocumentSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocumentTagViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocumentTag class"""

    queryset = models.DocumentTag.objects.all()
    serializer_class = serializers.DocumentTagSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocumentTagVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocumentTagVersion class"""

    queryset = models.DocumentTagVersion.objects.all()
    serializer_class = serializers.DocumentTagVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class DocumentVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the DocumentVersion class"""

    queryset = models.DocumentVersion.objects.all()
    serializer_class = serializers.DocumentVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class EventlogViewSet(viewsets.ModelViewSet):
    """ViewSet for the Eventlog class"""

    queryset = models.Eventlog.objects.all()
    serializer_class = serializers.EventlogSerializer
    permission_classes = [permissions.IsAuthenticated]


class EventlogVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the EventlogVersion class"""

    queryset = models.EventlogVersion.objects.all()
    serializer_class = serializers.EventlogVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingViewSet(viewsets.ModelViewSet):
    """ViewSet for the Filing class"""

    queryset = models.Filing.objects.all()
    serializer_class = serializers.FilingSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingFilingtypeViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingFilingtype class"""

    queryset = models.FilingFilingtype.objects.all()
    serializer_class = serializers.FilingFilingtypeSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingFilingtypeVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingFilingtypeVersion class"""

    queryset = models.FilingFilingtypeVersion.objects.all()
    serializer_class = serializers.FilingFilingtypeVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingPaymentViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingPayment class"""

    queryset = models.FilingPayment.objects.all()
    serializer_class = serializers.FilingPaymentSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingPaymentVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingPaymentVersion class"""

    queryset = models.FilingPaymentVersion.objects.all()
    serializer_class = serializers.FilingPaymentVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingVersion class"""

    queryset = models.FilingVersion.objects.all()
    serializer_class = serializers.FilingVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingtypeViewSet(viewsets.ModelViewSet):
    """ViewSet for the Filingtype class"""

    queryset = models.Filingtype.objects.all()
    serializer_class = serializers.FilingtypeSerializer
    permission_classes = [permissions.IsAuthenticated]


class FilingtypeVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the FilingtypeVersion class"""

    queryset = models.FilingtypeVersion.objects.all()
    serializer_class = serializers.FilingtypeVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterViewSet(viewsets.ModelViewSet):
    """ViewSet for the Gateregister class"""

    queryset = models.Gateregister.objects.all()
    serializer_class = serializers.GateregisterSerializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the GateregisterVersion class"""

    queryset = models.GateregisterVersion.objects.all()
    serializer_class = serializers.GateregisterVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterWarderViewSet(viewsets.ModelViewSet):
    """ViewSet for the GateregisterWarder class"""

    queryset = models.GateregisterWarder.objects.all()
    serializer_class = serializers.GateregisterWarderSerializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterWarder2ViewSet(viewsets.ModelViewSet):
    """ViewSet for the GateregisterWarder2 class"""

    queryset = models.GateregisterWarder2.objects.all()
    serializer_class = serializers.GateregisterWarder2Serializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterWarder2VersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the GateregisterWarder2Version class"""

    queryset = models.GateregisterWarder2Version.objects.all()
    serializer_class = serializers.GateregisterWarder2VersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class GateregisterWarderVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the GateregisterWarderVersion class"""

    queryset = models.GateregisterWarderVersion.objects.all()
    serializer_class = serializers.GateregisterWarderVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class GenderViewSet(viewsets.ModelViewSet):
    """ViewSet for the Gender class"""

    queryset = models.Gender.objects.all()
    serializer_class = serializers.GenderSerializer
    permission_classes = [permissions.IsAuthenticated]


class GenderVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the GenderVersion class"""

    queryset = models.GenderVersion.objects.all()
    serializer_class = serializers.GenderVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingViewSet(viewsets.ModelViewSet):
    """ViewSet for the Hearing class"""

    queryset = models.Hearing.objects.all()
    serializer_class = serializers.HearingSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingJudicialofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingJudicialofficer class"""

    queryset = models.HearingJudicialofficer.objects.all()
    serializer_class = serializers.HearingJudicialofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingJudicialofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingJudicialofficerVersion class"""

    queryset = models.HearingJudicialofficerVersion.objects.all()
    serializer_class = serializers.HearingJudicialofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingLawyersViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingLawyers class"""

    queryset = models.HearingLawyers.objects.all()
    serializer_class = serializers.HearingLawyersSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingLawyersVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingLawyersVersion class"""

    queryset = models.HearingLawyersVersion.objects.all()
    serializer_class = serializers.HearingLawyersVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingPolofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingPolofficer class"""

    queryset = models.HearingPolofficer.objects.all()
    serializer_class = serializers.HearingPolofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingPolofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingPolofficerVersion class"""

    queryset = models.HearingPolofficerVersion.objects.all()
    serializer_class = serializers.HearingPolofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingProsecutorViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingProsecutor class"""

    queryset = models.HearingProsecutor.objects.all()
    serializer_class = serializers.HearingProsecutorSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingProsecutorVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingProsecutorVersion class"""

    queryset = models.HearingProsecutorVersion.objects.all()
    serializer_class = serializers.HearingProsecutorVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingTagViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingTag class"""

    queryset = models.HearingTag.objects.all()
    serializer_class = serializers.HearingTagSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingTagVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingTagVersion class"""

    queryset = models.HearingTagVersion.objects.all()
    serializer_class = serializers.HearingTagVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingVersion class"""

    queryset = models.HearingVersion.objects.all()
    serializer_class = serializers.HearingVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingWitnessViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingWitness class"""

    queryset = models.HearingWitness.objects.all()
    serializer_class = serializers.HearingWitnessSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingWitnessVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingWitnessVersion class"""

    queryset = models.HearingWitnessVersion.objects.all()
    serializer_class = serializers.HearingWitnessVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingtypeViewSet(viewsets.ModelViewSet):
    """ViewSet for the Hearingtype class"""

    queryset = models.Hearingtype.objects.all()
    serializer_class = serializers.HearingtypeSerializer
    permission_classes = [permissions.IsAuthenticated]


class HearingtypeVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the HearingtypeVersion class"""

    queryset = models.HearingtypeVersion.objects.all()
    serializer_class = serializers.HearingtypeVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationViewSet(viewsets.ModelViewSet):
    """ViewSet for the Investigation class"""

    queryset = models.Investigation.objects.all()
    serializer_class = serializers.InvestigationSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationPolofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the InvestigationPolofficer class"""

    queryset = models.InvestigationPolofficer.objects.all()
    serializer_class = serializers.InvestigationPolofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationPolofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the InvestigationPolofficerVersion class"""

    queryset = models.InvestigationPolofficerVersion.objects.all()
    serializer_class = serializers.InvestigationPolofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the InvestigationVersion class"""

    queryset = models.InvestigationVersion.objects.all()
    serializer_class = serializers.InvestigationVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationWitnessViewSet(viewsets.ModelViewSet):
    """ViewSet for the InvestigationWitness class"""

    queryset = models.InvestigationWitness.objects.all()
    serializer_class = serializers.InvestigationWitnessSerializer
    permission_classes = [permissions.IsAuthenticated]


class InvestigationWitnessVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the InvestigationWitnessVersion class"""

    queryset = models.InvestigationWitnessVersion.objects.all()
    serializer_class = serializers.InvestigationWitnessVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class JoRankViewSet(viewsets.ModelViewSet):
    """ViewSet for the JoRank class"""

    queryset = models.JoRank.objects.all()
    serializer_class = serializers.JoRankSerializer
    permission_classes = [permissions.IsAuthenticated]


class JoRankVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the JoRankVersion class"""

    queryset = models.JoRankVersion.objects.all()
    serializer_class = serializers.JoRankVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class JudicialofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the Judicialofficer class"""

    queryset = models.Judicialofficer.objects.all()
    serializer_class = serializers.JudicialofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class JudicialofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the JudicialofficerVersion class"""

    queryset = models.JudicialofficerVersion.objects.all()
    serializer_class = serializers.JudicialofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class LawfirmViewSet(viewsets.ModelViewSet):
    """ViewSet for the Lawfirm class"""

    queryset = models.Lawfirm.objects.all()
    serializer_class = serializers.LawfirmSerializer
    permission_classes = [permissions.IsAuthenticated]


class LawfirmVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the LawfirmVersion class"""

    queryset = models.LawfirmVersion.objects.all()
    serializer_class = serializers.LawfirmVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class LawyersViewSet(viewsets.ModelViewSet):
    """ViewSet for the Lawyers class"""

    queryset = models.Lawyers.objects.all()
    serializer_class = serializers.LawyersSerializer
    permission_classes = [permissions.IsAuthenticated]


class LawyersVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the LawyersVersion class"""

    queryset = models.LawyersVersion.objects.all()
    serializer_class = serializers.LawyersVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class MedeventViewSet(viewsets.ModelViewSet):
    """ViewSet for the Medevent class"""

    queryset = models.Medevent.objects.all()
    serializer_class = serializers.MedeventSerializer
    permission_classes = [permissions.IsAuthenticated]


class MedeventVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the MedeventVersion class"""

    queryset = models.MedeventVersion.objects.all()
    serializer_class = serializers.MedeventVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class NatureofsuitViewSet(viewsets.ModelViewSet):
    """ViewSet for the Natureofsuit class"""

    queryset = models.Natureofsuit.objects.all()
    serializer_class = serializers.NatureofsuitSerializer
    permission_classes = [permissions.IsAuthenticated]


class NatureofsuitVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the NatureofsuitVersion class"""

    queryset = models.NatureofsuitVersion.objects.all()
    serializer_class = serializers.NatureofsuitVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PaymentViewSet(viewsets.ModelViewSet):
    """ViewSet for the Payment class"""

    queryset = models.Payment.objects.all()
    serializer_class = serializers.PaymentSerializer
    permission_classes = [permissions.IsAuthenticated]


class PaymentVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PaymentVersion class"""

    queryset = models.PaymentVersion.objects.all()
    serializer_class = serializers.PaymentVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PaymentmethodViewSet(viewsets.ModelViewSet):
    """ViewSet for the Paymentmethod class"""

    queryset = models.Paymentmethod.objects.all()
    serializer_class = serializers.PaymentmethodSerializer
    permission_classes = [permissions.IsAuthenticated]


class PaymentmethodVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PaymentmethodVersion class"""

    queryset = models.PaymentmethodVersion.objects.all()
    serializer_class = serializers.PaymentmethodVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PlaintiffViewSet(viewsets.ModelViewSet):
    """ViewSet for the Plaintiff class"""

    queryset = models.Plaintiff.objects.all()
    serializer_class = serializers.PlaintiffSerializer
    permission_classes = [permissions.IsAuthenticated]


class PlaintiffVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PlaintiffVersion class"""

    queryset = models.PlaintiffVersion.objects.all()
    serializer_class = serializers.PlaintiffVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicerankViewSet(viewsets.ModelViewSet):
    """ViewSet for the Policerank class"""

    queryset = models.Policerank.objects.all()
    serializer_class = serializers.PolicerankSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicerankVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolicerankVersion class"""

    queryset = models.PolicerankVersion.objects.all()
    serializer_class = serializers.PolicerankVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PoliceroleViewSet(viewsets.ModelViewSet):
    """ViewSet for the Policerole class"""

    queryset = models.Policerole.objects.all()
    serializer_class = serializers.PoliceroleSerializer
    permission_classes = [permissions.IsAuthenticated]


class PoliceroleVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PoliceroleVersion class"""

    queryset = models.PoliceroleVersion.objects.all()
    serializer_class = serializers.PoliceroleVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicestationViewSet(viewsets.ModelViewSet):
    """ViewSet for the Policestation class"""

    queryset = models.Policestation.objects.all()
    serializer_class = serializers.PolicestationSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicestationVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolicestationVersion class"""

    queryset = models.PolicestationVersion.objects.all()
    serializer_class = serializers.PolicestationVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicestationtypeViewSet(viewsets.ModelViewSet):
    """ViewSet for the Policestationtype class"""

    queryset = models.Policestationtype.objects.all()
    serializer_class = serializers.PolicestationtypeSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolicestationtypeVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolicestationtypeVersion class"""

    queryset = models.PolicestationtypeVersion.objects.all()
    serializer_class = serializers.PolicestationtypeVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolofficerViewSet(viewsets.ModelViewSet):
    """ViewSet for the Polofficer class"""

    queryset = models.Polofficer.objects.all()
    serializer_class = serializers.PolofficerSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolofficerPoliceroleViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolofficerPolicerole class"""

    queryset = models.PolofficerPolicerole.objects.all()
    serializer_class = serializers.PolofficerPoliceroleSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolofficerPoliceroleVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolofficerPoliceroleVersion class"""

    queryset = models.PolofficerPoliceroleVersion.objects.all()
    serializer_class = serializers.PolofficerPoliceroleVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PolofficerVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PolofficerVersion class"""

    queryset = models.PolofficerVersion.objects.all()
    serializer_class = serializers.PolofficerVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prison class"""

    queryset = models.Prison.objects.all()
    serializer_class = serializers.PrisonSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonSecurityrankViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisonSecurityrank class"""

    queryset = models.PrisonSecurityrank.objects.all()
    serializer_class = serializers.PrisonSecurityrankSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonSecurityrankVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisonSecurityrankVersion class"""

    queryset = models.PrisonSecurityrankVersion.objects.all()
    serializer_class = serializers.PrisonSecurityrankVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisonVersion class"""

    queryset = models.PrisonVersion.objects.all()
    serializer_class = serializers.PrisonVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncellViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prisoncell class"""

    queryset = models.Prisoncell.objects.all()
    serializer_class = serializers.PrisoncellSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncellVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisoncellVersion class"""

    queryset = models.PrisoncellVersion.objects.all()
    serializer_class = serializers.PrisoncellVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncommitalViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prisoncommital class"""

    queryset = models.Prisoncommital.objects.all()
    serializer_class = serializers.PrisoncommitalSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncommitalVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisoncommitalVersion class"""

    queryset = models.PrisoncommitalVersion.objects.all()
    serializer_class = serializers.PrisoncommitalVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncommitalWarderViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisoncommitalWarder class"""

    queryset = models.PrisoncommitalWarder.objects.all()
    serializer_class = serializers.PrisoncommitalWarderSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisoncommitalWarderVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisoncommitalWarderVersion class"""

    queryset = models.PrisoncommitalWarderVersion.objects.all()
    serializer_class = serializers.PrisoncommitalWarderVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonerpropertyViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prisonerproperty class"""

    queryset = models.Prisonerproperty.objects.all()
    serializer_class = serializers.PrisonerpropertySerializer
    permission_classes = [permissions.IsAuthenticated]


class PrisonerpropertyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the PrisonerpropertyVersion class"""

    queryset = models.PrisonerpropertyVersion.objects.all()
    serializer_class = serializers.PrisonerpropertyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prosecutor class"""

    queryset = models.Prosecutor.objects.all()
    serializer_class = serializers.ProsecutorSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorProsecutorteamViewSet(viewsets.ModelViewSet):
    """ViewSet for the ProsecutorProsecutorteam class"""

    queryset = models.ProsecutorProsecutorteam.objects.all()
    serializer_class = serializers.ProsecutorProsecutorteamSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorProsecutorteamVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the ProsecutorProsecutorteamVersion class"""

    queryset = models.ProsecutorProsecutorteamVersion.objects.all()
    serializer_class = serializers.ProsecutorProsecutorteamVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the ProsecutorVersion class"""

    queryset = models.ProsecutorVersion.objects.all()
    serializer_class = serializers.ProsecutorVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorteamViewSet(viewsets.ModelViewSet):
    """ViewSet for the Prosecutorteam class"""

    queryset = models.Prosecutorteam.objects.all()
    serializer_class = serializers.ProsecutorteamSerializer
    permission_classes = [permissions.IsAuthenticated]


class ProsecutorteamVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the ProsecutorteamVersion class"""

    queryset = models.ProsecutorteamVersion.objects.all()
    serializer_class = serializers.ProsecutorteamVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class RemissionViewSet(viewsets.ModelViewSet):
    """ViewSet for the Remission class"""

    queryset = models.Remission.objects.all()
    serializer_class = serializers.RemissionSerializer
    permission_classes = [permissions.IsAuthenticated]


class RemissionVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the RemissionVersion class"""

    queryset = models.RemissionVersion.objects.all()
    serializer_class = serializers.RemissionVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class SecurityrankViewSet(viewsets.ModelViewSet):
    """ViewSet for the Securityrank class"""

    queryset = models.Securityrank.objects.all()
    serializer_class = serializers.SecurityrankSerializer
    permission_classes = [permissions.IsAuthenticated]


class SecurityrankVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the SecurityrankVersion class"""

    queryset = models.SecurityrankVersion.objects.all()
    serializer_class = serializers.SecurityrankVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class SubcountyViewSet(viewsets.ModelViewSet):
    """ViewSet for the Subcounty class"""

    queryset = models.Subcounty.objects.all()
    serializer_class = serializers.SubcountySerializer
    permission_classes = [permissions.IsAuthenticated]


class SubcountyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the SubcountyVersion class"""

    queryset = models.SubcountyVersion.objects.all()
    serializer_class = serializers.SubcountyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class SuretyViewSet(viewsets.ModelViewSet):
    """ViewSet for the Surety class"""

    queryset = models.Surety.objects.all()
    serializer_class = serializers.SuretySerializer
    permission_classes = [permissions.IsAuthenticated]


class SuretyVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the SuretyVersion class"""

    queryset = models.SuretyVersion.objects.all()
    serializer_class = serializers.SuretyVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class TagViewSet(viewsets.ModelViewSet):
    """ViewSet for the Tag class"""

    queryset = models.Tag.objects.all()
    serializer_class = serializers.TagSerializer
    permission_classes = [permissions.IsAuthenticated]


class TagVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the TagVersion class"""

    queryset = models.TagVersion.objects.all()
    serializer_class = serializers.TagVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class TownViewSet(viewsets.ModelViewSet):
    """ViewSet for the Town class"""

    queryset = models.Town.objects.all()
    serializer_class = serializers.TownSerializer
    permission_classes = [permissions.IsAuthenticated]


class TownVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the TownVersion class"""

    queryset = models.TownVersion.objects.all()
    serializer_class = serializers.TownVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class TransactionViewSet(viewsets.ModelViewSet):
    """ViewSet for the Transaction class"""

    queryset = models.Transaction.objects.all()
    serializer_class = serializers.TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]


class VisitViewSet(viewsets.ModelViewSet):
    """ViewSet for the Visit class"""

    queryset = models.Visit.objects.all()
    serializer_class = serializers.VisitSerializer
    permission_classes = [permissions.IsAuthenticated]


class VisitVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the VisitVersion class"""

    queryset = models.VisitVersion.objects.all()
    serializer_class = serializers.VisitVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class VisitorViewSet(viewsets.ModelViewSet):
    """ViewSet for the Visitor class"""

    queryset = models.Visitor.objects.all()
    serializer_class = serializers.VisitorSerializer
    permission_classes = [permissions.IsAuthenticated]


class VisitorVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the VisitorVersion class"""

    queryset = models.VisitorVersion.objects.all()
    serializer_class = serializers.VisitorVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class WarderViewSet(viewsets.ModelViewSet):
    """ViewSet for the Warder class"""

    queryset = models.Warder.objects.all()
    serializer_class = serializers.WarderSerializer
    permission_classes = [permissions.IsAuthenticated]


class WarderVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the WarderVersion class"""

    queryset = models.WarderVersion.objects.all()
    serializer_class = serializers.WarderVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class WarderrankViewSet(viewsets.ModelViewSet):
    """ViewSet for the Warderrank class"""

    queryset = models.Warderrank.objects.all()
    serializer_class = serializers.WarderrankSerializer
    permission_classes = [permissions.IsAuthenticated]


class WarderrankVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the WarderrankVersion class"""

    queryset = models.WarderrankVersion.objects.all()
    serializer_class = serializers.WarderrankVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


class WitnessViewSet(viewsets.ModelViewSet):
    """ViewSet for the Witness class"""

    queryset = models.Witness.objects.all()
    serializer_class = serializers.WitnessSerializer
    permission_classes = [permissions.IsAuthenticated]


class WitnessVersionViewSet(viewsets.ModelViewSet):
    """ViewSet for the WitnessVersion class"""

    queryset = models.WitnessVersion.objects.all()
    serializer_class = serializers.WitnessVersionSerializer
    permission_classes = [permissions.IsAuthenticated]


