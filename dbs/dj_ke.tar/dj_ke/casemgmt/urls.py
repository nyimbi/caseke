from django.conf.urls import url, include
from rest_framework import routers
from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'bail', api.BailViewSet)
router.register(r'bailsurety', api.BailSuretyViewSet)
router.register(r'bailsuretyversion', api.BailSuretyVersionViewSet)
router.register(r'bailversion', api.BailVersionViewSet)
router.register(r'case', api.CaseViewSet)
router.register(r'casecasecategory', api.CaseCasecategoryViewSet)
router.register(r'casecasecategoryversion', api.CaseCasecategoryVersionViewSet)
router.register(r'casecauseofaction', api.CaseCauseofactionViewSet)
router.register(r'casecauseofactionversion', api.CaseCauseofactionVersionViewSet)
router.register(r'casedefendant', api.CaseDefendantViewSet)
router.register(r'casedefendantversion', api.CaseDefendantVersionViewSet)
router.register(r'casenatureofsuit', api.CaseNatureofsuitViewSet)
router.register(r'casenatureofsuitversion', api.CaseNatureofsuitVersionViewSet)
router.register(r'caseplaintiff', api.CasePlaintiffViewSet)
router.register(r'caseplaintiffversion', api.CasePlaintiffVersionViewSet)
router.register(r'casepolofficer', api.CasePolofficerViewSet)
router.register(r'casepolofficerversion', api.CasePolofficerVersionViewSet)
router.register(r'caseprosecutor', api.CaseProsecutorViewSet)
router.register(r'caseprosecutor2', api.CaseProsecutor2ViewSet)
router.register(r'caseprosecutor2version', api.CaseProsecutor2VersionViewSet)
router.register(r'caseprosecutorversion', api.CaseProsecutorVersionViewSet)
router.register(r'casetag', api.CaseTagViewSet)
router.register(r'casetagversion', api.CaseTagVersionViewSet)
router.register(r'caseversion', api.CaseVersionViewSet)
router.register(r'casewitness', api.CaseWitnessViewSet)
router.register(r'casewitnessversion', api.CaseWitnessVersionViewSet)
router.register(r'casecategory', api.CasecategoryViewSet)
router.register(r'casecategoryversion', api.CasecategoryVersionViewSet)
router.register(r'caseinvestigation', api.CaseinvestigationViewSet)
router.register(r'caseinvestigationversion', api.CaseinvestigationVersionViewSet)
router.register(r'causeofaction', api.CauseofactionViewSet)
router.register(r'causeofactionfiling', api.CauseofactionFilingViewSet)
router.register(r'causeofactionfilingversion', api.CauseofactionFilingVersionViewSet)
router.register(r'causeofactionhearing', api.CauseofactionHearingViewSet)
router.register(r'causeofactionhearingversion', api.CauseofactionHearingVersionViewSet)
router.register(r'causeofactionversion', api.CauseofactionVersionViewSet)
router.register(r'commitaltype', api.CommitaltypeViewSet)
router.register(r'commitaltypeprisoncommital', api.CommitaltypePrisoncommitalViewSet)
router.register(r'commitaltypeprisoncommitalversion', api.CommitaltypePrisoncommitalVersionViewSet)
router.register(r'commitaltypeversion', api.CommitaltypeVersionViewSet)
router.register(r'constituency', api.ConstituencyViewSet)
router.register(r'constituencyversion', api.ConstituencyVersionViewSet)
router.register(r'county', api.CountyViewSet)
router.register(r'countyversion', api.CountyVersionViewSet)
router.register(r'court', api.CourtViewSet)
router.register(r'courtversion', api.CourtVersionViewSet)
router.register(r'courtlevel', api.CourtlevelViewSet)
router.register(r'courtlevelversion', api.CourtlevelVersionViewSet)
router.register(r'courtstation', api.CourtstationViewSet)
router.register(r'courtstationversion', api.CourtstationVersionViewSet)
router.register(r'defendant', api.DefendantViewSet)
router.register(r'defendantgateregister', api.DefendantGateregisterViewSet)
router.register(r'defendantgateregisterversion', api.DefendantGateregisterVersionViewSet)
router.register(r'defendanthearing', api.DefendantHearingViewSet)
router.register(r'defendanthearingversion', api.DefendantHearingVersionViewSet)
router.register(r'defendantmedevent', api.DefendantMedeventViewSet)
router.register(r'defendantmedeventversion', api.DefendantMedeventVersionViewSet)
router.register(r'defendantversion', api.DefendantVersionViewSet)
router.register(r'discipline', api.DisciplineViewSet)
router.register(r'disciplineversion', api.DisciplineVersionViewSet)
router.register(r'docstore', api.DocStoreViewSet)
router.register(r'docarchive', api.DocarchiveViewSet)
router.register(r'docarchivetag', api.DocarchiveTagViewSet)
router.register(r'docarchivetagversion', api.DocarchiveTagVersionViewSet)
router.register(r'docarchiveversion', api.DocarchiveVersionViewSet)
router.register(r'doctemplate', api.DoctemplateViewSet)
router.register(r'doctemplateversion', api.DoctemplateVersionViewSet)
router.register(r'document', api.DocumentViewSet)
router.register(r'documenttag', api.DocumentTagViewSet)
router.register(r'documenttagversion', api.DocumentTagVersionViewSet)
router.register(r'documentversion', api.DocumentVersionViewSet)
router.register(r'eventlog', api.EventlogViewSet)
router.register(r'eventlogversion', api.EventlogVersionViewSet)
router.register(r'filing', api.FilingViewSet)
router.register(r'filingfilingtype', api.FilingFilingtypeViewSet)
router.register(r'filingfilingtypeversion', api.FilingFilingtypeVersionViewSet)
router.register(r'filingpayment', api.FilingPaymentViewSet)
router.register(r'filingpaymentversion', api.FilingPaymentVersionViewSet)
router.register(r'filingversion', api.FilingVersionViewSet)
router.register(r'filingtype', api.FilingtypeViewSet)
router.register(r'filingtypeversion', api.FilingtypeVersionViewSet)
router.register(r'gateregister', api.GateregisterViewSet)
router.register(r'gateregisterversion', api.GateregisterVersionViewSet)
router.register(r'gateregisterwarder', api.GateregisterWarderViewSet)
router.register(r'gateregisterwarder2', api.GateregisterWarder2ViewSet)
router.register(r'gateregisterwarder2version', api.GateregisterWarder2VersionViewSet)
router.register(r'gateregisterwarderversion', api.GateregisterWarderVersionViewSet)
router.register(r'gender', api.GenderViewSet)
router.register(r'genderversion', api.GenderVersionViewSet)
router.register(r'hearing', api.HearingViewSet)
router.register(r'hearingjudicialofficer', api.HearingJudicialofficerViewSet)
router.register(r'hearingjudicialofficerversion', api.HearingJudicialofficerVersionViewSet)
router.register(r'hearinglawyers', api.HearingLawyersViewSet)
router.register(r'hearinglawyersversion', api.HearingLawyersVersionViewSet)
router.register(r'hearingpolofficer', api.HearingPolofficerViewSet)
router.register(r'hearingpolofficerversion', api.HearingPolofficerVersionViewSet)
router.register(r'hearingprosecutor', api.HearingProsecutorViewSet)
router.register(r'hearingprosecutorversion', api.HearingProsecutorVersionViewSet)
router.register(r'hearingtag', api.HearingTagViewSet)
router.register(r'hearingtagversion', api.HearingTagVersionViewSet)
router.register(r'hearingversion', api.HearingVersionViewSet)
router.register(r'hearingwitness', api.HearingWitnessViewSet)
router.register(r'hearingwitnessversion', api.HearingWitnessVersionViewSet)
router.register(r'hearingtype', api.HearingtypeViewSet)
router.register(r'hearingtypeversion', api.HearingtypeVersionViewSet)
router.register(r'investigation', api.InvestigationViewSet)
router.register(r'investigationpolofficer', api.InvestigationPolofficerViewSet)
router.register(r'investigationpolofficerversion', api.InvestigationPolofficerVersionViewSet)
router.register(r'investigationversion', api.InvestigationVersionViewSet)
router.register(r'investigationwitness', api.InvestigationWitnessViewSet)
router.register(r'investigationwitnessversion', api.InvestigationWitnessVersionViewSet)
router.register(r'jorank', api.JoRankViewSet)
router.register(r'jorankversion', api.JoRankVersionViewSet)
router.register(r'judicialofficer', api.JudicialofficerViewSet)
router.register(r'judicialofficerversion', api.JudicialofficerVersionViewSet)
router.register(r'lawfirm', api.LawfirmViewSet)
router.register(r'lawfirmversion', api.LawfirmVersionViewSet)
router.register(r'lawyers', api.LawyersViewSet)
router.register(r'lawyersversion', api.LawyersVersionViewSet)
router.register(r'medevent', api.MedeventViewSet)
router.register(r'medeventversion', api.MedeventVersionViewSet)
router.register(r'natureofsuit', api.NatureofsuitViewSet)
router.register(r'natureofsuitversion', api.NatureofsuitVersionViewSet)
router.register(r'payment', api.PaymentViewSet)
router.register(r'paymentversion', api.PaymentVersionViewSet)
router.register(r'paymentmethod', api.PaymentmethodViewSet)
router.register(r'paymentmethodversion', api.PaymentmethodVersionViewSet)
router.register(r'plaintiff', api.PlaintiffViewSet)
router.register(r'plaintiffversion', api.PlaintiffVersionViewSet)
router.register(r'policerank', api.PolicerankViewSet)
router.register(r'policerankversion', api.PolicerankVersionViewSet)
router.register(r'policerole', api.PoliceroleViewSet)
router.register(r'policeroleversion', api.PoliceroleVersionViewSet)
router.register(r'policestation', api.PolicestationViewSet)
router.register(r'policestationversion', api.PolicestationVersionViewSet)
router.register(r'policestationtype', api.PolicestationtypeViewSet)
router.register(r'policestationtypeversion', api.PolicestationtypeVersionViewSet)
router.register(r'polofficer', api.PolofficerViewSet)
router.register(r'polofficerpolicerole', api.PolofficerPoliceroleViewSet)
router.register(r'polofficerpoliceroleversion', api.PolofficerPoliceroleVersionViewSet)
router.register(r'polofficerversion', api.PolofficerVersionViewSet)
router.register(r'prison', api.PrisonViewSet)
router.register(r'prisonsecurityrank', api.PrisonSecurityrankViewSet)
router.register(r'prisonsecurityrankversion', api.PrisonSecurityrankVersionViewSet)
router.register(r'prisonversion', api.PrisonVersionViewSet)
router.register(r'prisoncell', api.PrisoncellViewSet)
router.register(r'prisoncellversion', api.PrisoncellVersionViewSet)
router.register(r'prisoncommital', api.PrisoncommitalViewSet)
router.register(r'prisoncommitalversion', api.PrisoncommitalVersionViewSet)
router.register(r'prisoncommitalwarder', api.PrisoncommitalWarderViewSet)
router.register(r'prisoncommitalwarderversion', api.PrisoncommitalWarderVersionViewSet)
router.register(r'prisonerproperty', api.PrisonerpropertyViewSet)
router.register(r'prisonerpropertyversion', api.PrisonerpropertyVersionViewSet)
router.register(r'prosecutor', api.ProsecutorViewSet)
router.register(r'prosecutorprosecutorteam', api.ProsecutorProsecutorteamViewSet)
router.register(r'prosecutorprosecutorteamversion', api.ProsecutorProsecutorteamVersionViewSet)
router.register(r'prosecutorversion', api.ProsecutorVersionViewSet)
router.register(r'prosecutorteam', api.ProsecutorteamViewSet)
router.register(r'prosecutorteamversion', api.ProsecutorteamVersionViewSet)
router.register(r'remission', api.RemissionViewSet)
router.register(r'remissionversion', api.RemissionVersionViewSet)
router.register(r'securityrank', api.SecurityrankViewSet)
router.register(r'securityrankversion', api.SecurityrankVersionViewSet)
router.register(r'subcounty', api.SubcountyViewSet)
router.register(r'subcountyversion', api.SubcountyVersionViewSet)
router.register(r'surety', api.SuretyViewSet)
router.register(r'suretyversion', api.SuretyVersionViewSet)
router.register(r'tag', api.TagViewSet)
router.register(r'tagversion', api.TagVersionViewSet)
router.register(r'town', api.TownViewSet)
router.register(r'townversion', api.TownVersionViewSet)
router.register(r'transaction', api.TransactionViewSet)
router.register(r'visit', api.VisitViewSet)
router.register(r'visitversion', api.VisitVersionViewSet)
router.register(r'visitor', api.VisitorViewSet)
router.register(r'visitorversion', api.VisitorVersionViewSet)
router.register(r'warder', api.WarderViewSet)
router.register(r'warderversion', api.WarderVersionViewSet)
router.register(r'warderrank', api.WarderrankViewSet)
router.register(r'warderrankversion', api.WarderrankVersionViewSet)
router.register(r'witness', api.WitnessViewSet)
router.register(r'witnessversion', api.WitnessVersionViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    url(r'^api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for Bail
    url(r'^casemgmt/bail/$', views.BailListView.as_view(), name='casemgmt_bail_list'),
    url(r'^casemgmt/bail/create/$', views.BailCreateView.as_view(), name='casemgmt_bail_create'),
    url(r'^casemgmt/bail/detail/(?P<pk>\S+)/$', views.BailDetailView.as_view(), name='casemgmt_bail_detail'),
    url(r'^casemgmt/bail/update/(?P<pk>\S+)/$', views.BailUpdateView.as_view(), name='casemgmt_bail_update'),
)

urlpatterns += (
    # urls for BailSurety
    url(r'^casemgmt/bailsurety/$', views.BailSuretyListView.as_view(), name='casemgmt_bailsurety_list'),
    url(r'^casemgmt/bailsurety/create/$', views.BailSuretyCreateView.as_view(), name='casemgmt_bailsurety_create'),
    url(r'^casemgmt/bailsurety/detail/(?P<pk>\S+)/$', views.BailSuretyDetailView.as_view(), name='casemgmt_bailsurety_detail'),
    url(r'^casemgmt/bailsurety/update/(?P<pk>\S+)/$', views.BailSuretyUpdateView.as_view(), name='casemgmt_bailsurety_update'),
)

urlpatterns += (
    # urls for BailSuretyVersion
    url(r'^casemgmt/bailsuretyversion/$', views.BailSuretyVersionListView.as_view(), name='casemgmt_bailsuretyversion_list'),
    url(r'^casemgmt/bailsuretyversion/create/$', views.BailSuretyVersionCreateView.as_view(), name='casemgmt_bailsuretyversion_create'),
    url(r'^casemgmt/bailsuretyversion/detail/(?P<pk>\S+)/$', views.BailSuretyVersionDetailView.as_view(), name='casemgmt_bailsuretyversion_detail'),
    url(r'^casemgmt/bailsuretyversion/update/(?P<pk>\S+)/$', views.BailSuretyVersionUpdateView.as_view(), name='casemgmt_bailsuretyversion_update'),
)

urlpatterns += (
    # urls for BailVersion
    url(r'^casemgmt/bailversion/$', views.BailVersionListView.as_view(), name='casemgmt_bailversion_list'),
    url(r'^casemgmt/bailversion/create/$', views.BailVersionCreateView.as_view(), name='casemgmt_bailversion_create'),
    url(r'^casemgmt/bailversion/detail/(?P<pk>\S+)/$', views.BailVersionDetailView.as_view(), name='casemgmt_bailversion_detail'),
    url(r'^casemgmt/bailversion/update/(?P<pk>\S+)/$', views.BailVersionUpdateView.as_view(), name='casemgmt_bailversion_update'),
)

urlpatterns += (
    # urls for Case
    url(r'^casemgmt/case/$', views.CaseListView.as_view(), name='casemgmt_case_list'),
    url(r'^casemgmt/case/create/$', views.CaseCreateView.as_view(), name='casemgmt_case_create'),
    url(r'^casemgmt/case/detail/(?P<pk>\S+)/$', views.CaseDetailView.as_view(), name='casemgmt_case_detail'),
    url(r'^casemgmt/case/update/(?P<pk>\S+)/$', views.CaseUpdateView.as_view(), name='casemgmt_case_update'),
)

urlpatterns += (
    # urls for CaseCasecategory
    url(r'^casemgmt/casecasecategory/$', views.CaseCasecategoryListView.as_view(), name='casemgmt_casecasecategory_list'),
    url(r'^casemgmt/casecasecategory/create/$', views.CaseCasecategoryCreateView.as_view(), name='casemgmt_casecasecategory_create'),
    url(r'^casemgmt/casecasecategory/detail/(?P<pk>\S+)/$', views.CaseCasecategoryDetailView.as_view(), name='casemgmt_casecasecategory_detail'),
    url(r'^casemgmt/casecasecategory/update/(?P<pk>\S+)/$', views.CaseCasecategoryUpdateView.as_view(), name='casemgmt_casecasecategory_update'),
)

urlpatterns += (
    # urls for CaseCasecategoryVersion
    url(r'^casemgmt/casecasecategoryversion/$', views.CaseCasecategoryVersionListView.as_view(), name='casemgmt_casecasecategoryversion_list'),
    url(r'^casemgmt/casecasecategoryversion/create/$', views.CaseCasecategoryVersionCreateView.as_view(), name='casemgmt_casecasecategoryversion_create'),
    url(r'^casemgmt/casecasecategoryversion/detail/(?P<pk>\S+)/$', views.CaseCasecategoryVersionDetailView.as_view(), name='casemgmt_casecasecategoryversion_detail'),
    url(r'^casemgmt/casecasecategoryversion/update/(?P<pk>\S+)/$', views.CaseCasecategoryVersionUpdateView.as_view(), name='casemgmt_casecasecategoryversion_update'),
)

urlpatterns += (
    # urls for CaseCauseofaction
    url(r'^casemgmt/casecauseofaction/$', views.CaseCauseofactionListView.as_view(), name='casemgmt_casecauseofaction_list'),
    url(r'^casemgmt/casecauseofaction/create/$', views.CaseCauseofactionCreateView.as_view(), name='casemgmt_casecauseofaction_create'),
    url(r'^casemgmt/casecauseofaction/detail/(?P<pk>\S+)/$', views.CaseCauseofactionDetailView.as_view(), name='casemgmt_casecauseofaction_detail'),
    url(r'^casemgmt/casecauseofaction/update/(?P<pk>\S+)/$', views.CaseCauseofactionUpdateView.as_view(), name='casemgmt_casecauseofaction_update'),
)

urlpatterns += (
    # urls for CaseCauseofactionVersion
    url(r'^casemgmt/casecauseofactionversion/$', views.CaseCauseofactionVersionListView.as_view(), name='casemgmt_casecauseofactionversion_list'),
    url(r'^casemgmt/casecauseofactionversion/create/$', views.CaseCauseofactionVersionCreateView.as_view(), name='casemgmt_casecauseofactionversion_create'),
    url(r'^casemgmt/casecauseofactionversion/detail/(?P<pk>\S+)/$', views.CaseCauseofactionVersionDetailView.as_view(), name='casemgmt_casecauseofactionversion_detail'),
    url(r'^casemgmt/casecauseofactionversion/update/(?P<pk>\S+)/$', views.CaseCauseofactionVersionUpdateView.as_view(), name='casemgmt_casecauseofactionversion_update'),
)

urlpatterns += (
    # urls for CaseDefendant
    url(r'^casemgmt/casedefendant/$', views.CaseDefendantListView.as_view(), name='casemgmt_casedefendant_list'),
    url(r'^casemgmt/casedefendant/create/$', views.CaseDefendantCreateView.as_view(), name='casemgmt_casedefendant_create'),
    url(r'^casemgmt/casedefendant/detail/(?P<pk>\S+)/$', views.CaseDefendantDetailView.as_view(), name='casemgmt_casedefendant_detail'),
    url(r'^casemgmt/casedefendant/update/(?P<pk>\S+)/$', views.CaseDefendantUpdateView.as_view(), name='casemgmt_casedefendant_update'),
)

urlpatterns += (
    # urls for CaseDefendantVersion
    url(r'^casemgmt/casedefendantversion/$', views.CaseDefendantVersionListView.as_view(), name='casemgmt_casedefendantversion_list'),
    url(r'^casemgmt/casedefendantversion/create/$', views.CaseDefendantVersionCreateView.as_view(), name='casemgmt_casedefendantversion_create'),
    url(r'^casemgmt/casedefendantversion/detail/(?P<pk>\S+)/$', views.CaseDefendantVersionDetailView.as_view(), name='casemgmt_casedefendantversion_detail'),
    url(r'^casemgmt/casedefendantversion/update/(?P<pk>\S+)/$', views.CaseDefendantVersionUpdateView.as_view(), name='casemgmt_casedefendantversion_update'),
)

urlpatterns += (
    # urls for CaseNatureofsuit
    url(r'^casemgmt/casenatureofsuit/$', views.CaseNatureofsuitListView.as_view(), name='casemgmt_casenatureofsuit_list'),
    url(r'^casemgmt/casenatureofsuit/create/$', views.CaseNatureofsuitCreateView.as_view(), name='casemgmt_casenatureofsuit_create'),
    url(r'^casemgmt/casenatureofsuit/detail/(?P<pk>\S+)/$', views.CaseNatureofsuitDetailView.as_view(), name='casemgmt_casenatureofsuit_detail'),
    url(r'^casemgmt/casenatureofsuit/update/(?P<pk>\S+)/$', views.CaseNatureofsuitUpdateView.as_view(), name='casemgmt_casenatureofsuit_update'),
)

urlpatterns += (
    # urls for CaseNatureofsuitVersion
    url(r'^casemgmt/casenatureofsuitversion/$', views.CaseNatureofsuitVersionListView.as_view(), name='casemgmt_casenatureofsuitversion_list'),
    url(r'^casemgmt/casenatureofsuitversion/create/$', views.CaseNatureofsuitVersionCreateView.as_view(), name='casemgmt_casenatureofsuitversion_create'),
    url(r'^casemgmt/casenatureofsuitversion/detail/(?P<pk>\S+)/$', views.CaseNatureofsuitVersionDetailView.as_view(), name='casemgmt_casenatureofsuitversion_detail'),
    url(r'^casemgmt/casenatureofsuitversion/update/(?P<pk>\S+)/$', views.CaseNatureofsuitVersionUpdateView.as_view(), name='casemgmt_casenatureofsuitversion_update'),
)

urlpatterns += (
    # urls for CasePlaintiff
    url(r'^casemgmt/caseplaintiff/$', views.CasePlaintiffListView.as_view(), name='casemgmt_caseplaintiff_list'),
    url(r'^casemgmt/caseplaintiff/create/$', views.CasePlaintiffCreateView.as_view(), name='casemgmt_caseplaintiff_create'),
    url(r'^casemgmt/caseplaintiff/detail/(?P<pk>\S+)/$', views.CasePlaintiffDetailView.as_view(), name='casemgmt_caseplaintiff_detail'),
    url(r'^casemgmt/caseplaintiff/update/(?P<pk>\S+)/$', views.CasePlaintiffUpdateView.as_view(), name='casemgmt_caseplaintiff_update'),
)

urlpatterns += (
    # urls for CasePlaintiffVersion
    url(r'^casemgmt/caseplaintiffversion/$', views.CasePlaintiffVersionListView.as_view(), name='casemgmt_caseplaintiffversion_list'),
    url(r'^casemgmt/caseplaintiffversion/create/$', views.CasePlaintiffVersionCreateView.as_view(), name='casemgmt_caseplaintiffversion_create'),
    url(r'^casemgmt/caseplaintiffversion/detail/(?P<pk>\S+)/$', views.CasePlaintiffVersionDetailView.as_view(), name='casemgmt_caseplaintiffversion_detail'),
    url(r'^casemgmt/caseplaintiffversion/update/(?P<pk>\S+)/$', views.CasePlaintiffVersionUpdateView.as_view(), name='casemgmt_caseplaintiffversion_update'),
)

urlpatterns += (
    # urls for CasePolofficer
    url(r'^casemgmt/casepolofficer/$', views.CasePolofficerListView.as_view(), name='casemgmt_casepolofficer_list'),
    url(r'^casemgmt/casepolofficer/create/$', views.CasePolofficerCreateView.as_view(), name='casemgmt_casepolofficer_create'),
    url(r'^casemgmt/casepolofficer/detail/(?P<pk>\S+)/$', views.CasePolofficerDetailView.as_view(), name='casemgmt_casepolofficer_detail'),
    url(r'^casemgmt/casepolofficer/update/(?P<pk>\S+)/$', views.CasePolofficerUpdateView.as_view(), name='casemgmt_casepolofficer_update'),
)

urlpatterns += (
    # urls for CasePolofficerVersion
    url(r'^casemgmt/casepolofficerversion/$', views.CasePolofficerVersionListView.as_view(), name='casemgmt_casepolofficerversion_list'),
    url(r'^casemgmt/casepolofficerversion/create/$', views.CasePolofficerVersionCreateView.as_view(), name='casemgmt_casepolofficerversion_create'),
    url(r'^casemgmt/casepolofficerversion/detail/(?P<pk>\S+)/$', views.CasePolofficerVersionDetailView.as_view(), name='casemgmt_casepolofficerversion_detail'),
    url(r'^casemgmt/casepolofficerversion/update/(?P<pk>\S+)/$', views.CasePolofficerVersionUpdateView.as_view(), name='casemgmt_casepolofficerversion_update'),
)

urlpatterns += (
    # urls for CaseProsecutor
    url(r'^casemgmt/caseprosecutor/$', views.CaseProsecutorListView.as_view(), name='casemgmt_caseprosecutor_list'),
    url(r'^casemgmt/caseprosecutor/create/$', views.CaseProsecutorCreateView.as_view(), name='casemgmt_caseprosecutor_create'),
    url(r'^casemgmt/caseprosecutor/detail/(?P<pk>\S+)/$', views.CaseProsecutorDetailView.as_view(), name='casemgmt_caseprosecutor_detail'),
    url(r'^casemgmt/caseprosecutor/update/(?P<pk>\S+)/$', views.CaseProsecutorUpdateView.as_view(), name='casemgmt_caseprosecutor_update'),
)

urlpatterns += (
    # urls for CaseProsecutor2
    url(r'^casemgmt/caseprosecutor2/$', views.CaseProsecutor2ListView.as_view(), name='casemgmt_caseprosecutor2_list'),
    url(r'^casemgmt/caseprosecutor2/create/$', views.CaseProsecutor2CreateView.as_view(), name='casemgmt_caseprosecutor2_create'),
    url(r'^casemgmt/caseprosecutor2/detail/(?P<pk>\S+)/$', views.CaseProsecutor2DetailView.as_view(), name='casemgmt_caseprosecutor2_detail'),
    url(r'^casemgmt/caseprosecutor2/update/(?P<pk>\S+)/$', views.CaseProsecutor2UpdateView.as_view(), name='casemgmt_caseprosecutor2_update'),
)

urlpatterns += (
    # urls for CaseProsecutor2Version
    url(r'^casemgmt/caseprosecutor2version/$', views.CaseProsecutor2VersionListView.as_view(), name='casemgmt_caseprosecutor2version_list'),
    url(r'^casemgmt/caseprosecutor2version/create/$', views.CaseProsecutor2VersionCreateView.as_view(), name='casemgmt_caseprosecutor2version_create'),
    url(r'^casemgmt/caseprosecutor2version/detail/(?P<pk>\S+)/$', views.CaseProsecutor2VersionDetailView.as_view(), name='casemgmt_caseprosecutor2version_detail'),
    url(r'^casemgmt/caseprosecutor2version/update/(?P<pk>\S+)/$', views.CaseProsecutor2VersionUpdateView.as_view(), name='casemgmt_caseprosecutor2version_update'),
)

urlpatterns += (
    # urls for CaseProsecutorVersion
    url(r'^casemgmt/caseprosecutorversion/$', views.CaseProsecutorVersionListView.as_view(), name='casemgmt_caseprosecutorversion_list'),
    url(r'^casemgmt/caseprosecutorversion/create/$', views.CaseProsecutorVersionCreateView.as_view(), name='casemgmt_caseprosecutorversion_create'),
    url(r'^casemgmt/caseprosecutorversion/detail/(?P<pk>\S+)/$', views.CaseProsecutorVersionDetailView.as_view(), name='casemgmt_caseprosecutorversion_detail'),
    url(r'^casemgmt/caseprosecutorversion/update/(?P<pk>\S+)/$', views.CaseProsecutorVersionUpdateView.as_view(), name='casemgmt_caseprosecutorversion_update'),
)

urlpatterns += (
    # urls for CaseTag
    url(r'^casemgmt/casetag/$', views.CaseTagListView.as_view(), name='casemgmt_casetag_list'),
    url(r'^casemgmt/casetag/create/$', views.CaseTagCreateView.as_view(), name='casemgmt_casetag_create'),
    url(r'^casemgmt/casetag/detail/(?P<pk>\S+)/$', views.CaseTagDetailView.as_view(), name='casemgmt_casetag_detail'),
    url(r'^casemgmt/casetag/update/(?P<pk>\S+)/$', views.CaseTagUpdateView.as_view(), name='casemgmt_casetag_update'),
)

urlpatterns += (
    # urls for CaseTagVersion
    url(r'^casemgmt/casetagversion/$', views.CaseTagVersionListView.as_view(), name='casemgmt_casetagversion_list'),
    url(r'^casemgmt/casetagversion/create/$', views.CaseTagVersionCreateView.as_view(), name='casemgmt_casetagversion_create'),
    url(r'^casemgmt/casetagversion/detail/(?P<pk>\S+)/$', views.CaseTagVersionDetailView.as_view(), name='casemgmt_casetagversion_detail'),
    url(r'^casemgmt/casetagversion/update/(?P<pk>\S+)/$', views.CaseTagVersionUpdateView.as_view(), name='casemgmt_casetagversion_update'),
)

urlpatterns += (
    # urls for CaseVersion
    url(r'^casemgmt/caseversion/$', views.CaseVersionListView.as_view(), name='casemgmt_caseversion_list'),
    url(r'^casemgmt/caseversion/create/$', views.CaseVersionCreateView.as_view(), name='casemgmt_caseversion_create'),
    url(r'^casemgmt/caseversion/detail/(?P<pk>\S+)/$', views.CaseVersionDetailView.as_view(), name='casemgmt_caseversion_detail'),
    url(r'^casemgmt/caseversion/update/(?P<pk>\S+)/$', views.CaseVersionUpdateView.as_view(), name='casemgmt_caseversion_update'),
)

urlpatterns += (
    # urls for CaseWitness
    url(r'^casemgmt/casewitness/$', views.CaseWitnessListView.as_view(), name='casemgmt_casewitness_list'),
    url(r'^casemgmt/casewitness/create/$', views.CaseWitnessCreateView.as_view(), name='casemgmt_casewitness_create'),
    url(r'^casemgmt/casewitness/detail/(?P<pk>\S+)/$', views.CaseWitnessDetailView.as_view(), name='casemgmt_casewitness_detail'),
    url(r'^casemgmt/casewitness/update/(?P<pk>\S+)/$', views.CaseWitnessUpdateView.as_view(), name='casemgmt_casewitness_update'),
)

urlpatterns += (
    # urls for CaseWitnessVersion
    url(r'^casemgmt/casewitnessversion/$', views.CaseWitnessVersionListView.as_view(), name='casemgmt_casewitnessversion_list'),
    url(r'^casemgmt/casewitnessversion/create/$', views.CaseWitnessVersionCreateView.as_view(), name='casemgmt_casewitnessversion_create'),
    url(r'^casemgmt/casewitnessversion/detail/(?P<pk>\S+)/$', views.CaseWitnessVersionDetailView.as_view(), name='casemgmt_casewitnessversion_detail'),
    url(r'^casemgmt/casewitnessversion/update/(?P<pk>\S+)/$', views.CaseWitnessVersionUpdateView.as_view(), name='casemgmt_casewitnessversion_update'),
)

urlpatterns += (
    # urls for Casecategory
    url(r'^casemgmt/casecategory/$', views.CasecategoryListView.as_view(), name='casemgmt_casecategory_list'),
    url(r'^casemgmt/casecategory/create/$', views.CasecategoryCreateView.as_view(), name='casemgmt_casecategory_create'),
    url(r'^casemgmt/casecategory/detail/(?P<pk>\S+)/$', views.CasecategoryDetailView.as_view(), name='casemgmt_casecategory_detail'),
    url(r'^casemgmt/casecategory/update/(?P<pk>\S+)/$', views.CasecategoryUpdateView.as_view(), name='casemgmt_casecategory_update'),
)

urlpatterns += (
    # urls for CasecategoryVersion
    url(r'^casemgmt/casecategoryversion/$', views.CasecategoryVersionListView.as_view(), name='casemgmt_casecategoryversion_list'),
    url(r'^casemgmt/casecategoryversion/create/$', views.CasecategoryVersionCreateView.as_view(), name='casemgmt_casecategoryversion_create'),
    url(r'^casemgmt/casecategoryversion/detail/(?P<pk>\S+)/$', views.CasecategoryVersionDetailView.as_view(), name='casemgmt_casecategoryversion_detail'),
    url(r'^casemgmt/casecategoryversion/update/(?P<pk>\S+)/$', views.CasecategoryVersionUpdateView.as_view(), name='casemgmt_casecategoryversion_update'),
)

urlpatterns += (
    # urls for Caseinvestigation
    url(r'^casemgmt/caseinvestigation/$', views.CaseinvestigationListView.as_view(), name='casemgmt_caseinvestigation_list'),
    url(r'^casemgmt/caseinvestigation/create/$', views.CaseinvestigationCreateView.as_view(), name='casemgmt_caseinvestigation_create'),
    url(r'^casemgmt/caseinvestigation/detail/(?P<pk>\S+)/$', views.CaseinvestigationDetailView.as_view(), name='casemgmt_caseinvestigation_detail'),
    url(r'^casemgmt/caseinvestigation/update/(?P<pk>\S+)/$', views.CaseinvestigationUpdateView.as_view(), name='casemgmt_caseinvestigation_update'),
)

urlpatterns += (
    # urls for CaseinvestigationVersion
    url(r'^casemgmt/caseinvestigationversion/$', views.CaseinvestigationVersionListView.as_view(), name='casemgmt_caseinvestigationversion_list'),
    url(r'^casemgmt/caseinvestigationversion/create/$', views.CaseinvestigationVersionCreateView.as_view(), name='casemgmt_caseinvestigationversion_create'),
    url(r'^casemgmt/caseinvestigationversion/detail/(?P<pk>\S+)/$', views.CaseinvestigationVersionDetailView.as_view(), name='casemgmt_caseinvestigationversion_detail'),
    url(r'^casemgmt/caseinvestigationversion/update/(?P<pk>\S+)/$', views.CaseinvestigationVersionUpdateView.as_view(), name='casemgmt_caseinvestigationversion_update'),
)

urlpatterns += (
    # urls for Causeofaction
    url(r'^casemgmt/causeofaction/$', views.CauseofactionListView.as_view(), name='casemgmt_causeofaction_list'),
    url(r'^casemgmt/causeofaction/create/$', views.CauseofactionCreateView.as_view(), name='casemgmt_causeofaction_create'),
    url(r'^casemgmt/causeofaction/detail/(?P<pk>\S+)/$', views.CauseofactionDetailView.as_view(), name='casemgmt_causeofaction_detail'),
    url(r'^casemgmt/causeofaction/update/(?P<pk>\S+)/$', views.CauseofactionUpdateView.as_view(), name='casemgmt_causeofaction_update'),
)

urlpatterns += (
    # urls for CauseofactionFiling
    url(r'^casemgmt/causeofactionfiling/$', views.CauseofactionFilingListView.as_view(), name='casemgmt_causeofactionfiling_list'),
    url(r'^casemgmt/causeofactionfiling/create/$', views.CauseofactionFilingCreateView.as_view(), name='casemgmt_causeofactionfiling_create'),
    url(r'^casemgmt/causeofactionfiling/detail/(?P<pk>\S+)/$', views.CauseofactionFilingDetailView.as_view(), name='casemgmt_causeofactionfiling_detail'),
    url(r'^casemgmt/causeofactionfiling/update/(?P<pk>\S+)/$', views.CauseofactionFilingUpdateView.as_view(), name='casemgmt_causeofactionfiling_update'),
)

urlpatterns += (
    # urls for CauseofactionFilingVersion
    url(r'^casemgmt/causeofactionfilingversion/$', views.CauseofactionFilingVersionListView.as_view(), name='casemgmt_causeofactionfilingversion_list'),
    url(r'^casemgmt/causeofactionfilingversion/create/$', views.CauseofactionFilingVersionCreateView.as_view(), name='casemgmt_causeofactionfilingversion_create'),
    url(r'^casemgmt/causeofactionfilingversion/detail/(?P<pk>\S+)/$', views.CauseofactionFilingVersionDetailView.as_view(), name='casemgmt_causeofactionfilingversion_detail'),
    url(r'^casemgmt/causeofactionfilingversion/update/(?P<pk>\S+)/$', views.CauseofactionFilingVersionUpdateView.as_view(), name='casemgmt_causeofactionfilingversion_update'),
)

urlpatterns += (
    # urls for CauseofactionHearing
    url(r'^casemgmt/causeofactionhearing/$', views.CauseofactionHearingListView.as_view(), name='casemgmt_causeofactionhearing_list'),
    url(r'^casemgmt/causeofactionhearing/create/$', views.CauseofactionHearingCreateView.as_view(), name='casemgmt_causeofactionhearing_create'),
    url(r'^casemgmt/causeofactionhearing/detail/(?P<pk>\S+)/$', views.CauseofactionHearingDetailView.as_view(), name='casemgmt_causeofactionhearing_detail'),
    url(r'^casemgmt/causeofactionhearing/update/(?P<pk>\S+)/$', views.CauseofactionHearingUpdateView.as_view(), name='casemgmt_causeofactionhearing_update'),
)

urlpatterns += (
    # urls for CauseofactionHearingVersion
    url(r'^casemgmt/causeofactionhearingversion/$', views.CauseofactionHearingVersionListView.as_view(), name='casemgmt_causeofactionhearingversion_list'),
    url(r'^casemgmt/causeofactionhearingversion/create/$', views.CauseofactionHearingVersionCreateView.as_view(), name='casemgmt_causeofactionhearingversion_create'),
    url(r'^casemgmt/causeofactionhearingversion/detail/(?P<pk>\S+)/$', views.CauseofactionHearingVersionDetailView.as_view(), name='casemgmt_causeofactionhearingversion_detail'),
    url(r'^casemgmt/causeofactionhearingversion/update/(?P<pk>\S+)/$', views.CauseofactionHearingVersionUpdateView.as_view(), name='casemgmt_causeofactionhearingversion_update'),
)

urlpatterns += (
    # urls for CauseofactionVersion
    url(r'^casemgmt/causeofactionversion/$', views.CauseofactionVersionListView.as_view(), name='casemgmt_causeofactionversion_list'),
    url(r'^casemgmt/causeofactionversion/create/$', views.CauseofactionVersionCreateView.as_view(), name='casemgmt_causeofactionversion_create'),
    url(r'^casemgmt/causeofactionversion/detail/(?P<pk>\S+)/$', views.CauseofactionVersionDetailView.as_view(), name='casemgmt_causeofactionversion_detail'),
    url(r'^casemgmt/causeofactionversion/update/(?P<pk>\S+)/$', views.CauseofactionVersionUpdateView.as_view(), name='casemgmt_causeofactionversion_update'),
)

urlpatterns += (
    # urls for Commitaltype
    url(r'^casemgmt/commitaltype/$', views.CommitaltypeListView.as_view(), name='casemgmt_commitaltype_list'),
    url(r'^casemgmt/commitaltype/create/$', views.CommitaltypeCreateView.as_view(), name='casemgmt_commitaltype_create'),
    url(r'^casemgmt/commitaltype/detail/(?P<pk>\S+)/$', views.CommitaltypeDetailView.as_view(), name='casemgmt_commitaltype_detail'),
    url(r'^casemgmt/commitaltype/update/(?P<pk>\S+)/$', views.CommitaltypeUpdateView.as_view(), name='casemgmt_commitaltype_update'),
)

urlpatterns += (
    # urls for CommitaltypePrisoncommital
    url(r'^casemgmt/commitaltypeprisoncommital/$', views.CommitaltypePrisoncommitalListView.as_view(), name='casemgmt_commitaltypeprisoncommital_list'),
    url(r'^casemgmt/commitaltypeprisoncommital/create/$', views.CommitaltypePrisoncommitalCreateView.as_view(), name='casemgmt_commitaltypeprisoncommital_create'),
    url(r'^casemgmt/commitaltypeprisoncommital/detail/(?P<pk>\S+)/$', views.CommitaltypePrisoncommitalDetailView.as_view(), name='casemgmt_commitaltypeprisoncommital_detail'),
    url(r'^casemgmt/commitaltypeprisoncommital/update/(?P<pk>\S+)/$', views.CommitaltypePrisoncommitalUpdateView.as_view(), name='casemgmt_commitaltypeprisoncommital_update'),
)

urlpatterns += (
    # urls for CommitaltypePrisoncommitalVersion
    url(r'^casemgmt/commitaltypeprisoncommitalversion/$', views.CommitaltypePrisoncommitalVersionListView.as_view(), name='casemgmt_commitaltypeprisoncommitalversion_list'),
    url(r'^casemgmt/commitaltypeprisoncommitalversion/create/$', views.CommitaltypePrisoncommitalVersionCreateView.as_view(), name='casemgmt_commitaltypeprisoncommitalversion_create'),
    url(r'^casemgmt/commitaltypeprisoncommitalversion/detail/(?P<pk>\S+)/$', views.CommitaltypePrisoncommitalVersionDetailView.as_view(), name='casemgmt_commitaltypeprisoncommitalversion_detail'),
    url(r'^casemgmt/commitaltypeprisoncommitalversion/update/(?P<pk>\S+)/$', views.CommitaltypePrisoncommitalVersionUpdateView.as_view(), name='casemgmt_commitaltypeprisoncommitalversion_update'),
)

urlpatterns += (
    # urls for CommitaltypeVersion
    url(r'^casemgmt/commitaltypeversion/$', views.CommitaltypeVersionListView.as_view(), name='casemgmt_commitaltypeversion_list'),
    url(r'^casemgmt/commitaltypeversion/create/$', views.CommitaltypeVersionCreateView.as_view(), name='casemgmt_commitaltypeversion_create'),
    url(r'^casemgmt/commitaltypeversion/detail/(?P<pk>\S+)/$', views.CommitaltypeVersionDetailView.as_view(), name='casemgmt_commitaltypeversion_detail'),
    url(r'^casemgmt/commitaltypeversion/update/(?P<pk>\S+)/$', views.CommitaltypeVersionUpdateView.as_view(), name='casemgmt_commitaltypeversion_update'),
)

urlpatterns += (
    # urls for Constituency
    url(r'^casemgmt/constituency/$', views.ConstituencyListView.as_view(), name='casemgmt_constituency_list'),
    url(r'^casemgmt/constituency/create/$', views.ConstituencyCreateView.as_view(), name='casemgmt_constituency_create'),
    url(r'^casemgmt/constituency/detail/(?P<pk>\S+)/$', views.ConstituencyDetailView.as_view(), name='casemgmt_constituency_detail'),
    url(r'^casemgmt/constituency/update/(?P<pk>\S+)/$', views.ConstituencyUpdateView.as_view(), name='casemgmt_constituency_update'),
)

urlpatterns += (
    # urls for ConstituencyVersion
    url(r'^casemgmt/constituencyversion/$', views.ConstituencyVersionListView.as_view(), name='casemgmt_constituencyversion_list'),
    url(r'^casemgmt/constituencyversion/create/$', views.ConstituencyVersionCreateView.as_view(), name='casemgmt_constituencyversion_create'),
    url(r'^casemgmt/constituencyversion/detail/(?P<pk>\S+)/$', views.ConstituencyVersionDetailView.as_view(), name='casemgmt_constituencyversion_detail'),
    url(r'^casemgmt/constituencyversion/update/(?P<pk>\S+)/$', views.ConstituencyVersionUpdateView.as_view(), name='casemgmt_constituencyversion_update'),
)

urlpatterns += (
    # urls for County
    url(r'^casemgmt/county/$', views.CountyListView.as_view(), name='casemgmt_county_list'),
    url(r'^casemgmt/county/create/$', views.CountyCreateView.as_view(), name='casemgmt_county_create'),
    url(r'^casemgmt/county/detail/(?P<pk>\S+)/$', views.CountyDetailView.as_view(), name='casemgmt_county_detail'),
    url(r'^casemgmt/county/update/(?P<pk>\S+)/$', views.CountyUpdateView.as_view(), name='casemgmt_county_update'),
)

urlpatterns += (
    # urls for CountyVersion
    url(r'^casemgmt/countyversion/$', views.CountyVersionListView.as_view(), name='casemgmt_countyversion_list'),
    url(r'^casemgmt/countyversion/create/$', views.CountyVersionCreateView.as_view(), name='casemgmt_countyversion_create'),
    url(r'^casemgmt/countyversion/detail/(?P<pk>\S+)/$', views.CountyVersionDetailView.as_view(), name='casemgmt_countyversion_detail'),
    url(r'^casemgmt/countyversion/update/(?P<pk>\S+)/$', views.CountyVersionUpdateView.as_view(), name='casemgmt_countyversion_update'),
)

urlpatterns += (
    # urls for Court
    url(r'^casemgmt/court/$', views.CourtListView.as_view(), name='casemgmt_court_list'),
    url(r'^casemgmt/court/create/$', views.CourtCreateView.as_view(), name='casemgmt_court_create'),
    url(r'^casemgmt/court/detail/(?P<pk>\S+)/$', views.CourtDetailView.as_view(), name='casemgmt_court_detail'),
    url(r'^casemgmt/court/update/(?P<pk>\S+)/$', views.CourtUpdateView.as_view(), name='casemgmt_court_update'),
)

urlpatterns += (
    # urls for CourtVersion
    url(r'^casemgmt/courtversion/$', views.CourtVersionListView.as_view(), name='casemgmt_courtversion_list'),
    url(r'^casemgmt/courtversion/create/$', views.CourtVersionCreateView.as_view(), name='casemgmt_courtversion_create'),
    url(r'^casemgmt/courtversion/detail/(?P<pk>\S+)/$', views.CourtVersionDetailView.as_view(), name='casemgmt_courtversion_detail'),
    url(r'^casemgmt/courtversion/update/(?P<pk>\S+)/$', views.CourtVersionUpdateView.as_view(), name='casemgmt_courtversion_update'),
)

urlpatterns += (
    # urls for Courtlevel
    url(r'^casemgmt/courtlevel/$', views.CourtlevelListView.as_view(), name='casemgmt_courtlevel_list'),
    url(r'^casemgmt/courtlevel/create/$', views.CourtlevelCreateView.as_view(), name='casemgmt_courtlevel_create'),
    url(r'^casemgmt/courtlevel/detail/(?P<pk>\S+)/$', views.CourtlevelDetailView.as_view(), name='casemgmt_courtlevel_detail'),
    url(r'^casemgmt/courtlevel/update/(?P<pk>\S+)/$', views.CourtlevelUpdateView.as_view(), name='casemgmt_courtlevel_update'),
)

urlpatterns += (
    # urls for CourtlevelVersion
    url(r'^casemgmt/courtlevelversion/$', views.CourtlevelVersionListView.as_view(), name='casemgmt_courtlevelversion_list'),
    url(r'^casemgmt/courtlevelversion/create/$', views.CourtlevelVersionCreateView.as_view(), name='casemgmt_courtlevelversion_create'),
    url(r'^casemgmt/courtlevelversion/detail/(?P<pk>\S+)/$', views.CourtlevelVersionDetailView.as_view(), name='casemgmt_courtlevelversion_detail'),
    url(r'^casemgmt/courtlevelversion/update/(?P<pk>\S+)/$', views.CourtlevelVersionUpdateView.as_view(), name='casemgmt_courtlevelversion_update'),
)

urlpatterns += (
    # urls for Courtstation
    url(r'^casemgmt/courtstation/$', views.CourtstationListView.as_view(), name='casemgmt_courtstation_list'),
    url(r'^casemgmt/courtstation/create/$', views.CourtstationCreateView.as_view(), name='casemgmt_courtstation_create'),
    url(r'^casemgmt/courtstation/detail/(?P<pk>\S+)/$', views.CourtstationDetailView.as_view(), name='casemgmt_courtstation_detail'),
    url(r'^casemgmt/courtstation/update/(?P<pk>\S+)/$', views.CourtstationUpdateView.as_view(), name='casemgmt_courtstation_update'),
)

urlpatterns += (
    # urls for CourtstationVersion
    url(r'^casemgmt/courtstationversion/$', views.CourtstationVersionListView.as_view(), name='casemgmt_courtstationversion_list'),
    url(r'^casemgmt/courtstationversion/create/$', views.CourtstationVersionCreateView.as_view(), name='casemgmt_courtstationversion_create'),
    url(r'^casemgmt/courtstationversion/detail/(?P<pk>\S+)/$', views.CourtstationVersionDetailView.as_view(), name='casemgmt_courtstationversion_detail'),
    url(r'^casemgmt/courtstationversion/update/(?P<pk>\S+)/$', views.CourtstationVersionUpdateView.as_view(), name='casemgmt_courtstationversion_update'),
)

urlpatterns += (
    # urls for Defendant
    url(r'^casemgmt/defendant/$', views.DefendantListView.as_view(), name='casemgmt_defendant_list'),
    url(r'^casemgmt/defendant/create/$', views.DefendantCreateView.as_view(), name='casemgmt_defendant_create'),
    url(r'^casemgmt/defendant/detail/(?P<pk>\S+)/$', views.DefendantDetailView.as_view(), name='casemgmt_defendant_detail'),
    url(r'^casemgmt/defendant/update/(?P<pk>\S+)/$', views.DefendantUpdateView.as_view(), name='casemgmt_defendant_update'),
)

urlpatterns += (
    # urls for DefendantGateregister
    url(r'^casemgmt/defendantgateregister/$', views.DefendantGateregisterListView.as_view(), name='casemgmt_defendantgateregister_list'),
    url(r'^casemgmt/defendantgateregister/create/$', views.DefendantGateregisterCreateView.as_view(), name='casemgmt_defendantgateregister_create'),
    url(r'^casemgmt/defendantgateregister/detail/(?P<pk>\S+)/$', views.DefendantGateregisterDetailView.as_view(), name='casemgmt_defendantgateregister_detail'),
    url(r'^casemgmt/defendantgateregister/update/(?P<pk>\S+)/$', views.DefendantGateregisterUpdateView.as_view(), name='casemgmt_defendantgateregister_update'),
)

urlpatterns += (
    # urls for DefendantGateregisterVersion
    url(r'^casemgmt/defendantgateregisterversion/$', views.DefendantGateregisterVersionListView.as_view(), name='casemgmt_defendantgateregisterversion_list'),
    url(r'^casemgmt/defendantgateregisterversion/create/$', views.DefendantGateregisterVersionCreateView.as_view(), name='casemgmt_defendantgateregisterversion_create'),
    url(r'^casemgmt/defendantgateregisterversion/detail/(?P<pk>\S+)/$', views.DefendantGateregisterVersionDetailView.as_view(), name='casemgmt_defendantgateregisterversion_detail'),
    url(r'^casemgmt/defendantgateregisterversion/update/(?P<pk>\S+)/$', views.DefendantGateregisterVersionUpdateView.as_view(), name='casemgmt_defendantgateregisterversion_update'),
)

urlpatterns += (
    # urls for DefendantHearing
    url(r'^casemgmt/defendanthearing/$', views.DefendantHearingListView.as_view(), name='casemgmt_defendanthearing_list'),
    url(r'^casemgmt/defendanthearing/create/$', views.DefendantHearingCreateView.as_view(), name='casemgmt_defendanthearing_create'),
    url(r'^casemgmt/defendanthearing/detail/(?P<pk>\S+)/$', views.DefendantHearingDetailView.as_view(), name='casemgmt_defendanthearing_detail'),
    url(r'^casemgmt/defendanthearing/update/(?P<pk>\S+)/$', views.DefendantHearingUpdateView.as_view(), name='casemgmt_defendanthearing_update'),
)

urlpatterns += (
    # urls for DefendantHearingVersion
    url(r'^casemgmt/defendanthearingversion/$', views.DefendantHearingVersionListView.as_view(), name='casemgmt_defendanthearingversion_list'),
    url(r'^casemgmt/defendanthearingversion/create/$', views.DefendantHearingVersionCreateView.as_view(), name='casemgmt_defendanthearingversion_create'),
    url(r'^casemgmt/defendanthearingversion/detail/(?P<pk>\S+)/$', views.DefendantHearingVersionDetailView.as_view(), name='casemgmt_defendanthearingversion_detail'),
    url(r'^casemgmt/defendanthearingversion/update/(?P<pk>\S+)/$', views.DefendantHearingVersionUpdateView.as_view(), name='casemgmt_defendanthearingversion_update'),
)

urlpatterns += (
    # urls for DefendantMedevent
    url(r'^casemgmt/defendantmedevent/$', views.DefendantMedeventListView.as_view(), name='casemgmt_defendantmedevent_list'),
    url(r'^casemgmt/defendantmedevent/create/$', views.DefendantMedeventCreateView.as_view(), name='casemgmt_defendantmedevent_create'),
    url(r'^casemgmt/defendantmedevent/detail/(?P<pk>\S+)/$', views.DefendantMedeventDetailView.as_view(), name='casemgmt_defendantmedevent_detail'),
    url(r'^casemgmt/defendantmedevent/update/(?P<pk>\S+)/$', views.DefendantMedeventUpdateView.as_view(), name='casemgmt_defendantmedevent_update'),
)

urlpatterns += (
    # urls for DefendantMedeventVersion
    url(r'^casemgmt/defendantmedeventversion/$', views.DefendantMedeventVersionListView.as_view(), name='casemgmt_defendantmedeventversion_list'),
    url(r'^casemgmt/defendantmedeventversion/create/$', views.DefendantMedeventVersionCreateView.as_view(), name='casemgmt_defendantmedeventversion_create'),
    url(r'^casemgmt/defendantmedeventversion/detail/(?P<pk>\S+)/$', views.DefendantMedeventVersionDetailView.as_view(), name='casemgmt_defendantmedeventversion_detail'),
    url(r'^casemgmt/defendantmedeventversion/update/(?P<pk>\S+)/$', views.DefendantMedeventVersionUpdateView.as_view(), name='casemgmt_defendantmedeventversion_update'),
)

urlpatterns += (
    # urls for DefendantVersion
    url(r'^casemgmt/defendantversion/$', views.DefendantVersionListView.as_view(), name='casemgmt_defendantversion_list'),
    url(r'^casemgmt/defendantversion/create/$', views.DefendantVersionCreateView.as_view(), name='casemgmt_defendantversion_create'),
    url(r'^casemgmt/defendantversion/detail/(?P<pk>\S+)/$', views.DefendantVersionDetailView.as_view(), name='casemgmt_defendantversion_detail'),
    url(r'^casemgmt/defendantversion/update/(?P<pk>\S+)/$', views.DefendantVersionUpdateView.as_view(), name='casemgmt_defendantversion_update'),
)

urlpatterns += (
    # urls for Discipline
    url(r'^casemgmt/discipline/$', views.DisciplineListView.as_view(), name='casemgmt_discipline_list'),
    url(r'^casemgmt/discipline/create/$', views.DisciplineCreateView.as_view(), name='casemgmt_discipline_create'),
    url(r'^casemgmt/discipline/detail/(?P<pk>\S+)/$', views.DisciplineDetailView.as_view(), name='casemgmt_discipline_detail'),
    url(r'^casemgmt/discipline/update/(?P<pk>\S+)/$', views.DisciplineUpdateView.as_view(), name='casemgmt_discipline_update'),
)

urlpatterns += (
    # urls for DisciplineVersion
    url(r'^casemgmt/disciplineversion/$', views.DisciplineVersionListView.as_view(), name='casemgmt_disciplineversion_list'),
    url(r'^casemgmt/disciplineversion/create/$', views.DisciplineVersionCreateView.as_view(), name='casemgmt_disciplineversion_create'),
    url(r'^casemgmt/disciplineversion/detail/(?P<pk>\S+)/$', views.DisciplineVersionDetailView.as_view(), name='casemgmt_disciplineversion_detail'),
    url(r'^casemgmt/disciplineversion/update/(?P<pk>\S+)/$', views.DisciplineVersionUpdateView.as_view(), name='casemgmt_disciplineversion_update'),
)

urlpatterns += (
    # urls for DocStore
    url(r'^casemgmt/docstore/$', views.DocStoreListView.as_view(), name='casemgmt_docstore_list'),
    url(r'^casemgmt/docstore/create/$', views.DocStoreCreateView.as_view(), name='casemgmt_docstore_create'),
    url(r'^casemgmt/docstore/detail/(?P<pk>\S+)/$', views.DocStoreDetailView.as_view(), name='casemgmt_docstore_detail'),
    url(r'^casemgmt/docstore/update/(?P<pk>\S+)/$', views.DocStoreUpdateView.as_view(), name='casemgmt_docstore_update'),
)

urlpatterns += (
    # urls for Docarchive
    url(r'^casemgmt/docarchive/$', views.DocarchiveListView.as_view(), name='casemgmt_docarchive_list'),
    url(r'^casemgmt/docarchive/create/$', views.DocarchiveCreateView.as_view(), name='casemgmt_docarchive_create'),
    url(r'^casemgmt/docarchive/detail/(?P<pk>\S+)/$', views.DocarchiveDetailView.as_view(), name='casemgmt_docarchive_detail'),
    url(r'^casemgmt/docarchive/update/(?P<pk>\S+)/$', views.DocarchiveUpdateView.as_view(), name='casemgmt_docarchive_update'),
)

urlpatterns += (
    # urls for DocarchiveTag
    url(r'^casemgmt/docarchivetag/$', views.DocarchiveTagListView.as_view(), name='casemgmt_docarchivetag_list'),
    url(r'^casemgmt/docarchivetag/create/$', views.DocarchiveTagCreateView.as_view(), name='casemgmt_docarchivetag_create'),
    url(r'^casemgmt/docarchivetag/detail/(?P<pk>\S+)/$', views.DocarchiveTagDetailView.as_view(), name='casemgmt_docarchivetag_detail'),
    url(r'^casemgmt/docarchivetag/update/(?P<pk>\S+)/$', views.DocarchiveTagUpdateView.as_view(), name='casemgmt_docarchivetag_update'),
)

urlpatterns += (
    # urls for DocarchiveTagVersion
    url(r'^casemgmt/docarchivetagversion/$', views.DocarchiveTagVersionListView.as_view(), name='casemgmt_docarchivetagversion_list'),
    url(r'^casemgmt/docarchivetagversion/create/$', views.DocarchiveTagVersionCreateView.as_view(), name='casemgmt_docarchivetagversion_create'),
    url(r'^casemgmt/docarchivetagversion/detail/(?P<pk>\S+)/$', views.DocarchiveTagVersionDetailView.as_view(), name='casemgmt_docarchivetagversion_detail'),
    url(r'^casemgmt/docarchivetagversion/update/(?P<pk>\S+)/$', views.DocarchiveTagVersionUpdateView.as_view(), name='casemgmt_docarchivetagversion_update'),
)

urlpatterns += (
    # urls for DocarchiveVersion
    url(r'^casemgmt/docarchiveversion/$', views.DocarchiveVersionListView.as_view(), name='casemgmt_docarchiveversion_list'),
    url(r'^casemgmt/docarchiveversion/create/$', views.DocarchiveVersionCreateView.as_view(), name='casemgmt_docarchiveversion_create'),
    url(r'^casemgmt/docarchiveversion/detail/(?P<pk>\S+)/$', views.DocarchiveVersionDetailView.as_view(), name='casemgmt_docarchiveversion_detail'),
    url(r'^casemgmt/docarchiveversion/update/(?P<pk>\S+)/$', views.DocarchiveVersionUpdateView.as_view(), name='casemgmt_docarchiveversion_update'),
)

urlpatterns += (
    # urls for Doctemplate
    url(r'^casemgmt/doctemplate/$', views.DoctemplateListView.as_view(), name='casemgmt_doctemplate_list'),
    url(r'^casemgmt/doctemplate/create/$', views.DoctemplateCreateView.as_view(), name='casemgmt_doctemplate_create'),
    url(r'^casemgmt/doctemplate/detail/(?P<pk>\S+)/$', views.DoctemplateDetailView.as_view(), name='casemgmt_doctemplate_detail'),
    url(r'^casemgmt/doctemplate/update/(?P<pk>\S+)/$', views.DoctemplateUpdateView.as_view(), name='casemgmt_doctemplate_update'),
)

urlpatterns += (
    # urls for DoctemplateVersion
    url(r'^casemgmt/doctemplateversion/$', views.DoctemplateVersionListView.as_view(), name='casemgmt_doctemplateversion_list'),
    url(r'^casemgmt/doctemplateversion/create/$', views.DoctemplateVersionCreateView.as_view(), name='casemgmt_doctemplateversion_create'),
    url(r'^casemgmt/doctemplateversion/detail/(?P<pk>\S+)/$', views.DoctemplateVersionDetailView.as_view(), name='casemgmt_doctemplateversion_detail'),
    url(r'^casemgmt/doctemplateversion/update/(?P<pk>\S+)/$', views.DoctemplateVersionUpdateView.as_view(), name='casemgmt_doctemplateversion_update'),
)

urlpatterns += (
    # urls for Document
    url(r'^casemgmt/document/$', views.DocumentListView.as_view(), name='casemgmt_document_list'),
    url(r'^casemgmt/document/create/$', views.DocumentCreateView.as_view(), name='casemgmt_document_create'),
    url(r'^casemgmt/document/detail/(?P<pk>\S+)/$', views.DocumentDetailView.as_view(), name='casemgmt_document_detail'),
    url(r'^casemgmt/document/update/(?P<pk>\S+)/$', views.DocumentUpdateView.as_view(), name='casemgmt_document_update'),
)

urlpatterns += (
    # urls for DocumentTag
    url(r'^casemgmt/documenttag/$', views.DocumentTagListView.as_view(), name='casemgmt_documenttag_list'),
    url(r'^casemgmt/documenttag/create/$', views.DocumentTagCreateView.as_view(), name='casemgmt_documenttag_create'),
    url(r'^casemgmt/documenttag/detail/(?P<pk>\S+)/$', views.DocumentTagDetailView.as_view(), name='casemgmt_documenttag_detail'),
    url(r'^casemgmt/documenttag/update/(?P<pk>\S+)/$', views.DocumentTagUpdateView.as_view(), name='casemgmt_documenttag_update'),
)

urlpatterns += (
    # urls for DocumentTagVersion
    url(r'^casemgmt/documenttagversion/$', views.DocumentTagVersionListView.as_view(), name='casemgmt_documenttagversion_list'),
    url(r'^casemgmt/documenttagversion/create/$', views.DocumentTagVersionCreateView.as_view(), name='casemgmt_documenttagversion_create'),
    url(r'^casemgmt/documenttagversion/detail/(?P<pk>\S+)/$', views.DocumentTagVersionDetailView.as_view(), name='casemgmt_documenttagversion_detail'),
    url(r'^casemgmt/documenttagversion/update/(?P<pk>\S+)/$', views.DocumentTagVersionUpdateView.as_view(), name='casemgmt_documenttagversion_update'),
)

urlpatterns += (
    # urls for DocumentVersion
    url(r'^casemgmt/documentversion/$', views.DocumentVersionListView.as_view(), name='casemgmt_documentversion_list'),
    url(r'^casemgmt/documentversion/create/$', views.DocumentVersionCreateView.as_view(), name='casemgmt_documentversion_create'),
    url(r'^casemgmt/documentversion/detail/(?P<pk>\S+)/$', views.DocumentVersionDetailView.as_view(), name='casemgmt_documentversion_detail'),
    url(r'^casemgmt/documentversion/update/(?P<pk>\S+)/$', views.DocumentVersionUpdateView.as_view(), name='casemgmt_documentversion_update'),
)

urlpatterns += (
    # urls for Eventlog
    url(r'^casemgmt/eventlog/$', views.EventlogListView.as_view(), name='casemgmt_eventlog_list'),
    url(r'^casemgmt/eventlog/create/$', views.EventlogCreateView.as_view(), name='casemgmt_eventlog_create'),
    url(r'^casemgmt/eventlog/detail/(?P<pk>\S+)/$', views.EventlogDetailView.as_view(), name='casemgmt_eventlog_detail'),
    url(r'^casemgmt/eventlog/update/(?P<pk>\S+)/$', views.EventlogUpdateView.as_view(), name='casemgmt_eventlog_update'),
)

urlpatterns += (
    # urls for EventlogVersion
    url(r'^casemgmt/eventlogversion/$', views.EventlogVersionListView.as_view(), name='casemgmt_eventlogversion_list'),
    url(r'^casemgmt/eventlogversion/create/$', views.EventlogVersionCreateView.as_view(), name='casemgmt_eventlogversion_create'),
    url(r'^casemgmt/eventlogversion/detail/(?P<pk>\S+)/$', views.EventlogVersionDetailView.as_view(), name='casemgmt_eventlogversion_detail'),
    url(r'^casemgmt/eventlogversion/update/(?P<pk>\S+)/$', views.EventlogVersionUpdateView.as_view(), name='casemgmt_eventlogversion_update'),
)

urlpatterns += (
    # urls for Filing
    url(r'^casemgmt/filing/$', views.FilingListView.as_view(), name='casemgmt_filing_list'),
    url(r'^casemgmt/filing/create/$', views.FilingCreateView.as_view(), name='casemgmt_filing_create'),
    url(r'^casemgmt/filing/detail/(?P<pk>\S+)/$', views.FilingDetailView.as_view(), name='casemgmt_filing_detail'),
    url(r'^casemgmt/filing/update/(?P<pk>\S+)/$', views.FilingUpdateView.as_view(), name='casemgmt_filing_update'),
)

urlpatterns += (
    # urls for FilingFilingtype
    url(r'^casemgmt/filingfilingtype/$', views.FilingFilingtypeListView.as_view(), name='casemgmt_filingfilingtype_list'),
    url(r'^casemgmt/filingfilingtype/create/$', views.FilingFilingtypeCreateView.as_view(), name='casemgmt_filingfilingtype_create'),
    url(r'^casemgmt/filingfilingtype/detail/(?P<pk>\S+)/$', views.FilingFilingtypeDetailView.as_view(), name='casemgmt_filingfilingtype_detail'),
    url(r'^casemgmt/filingfilingtype/update/(?P<pk>\S+)/$', views.FilingFilingtypeUpdateView.as_view(), name='casemgmt_filingfilingtype_update'),
)

urlpatterns += (
    # urls for FilingFilingtypeVersion
    url(r'^casemgmt/filingfilingtypeversion/$', views.FilingFilingtypeVersionListView.as_view(), name='casemgmt_filingfilingtypeversion_list'),
    url(r'^casemgmt/filingfilingtypeversion/create/$', views.FilingFilingtypeVersionCreateView.as_view(), name='casemgmt_filingfilingtypeversion_create'),
    url(r'^casemgmt/filingfilingtypeversion/detail/(?P<pk>\S+)/$', views.FilingFilingtypeVersionDetailView.as_view(), name='casemgmt_filingfilingtypeversion_detail'),
    url(r'^casemgmt/filingfilingtypeversion/update/(?P<pk>\S+)/$', views.FilingFilingtypeVersionUpdateView.as_view(), name='casemgmt_filingfilingtypeversion_update'),
)

urlpatterns += (
    # urls for FilingPayment
    url(r'^casemgmt/filingpayment/$', views.FilingPaymentListView.as_view(), name='casemgmt_filingpayment_list'),
    url(r'^casemgmt/filingpayment/create/$', views.FilingPaymentCreateView.as_view(), name='casemgmt_filingpayment_create'),
    url(r'^casemgmt/filingpayment/detail/(?P<pk>\S+)/$', views.FilingPaymentDetailView.as_view(), name='casemgmt_filingpayment_detail'),
    url(r'^casemgmt/filingpayment/update/(?P<pk>\S+)/$', views.FilingPaymentUpdateView.as_view(), name='casemgmt_filingpayment_update'),
)

urlpatterns += (
    # urls for FilingPaymentVersion
    url(r'^casemgmt/filingpaymentversion/$', views.FilingPaymentVersionListView.as_view(), name='casemgmt_filingpaymentversion_list'),
    url(r'^casemgmt/filingpaymentversion/create/$', views.FilingPaymentVersionCreateView.as_view(), name='casemgmt_filingpaymentversion_create'),
    url(r'^casemgmt/filingpaymentversion/detail/(?P<pk>\S+)/$', views.FilingPaymentVersionDetailView.as_view(), name='casemgmt_filingpaymentversion_detail'),
    url(r'^casemgmt/filingpaymentversion/update/(?P<pk>\S+)/$', views.FilingPaymentVersionUpdateView.as_view(), name='casemgmt_filingpaymentversion_update'),
)

urlpatterns += (
    # urls for FilingVersion
    url(r'^casemgmt/filingversion/$', views.FilingVersionListView.as_view(), name='casemgmt_filingversion_list'),
    url(r'^casemgmt/filingversion/create/$', views.FilingVersionCreateView.as_view(), name='casemgmt_filingversion_create'),
    url(r'^casemgmt/filingversion/detail/(?P<pk>\S+)/$', views.FilingVersionDetailView.as_view(), name='casemgmt_filingversion_detail'),
    url(r'^casemgmt/filingversion/update/(?P<pk>\S+)/$', views.FilingVersionUpdateView.as_view(), name='casemgmt_filingversion_update'),
)

urlpatterns += (
    # urls for Filingtype
    url(r'^casemgmt/filingtype/$', views.FilingtypeListView.as_view(), name='casemgmt_filingtype_list'),
    url(r'^casemgmt/filingtype/create/$', views.FilingtypeCreateView.as_view(), name='casemgmt_filingtype_create'),
    url(r'^casemgmt/filingtype/detail/(?P<pk>\S+)/$', views.FilingtypeDetailView.as_view(), name='casemgmt_filingtype_detail'),
    url(r'^casemgmt/filingtype/update/(?P<pk>\S+)/$', views.FilingtypeUpdateView.as_view(), name='casemgmt_filingtype_update'),
)

urlpatterns += (
    # urls for FilingtypeVersion
    url(r'^casemgmt/filingtypeversion/$', views.FilingtypeVersionListView.as_view(), name='casemgmt_filingtypeversion_list'),
    url(r'^casemgmt/filingtypeversion/create/$', views.FilingtypeVersionCreateView.as_view(), name='casemgmt_filingtypeversion_create'),
    url(r'^casemgmt/filingtypeversion/detail/(?P<pk>\S+)/$', views.FilingtypeVersionDetailView.as_view(), name='casemgmt_filingtypeversion_detail'),
    url(r'^casemgmt/filingtypeversion/update/(?P<pk>\S+)/$', views.FilingtypeVersionUpdateView.as_view(), name='casemgmt_filingtypeversion_update'),
)

urlpatterns += (
    # urls for Gateregister
    url(r'^casemgmt/gateregister/$', views.GateregisterListView.as_view(), name='casemgmt_gateregister_list'),
    url(r'^casemgmt/gateregister/create/$', views.GateregisterCreateView.as_view(), name='casemgmt_gateregister_create'),
    url(r'^casemgmt/gateregister/detail/(?P<pk>\S+)/$', views.GateregisterDetailView.as_view(), name='casemgmt_gateregister_detail'),
    url(r'^casemgmt/gateregister/update/(?P<pk>\S+)/$', views.GateregisterUpdateView.as_view(), name='casemgmt_gateregister_update'),
)

urlpatterns += (
    # urls for GateregisterVersion
    url(r'^casemgmt/gateregisterversion/$', views.GateregisterVersionListView.as_view(), name='casemgmt_gateregisterversion_list'),
    url(r'^casemgmt/gateregisterversion/create/$', views.GateregisterVersionCreateView.as_view(), name='casemgmt_gateregisterversion_create'),
    url(r'^casemgmt/gateregisterversion/detail/(?P<pk>\S+)/$', views.GateregisterVersionDetailView.as_view(), name='casemgmt_gateregisterversion_detail'),
    url(r'^casemgmt/gateregisterversion/update/(?P<pk>\S+)/$', views.GateregisterVersionUpdateView.as_view(), name='casemgmt_gateregisterversion_update'),
)

urlpatterns += (
    # urls for GateregisterWarder
    url(r'^casemgmt/gateregisterwarder/$', views.GateregisterWarderListView.as_view(), name='casemgmt_gateregisterwarder_list'),
    url(r'^casemgmt/gateregisterwarder/create/$', views.GateregisterWarderCreateView.as_view(), name='casemgmt_gateregisterwarder_create'),
    url(r'^casemgmt/gateregisterwarder/detail/(?P<pk>\S+)/$', views.GateregisterWarderDetailView.as_view(), name='casemgmt_gateregisterwarder_detail'),
    url(r'^casemgmt/gateregisterwarder/update/(?P<pk>\S+)/$', views.GateregisterWarderUpdateView.as_view(), name='casemgmt_gateregisterwarder_update'),
)

urlpatterns += (
    # urls for GateregisterWarder2
    url(r'^casemgmt/gateregisterwarder2/$', views.GateregisterWarder2ListView.as_view(), name='casemgmt_gateregisterwarder2_list'),
    url(r'^casemgmt/gateregisterwarder2/create/$', views.GateregisterWarder2CreateView.as_view(), name='casemgmt_gateregisterwarder2_create'),
    url(r'^casemgmt/gateregisterwarder2/detail/(?P<pk>\S+)/$', views.GateregisterWarder2DetailView.as_view(), name='casemgmt_gateregisterwarder2_detail'),
    url(r'^casemgmt/gateregisterwarder2/update/(?P<pk>\S+)/$', views.GateregisterWarder2UpdateView.as_view(), name='casemgmt_gateregisterwarder2_update'),
)

urlpatterns += (
    # urls for GateregisterWarder2Version
    url(r'^casemgmt/gateregisterwarder2version/$', views.GateregisterWarder2VersionListView.as_view(), name='casemgmt_gateregisterwarder2version_list'),
    url(r'^casemgmt/gateregisterwarder2version/create/$', views.GateregisterWarder2VersionCreateView.as_view(), name='casemgmt_gateregisterwarder2version_create'),
    url(r'^casemgmt/gateregisterwarder2version/detail/(?P<pk>\S+)/$', views.GateregisterWarder2VersionDetailView.as_view(), name='casemgmt_gateregisterwarder2version_detail'),
    url(r'^casemgmt/gateregisterwarder2version/update/(?P<pk>\S+)/$', views.GateregisterWarder2VersionUpdateView.as_view(), name='casemgmt_gateregisterwarder2version_update'),
)

urlpatterns += (
    # urls for GateregisterWarderVersion
    url(r'^casemgmt/gateregisterwarderversion/$', views.GateregisterWarderVersionListView.as_view(), name='casemgmt_gateregisterwarderversion_list'),
    url(r'^casemgmt/gateregisterwarderversion/create/$', views.GateregisterWarderVersionCreateView.as_view(), name='casemgmt_gateregisterwarderversion_create'),
    url(r'^casemgmt/gateregisterwarderversion/detail/(?P<pk>\S+)/$', views.GateregisterWarderVersionDetailView.as_view(), name='casemgmt_gateregisterwarderversion_detail'),
    url(r'^casemgmt/gateregisterwarderversion/update/(?P<pk>\S+)/$', views.GateregisterWarderVersionUpdateView.as_view(), name='casemgmt_gateregisterwarderversion_update'),
)

urlpatterns += (
    # urls for Gender
    url(r'^casemgmt/gender/$', views.GenderListView.as_view(), name='casemgmt_gender_list'),
    url(r'^casemgmt/gender/create/$', views.GenderCreateView.as_view(), name='casemgmt_gender_create'),
    url(r'^casemgmt/gender/detail/(?P<pk>\S+)/$', views.GenderDetailView.as_view(), name='casemgmt_gender_detail'),
    url(r'^casemgmt/gender/update/(?P<pk>\S+)/$', views.GenderUpdateView.as_view(), name='casemgmt_gender_update'),
)

urlpatterns += (
    # urls for GenderVersion
    url(r'^casemgmt/genderversion/$', views.GenderVersionListView.as_view(), name='casemgmt_genderversion_list'),
    url(r'^casemgmt/genderversion/create/$', views.GenderVersionCreateView.as_view(), name='casemgmt_genderversion_create'),
    url(r'^casemgmt/genderversion/detail/(?P<pk>\S+)/$', views.GenderVersionDetailView.as_view(), name='casemgmt_genderversion_detail'),
    url(r'^casemgmt/genderversion/update/(?P<pk>\S+)/$', views.GenderVersionUpdateView.as_view(), name='casemgmt_genderversion_update'),
)

urlpatterns += (
    # urls for Hearing
    url(r'^casemgmt/hearing/$', views.HearingListView.as_view(), name='casemgmt_hearing_list'),
    url(r'^casemgmt/hearing/create/$', views.HearingCreateView.as_view(), name='casemgmt_hearing_create'),
    url(r'^casemgmt/hearing/detail/(?P<pk>\S+)/$', views.HearingDetailView.as_view(), name='casemgmt_hearing_detail'),
    url(r'^casemgmt/hearing/update/(?P<pk>\S+)/$', views.HearingUpdateView.as_view(), name='casemgmt_hearing_update'),
)

urlpatterns += (
    # urls for HearingJudicialofficer
    url(r'^casemgmt/hearingjudicialofficer/$', views.HearingJudicialofficerListView.as_view(), name='casemgmt_hearingjudicialofficer_list'),
    url(r'^casemgmt/hearingjudicialofficer/create/$', views.HearingJudicialofficerCreateView.as_view(), name='casemgmt_hearingjudicialofficer_create'),
    url(r'^casemgmt/hearingjudicialofficer/detail/(?P<pk>\S+)/$', views.HearingJudicialofficerDetailView.as_view(), name='casemgmt_hearingjudicialofficer_detail'),
    url(r'^casemgmt/hearingjudicialofficer/update/(?P<pk>\S+)/$', views.HearingJudicialofficerUpdateView.as_view(), name='casemgmt_hearingjudicialofficer_update'),
)

urlpatterns += (
    # urls for HearingJudicialofficerVersion
    url(r'^casemgmt/hearingjudicialofficerversion/$', views.HearingJudicialofficerVersionListView.as_view(), name='casemgmt_hearingjudicialofficerversion_list'),
    url(r'^casemgmt/hearingjudicialofficerversion/create/$', views.HearingJudicialofficerVersionCreateView.as_view(), name='casemgmt_hearingjudicialofficerversion_create'),
    url(r'^casemgmt/hearingjudicialofficerversion/detail/(?P<pk>\S+)/$', views.HearingJudicialofficerVersionDetailView.as_view(), name='casemgmt_hearingjudicialofficerversion_detail'),
    url(r'^casemgmt/hearingjudicialofficerversion/update/(?P<pk>\S+)/$', views.HearingJudicialofficerVersionUpdateView.as_view(), name='casemgmt_hearingjudicialofficerversion_update'),
)

urlpatterns += (
    # urls for HearingLawyers
    url(r'^casemgmt/hearinglawyers/$', views.HearingLawyersListView.as_view(), name='casemgmt_hearinglawyers_list'),
    url(r'^casemgmt/hearinglawyers/create/$', views.HearingLawyersCreateView.as_view(), name='casemgmt_hearinglawyers_create'),
    url(r'^casemgmt/hearinglawyers/detail/(?P<pk>\S+)/$', views.HearingLawyersDetailView.as_view(), name='casemgmt_hearinglawyers_detail'),
    url(r'^casemgmt/hearinglawyers/update/(?P<pk>\S+)/$', views.HearingLawyersUpdateView.as_view(), name='casemgmt_hearinglawyers_update'),
)

urlpatterns += (
    # urls for HearingLawyersVersion
    url(r'^casemgmt/hearinglawyersversion/$', views.HearingLawyersVersionListView.as_view(), name='casemgmt_hearinglawyersversion_list'),
    url(r'^casemgmt/hearinglawyersversion/create/$', views.HearingLawyersVersionCreateView.as_view(), name='casemgmt_hearinglawyersversion_create'),
    url(r'^casemgmt/hearinglawyersversion/detail/(?P<pk>\S+)/$', views.HearingLawyersVersionDetailView.as_view(), name='casemgmt_hearinglawyersversion_detail'),
    url(r'^casemgmt/hearinglawyersversion/update/(?P<pk>\S+)/$', views.HearingLawyersVersionUpdateView.as_view(), name='casemgmt_hearinglawyersversion_update'),
)

urlpatterns += (
    # urls for HearingPolofficer
    url(r'^casemgmt/hearingpolofficer/$', views.HearingPolofficerListView.as_view(), name='casemgmt_hearingpolofficer_list'),
    url(r'^casemgmt/hearingpolofficer/create/$', views.HearingPolofficerCreateView.as_view(), name='casemgmt_hearingpolofficer_create'),
    url(r'^casemgmt/hearingpolofficer/detail/(?P<pk>\S+)/$', views.HearingPolofficerDetailView.as_view(), name='casemgmt_hearingpolofficer_detail'),
    url(r'^casemgmt/hearingpolofficer/update/(?P<pk>\S+)/$', views.HearingPolofficerUpdateView.as_view(), name='casemgmt_hearingpolofficer_update'),
)

urlpatterns += (
    # urls for HearingPolofficerVersion
    url(r'^casemgmt/hearingpolofficerversion/$', views.HearingPolofficerVersionListView.as_view(), name='casemgmt_hearingpolofficerversion_list'),
    url(r'^casemgmt/hearingpolofficerversion/create/$', views.HearingPolofficerVersionCreateView.as_view(), name='casemgmt_hearingpolofficerversion_create'),
    url(r'^casemgmt/hearingpolofficerversion/detail/(?P<pk>\S+)/$', views.HearingPolofficerVersionDetailView.as_view(), name='casemgmt_hearingpolofficerversion_detail'),
    url(r'^casemgmt/hearingpolofficerversion/update/(?P<pk>\S+)/$', views.HearingPolofficerVersionUpdateView.as_view(), name='casemgmt_hearingpolofficerversion_update'),
)

urlpatterns += (
    # urls for HearingProsecutor
    url(r'^casemgmt/hearingprosecutor/$', views.HearingProsecutorListView.as_view(), name='casemgmt_hearingprosecutor_list'),
    url(r'^casemgmt/hearingprosecutor/create/$', views.HearingProsecutorCreateView.as_view(), name='casemgmt_hearingprosecutor_create'),
    url(r'^casemgmt/hearingprosecutor/detail/(?P<pk>\S+)/$', views.HearingProsecutorDetailView.as_view(), name='casemgmt_hearingprosecutor_detail'),
    url(r'^casemgmt/hearingprosecutor/update/(?P<pk>\S+)/$', views.HearingProsecutorUpdateView.as_view(), name='casemgmt_hearingprosecutor_update'),
)

urlpatterns += (
    # urls for HearingProsecutorVersion
    url(r'^casemgmt/hearingprosecutorversion/$', views.HearingProsecutorVersionListView.as_view(), name='casemgmt_hearingprosecutorversion_list'),
    url(r'^casemgmt/hearingprosecutorversion/create/$', views.HearingProsecutorVersionCreateView.as_view(), name='casemgmt_hearingprosecutorversion_create'),
    url(r'^casemgmt/hearingprosecutorversion/detail/(?P<pk>\S+)/$', views.HearingProsecutorVersionDetailView.as_view(), name='casemgmt_hearingprosecutorversion_detail'),
    url(r'^casemgmt/hearingprosecutorversion/update/(?P<pk>\S+)/$', views.HearingProsecutorVersionUpdateView.as_view(), name='casemgmt_hearingprosecutorversion_update'),
)

urlpatterns += (
    # urls for HearingTag
    url(r'^casemgmt/hearingtag/$', views.HearingTagListView.as_view(), name='casemgmt_hearingtag_list'),
    url(r'^casemgmt/hearingtag/create/$', views.HearingTagCreateView.as_view(), name='casemgmt_hearingtag_create'),
    url(r'^casemgmt/hearingtag/detail/(?P<pk>\S+)/$', views.HearingTagDetailView.as_view(), name='casemgmt_hearingtag_detail'),
    url(r'^casemgmt/hearingtag/update/(?P<pk>\S+)/$', views.HearingTagUpdateView.as_view(), name='casemgmt_hearingtag_update'),
)

urlpatterns += (
    # urls for HearingTagVersion
    url(r'^casemgmt/hearingtagversion/$', views.HearingTagVersionListView.as_view(), name='casemgmt_hearingtagversion_list'),
    url(r'^casemgmt/hearingtagversion/create/$', views.HearingTagVersionCreateView.as_view(), name='casemgmt_hearingtagversion_create'),
    url(r'^casemgmt/hearingtagversion/detail/(?P<pk>\S+)/$', views.HearingTagVersionDetailView.as_view(), name='casemgmt_hearingtagversion_detail'),
    url(r'^casemgmt/hearingtagversion/update/(?P<pk>\S+)/$', views.HearingTagVersionUpdateView.as_view(), name='casemgmt_hearingtagversion_update'),
)

urlpatterns += (
    # urls for HearingVersion
    url(r'^casemgmt/hearingversion/$', views.HearingVersionListView.as_view(), name='casemgmt_hearingversion_list'),
    url(r'^casemgmt/hearingversion/create/$', views.HearingVersionCreateView.as_view(), name='casemgmt_hearingversion_create'),
    url(r'^casemgmt/hearingversion/detail/(?P<pk>\S+)/$', views.HearingVersionDetailView.as_view(), name='casemgmt_hearingversion_detail'),
    url(r'^casemgmt/hearingversion/update/(?P<pk>\S+)/$', views.HearingVersionUpdateView.as_view(), name='casemgmt_hearingversion_update'),
)

urlpatterns += (
    # urls for HearingWitness
    url(r'^casemgmt/hearingwitness/$', views.HearingWitnessListView.as_view(), name='casemgmt_hearingwitness_list'),
    url(r'^casemgmt/hearingwitness/create/$', views.HearingWitnessCreateView.as_view(), name='casemgmt_hearingwitness_create'),
    url(r'^casemgmt/hearingwitness/detail/(?P<pk>\S+)/$', views.HearingWitnessDetailView.as_view(), name='casemgmt_hearingwitness_detail'),
    url(r'^casemgmt/hearingwitness/update/(?P<pk>\S+)/$', views.HearingWitnessUpdateView.as_view(), name='casemgmt_hearingwitness_update'),
)

urlpatterns += (
    # urls for HearingWitnessVersion
    url(r'^casemgmt/hearingwitnessversion/$', views.HearingWitnessVersionListView.as_view(), name='casemgmt_hearingwitnessversion_list'),
    url(r'^casemgmt/hearingwitnessversion/create/$', views.HearingWitnessVersionCreateView.as_view(), name='casemgmt_hearingwitnessversion_create'),
    url(r'^casemgmt/hearingwitnessversion/detail/(?P<pk>\S+)/$', views.HearingWitnessVersionDetailView.as_view(), name='casemgmt_hearingwitnessversion_detail'),
    url(r'^casemgmt/hearingwitnessversion/update/(?P<pk>\S+)/$', views.HearingWitnessVersionUpdateView.as_view(), name='casemgmt_hearingwitnessversion_update'),
)

urlpatterns += (
    # urls for Hearingtype
    url(r'^casemgmt/hearingtype/$', views.HearingtypeListView.as_view(), name='casemgmt_hearingtype_list'),
    url(r'^casemgmt/hearingtype/create/$', views.HearingtypeCreateView.as_view(), name='casemgmt_hearingtype_create'),
    url(r'^casemgmt/hearingtype/detail/(?P<pk>\S+)/$', views.HearingtypeDetailView.as_view(), name='casemgmt_hearingtype_detail'),
    url(r'^casemgmt/hearingtype/update/(?P<pk>\S+)/$', views.HearingtypeUpdateView.as_view(), name='casemgmt_hearingtype_update'),
)

urlpatterns += (
    # urls for HearingtypeVersion
    url(r'^casemgmt/hearingtypeversion/$', views.HearingtypeVersionListView.as_view(), name='casemgmt_hearingtypeversion_list'),
    url(r'^casemgmt/hearingtypeversion/create/$', views.HearingtypeVersionCreateView.as_view(), name='casemgmt_hearingtypeversion_create'),
    url(r'^casemgmt/hearingtypeversion/detail/(?P<pk>\S+)/$', views.HearingtypeVersionDetailView.as_view(), name='casemgmt_hearingtypeversion_detail'),
    url(r'^casemgmt/hearingtypeversion/update/(?P<pk>\S+)/$', views.HearingtypeVersionUpdateView.as_view(), name='casemgmt_hearingtypeversion_update'),
)

urlpatterns += (
    # urls for Investigation
    url(r'^casemgmt/investigation/$', views.InvestigationListView.as_view(), name='casemgmt_investigation_list'),
    url(r'^casemgmt/investigation/create/$', views.InvestigationCreateView.as_view(), name='casemgmt_investigation_create'),
    url(r'^casemgmt/investigation/detail/(?P<pk>\S+)/$', views.InvestigationDetailView.as_view(), name='casemgmt_investigation_detail'),
    url(r'^casemgmt/investigation/update/(?P<pk>\S+)/$', views.InvestigationUpdateView.as_view(), name='casemgmt_investigation_update'),
)

urlpatterns += (
    # urls for InvestigationPolofficer
    url(r'^casemgmt/investigationpolofficer/$', views.InvestigationPolofficerListView.as_view(), name='casemgmt_investigationpolofficer_list'),
    url(r'^casemgmt/investigationpolofficer/create/$', views.InvestigationPolofficerCreateView.as_view(), name='casemgmt_investigationpolofficer_create'),
    url(r'^casemgmt/investigationpolofficer/detail/(?P<pk>\S+)/$', views.InvestigationPolofficerDetailView.as_view(), name='casemgmt_investigationpolofficer_detail'),
    url(r'^casemgmt/investigationpolofficer/update/(?P<pk>\S+)/$', views.InvestigationPolofficerUpdateView.as_view(), name='casemgmt_investigationpolofficer_update'),
)

urlpatterns += (
    # urls for InvestigationPolofficerVersion
    url(r'^casemgmt/investigationpolofficerversion/$', views.InvestigationPolofficerVersionListView.as_view(), name='casemgmt_investigationpolofficerversion_list'),
    url(r'^casemgmt/investigationpolofficerversion/create/$', views.InvestigationPolofficerVersionCreateView.as_view(), name='casemgmt_investigationpolofficerversion_create'),
    url(r'^casemgmt/investigationpolofficerversion/detail/(?P<pk>\S+)/$', views.InvestigationPolofficerVersionDetailView.as_view(), name='casemgmt_investigationpolofficerversion_detail'),
    url(r'^casemgmt/investigationpolofficerversion/update/(?P<pk>\S+)/$', views.InvestigationPolofficerVersionUpdateView.as_view(), name='casemgmt_investigationpolofficerversion_update'),
)

urlpatterns += (
    # urls for InvestigationVersion
    url(r'^casemgmt/investigationversion/$', views.InvestigationVersionListView.as_view(), name='casemgmt_investigationversion_list'),
    url(r'^casemgmt/investigationversion/create/$', views.InvestigationVersionCreateView.as_view(), name='casemgmt_investigationversion_create'),
    url(r'^casemgmt/investigationversion/detail/(?P<pk>\S+)/$', views.InvestigationVersionDetailView.as_view(), name='casemgmt_investigationversion_detail'),
    url(r'^casemgmt/investigationversion/update/(?P<pk>\S+)/$', views.InvestigationVersionUpdateView.as_view(), name='casemgmt_investigationversion_update'),
)

urlpatterns += (
    # urls for InvestigationWitness
    url(r'^casemgmt/investigationwitness/$', views.InvestigationWitnessListView.as_view(), name='casemgmt_investigationwitness_list'),
    url(r'^casemgmt/investigationwitness/create/$', views.InvestigationWitnessCreateView.as_view(), name='casemgmt_investigationwitness_create'),
    url(r'^casemgmt/investigationwitness/detail/(?P<pk>\S+)/$', views.InvestigationWitnessDetailView.as_view(), name='casemgmt_investigationwitness_detail'),
    url(r'^casemgmt/investigationwitness/update/(?P<pk>\S+)/$', views.InvestigationWitnessUpdateView.as_view(), name='casemgmt_investigationwitness_update'),
)

urlpatterns += (
    # urls for InvestigationWitnessVersion
    url(r'^casemgmt/investigationwitnessversion/$', views.InvestigationWitnessVersionListView.as_view(), name='casemgmt_investigationwitnessversion_list'),
    url(r'^casemgmt/investigationwitnessversion/create/$', views.InvestigationWitnessVersionCreateView.as_view(), name='casemgmt_investigationwitnessversion_create'),
    url(r'^casemgmt/investigationwitnessversion/detail/(?P<pk>\S+)/$', views.InvestigationWitnessVersionDetailView.as_view(), name='casemgmt_investigationwitnessversion_detail'),
    url(r'^casemgmt/investigationwitnessversion/update/(?P<pk>\S+)/$', views.InvestigationWitnessVersionUpdateView.as_view(), name='casemgmt_investigationwitnessversion_update'),
)

urlpatterns += (
    # urls for JoRank
    url(r'^casemgmt/jorank/$', views.JoRankListView.as_view(), name='casemgmt_jorank_list'),
    url(r'^casemgmt/jorank/create/$', views.JoRankCreateView.as_view(), name='casemgmt_jorank_create'),
    url(r'^casemgmt/jorank/detail/(?P<pk>\S+)/$', views.JoRankDetailView.as_view(), name='casemgmt_jorank_detail'),
    url(r'^casemgmt/jorank/update/(?P<pk>\S+)/$', views.JoRankUpdateView.as_view(), name='casemgmt_jorank_update'),
)

urlpatterns += (
    # urls for JoRankVersion
    url(r'^casemgmt/jorankversion/$', views.JoRankVersionListView.as_view(), name='casemgmt_jorankversion_list'),
    url(r'^casemgmt/jorankversion/create/$', views.JoRankVersionCreateView.as_view(), name='casemgmt_jorankversion_create'),
    url(r'^casemgmt/jorankversion/detail/(?P<pk>\S+)/$', views.JoRankVersionDetailView.as_view(), name='casemgmt_jorankversion_detail'),
    url(r'^casemgmt/jorankversion/update/(?P<pk>\S+)/$', views.JoRankVersionUpdateView.as_view(), name='casemgmt_jorankversion_update'),
)

urlpatterns += (
    # urls for Judicialofficer
    url(r'^casemgmt/judicialofficer/$', views.JudicialofficerListView.as_view(), name='casemgmt_judicialofficer_list'),
    url(r'^casemgmt/judicialofficer/create/$', views.JudicialofficerCreateView.as_view(), name='casemgmt_judicialofficer_create'),
    url(r'^casemgmt/judicialofficer/detail/(?P<pk>\S+)/$', views.JudicialofficerDetailView.as_view(), name='casemgmt_judicialofficer_detail'),
    url(r'^casemgmt/judicialofficer/update/(?P<pk>\S+)/$', views.JudicialofficerUpdateView.as_view(), name='casemgmt_judicialofficer_update'),
)

urlpatterns += (
    # urls for JudicialofficerVersion
    url(r'^casemgmt/judicialofficerversion/$', views.JudicialofficerVersionListView.as_view(), name='casemgmt_judicialofficerversion_list'),
    url(r'^casemgmt/judicialofficerversion/create/$', views.JudicialofficerVersionCreateView.as_view(), name='casemgmt_judicialofficerversion_create'),
    url(r'^casemgmt/judicialofficerversion/detail/(?P<pk>\S+)/$', views.JudicialofficerVersionDetailView.as_view(), name='casemgmt_judicialofficerversion_detail'),
    url(r'^casemgmt/judicialofficerversion/update/(?P<pk>\S+)/$', views.JudicialofficerVersionUpdateView.as_view(), name='casemgmt_judicialofficerversion_update'),
)

urlpatterns += (
    # urls for Lawfirm
    url(r'^casemgmt/lawfirm/$', views.LawfirmListView.as_view(), name='casemgmt_lawfirm_list'),
    url(r'^casemgmt/lawfirm/create/$', views.LawfirmCreateView.as_view(), name='casemgmt_lawfirm_create'),
    url(r'^casemgmt/lawfirm/detail/(?P<pk>\S+)/$', views.LawfirmDetailView.as_view(), name='casemgmt_lawfirm_detail'),
    url(r'^casemgmt/lawfirm/update/(?P<pk>\S+)/$', views.LawfirmUpdateView.as_view(), name='casemgmt_lawfirm_update'),
)

urlpatterns += (
    # urls for LawfirmVersion
    url(r'^casemgmt/lawfirmversion/$', views.LawfirmVersionListView.as_view(), name='casemgmt_lawfirmversion_list'),
    url(r'^casemgmt/lawfirmversion/create/$', views.LawfirmVersionCreateView.as_view(), name='casemgmt_lawfirmversion_create'),
    url(r'^casemgmt/lawfirmversion/detail/(?P<pk>\S+)/$', views.LawfirmVersionDetailView.as_view(), name='casemgmt_lawfirmversion_detail'),
    url(r'^casemgmt/lawfirmversion/update/(?P<pk>\S+)/$', views.LawfirmVersionUpdateView.as_view(), name='casemgmt_lawfirmversion_update'),
)

urlpatterns += (
    # urls for Lawyers
    url(r'^casemgmt/lawyers/$', views.LawyersListView.as_view(), name='casemgmt_lawyers_list'),
    url(r'^casemgmt/lawyers/create/$', views.LawyersCreateView.as_view(), name='casemgmt_lawyers_create'),
    url(r'^casemgmt/lawyers/detail/(?P<pk>\S+)/$', views.LawyersDetailView.as_view(), name='casemgmt_lawyers_detail'),
    url(r'^casemgmt/lawyers/update/(?P<pk>\S+)/$', views.LawyersUpdateView.as_view(), name='casemgmt_lawyers_update'),
)

urlpatterns += (
    # urls for LawyersVersion
    url(r'^casemgmt/lawyersversion/$', views.LawyersVersionListView.as_view(), name='casemgmt_lawyersversion_list'),
    url(r'^casemgmt/lawyersversion/create/$', views.LawyersVersionCreateView.as_view(), name='casemgmt_lawyersversion_create'),
    url(r'^casemgmt/lawyersversion/detail/(?P<pk>\S+)/$', views.LawyersVersionDetailView.as_view(), name='casemgmt_lawyersversion_detail'),
    url(r'^casemgmt/lawyersversion/update/(?P<pk>\S+)/$', views.LawyersVersionUpdateView.as_view(), name='casemgmt_lawyersversion_update'),
)

urlpatterns += (
    # urls for Medevent
    url(r'^casemgmt/medevent/$', views.MedeventListView.as_view(), name='casemgmt_medevent_list'),
    url(r'^casemgmt/medevent/create/$', views.MedeventCreateView.as_view(), name='casemgmt_medevent_create'),
    url(r'^casemgmt/medevent/detail/(?P<pk>\S+)/$', views.MedeventDetailView.as_view(), name='casemgmt_medevent_detail'),
    url(r'^casemgmt/medevent/update/(?P<pk>\S+)/$', views.MedeventUpdateView.as_view(), name='casemgmt_medevent_update'),
)

urlpatterns += (
    # urls for MedeventVersion
    url(r'^casemgmt/medeventversion/$', views.MedeventVersionListView.as_view(), name='casemgmt_medeventversion_list'),
    url(r'^casemgmt/medeventversion/create/$', views.MedeventVersionCreateView.as_view(), name='casemgmt_medeventversion_create'),
    url(r'^casemgmt/medeventversion/detail/(?P<pk>\S+)/$', views.MedeventVersionDetailView.as_view(), name='casemgmt_medeventversion_detail'),
    url(r'^casemgmt/medeventversion/update/(?P<pk>\S+)/$', views.MedeventVersionUpdateView.as_view(), name='casemgmt_medeventversion_update'),
)

urlpatterns += (
    # urls for Natureofsuit
    url(r'^casemgmt/natureofsuit/$', views.NatureofsuitListView.as_view(), name='casemgmt_natureofsuit_list'),
    url(r'^casemgmt/natureofsuit/create/$', views.NatureofsuitCreateView.as_view(), name='casemgmt_natureofsuit_create'),
    url(r'^casemgmt/natureofsuit/detail/(?P<pk>\S+)/$', views.NatureofsuitDetailView.as_view(), name='casemgmt_natureofsuit_detail'),
    url(r'^casemgmt/natureofsuit/update/(?P<pk>\S+)/$', views.NatureofsuitUpdateView.as_view(), name='casemgmt_natureofsuit_update'),
)

urlpatterns += (
    # urls for NatureofsuitVersion
    url(r'^casemgmt/natureofsuitversion/$', views.NatureofsuitVersionListView.as_view(), name='casemgmt_natureofsuitversion_list'),
    url(r'^casemgmt/natureofsuitversion/create/$', views.NatureofsuitVersionCreateView.as_view(), name='casemgmt_natureofsuitversion_create'),
    url(r'^casemgmt/natureofsuitversion/detail/(?P<pk>\S+)/$', views.NatureofsuitVersionDetailView.as_view(), name='casemgmt_natureofsuitversion_detail'),
    url(r'^casemgmt/natureofsuitversion/update/(?P<pk>\S+)/$', views.NatureofsuitVersionUpdateView.as_view(), name='casemgmt_natureofsuitversion_update'),
)

urlpatterns += (
    # urls for Payment
    url(r'^casemgmt/payment/$', views.PaymentListView.as_view(), name='casemgmt_payment_list'),
    url(r'^casemgmt/payment/create/$', views.PaymentCreateView.as_view(), name='casemgmt_payment_create'),
    url(r'^casemgmt/payment/detail/(?P<pk>\S+)/$', views.PaymentDetailView.as_view(), name='casemgmt_payment_detail'),
    url(r'^casemgmt/payment/update/(?P<pk>\S+)/$', views.PaymentUpdateView.as_view(), name='casemgmt_payment_update'),
)

urlpatterns += (
    # urls for PaymentVersion
    url(r'^casemgmt/paymentversion/$', views.PaymentVersionListView.as_view(), name='casemgmt_paymentversion_list'),
    url(r'^casemgmt/paymentversion/create/$', views.PaymentVersionCreateView.as_view(), name='casemgmt_paymentversion_create'),
    url(r'^casemgmt/paymentversion/detail/(?P<pk>\S+)/$', views.PaymentVersionDetailView.as_view(), name='casemgmt_paymentversion_detail'),
    url(r'^casemgmt/paymentversion/update/(?P<pk>\S+)/$', views.PaymentVersionUpdateView.as_view(), name='casemgmt_paymentversion_update'),
)

urlpatterns += (
    # urls for Paymentmethod
    url(r'^casemgmt/paymentmethod/$', views.PaymentmethodListView.as_view(), name='casemgmt_paymentmethod_list'),
    url(r'^casemgmt/paymentmethod/create/$', views.PaymentmethodCreateView.as_view(), name='casemgmt_paymentmethod_create'),
    url(r'^casemgmt/paymentmethod/detail/(?P<pk>\S+)/$', views.PaymentmethodDetailView.as_view(), name='casemgmt_paymentmethod_detail'),
    url(r'^casemgmt/paymentmethod/update/(?P<pk>\S+)/$', views.PaymentmethodUpdateView.as_view(), name='casemgmt_paymentmethod_update'),
)

urlpatterns += (
    # urls for PaymentmethodVersion
    url(r'^casemgmt/paymentmethodversion/$', views.PaymentmethodVersionListView.as_view(), name='casemgmt_paymentmethodversion_list'),
    url(r'^casemgmt/paymentmethodversion/create/$', views.PaymentmethodVersionCreateView.as_view(), name='casemgmt_paymentmethodversion_create'),
    url(r'^casemgmt/paymentmethodversion/detail/(?P<pk>\S+)/$', views.PaymentmethodVersionDetailView.as_view(), name='casemgmt_paymentmethodversion_detail'),
    url(r'^casemgmt/paymentmethodversion/update/(?P<pk>\S+)/$', views.PaymentmethodVersionUpdateView.as_view(), name='casemgmt_paymentmethodversion_update'),
)

urlpatterns += (
    # urls for Plaintiff
    url(r'^casemgmt/plaintiff/$', views.PlaintiffListView.as_view(), name='casemgmt_plaintiff_list'),
    url(r'^casemgmt/plaintiff/create/$', views.PlaintiffCreateView.as_view(), name='casemgmt_plaintiff_create'),
    url(r'^casemgmt/plaintiff/detail/(?P<pk>\S+)/$', views.PlaintiffDetailView.as_view(), name='casemgmt_plaintiff_detail'),
    url(r'^casemgmt/plaintiff/update/(?P<pk>\S+)/$', views.PlaintiffUpdateView.as_view(), name='casemgmt_plaintiff_update'),
)

urlpatterns += (
    # urls for PlaintiffVersion
    url(r'^casemgmt/plaintiffversion/$', views.PlaintiffVersionListView.as_view(), name='casemgmt_plaintiffversion_list'),
    url(r'^casemgmt/plaintiffversion/create/$', views.PlaintiffVersionCreateView.as_view(), name='casemgmt_plaintiffversion_create'),
    url(r'^casemgmt/plaintiffversion/detail/(?P<pk>\S+)/$', views.PlaintiffVersionDetailView.as_view(), name='casemgmt_plaintiffversion_detail'),
    url(r'^casemgmt/plaintiffversion/update/(?P<pk>\S+)/$', views.PlaintiffVersionUpdateView.as_view(), name='casemgmt_plaintiffversion_update'),
)

urlpatterns += (
    # urls for Policerank
    url(r'^casemgmt/policerank/$', views.PolicerankListView.as_view(), name='casemgmt_policerank_list'),
    url(r'^casemgmt/policerank/create/$', views.PolicerankCreateView.as_view(), name='casemgmt_policerank_create'),
    url(r'^casemgmt/policerank/detail/(?P<pk>\S+)/$', views.PolicerankDetailView.as_view(), name='casemgmt_policerank_detail'),
    url(r'^casemgmt/policerank/update/(?P<pk>\S+)/$', views.PolicerankUpdateView.as_view(), name='casemgmt_policerank_update'),
)

urlpatterns += (
    # urls for PolicerankVersion
    url(r'^casemgmt/policerankversion/$', views.PolicerankVersionListView.as_view(), name='casemgmt_policerankversion_list'),
    url(r'^casemgmt/policerankversion/create/$', views.PolicerankVersionCreateView.as_view(), name='casemgmt_policerankversion_create'),
    url(r'^casemgmt/policerankversion/detail/(?P<pk>\S+)/$', views.PolicerankVersionDetailView.as_view(), name='casemgmt_policerankversion_detail'),
    url(r'^casemgmt/policerankversion/update/(?P<pk>\S+)/$', views.PolicerankVersionUpdateView.as_view(), name='casemgmt_policerankversion_update'),
)

urlpatterns += (
    # urls for Policerole
    url(r'^casemgmt/policerole/$', views.PoliceroleListView.as_view(), name='casemgmt_policerole_list'),
    url(r'^casemgmt/policerole/create/$', views.PoliceroleCreateView.as_view(), name='casemgmt_policerole_create'),
    url(r'^casemgmt/policerole/detail/(?P<pk>\S+)/$', views.PoliceroleDetailView.as_view(), name='casemgmt_policerole_detail'),
    url(r'^casemgmt/policerole/update/(?P<pk>\S+)/$', views.PoliceroleUpdateView.as_view(), name='casemgmt_policerole_update'),
)

urlpatterns += (
    # urls for PoliceroleVersion
    url(r'^casemgmt/policeroleversion/$', views.PoliceroleVersionListView.as_view(), name='casemgmt_policeroleversion_list'),
    url(r'^casemgmt/policeroleversion/create/$', views.PoliceroleVersionCreateView.as_view(), name='casemgmt_policeroleversion_create'),
    url(r'^casemgmt/policeroleversion/detail/(?P<pk>\S+)/$', views.PoliceroleVersionDetailView.as_view(), name='casemgmt_policeroleversion_detail'),
    url(r'^casemgmt/policeroleversion/update/(?P<pk>\S+)/$', views.PoliceroleVersionUpdateView.as_view(), name='casemgmt_policeroleversion_update'),
)

urlpatterns += (
    # urls for Policestation
    url(r'^casemgmt/policestation/$', views.PolicestationListView.as_view(), name='casemgmt_policestation_list'),
    url(r'^casemgmt/policestation/create/$', views.PolicestationCreateView.as_view(), name='casemgmt_policestation_create'),
    url(r'^casemgmt/policestation/detail/(?P<pk>\S+)/$', views.PolicestationDetailView.as_view(), name='casemgmt_policestation_detail'),
    url(r'^casemgmt/policestation/update/(?P<pk>\S+)/$', views.PolicestationUpdateView.as_view(), name='casemgmt_policestation_update'),
)

urlpatterns += (
    # urls for PolicestationVersion
    url(r'^casemgmt/policestationversion/$', views.PolicestationVersionListView.as_view(), name='casemgmt_policestationversion_list'),
    url(r'^casemgmt/policestationversion/create/$', views.PolicestationVersionCreateView.as_view(), name='casemgmt_policestationversion_create'),
    url(r'^casemgmt/policestationversion/detail/(?P<pk>\S+)/$', views.PolicestationVersionDetailView.as_view(), name='casemgmt_policestationversion_detail'),
    url(r'^casemgmt/policestationversion/update/(?P<pk>\S+)/$', views.PolicestationVersionUpdateView.as_view(), name='casemgmt_policestationversion_update'),
)

urlpatterns += (
    # urls for Policestationtype
    url(r'^casemgmt/policestationtype/$', views.PolicestationtypeListView.as_view(), name='casemgmt_policestationtype_list'),
    url(r'^casemgmt/policestationtype/create/$', views.PolicestationtypeCreateView.as_view(), name='casemgmt_policestationtype_create'),
    url(r'^casemgmt/policestationtype/detail/(?P<pk>\S+)/$', views.PolicestationtypeDetailView.as_view(), name='casemgmt_policestationtype_detail'),
    url(r'^casemgmt/policestationtype/update/(?P<pk>\S+)/$', views.PolicestationtypeUpdateView.as_view(), name='casemgmt_policestationtype_update'),
)

urlpatterns += (
    # urls for PolicestationtypeVersion
    url(r'^casemgmt/policestationtypeversion/$', views.PolicestationtypeVersionListView.as_view(), name='casemgmt_policestationtypeversion_list'),
    url(r'^casemgmt/policestationtypeversion/create/$', views.PolicestationtypeVersionCreateView.as_view(), name='casemgmt_policestationtypeversion_create'),
    url(r'^casemgmt/policestationtypeversion/detail/(?P<pk>\S+)/$', views.PolicestationtypeVersionDetailView.as_view(), name='casemgmt_policestationtypeversion_detail'),
    url(r'^casemgmt/policestationtypeversion/update/(?P<pk>\S+)/$', views.PolicestationtypeVersionUpdateView.as_view(), name='casemgmt_policestationtypeversion_update'),
)

urlpatterns += (
    # urls for Polofficer
    url(r'^casemgmt/polofficer/$', views.PolofficerListView.as_view(), name='casemgmt_polofficer_list'),
    url(r'^casemgmt/polofficer/create/$', views.PolofficerCreateView.as_view(), name='casemgmt_polofficer_create'),
    url(r'^casemgmt/polofficer/detail/(?P<pk>\S+)/$', views.PolofficerDetailView.as_view(), name='casemgmt_polofficer_detail'),
    url(r'^casemgmt/polofficer/update/(?P<pk>\S+)/$', views.PolofficerUpdateView.as_view(), name='casemgmt_polofficer_update'),
)

urlpatterns += (
    # urls for PolofficerPolicerole
    url(r'^casemgmt/polofficerpolicerole/$', views.PolofficerPoliceroleListView.as_view(), name='casemgmt_polofficerpolicerole_list'),
    url(r'^casemgmt/polofficerpolicerole/create/$', views.PolofficerPoliceroleCreateView.as_view(), name='casemgmt_polofficerpolicerole_create'),
    url(r'^casemgmt/polofficerpolicerole/detail/(?P<pk>\S+)/$', views.PolofficerPoliceroleDetailView.as_view(), name='casemgmt_polofficerpolicerole_detail'),
    url(r'^casemgmt/polofficerpolicerole/update/(?P<pk>\S+)/$', views.PolofficerPoliceroleUpdateView.as_view(), name='casemgmt_polofficerpolicerole_update'),
)

urlpatterns += (
    # urls for PolofficerPoliceroleVersion
    url(r'^casemgmt/polofficerpoliceroleversion/$', views.PolofficerPoliceroleVersionListView.as_view(), name='casemgmt_polofficerpoliceroleversion_list'),
    url(r'^casemgmt/polofficerpoliceroleversion/create/$', views.PolofficerPoliceroleVersionCreateView.as_view(), name='casemgmt_polofficerpoliceroleversion_create'),
    url(r'^casemgmt/polofficerpoliceroleversion/detail/(?P<pk>\S+)/$', views.PolofficerPoliceroleVersionDetailView.as_view(), name='casemgmt_polofficerpoliceroleversion_detail'),
    url(r'^casemgmt/polofficerpoliceroleversion/update/(?P<pk>\S+)/$', views.PolofficerPoliceroleVersionUpdateView.as_view(), name='casemgmt_polofficerpoliceroleversion_update'),
)

urlpatterns += (
    # urls for PolofficerVersion
    url(r'^casemgmt/polofficerversion/$', views.PolofficerVersionListView.as_view(), name='casemgmt_polofficerversion_list'),
    url(r'^casemgmt/polofficerversion/create/$', views.PolofficerVersionCreateView.as_view(), name='casemgmt_polofficerversion_create'),
    url(r'^casemgmt/polofficerversion/detail/(?P<pk>\S+)/$', views.PolofficerVersionDetailView.as_view(), name='casemgmt_polofficerversion_detail'),
    url(r'^casemgmt/polofficerversion/update/(?P<pk>\S+)/$', views.PolofficerVersionUpdateView.as_view(), name='casemgmt_polofficerversion_update'),
)

urlpatterns += (
    # urls for Prison
    url(r'^casemgmt/prison/$', views.PrisonListView.as_view(), name='casemgmt_prison_list'),
    url(r'^casemgmt/prison/create/$', views.PrisonCreateView.as_view(), name='casemgmt_prison_create'),
    url(r'^casemgmt/prison/detail/(?P<pk>\S+)/$', views.PrisonDetailView.as_view(), name='casemgmt_prison_detail'),
    url(r'^casemgmt/prison/update/(?P<pk>\S+)/$', views.PrisonUpdateView.as_view(), name='casemgmt_prison_update'),
)

urlpatterns += (
    # urls for PrisonSecurityrank
    url(r'^casemgmt/prisonsecurityrank/$', views.PrisonSecurityrankListView.as_view(), name='casemgmt_prisonsecurityrank_list'),
    url(r'^casemgmt/prisonsecurityrank/create/$', views.PrisonSecurityrankCreateView.as_view(), name='casemgmt_prisonsecurityrank_create'),
    url(r'^casemgmt/prisonsecurityrank/detail/(?P<pk>\S+)/$', views.PrisonSecurityrankDetailView.as_view(), name='casemgmt_prisonsecurityrank_detail'),
    url(r'^casemgmt/prisonsecurityrank/update/(?P<pk>\S+)/$', views.PrisonSecurityrankUpdateView.as_view(), name='casemgmt_prisonsecurityrank_update'),
)

urlpatterns += (
    # urls for PrisonSecurityrankVersion
    url(r'^casemgmt/prisonsecurityrankversion/$', views.PrisonSecurityrankVersionListView.as_view(), name='casemgmt_prisonsecurityrankversion_list'),
    url(r'^casemgmt/prisonsecurityrankversion/create/$', views.PrisonSecurityrankVersionCreateView.as_view(), name='casemgmt_prisonsecurityrankversion_create'),
    url(r'^casemgmt/prisonsecurityrankversion/detail/(?P<pk>\S+)/$', views.PrisonSecurityrankVersionDetailView.as_view(), name='casemgmt_prisonsecurityrankversion_detail'),
    url(r'^casemgmt/prisonsecurityrankversion/update/(?P<pk>\S+)/$', views.PrisonSecurityrankVersionUpdateView.as_view(), name='casemgmt_prisonsecurityrankversion_update'),
)

urlpatterns += (
    # urls for PrisonVersion
    url(r'^casemgmt/prisonversion/$', views.PrisonVersionListView.as_view(), name='casemgmt_prisonversion_list'),
    url(r'^casemgmt/prisonversion/create/$', views.PrisonVersionCreateView.as_view(), name='casemgmt_prisonversion_create'),
    url(r'^casemgmt/prisonversion/detail/(?P<pk>\S+)/$', views.PrisonVersionDetailView.as_view(), name='casemgmt_prisonversion_detail'),
    url(r'^casemgmt/prisonversion/update/(?P<pk>\S+)/$', views.PrisonVersionUpdateView.as_view(), name='casemgmt_prisonversion_update'),
)

urlpatterns += (
    # urls for Prisoncell
    url(r'^casemgmt/prisoncell/$', views.PrisoncellListView.as_view(), name='casemgmt_prisoncell_list'),
    url(r'^casemgmt/prisoncell/create/$', views.PrisoncellCreateView.as_view(), name='casemgmt_prisoncell_create'),
    url(r'^casemgmt/prisoncell/detail/(?P<pk>\S+)/$', views.PrisoncellDetailView.as_view(), name='casemgmt_prisoncell_detail'),
    url(r'^casemgmt/prisoncell/update/(?P<pk>\S+)/$', views.PrisoncellUpdateView.as_view(), name='casemgmt_prisoncell_update'),
)

urlpatterns += (
    # urls for PrisoncellVersion
    url(r'^casemgmt/prisoncellversion/$', views.PrisoncellVersionListView.as_view(), name='casemgmt_prisoncellversion_list'),
    url(r'^casemgmt/prisoncellversion/create/$', views.PrisoncellVersionCreateView.as_view(), name='casemgmt_prisoncellversion_create'),
    url(r'^casemgmt/prisoncellversion/detail/(?P<pk>\S+)/$', views.PrisoncellVersionDetailView.as_view(), name='casemgmt_prisoncellversion_detail'),
    url(r'^casemgmt/prisoncellversion/update/(?P<pk>\S+)/$', views.PrisoncellVersionUpdateView.as_view(), name='casemgmt_prisoncellversion_update'),
)

urlpatterns += (
    # urls for Prisoncommital
    url(r'^casemgmt/prisoncommital/$', views.PrisoncommitalListView.as_view(), name='casemgmt_prisoncommital_list'),
    url(r'^casemgmt/prisoncommital/create/$', views.PrisoncommitalCreateView.as_view(), name='casemgmt_prisoncommital_create'),
    url(r'^casemgmt/prisoncommital/detail/(?P<pk>\S+)/$', views.PrisoncommitalDetailView.as_view(), name='casemgmt_prisoncommital_detail'),
    url(r'^casemgmt/prisoncommital/update/(?P<pk>\S+)/$', views.PrisoncommitalUpdateView.as_view(), name='casemgmt_prisoncommital_update'),
)

urlpatterns += (
    # urls for PrisoncommitalVersion
    url(r'^casemgmt/prisoncommitalversion/$', views.PrisoncommitalVersionListView.as_view(), name='casemgmt_prisoncommitalversion_list'),
    url(r'^casemgmt/prisoncommitalversion/create/$', views.PrisoncommitalVersionCreateView.as_view(), name='casemgmt_prisoncommitalversion_create'),
    url(r'^casemgmt/prisoncommitalversion/detail/(?P<pk>\S+)/$', views.PrisoncommitalVersionDetailView.as_view(), name='casemgmt_prisoncommitalversion_detail'),
    url(r'^casemgmt/prisoncommitalversion/update/(?P<pk>\S+)/$', views.PrisoncommitalVersionUpdateView.as_view(), name='casemgmt_prisoncommitalversion_update'),
)

urlpatterns += (
    # urls for PrisoncommitalWarder
    url(r'^casemgmt/prisoncommitalwarder/$', views.PrisoncommitalWarderListView.as_view(), name='casemgmt_prisoncommitalwarder_list'),
    url(r'^casemgmt/prisoncommitalwarder/create/$', views.PrisoncommitalWarderCreateView.as_view(), name='casemgmt_prisoncommitalwarder_create'),
    url(r'^casemgmt/prisoncommitalwarder/detail/(?P<pk>\S+)/$', views.PrisoncommitalWarderDetailView.as_view(), name='casemgmt_prisoncommitalwarder_detail'),
    url(r'^casemgmt/prisoncommitalwarder/update/(?P<pk>\S+)/$', views.PrisoncommitalWarderUpdateView.as_view(), name='casemgmt_prisoncommitalwarder_update'),
)

urlpatterns += (
    # urls for PrisoncommitalWarderVersion
    url(r'^casemgmt/prisoncommitalwarderversion/$', views.PrisoncommitalWarderVersionListView.as_view(), name='casemgmt_prisoncommitalwarderversion_list'),
    url(r'^casemgmt/prisoncommitalwarderversion/create/$', views.PrisoncommitalWarderVersionCreateView.as_view(), name='casemgmt_prisoncommitalwarderversion_create'),
    url(r'^casemgmt/prisoncommitalwarderversion/detail/(?P<pk>\S+)/$', views.PrisoncommitalWarderVersionDetailView.as_view(), name='casemgmt_prisoncommitalwarderversion_detail'),
    url(r'^casemgmt/prisoncommitalwarderversion/update/(?P<pk>\S+)/$', views.PrisoncommitalWarderVersionUpdateView.as_view(), name='casemgmt_prisoncommitalwarderversion_update'),
)

urlpatterns += (
    # urls for Prisonerproperty
    url(r'^casemgmt/prisonerproperty/$', views.PrisonerpropertyListView.as_view(), name='casemgmt_prisonerproperty_list'),
    url(r'^casemgmt/prisonerproperty/create/$', views.PrisonerpropertyCreateView.as_view(), name='casemgmt_prisonerproperty_create'),
    url(r'^casemgmt/prisonerproperty/detail/(?P<pk>\S+)/$', views.PrisonerpropertyDetailView.as_view(), name='casemgmt_prisonerproperty_detail'),
    url(r'^casemgmt/prisonerproperty/update/(?P<pk>\S+)/$', views.PrisonerpropertyUpdateView.as_view(), name='casemgmt_prisonerproperty_update'),
)

urlpatterns += (
    # urls for PrisonerpropertyVersion
    url(r'^casemgmt/prisonerpropertyversion/$', views.PrisonerpropertyVersionListView.as_view(), name='casemgmt_prisonerpropertyversion_list'),
    url(r'^casemgmt/prisonerpropertyversion/create/$', views.PrisonerpropertyVersionCreateView.as_view(), name='casemgmt_prisonerpropertyversion_create'),
    url(r'^casemgmt/prisonerpropertyversion/detail/(?P<pk>\S+)/$', views.PrisonerpropertyVersionDetailView.as_view(), name='casemgmt_prisonerpropertyversion_detail'),
    url(r'^casemgmt/prisonerpropertyversion/update/(?P<pk>\S+)/$', views.PrisonerpropertyVersionUpdateView.as_view(), name='casemgmt_prisonerpropertyversion_update'),
)

urlpatterns += (
    # urls for Prosecutor
    url(r'^casemgmt/prosecutor/$', views.ProsecutorListView.as_view(), name='casemgmt_prosecutor_list'),
    url(r'^casemgmt/prosecutor/create/$', views.ProsecutorCreateView.as_view(), name='casemgmt_prosecutor_create'),
    url(r'^casemgmt/prosecutor/detail/(?P<pk>\S+)/$', views.ProsecutorDetailView.as_view(), name='casemgmt_prosecutor_detail'),
    url(r'^casemgmt/prosecutor/update/(?P<pk>\S+)/$', views.ProsecutorUpdateView.as_view(), name='casemgmt_prosecutor_update'),
)

urlpatterns += (
    # urls for ProsecutorProsecutorteam
    url(r'^casemgmt/prosecutorprosecutorteam/$', views.ProsecutorProsecutorteamListView.as_view(), name='casemgmt_prosecutorprosecutorteam_list'),
    url(r'^casemgmt/prosecutorprosecutorteam/create/$', views.ProsecutorProsecutorteamCreateView.as_view(), name='casemgmt_prosecutorprosecutorteam_create'),
    url(r'^casemgmt/prosecutorprosecutorteam/detail/(?P<pk>\S+)/$', views.ProsecutorProsecutorteamDetailView.as_view(), name='casemgmt_prosecutorprosecutorteam_detail'),
    url(r'^casemgmt/prosecutorprosecutorteam/update/(?P<pk>\S+)/$', views.ProsecutorProsecutorteamUpdateView.as_view(), name='casemgmt_prosecutorprosecutorteam_update'),
)

urlpatterns += (
    # urls for ProsecutorProsecutorteamVersion
    url(r'^casemgmt/prosecutorprosecutorteamversion/$', views.ProsecutorProsecutorteamVersionListView.as_view(), name='casemgmt_prosecutorprosecutorteamversion_list'),
    url(r'^casemgmt/prosecutorprosecutorteamversion/create/$', views.ProsecutorProsecutorteamVersionCreateView.as_view(), name='casemgmt_prosecutorprosecutorteamversion_create'),
    url(r'^casemgmt/prosecutorprosecutorteamversion/detail/(?P<pk>\S+)/$', views.ProsecutorProsecutorteamVersionDetailView.as_view(), name='casemgmt_prosecutorprosecutorteamversion_detail'),
    url(r'^casemgmt/prosecutorprosecutorteamversion/update/(?P<pk>\S+)/$', views.ProsecutorProsecutorteamVersionUpdateView.as_view(), name='casemgmt_prosecutorprosecutorteamversion_update'),
)

urlpatterns += (
    # urls for ProsecutorVersion
    url(r'^casemgmt/prosecutorversion/$', views.ProsecutorVersionListView.as_view(), name='casemgmt_prosecutorversion_list'),
    url(r'^casemgmt/prosecutorversion/create/$', views.ProsecutorVersionCreateView.as_view(), name='casemgmt_prosecutorversion_create'),
    url(r'^casemgmt/prosecutorversion/detail/(?P<pk>\S+)/$', views.ProsecutorVersionDetailView.as_view(), name='casemgmt_prosecutorversion_detail'),
    url(r'^casemgmt/prosecutorversion/update/(?P<pk>\S+)/$', views.ProsecutorVersionUpdateView.as_view(), name='casemgmt_prosecutorversion_update'),
)

urlpatterns += (
    # urls for Prosecutorteam
    url(r'^casemgmt/prosecutorteam/$', views.ProsecutorteamListView.as_view(), name='casemgmt_prosecutorteam_list'),
    url(r'^casemgmt/prosecutorteam/create/$', views.ProsecutorteamCreateView.as_view(), name='casemgmt_prosecutorteam_create'),
    url(r'^casemgmt/prosecutorteam/detail/(?P<pk>\S+)/$', views.ProsecutorteamDetailView.as_view(), name='casemgmt_prosecutorteam_detail'),
    url(r'^casemgmt/prosecutorteam/update/(?P<pk>\S+)/$', views.ProsecutorteamUpdateView.as_view(), name='casemgmt_prosecutorteam_update'),
)

urlpatterns += (
    # urls for ProsecutorteamVersion
    url(r'^casemgmt/prosecutorteamversion/$', views.ProsecutorteamVersionListView.as_view(), name='casemgmt_prosecutorteamversion_list'),
    url(r'^casemgmt/prosecutorteamversion/create/$', views.ProsecutorteamVersionCreateView.as_view(), name='casemgmt_prosecutorteamversion_create'),
    url(r'^casemgmt/prosecutorteamversion/detail/(?P<pk>\S+)/$', views.ProsecutorteamVersionDetailView.as_view(), name='casemgmt_prosecutorteamversion_detail'),
    url(r'^casemgmt/prosecutorteamversion/update/(?P<pk>\S+)/$', views.ProsecutorteamVersionUpdateView.as_view(), name='casemgmt_prosecutorteamversion_update'),
)

urlpatterns += (
    # urls for Remission
    url(r'^casemgmt/remission/$', views.RemissionListView.as_view(), name='casemgmt_remission_list'),
    url(r'^casemgmt/remission/create/$', views.RemissionCreateView.as_view(), name='casemgmt_remission_create'),
    url(r'^casemgmt/remission/detail/(?P<pk>\S+)/$', views.RemissionDetailView.as_view(), name='casemgmt_remission_detail'),
    url(r'^casemgmt/remission/update/(?P<pk>\S+)/$', views.RemissionUpdateView.as_view(), name='casemgmt_remission_update'),
)

urlpatterns += (
    # urls for RemissionVersion
    url(r'^casemgmt/remissionversion/$', views.RemissionVersionListView.as_view(), name='casemgmt_remissionversion_list'),
    url(r'^casemgmt/remissionversion/create/$', views.RemissionVersionCreateView.as_view(), name='casemgmt_remissionversion_create'),
    url(r'^casemgmt/remissionversion/detail/(?P<pk>\S+)/$', views.RemissionVersionDetailView.as_view(), name='casemgmt_remissionversion_detail'),
    url(r'^casemgmt/remissionversion/update/(?P<pk>\S+)/$', views.RemissionVersionUpdateView.as_view(), name='casemgmt_remissionversion_update'),
)

urlpatterns += (
    # urls for Securityrank
    url(r'^casemgmt/securityrank/$', views.SecurityrankListView.as_view(), name='casemgmt_securityrank_list'),
    url(r'^casemgmt/securityrank/create/$', views.SecurityrankCreateView.as_view(), name='casemgmt_securityrank_create'),
    url(r'^casemgmt/securityrank/detail/(?P<pk>\S+)/$', views.SecurityrankDetailView.as_view(), name='casemgmt_securityrank_detail'),
    url(r'^casemgmt/securityrank/update/(?P<pk>\S+)/$', views.SecurityrankUpdateView.as_view(), name='casemgmt_securityrank_update'),
)

urlpatterns += (
    # urls for SecurityrankVersion
    url(r'^casemgmt/securityrankversion/$', views.SecurityrankVersionListView.as_view(), name='casemgmt_securityrankversion_list'),
    url(r'^casemgmt/securityrankversion/create/$', views.SecurityrankVersionCreateView.as_view(), name='casemgmt_securityrankversion_create'),
    url(r'^casemgmt/securityrankversion/detail/(?P<pk>\S+)/$', views.SecurityrankVersionDetailView.as_view(), name='casemgmt_securityrankversion_detail'),
    url(r'^casemgmt/securityrankversion/update/(?P<pk>\S+)/$', views.SecurityrankVersionUpdateView.as_view(), name='casemgmt_securityrankversion_update'),
)

urlpatterns += (
    # urls for Subcounty
    url(r'^casemgmt/subcounty/$', views.SubcountyListView.as_view(), name='casemgmt_subcounty_list'),
    url(r'^casemgmt/subcounty/create/$', views.SubcountyCreateView.as_view(), name='casemgmt_subcounty_create'),
    url(r'^casemgmt/subcounty/detail/(?P<pk>\S+)/$', views.SubcountyDetailView.as_view(), name='casemgmt_subcounty_detail'),
    url(r'^casemgmt/subcounty/update/(?P<pk>\S+)/$', views.SubcountyUpdateView.as_view(), name='casemgmt_subcounty_update'),
)

urlpatterns += (
    # urls for SubcountyVersion
    url(r'^casemgmt/subcountyversion/$', views.SubcountyVersionListView.as_view(), name='casemgmt_subcountyversion_list'),
    url(r'^casemgmt/subcountyversion/create/$', views.SubcountyVersionCreateView.as_view(), name='casemgmt_subcountyversion_create'),
    url(r'^casemgmt/subcountyversion/detail/(?P<pk>\S+)/$', views.SubcountyVersionDetailView.as_view(), name='casemgmt_subcountyversion_detail'),
    url(r'^casemgmt/subcountyversion/update/(?P<pk>\S+)/$', views.SubcountyVersionUpdateView.as_view(), name='casemgmt_subcountyversion_update'),
)

urlpatterns += (
    # urls for Surety
    url(r'^casemgmt/surety/$', views.SuretyListView.as_view(), name='casemgmt_surety_list'),
    url(r'^casemgmt/surety/create/$', views.SuretyCreateView.as_view(), name='casemgmt_surety_create'),
    url(r'^casemgmt/surety/detail/(?P<pk>\S+)/$', views.SuretyDetailView.as_view(), name='casemgmt_surety_detail'),
    url(r'^casemgmt/surety/update/(?P<pk>\S+)/$', views.SuretyUpdateView.as_view(), name='casemgmt_surety_update'),
)

urlpatterns += (
    # urls for SuretyVersion
    url(r'^casemgmt/suretyversion/$', views.SuretyVersionListView.as_view(), name='casemgmt_suretyversion_list'),
    url(r'^casemgmt/suretyversion/create/$', views.SuretyVersionCreateView.as_view(), name='casemgmt_suretyversion_create'),
    url(r'^casemgmt/suretyversion/detail/(?P<pk>\S+)/$', views.SuretyVersionDetailView.as_view(), name='casemgmt_suretyversion_detail'),
    url(r'^casemgmt/suretyversion/update/(?P<pk>\S+)/$', views.SuretyVersionUpdateView.as_view(), name='casemgmt_suretyversion_update'),
)

urlpatterns += (
    # urls for Tag
    url(r'^casemgmt/tag/$', views.TagListView.as_view(), name='casemgmt_tag_list'),
    url(r'^casemgmt/tag/create/$', views.TagCreateView.as_view(), name='casemgmt_tag_create'),
    url(r'^casemgmt/tag/detail/(?P<pk>\S+)/$', views.TagDetailView.as_view(), name='casemgmt_tag_detail'),
    url(r'^casemgmt/tag/update/(?P<pk>\S+)/$', views.TagUpdateView.as_view(), name='casemgmt_tag_update'),
)

urlpatterns += (
    # urls for TagVersion
    url(r'^casemgmt/tagversion/$', views.TagVersionListView.as_view(), name='casemgmt_tagversion_list'),
    url(r'^casemgmt/tagversion/create/$', views.TagVersionCreateView.as_view(), name='casemgmt_tagversion_create'),
    url(r'^casemgmt/tagversion/detail/(?P<pk>\S+)/$', views.TagVersionDetailView.as_view(), name='casemgmt_tagversion_detail'),
    url(r'^casemgmt/tagversion/update/(?P<pk>\S+)/$', views.TagVersionUpdateView.as_view(), name='casemgmt_tagversion_update'),
)

urlpatterns += (
    # urls for Town
    url(r'^casemgmt/town/$', views.TownListView.as_view(), name='casemgmt_town_list'),
    url(r'^casemgmt/town/create/$', views.TownCreateView.as_view(), name='casemgmt_town_create'),
    url(r'^casemgmt/town/detail/(?P<pk>\S+)/$', views.TownDetailView.as_view(), name='casemgmt_town_detail'),
    url(r'^casemgmt/town/update/(?P<pk>\S+)/$', views.TownUpdateView.as_view(), name='casemgmt_town_update'),
)

urlpatterns += (
    # urls for TownVersion
    url(r'^casemgmt/townversion/$', views.TownVersionListView.as_view(), name='casemgmt_townversion_list'),
    url(r'^casemgmt/townversion/create/$', views.TownVersionCreateView.as_view(), name='casemgmt_townversion_create'),
    url(r'^casemgmt/townversion/detail/(?P<pk>\S+)/$', views.TownVersionDetailView.as_view(), name='casemgmt_townversion_detail'),
    url(r'^casemgmt/townversion/update/(?P<pk>\S+)/$', views.TownVersionUpdateView.as_view(), name='casemgmt_townversion_update'),
)

urlpatterns += (
    # urls for Transaction
    url(r'^casemgmt/transaction/$', views.TransactionListView.as_view(), name='casemgmt_transaction_list'),
    url(r'^casemgmt/transaction/create/$', views.TransactionCreateView.as_view(), name='casemgmt_transaction_create'),
    url(r'^casemgmt/transaction/detail/(?P<pk>\S+)/$', views.TransactionDetailView.as_view(), name='casemgmt_transaction_detail'),
    url(r'^casemgmt/transaction/update/(?P<pk>\S+)/$', views.TransactionUpdateView.as_view(), name='casemgmt_transaction_update'),
)

urlpatterns += (
    # urls for Visit
    url(r'^casemgmt/visit/$', views.VisitListView.as_view(), name='casemgmt_visit_list'),
    url(r'^casemgmt/visit/create/$', views.VisitCreateView.as_view(), name='casemgmt_visit_create'),
    url(r'^casemgmt/visit/detail/(?P<pk>\S+)/$', views.VisitDetailView.as_view(), name='casemgmt_visit_detail'),
    url(r'^casemgmt/visit/update/(?P<pk>\S+)/$', views.VisitUpdateView.as_view(), name='casemgmt_visit_update'),
)

urlpatterns += (
    # urls for VisitVersion
    url(r'^casemgmt/visitversion/$', views.VisitVersionListView.as_view(), name='casemgmt_visitversion_list'),
    url(r'^casemgmt/visitversion/create/$', views.VisitVersionCreateView.as_view(), name='casemgmt_visitversion_create'),
    url(r'^casemgmt/visitversion/detail/(?P<pk>\S+)/$', views.VisitVersionDetailView.as_view(), name='casemgmt_visitversion_detail'),
    url(r'^casemgmt/visitversion/update/(?P<pk>\S+)/$', views.VisitVersionUpdateView.as_view(), name='casemgmt_visitversion_update'),
)

urlpatterns += (
    # urls for Visitor
    url(r'^casemgmt/visitor/$', views.VisitorListView.as_view(), name='casemgmt_visitor_list'),
    url(r'^casemgmt/visitor/create/$', views.VisitorCreateView.as_view(), name='casemgmt_visitor_create'),
    url(r'^casemgmt/visitor/detail/(?P<pk>\S+)/$', views.VisitorDetailView.as_view(), name='casemgmt_visitor_detail'),
    url(r'^casemgmt/visitor/update/(?P<pk>\S+)/$', views.VisitorUpdateView.as_view(), name='casemgmt_visitor_update'),
)

urlpatterns += (
    # urls for VisitorVersion
    url(r'^casemgmt/visitorversion/$', views.VisitorVersionListView.as_view(), name='casemgmt_visitorversion_list'),
    url(r'^casemgmt/visitorversion/create/$', views.VisitorVersionCreateView.as_view(), name='casemgmt_visitorversion_create'),
    url(r'^casemgmt/visitorversion/detail/(?P<pk>\S+)/$', views.VisitorVersionDetailView.as_view(), name='casemgmt_visitorversion_detail'),
    url(r'^casemgmt/visitorversion/update/(?P<pk>\S+)/$', views.VisitorVersionUpdateView.as_view(), name='casemgmt_visitorversion_update'),
)

urlpatterns += (
    # urls for Warder
    url(r'^casemgmt/warder/$', views.WarderListView.as_view(), name='casemgmt_warder_list'),
    url(r'^casemgmt/warder/create/$', views.WarderCreateView.as_view(), name='casemgmt_warder_create'),
    url(r'^casemgmt/warder/detail/(?P<pk>\S+)/$', views.WarderDetailView.as_view(), name='casemgmt_warder_detail'),
    url(r'^casemgmt/warder/update/(?P<pk>\S+)/$', views.WarderUpdateView.as_view(), name='casemgmt_warder_update'),
)

urlpatterns += (
    # urls for WarderVersion
    url(r'^casemgmt/warderversion/$', views.WarderVersionListView.as_view(), name='casemgmt_warderversion_list'),
    url(r'^casemgmt/warderversion/create/$', views.WarderVersionCreateView.as_view(), name='casemgmt_warderversion_create'),
    url(r'^casemgmt/warderversion/detail/(?P<pk>\S+)/$', views.WarderVersionDetailView.as_view(), name='casemgmt_warderversion_detail'),
    url(r'^casemgmt/warderversion/update/(?P<pk>\S+)/$', views.WarderVersionUpdateView.as_view(), name='casemgmt_warderversion_update'),
)

urlpatterns += (
    # urls for Warderrank
    url(r'^casemgmt/warderrank/$', views.WarderrankListView.as_view(), name='casemgmt_warderrank_list'),
    url(r'^casemgmt/warderrank/create/$', views.WarderrankCreateView.as_view(), name='casemgmt_warderrank_create'),
    url(r'^casemgmt/warderrank/detail/(?P<pk>\S+)/$', views.WarderrankDetailView.as_view(), name='casemgmt_warderrank_detail'),
    url(r'^casemgmt/warderrank/update/(?P<pk>\S+)/$', views.WarderrankUpdateView.as_view(), name='casemgmt_warderrank_update'),
)

urlpatterns += (
    # urls for WarderrankVersion
    url(r'^casemgmt/warderrankversion/$', views.WarderrankVersionListView.as_view(), name='casemgmt_warderrankversion_list'),
    url(r'^casemgmt/warderrankversion/create/$', views.WarderrankVersionCreateView.as_view(), name='casemgmt_warderrankversion_create'),
    url(r'^casemgmt/warderrankversion/detail/(?P<pk>\S+)/$', views.WarderrankVersionDetailView.as_view(), name='casemgmt_warderrankversion_detail'),
    url(r'^casemgmt/warderrankversion/update/(?P<pk>\S+)/$', views.WarderrankVersionUpdateView.as_view(), name='casemgmt_warderrankversion_update'),
)

urlpatterns += (
    # urls for Witness
    url(r'^casemgmt/witness/$', views.WitnessListView.as_view(), name='casemgmt_witness_list'),
    url(r'^casemgmt/witness/create/$', views.WitnessCreateView.as_view(), name='casemgmt_witness_create'),
    url(r'^casemgmt/witness/detail/(?P<pk>\S+)/$', views.WitnessDetailView.as_view(), name='casemgmt_witness_detail'),
    url(r'^casemgmt/witness/update/(?P<pk>\S+)/$', views.WitnessUpdateView.as_view(), name='casemgmt_witness_update'),
)

urlpatterns += (
    # urls for WitnessVersion
    url(r'^casemgmt/witnessversion/$', views.WitnessVersionListView.as_view(), name='casemgmt_witnessversion_list'),
    url(r'^casemgmt/witnessversion/create/$', views.WitnessVersionCreateView.as_view(), name='casemgmt_witnessversion_create'),
    url(r'^casemgmt/witnessversion/detail/(?P<pk>\S+)/$', views.WitnessVersionDetailView.as_view(), name='casemgmt_witnessversion_detail'),
    url(r'^casemgmt/witnessversion/update/(?P<pk>\S+)/$', views.WitnessVersionUpdateView.as_view(), name='casemgmt_witnessversion_update'),
)

