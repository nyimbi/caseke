-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2017 at 12:08 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `case_id` int(11) NOT NULL,
  `number` varchar(20) NOT NULL,
  `case_category_id` int(11) DEFAULT NULL,
  `number_on_file` varchar(100) NOT NULL,
  `citation` varchar(255) NOT NULL,
  `case_status_id` int(11) NOT NULL,
  `filing_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text,
  `filed_by` int(11) UNSIGNED DEFAULT NULL,
  `is_appeal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`case_id`, `number`, `case_category_id`, `number_on_file`, `citation`, `case_status_id`, `filing_date`, `description`, `filed_by`, `is_appeal`) VALUES
(1, 'MSACA/0001/2017', NULL, 'HC.CR.C./10/2017', 'Philip Ayaya Vs Nuclear Investment', 2, '2017-02-09 13:05:28', NULL, 1, 2),
(2, 'NYRIC/0123/2016', NULL, 'HC.CR.C./12/2017', 'Peter Mburu Vs George Gatimu Mungai', 2, '2017-02-09 13:06:28', NULL, 1, NULL),
(3, 'KIRMC/1617/2015', NULL, 'HC.CR.C./15/2017', 'Jane Wanjiku Vs The Ag', 3, '2017-02-09 13:07:12', NULL, 1, 6),
(4, 'KGDMC/0014/2015', NULL, 'SCPT/12/2017', 'Emmily Mwende Vs Ventures Holdings Limited', 2, '2017-02-09 13:09:50', NULL, 1, NULL),
(5, 'MNDMC/0003/2017', NULL, 'SCApplc./2/2017', 'Shaista Yasmin nur-UI-Haq', 4, '2017-02-09 13:12:45', NULL, 1, 11),
(6, 'MKNMC/0027/2017', NULL, 'SCAO.RF/10/2017', 'Mbithi Peter Mutuku Vs Council of Legal Education & 2 Others', 2, '2017-02-09 13:13:57', NULL, 1, NULL),
(7, 'NKRHC/234/2017', NULL, 'HC.CR.C./234/2017', 'tezsrdtryfghnilug    vs   hshdtykumio', 1, '2017-02-22 00:00:00', 'rgthyfvjgmtyctc \r\nrresthdfg \r\nrtfh gb', 1, NULL),
(8, 'NKRHC/178/2017', NULL, 'HC.CR.C./78/2017', '23323454323443234', 1, '2017-02-22 00:00:00', '34432123443212343234432344', 1, NULL),
(11, 'NKRHC/78/2017', NULL, 'HC.F.A/78/2017', 'zcxvzcxvzcxv', 1, '2017-02-22 00:00:00', 'zxcvzcxvzxcvv', 1, 3),
(12, 'NKRHC/110/2017', NULL, 'HC.CR.C./110/2017', 'test vs test', 1, '2017-02-07 00:00:00', 'asdsad', 1, NULL),
(13, 'NKRHC/233/2017', NULL, 'HC.CR.C./233/2017', '222', 1, '2017-02-21 00:00:00', '22', 1, NULL),
(14, 'NKRHC/34567/2017', NULL, 'HC.F.A/34567/2017', 'rtyuioui', 1, '2017-02-27 00:00:00', 'tyuiu', 1, NULL),
(15, 'NKRHC/132/2017', NULL, 'HC.CR.C./132/2017', 'Test vs Test', 1, '2017-02-28 00:00:00', 'Test', 1, NULL),
(16, 'NKRHC/124/2017', NULL, 'HC.CR.C./124/2017', 'Test vs Test', 1, '2017-02-22 00:00:00', 'Test', 1, NULL),
(17, 'NKRHC/123/2017', NULL, 'HC.COMM. MISC.NO./123/2017', 'dfgsdfg', 1, '2017-03-27 00:00:00', 'sdfgdsfg', 1, NULL),
(19, 'NKRHC/654/2017', NULL, 'HC.BC/654/2017', 'regds', 1, '2017-02-21 00:00:00', 'rtrewt', 1, NULL),
(21, 'NKRHC/2343/2017', NULL, 'HCCC/2343/2017', 'fddfgds', 1, '2017-02-22 00:00:00', 'dsfgdsg', 1, 7),
(22, 'NKRHC/333/2017', NULL, 'HC.F.A Misc/333/2017', '4356', 1, '2017-02-22 00:00:00', '436435 654', 1, NULL),
(24, 'NKRHC/23433/2017', NULL, 'HC.F.A/23433/2017', 'wert', 1, '2017-02-21 00:00:00', 'wertwet', 1, NULL),
(28, 'NKRHC/2343444/2017', NULL, 'HC.F.A/2343444/2017', 'ewqrqe', 1, '2017-02-21 00:00:00', 'wqerer', 1, NULL),
(29, 'NKRHC/453/2017', NULL, 'HC.F.A/453/2017', 'wasfdf', 1, '2017-02-22 00:00:00', 'asdf', 1, NULL),
(30, 'NKRHC/455/2017', NULL, 'HC.CR.C./455/2017', '456', 1, '2017-02-22 00:00:00', '232c 4q ', 1, 6),
(31, 'NKRHC/1000/2017', NULL, 'HC.CR.C./1000/2017', 'chelule vs test', 1, '2017-02-21 00:00:00', 'types - Check whether variable is number or string in javascript - Stack ...\r\nstackoverflow.com/questions/.../check-whether-variable-is-number-or-string-in-javasc...\r\nAug 20, 2009 - If you\'re dealing with literal notation, and not constructors, you can use typeof:. ... Check whether variable is number or string in javascript.', 1, NULL),
(32, 'MDUMC/1003/2017', NULL, 'HC.CR.C./1003/2017', 'fddg gfh fgh ', 1, '2017-02-13 00:00:00', 'fdhfh fgh ', 1, 4),
(33, 'NKRHC/12345/2017', NULL, 'HC.CR.C./12345/2017', '12 VS VS', 1, '2017-01-02 00:00:00', '124DS SDF DA ASD', NULL, NULL),
(34, 'NKRHC/1232435/2017', NULL, 'HC.CR.C./1232435/2017', 'DASF', 1, '2017-02-23 00:00:00', 'SADF', NULL, NULL),
(35, 'NKRHC/10/2017', NULL, 'HC.COMM./10/2017', 'cba Vs kcb', 1, '2017-02-23 00:00:00', 'Money laundering', NULL, NULL),
(36, 'MILCC/1234/2017', NULL, 'HC.COMM./1234/2017', 'Test vs test', 1, '2017-02-23 00:00:00', 'I have select2 customized via css with its general classes and ids.\r\n\r\nNow, I\'m trying to customize a specific class that will be provided to select2 and then apply in css to it.\r\n\r\nMy issue: is NOT the select per say but the drop of it ( the div with the class select2-drop ) that is appended to the body, how can i access that one?\r\n\r\nI\'ve already tried:', NULL, NULL),
(37, 'MILCC/004/2017', NULL, 'HC.COMM./004/2017', 'asdfasdfs', 1, '2017-02-20 00:00:00', 'asdfasdf', NULL, NULL),
(39, 'MILCC/003/2017', NULL, 'HC.COMM./003/2017', 'asdfasdfs', 1, '2017-02-20 00:00:00', 'asdfasdf', NULL, NULL),
(40, 'MILCC/0004/2017', NULL, 'HC.COMM./0004/2017', 'asdfasdfs', 1, '2017-02-20 00:00:00', 'asdfasdf', NULL, NULL),
(41, 'MILCC/123/2017', NULL, 'HC.COMM./123/2017', 'asdfasdfs', 1, '2017-02-20 00:00:00', 'asdfasdf', NULL, NULL),
(42, 'MILCC/4537/2017', NULL, 'HC.COMM./4537/2017', 'chelule Maina vs Benson', 1, '2017-02-23 00:00:00', 'Case Details and Information about the suit', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cases2parties`
--

CREATE TABLE `cases2parties` (
  `id` tinyint(4) NOT NULL,
  `case_id` int(11) NOT NULL,
  `case_party_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cases2parties`
--

INSERT INTO `cases2parties` (`id`, `case_id`, `case_party_id`) VALUES
(1, 3, 2),
(2, 12, 3),
(3, 42, 4);

-- --------------------------------------------------------

--
-- Table structure for table `case_activities`
--

CREATE TABLE `case_activities` (
  `case_activity_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `outcome_id` int(11) DEFAULT NULL,
  `activity_date` datetime NOT NULL,
  `court_room` varchar(20) NOT NULL,
  `entered_by` int(11) UNSIGNED DEFAULT NULL,
  `remarks` mediumtext,
  `date_entered` datetime DEFAULT CURRENT_TIMESTAMP,
  `next_activity_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `next_activity_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_activities`
--

INSERT INTO `case_activities` (`case_activity_id`, `case_id`, `activity_id`, `outcome_id`, `activity_date`, `court_room`, `entered_by`, `remarks`, `date_entered`, `next_activity_date`, `next_activity_id`) VALUES
(1, 3, 1, 2, '2017-02-05 21:08:35', 'RM 407', 2, 'I hereby approve the case to proceed for gazettement', '2017-02-13 21:09:46', '2017-02-22 12:33:36', NULL),
(2, 6, 5, 3, '2017-02-14 21:37:26', 'RM 26', 1, 'This case was heard and will be dismissed if no much evidence is provided', '2017-02-13 21:38:22', '2017-02-22 12:53:55', NULL),
(3, 4, 8, 4, '2017-02-25 17:02:40', 'RM 36', 3, 'This case came for mention today', '2017-02-14 17:03:27', '2017-02-22 12:33:28', NULL),
(4, 14, 2, NULL, '2017-01-31 00:00:00', 'room34', 1, 'tesr', '2017-02-22 02:02:41', NULL, NULL),
(5, 14, 3, NULL, '2017-02-26 00:00:00', 'rroom 2', 1, 'vbxcvbcvb', '2017-02-22 03:02:23', '2017-02-22 12:32:58', NULL),
(7, 14, 7, NULL, '2017-02-24 00:00:00', 'room3', 1, 'Test', '2017-02-22 03:02:56', '2017-02-22 12:32:55', NULL),
(20, 12, 4, NULL, '2017-01-02 00:00:00', 'RM402', 1, 'Tst', '2017-02-22 11:02:11', '2017-02-23 11:09:36', NULL),
(21, 12, 2, NULL, '2017-02-22 11:32:17', 'RM002', 1, '2', '2017-02-22 11:32:44', '2017-02-22 12:34:43', NULL),
(22, 12, 2, NULL, '2017-02-04 11:32:17', 'RM003', 1, '2', '2017-02-22 11:33:05', '2017-02-22 12:32:37', NULL),
(23, 12, 2, NULL, '2017-02-01 11:32:17', 'RM004', 1, '2', '2017-02-22 11:33:09', '2017-02-22 12:31:31', NULL),
(24, 12, 2, NULL, '2017-02-12 11:32:17', 'RM005', 1, '2', '2017-02-22 11:33:12', '2017-02-22 12:31:33', NULL),
(25, 12, 2, NULL, '2017-02-20 11:32:17', 'RM006', 1, '2', '2017-02-22 11:33:14', '2017-02-22 12:31:37', NULL),
(26, 12, 2, NULL, '2017-02-16 12:33:39', 'RM007', 1, '2', '2017-02-22 11:33:17', '2017-02-22 12:33:48', NULL),
(27, 12, 2, NULL, '2017-02-10 11:32:17', 'RM008', 1, '2', '2017-02-22 11:33:19', '2017-02-22 12:34:40', NULL),
(28, 12, 2, NULL, '2017-02-02 11:32:17', 'RM009', 1, '2', '2017-02-22 11:33:22', '2017-02-22 12:32:18', NULL),
(29, 31, 3, 3, '2017-02-21 00:00:00', 'RM004', 1, 'To sent to the Kenya gazzete', '2017-02-22 04:02:44', '2017-02-15 10:48:05', NULL),
(30, 32, 9, 3, '2017-02-23 10:46:47', 'Chambers 3', 2, 'Was not an adjournment', '2017-02-23 10:47:52', '2017-02-23 10:47:41', NULL),
(31, 40, 46, NULL, '2017-02-23 03:02:30', '', 8, NULL, '2017-02-23 03:02:30', NULL, NULL),
(32, 40, 47, NULL, '2017-02-23 03:02:42', '', 8, 'Case Registered online', '2017-02-23 03:02:42', '2017-02-24 08:53:03', NULL),
(33, 40, 48, NULL, '2017-02-23 03:02:20', '', 8, 'Case Pending Screening for mediation option', '2017-02-23 03:02:20', '2017-02-24 08:53:05', NULL),
(34, 40, 49, NULL, '2017-02-23 04:02:38', '', 8, 'Mention', '2017-02-23 04:02:38', '2017-02-24 08:53:07', NULL),
(35, 42, 50, NULL, '2017-02-23 04:02:13', '', 8, 'Hearing', '2017-02-23 04:02:13', '2017-02-24 08:53:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `case_categories`
--

CREATE TABLE `case_categories` (
  `category_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_categories`
--

INSERT INTO `case_categories` (`category_id`, `division_id`, `name`, `description`) VALUES
(1, 1, 'HC.CR.C.', 'High Court Criminal Case '),
(2, 1, 'HC.MISC.CR.APPL', 'High Court Criminal Miscellaneous Application '),
(3, 1, 'HC.CR.A.', 'High Court Criminal Appeal '),
(4, 1, 'HC.CR.REV', 'High Court Criminal Revision '),
(5, 2, 'HC.COMM', 'High Court Commercial - Commercial Matters'),
(6, 2, 'HC.COMM. MISC', 'High Court Commercial - Miscellaneous '),
(7, 2, 'HC.WC', 'High Court Commercial - Winding Up Cause '),
(8, 2, 'HC.ITA', 'High Court Commercial - Income Tax Appeal  Commercial '),
(9, 2, 'HC.BC', 'High Court Commercial - Bankruptcy Cause '),
(10, 2, 'HC.BN', 'High Court Commercial - Bankruptcy Notice '),
(11, 3, 'HCCC', 'High Court Civil Case '),
(12, 3, 'HCCC Misc.', 'High Court Civil Case Miscellaneous '),
(13, 3, 'HCCA', 'High Court Civil Appeal '),
(14, 4, 'HC.F.A', 'High Court Family - Appeals '),
(15, 4, 'HC.F.A Misc', 'High Court Family - Miscellaneous Application'),
(16, 4, 'HC.PA', 'High Court Family - Probate And Administration '),
(17, 4, 'HC.D.C', 'High Court Family - Divorce  Case'),
(18, 4, 'HC.ADOP', 'High Court Family - Adoption '),
(19, 4, 'HC.MP', 'High Court Family - Matrimonial Property'),
(20, 1, 'HC.J.R', 'High Court Judicial Review '),
(21, 1, 'HC.J.R Misc', 'High Court Judicial Review Miscellaneous '),
(22, 1, 'HC.J.R ELC', 'High Court Judicial Review Environment and Land Case '),
(23, 1, 'HC.PET', 'High Court Petitions'),
(24, 2, 'HCCA', 'High Court Commercial - Commercial Appeal'),
(25, 2, 'HC.IC', 'High Court Commercial - Insolvency Cause'),
(26, 2, 'HC.IP', 'High Court Commercial - Insolvency Petition'),
(27, 2, 'HC.NP', 'High Court Commercial - Insolvency Notice '),
(28, 2, 'HC.INP', 'High Court Commercial - Insolvency Notice Petiton');

-- --------------------------------------------------------

--
-- Table structure for table `case_outcomes`
--

CREATE TABLE `case_outcomes` (
  `outcome_id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `court_rank_id` int(11) DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_outcomes`
--

INSERT INTO `case_outcomes` (`outcome_id`, `description`, `court_rank_id`, `action_id`) VALUES
(1, 'Adjournment', 1, NULL),
(2, 'Application heard', 1, NULL),
(3, 'Case Registered/Filed', 1, NULL),
(4, 'Consent filed in the registry', 1, NULL),
(5, 'Certified urgent', 1, NULL),
(6, 'Not certified urgent', 1, NULL),
(7, 'Consent recorded - case closed', 1, NULL),
(8, 'Consolidated', 1, NULL),
(9, 'Consolidated- case closed', 1, NULL),
(10, 'Directions given', 1, NULL),
(11, 'File transferred', 1, NULL),
(12, 'Hearing date set (in court)', 1, NULL),
(13, 'Out of court settlement reached ', 1, NULL),
(14, 'Mention date set (in court)', 1, NULL),
(15, 'Judgment date given', 1, NULL),
(16, 'Judgment delivered- acquittal', 1, NULL),
(17, 'Judgment delivered- case closed', 1, NULL),
(18, 'Judgment delivered- convicted', 1, NULL),
(19, 'Judgment on notice', 1, NULL),
(20, 'Matter referred for arbitration/mediation', 1, NULL),
(21, 'Ruling date given', 1, NULL),
(22, 'Ruling delivered', 1, NULL),
(23, 'Ruling delivered- case closed', 1, NULL),
(24, 'Ruling on notice', 1, NULL),
(25, 'Written submissions filed', 1, NULL),
(26, 'Oral submissions made', 1, NULL),
(27, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 1, NULL),
(29, 'Other (specify in details of case)', 1, NULL),
(30, 'Adjournment', 2, NULL),
(31, 'Application heard', 2, NULL),
(32, 'Case Registered/Filed', 2, NULL),
(33, 'Consent filed in the registry', 2, NULL),
(34, 'Certified urgent', 2, NULL),
(35, 'Not certified urgent', 2, NULL),
(36, 'Consent recorded - case closed', 2, NULL),
(37, 'Consolidated', 2, NULL),
(38, 'Consolidated- case closed', 2, NULL),
(39, 'Directions given', 2, NULL),
(40, 'File transferred', 2, NULL),
(41, 'Hearing date set (in court)', 2, NULL),
(42, 'Out of court settlement reached ', 2, NULL),
(43, 'Mention date set (in court)', 2, NULL),
(44, 'Judgment date given', 2, NULL),
(45, 'Judgment delivered- acquittal', 2, NULL),
(46, 'Judgment delivered- case closed', 2, NULL),
(47, 'Judgment delivered- convicted', 2, NULL),
(48, 'Judgment on notice', 2, NULL),
(49, 'Matter referred for arbitration/mediation', 2, NULL),
(50, 'Ruling date given', 2, NULL),
(51, 'Ruling delivered', 2, NULL),
(52, 'Ruling delivered- case closed', 2, NULL),
(53, 'Ruling on notice', 2, NULL),
(54, 'Written submissions filed', 2, NULL),
(55, 'Oral submissions made', 2, NULL),
(56, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 2, NULL),
(57, 'Other (specify in details of case)', 2, NULL),
(58, 'Adjournment', 3, NULL),
(59, 'Application heard', 3, NULL),
(60, 'Case Registered/Filed', 3, NULL),
(61, 'Consent filed in the registry', 3, NULL),
(62, 'Certified urgent', 3, NULL),
(63, 'Not certified urgent', 3, NULL),
(64, 'Consent recorded - case closed', 3, NULL),
(65, 'Consolidated', 3, NULL),
(66, 'Consolidated- case closed', 3, NULL),
(67, 'Directions given', 3, NULL),
(68, 'File transferred', 3, NULL),
(69, 'Grant issued', 3, NULL),
(70, 'Grant revoked', 3, NULL),
(71, 'Grant confirmed', 3, NULL),
(72, 'Limited grant issued', 3, NULL),
(73, 'Hearing date set (in court)', 3, NULL),
(74, 'Out of court settlement reached ', 3, NULL),
(75, 'Mention date set (in court)', 3, NULL),
(76, 'Judgment date given', 3, NULL),
(77, 'Judgment delivered- acquittal', 3, NULL),
(78, 'Judgment delivered- case closed', 3, NULL),
(79, 'Judgment delivered- convicted', 3, NULL),
(80, 'Judgment on notice', 3, NULL),
(81, 'Matter referred for arbitration/mediation', 3, NULL),
(82, 'Ruling date given', 3, NULL),
(83, 'Ruling delivered', 3, NULL),
(84, 'Ruling delivered- case closed', 3, NULL),
(85, 'Ruling on notice', 3, NULL),
(86, 'Written submissions filed', 3, NULL),
(87, 'Oral submissions made', 3, NULL),
(88, 'Sentenced', 3, NULL),
(89, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 3, NULL),
(90, 'Other (specify in details of case)', 3, NULL),
(91, 'Adjournment', 4, NULL),
(92, 'Application heard', 4, NULL),
(93, 'Case Registered/Filed', 4, NULL),
(94, 'Consent filed in the registry', 4, NULL),
(95, 'Certified urgent', 4, NULL),
(96, 'Not certified urgent', 4, NULL),
(97, 'Consent recorded - case closed', 4, NULL),
(98, 'Consolidated', 4, NULL),
(99, 'Consolidated- case closed', 4, NULL),
(100, 'Directions given', 4, NULL),
(101, 'File transferred', 4, NULL),
(102, 'Hearing date set (in court)', 4, NULL),
(103, 'Out of court settlement reached ', 4, NULL),
(104, 'Mention date set (in court)', 4, NULL),
(105, 'Judgment date given', 4, NULL),
(106, 'Judgment delivered', 4, NULL),
(107, 'Judgment delivered- case closed', 4, NULL),
(108, 'Judgment on notice', 4, NULL),
(109, 'Matter referred for arbitration/mediation', 4, NULL),
(110, 'Ruling date given', 4, NULL),
(111, 'Ruling delivered', 4, NULL),
(112, 'Ruling delivered- case closed', 4, NULL),
(113, 'Ruling on notice', 4, NULL),
(114, 'Written submissions filed', 4, NULL),
(115, 'Oral submissions made', 4, NULL),
(116, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 4, NULL),
(117, 'Other (specify in details of case)', 4, NULL),
(118, 'Adjournment', 5, NULL),
(119, 'Application heard', 5, NULL),
(120, 'Case Registered/Filed', 5, NULL),
(121, 'Consent filed in the registry', 5, NULL),
(122, 'Certified urgent', 5, NULL),
(123, 'Not certified urgent', 5, NULL),
(124, 'Consent recorded - case closed', 5, NULL),
(125, 'Consolidated', 5, NULL),
(126, 'Consolidated- case closed', 5, NULL),
(127, 'Directions given', 5, NULL),
(128, 'File transferred', 5, NULL),
(129, 'Hearing date set (in court)', 5, NULL),
(130, 'Out of court settlement reached ', 5, NULL),
(131, 'Mention date set (in court)', 5, NULL),
(132, 'Judgment date given', 5, NULL),
(133, 'Judgment delivered', 5, NULL),
(134, 'Judgment delivered- case closed', 5, NULL),
(135, 'Judgment on notice', 5, NULL),
(136, 'Matter referred for arbitration/mediation', 5, NULL),
(137, 'Ruling date given', 5, NULL),
(138, 'Ruling delivered', 5, NULL),
(139, 'Ruling delivered- case closed', 5, NULL),
(140, 'Ruling on notice', 5, NULL),
(141, 'Written submissions filed', 5, NULL),
(142, 'Oral submissions made', 5, NULL),
(143, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 5, NULL),
(144, 'Other (specify in details of case)', 5, NULL),
(145, 'Adjournment', 6, NULL),
(146, 'Application heard', 6, NULL),
(147, 'Case Registered/Filed', 6, NULL),
(148, 'Consent filed in the registry', 6, NULL),
(149, 'Certified urgent', 6, NULL),
(150, 'Not certified urgent', 6, NULL),
(151, 'Consent recorded - case closed', 6, NULL),
(152, 'Consolidated', 6, NULL),
(153, 'Consolidated- case closed', 6, NULL),
(154, 'Directions given', 6, NULL),
(155, 'File transferred', 6, NULL),
(156, 'Grant issued', 6, NULL),
(157, 'Grant revoked', 6, NULL),
(158, 'Grant confirmed', 6, NULL),
(159, 'Limited grant issued', 6, NULL),
(160, 'Hearing date set (in court)', 6, NULL),
(161, 'Out of court settlement reached ', 6, NULL),
(162, 'Mention date set (in court)', 6, NULL),
(163, 'Judgment date given', 6, NULL),
(164, 'Judgment delivered- acquittal', 6, NULL),
(165, 'Judgment delivered- case closed', 6, NULL),
(166, 'Judgment delivered- convicted', 6, NULL),
(167, 'Judgment on notice', 6, NULL),
(168, 'Matter referred for arbitration/mediation', 6, NULL),
(169, 'Ruling date given', 6, NULL),
(170, 'Ruling delivered', 6, NULL),
(171, 'Ruling delivered- case closed', 6, NULL),
(172, 'Ruling on notice', 6, NULL),
(173, 'Written submissions filed', 6, NULL),
(174, 'Oral submissions made', 6, NULL),
(175, 'Sentenced', 6, NULL),
(176, 'Terminated/ struck out/ dismissed/case closed (specify in details of case)', 6, NULL),
(177, 'Other (specify in details of case)', 6, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `case_parties`
--

CREATE TABLE `case_parties` (
  `case_party_id` int(11) NOT NULL,
  `party_type_id` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `party_name` varchar(255) DEFAULT NULL,
  `nationality` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `individual_or_organization` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `uniques_id_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_parties`
--

INSERT INTO `case_parties` (`case_party_id`, `party_type_id`, `gender`, `party_name`, `nationality`, `address`, `phone`, `email`, `occupation`, `individual_or_organization`, `status`, `uniques_id_number`) VALUES
(1, 7, 'Male', '', 'Kenyan', NULL, '', '', '', NULL, 1, NULL),
(2, 1, 'Male', '', '', 'P.O. Box 278 KRT', '0700676767', '', '', NULL, 1, NULL),
(3, 2, '', 'dsfasf', '', 'sdfas', 'sdfasdf', 'asdfa', '', NULL, 1, 0),
(4, 4, 'Male', 'Chelule', 'Kenyan', '4650', '07354739', 'chelumaina@gmail.com', 'Peasant Farmer', 1, 1, 2564037);

-- --------------------------------------------------------

--
-- Table structure for table `case_party_types`
--

CREATE TABLE `case_party_types` (
  `case_party_type_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_party_types`
--

INSERT INTO `case_party_types` (`case_party_type_id`, `description`) VALUES
(1, 'Witness'),
(2, 'Respondent/Defendant'),
(3, 'Petitioner/Plaintiff'),
(4, 'Advocate'),
(5, 'Accused'),
(6, 'Probation Officer'),
(7, 'Judges'),
(8, 'Interested Parties');

-- --------------------------------------------------------

--
-- Table structure for table `case_special_murder`
--

CREATE TABLE `case_special_murder` (
  `case_murder_id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `deceased_surname` varchar(255) DEFAULT NULL,
  `deceased_othernames` varchar(255) DEFAULT NULL,
  `Death_Date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deceased_age` int(255) DEFAULT NULL,
  `deceased_gender` varchar(255) DEFAULT NULL,
  `deceased_relationship` varchar(255) DEFAULT NULL,
  `accused_gender` varchar(255) DEFAULT NULL,
  `accused_age` int(255) DEFAULT NULL,
  `investigating_forcenumber` int(11) DEFAULT NULL,
  `investigating_name` varchar(255) DEFAULT NULL,
  `charges` text,
  `odpp_statement` text,
  `witness_statement` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_special_murder`
--

INSERT INTO `case_special_murder` (`case_murder_id`, `case_id`, `deceased_surname`, `deceased_othernames`, `Death_Date`, `deceased_age`, `deceased_gender`, `deceased_relationship`, `accused_gender`, `accused_age`, `investigating_forcenumber`, `investigating_name`, `charges`, `odpp_statement`, `witness_statement`) VALUES
(1, 7, '34567', 'rtyuiogbhv yh', '2017-02-22 00:00:00', 4567, 'Male', 'Brother', 'Male', 454, 4567, 'wret gb  tdghhv jg fhgvb kg tcv\r\nrtsgd ujf cfhgf hfyhj\r\njdfugun\r\ng y', NULL, 'trhgfhghyrtxstdhjghvgcsdrft\r\nrgthfghvb k\r\nhttrci f\r\nxtrgthchgv ', 'weesgxdgcfj \r\nrdfcyu \r\nthjhfgbn '),
(2, 33, '342', '2134', '2017-02-21 00:00:00', 2314, 'Male', 'Brother', 'Male', 23, 12, '12', NULL, '12', '12');

-- --------------------------------------------------------

--
-- Table structure for table `case_status`
--

CREATE TABLE `case_status` (
  `case_status_id` int(11) NOT NULL,
  `case_status_desc` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_status`
--

INSERT INTO `case_status` (`case_status_id`, `case_status_desc`) VALUES
(1, 'Active'),
(2, 'Closed'),
(3, 'Archived'),
(4, 'Disposed');

-- --------------------------------------------------------

--
-- Table structure for table `case_types`
--

CREATE TABLE `case_types` (
  `case_type_id` int(11) NOT NULL,
  `case_category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `case_types`
--

INSERT INTO `case_types` (`case_type_id`, `case_category_id`, `name`) VALUES
(1, 1, 'Murder Case'),
(2, 3, 'Criminal Apeal'),
(3, 4, 'Criminal Revision'),
(4, 2, 'Misc. Applications in Criminal Matters'),
(5, 16, 'Probate and Administration'),
(6, 17, 'Divorce');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('6ac4f2c6d28e36b91e984905ea56738808d99db7', '127.0.0.1', 1487934628, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373932373131373b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2237663838633035613332376434336266316633333635343664326432376134373135656233393066223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('de5a430cae6c41c3fa5dfc54bcf700c2cf435067', '127.0.0.1', 1487924489, ''),
('0ad056a560fa80d086927005d1d3941cabc5bee5', '127.0.0.1', 1487926244, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373932353031383b6d6573736167657c733a36343a223c7020636c6173733d227374617475735f6d7367223e596f752068617665206265656e207375636365737366756c6c79206c6f67676564206f75742e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d),
('885e68005d1cbd5fd3fc06bc8958a53b7cc031a9', '127.0.0.1', 1487927112, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373932363234373b6d6573736167657c733a36343a223c7020636c6173733d227374617475735f6d7367223e596f752068617665206265656e207375636365737366756c6c79206c6f67676564206f75742e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d),
('f385b61641938d83598cec71e39a4e0ff41e84b3', '127.0.0.1', 1487924999, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373932343233333b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2262663839356666346365393836343165326237343137303462343561333830323632613539623137223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('3d7a8913c92ec796e8c51f6b1bd87518e99ab51e', '127.0.0.1', 1487924223, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931393935393b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2262663839356666346365393836343165326237343137303462343561333830323632613539623137223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('f3f71f9ac5a0da2e8c244351da7e14e8aa1e9d5f', '127.0.0.1', 1487919916, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931393632393b6d6573736167657c733a36343a223c7020636c6173733d227374617475735f6d7367223e596f752068617665206265656e207375636365737366756c6c79206c6f67676564206f75742e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d),
('61622e52e717ce0904e0c3d07cd9962ec10228df', '127.0.0.1', 1487924233, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373932343233333b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2262663839356666346365393836343165326237343137303462343561333830323632613539623137223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('f29080c84b9cf00335f2d31df4ef5e02c6cb664f', '127.0.0.1', 1487919363, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931393238303b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('4f2009e399808299114aa4728eeb20586ab1ce1e', '127.0.0.1', 1487918726, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931383639303b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('a2e16f03a4ce491dd7e596588f24831571c9f0c7', '127.0.0.1', 1487918618, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931383230353b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('6471f7f943bf2842e7ef7c11d5b674f0c9ee518f', '127.0.0.1', 1487918194, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373931343530353b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('551aba931e519e5aecf337b9cc6260890a2143b9', '127.0.0.1', 1487909788, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930393439303b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('93dde544eea019971cbd17e2f8712950e3646481', '127.0.0.1', 1487909451, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930393137323b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('d71f0f43b03a5a0ca52a00f74fc45771cf718725', '127.0.0.1', 1487909169, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930383836343b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('6d185dca8d2f85785e27ad2cb2492cdce9447984', '127.0.0.1', 1487908864, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930383836343b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('59786a17967958c310d0a43e2e7386685fbdd2e9', '127.0.0.1', 1487908861, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930383438303b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('c48245deb3a62d5916f220f16b5adb7a99b0ecc0', '127.0.0.1', 1487908468, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930383131333b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('127755cb80400a5e808a6697e0643ea85f9b7d2d', '127.0.0.1', 1487907969, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373930373738363b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2236663934383830356233636463616238306333333433306464396334313765613362336161623966223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('737db82ec88094bdc6ad30ca451255c516cda9a2', '127.0.0.1', 1487883411, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373838333135383b6d6573736167657c733a36343a223c7020636c6173733d227374617475735f6d7367223e596f752068617665206265656e207375636365737366756c6c79206c6f67676564206f75742e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d),
('275bb73cc7db77540b5b560d06ff4012f12c6dfb', '127.0.0.1', 1487883128, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373838323834323b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('0f3c76059f902f8fb62f732a03a089ce981354f8', '127.0.0.1', 1487882714, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373838323532373b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('14568d477247abc05193ce9d808210bda7be0353', '127.0.0.1', 1487882512, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373838323131373b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('179b7885f4e1de9db13802912207f641fb113859', '127.0.0.1', 1487882095, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373838313830313b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('bb63cdf2dda53548b16583f26a2eca0da243fdb9', '127.0.0.1', 1487881780, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837393837363b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('bc161c541e878d8465d14d605e3494a0699b6bbd', '127.0.0.1', 1487879866, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837393530393b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('8ba80d5d5667a5cbaed16802ca2bb5a925b7b51c', '127.0.0.1', 1487879498, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837383937333b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('157ae7e9d455ecbba8cce447b2dc79c1605f9ddd', '127.0.0.1', 1487878958, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837383537343b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('93f949d6ae2218666329a0649756949c21833c53', '127.0.0.1', 1487878564, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837383236313b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('17931aa52a85fabc7aa7f70a90e1bbc8424e3203', '127.0.0.1', 1487878247, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837373134303b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('433c3f6138822d1a2bdfb69ef0101ee6fb24dc8a', '127.0.0.1', 1487876821, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837353836343b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('61564f5842396d7c3c8498186e1d869f955bd35c', '127.0.0.1', 1487875859, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837343231343b666c6578695f617574687c4e3b6d6573736167657c733a3132383a223c7020636c6173733d226572726f725f6d7367223e596f7572206c6f67696e2073657373696f6e2068617320657870697265642e3c2f703e3c7020636c6173733d226572726f725f6d7367223e596f75206d757374206c6f67696e20617320616e2061646d696e20746f20616363657373207468697320617265612e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226f6c64223b7d),
('8723bf1e550419fe3ef46ea75414b0089983b21b', '127.0.0.1', 1487877121, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837363833313b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2235363936393963383963366564333862363762323332663139313837363265326233653366313435223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('924fa2ef29e6478631308d2f78a204d6520b4479', '127.0.0.1', 1487874031, 0x6d6573736167657c733a36303a223c7020636c6173733d226572726f725f6d7367223e596f75206d757374206c6f67696e20746f20616363657373207468697320617265612e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226e6577223b7d),
('65a7f61e5fccb3243699c4d6f145f25645df74bf', '127.0.0.1', 1487874039, 0x6d6573736167657c733a36303a223c7020636c6173733d226572726f725f6d7367223e596f75206d757374206c6f67696e20746f20616363657373207468697320617265612e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226e6577223b7d),
('fb0a31ad929ce0cca0e80ca1cb533db0c401115d', '127.0.0.1', 1487874042, 0x6d6573736167657c733a36303a223c7020636c6173733d226572726f725f6d7367223e596f75206d757374206c6f67696e20746f20616363657373207468697320617265612e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226e6577223b7d),
('13894f1111f0cae1eecc5a68b09a1cb839e03f26', '127.0.0.1', 1487874109, 0x6d6573736167657c733a36303a223c7020636c6173733d226572726f725f6d7367223e596f75206d757374206c6f67696e20746f20616363657373207468697320617265612e3c2f703e223b5f5f63695f766172737c613a313a7b733a373a226d657373616765223b733a333a226e6577223b7d),
('f6ecffe10c7d353eb9488fb62c764a67a66fb591', '::1', 1487873515, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837323939343b),
('4fa212cfb02069a9daa713bdc88884eb87402c38', '::1', 1487874097, 0x5f5f63695f6c6173745f726567656e65726174657c693a313438373837333532353b666c6578695f617574687c613a373a7b733a31393a226c6f67696e5f73657373696f6e5f746f6b656e223b733a34303a2232383339393765646134363133363336373536343535386235643834393735656434626663613936223b733a32323a226c6f676765645f696e5f7669615f70617373776f7264223b623a313b733a323a226964223b733a313a2231223b733a31353a22757365725f6964656e746966696572223b733a31353a2261646d696e4061646d696e2e636f6d223b733a353a2261646d696e223b623a313b733a353a2267726f7570223b613a313a7b693a333b733a353a2241646d696e223b7d733a31303a2270726976696c65676573223b613a31313a7b693a313b733a31303a2256696577205573657273223b693a323b733a31363a225669657720557365722047726f757073223b693a333b733a31353a22566965772050726976696c65676573223b693a343b733a31383a22496e7365727420557365722047726f757073223b693a353b733a31373a22496e736572742050726976696c65676573223b693a363b733a31323a22557064617465205573657273223b693a373b733a31383a2255706461746520557365722047726f757073223b693a383b733a31373a225570646174652050726976696c65676573223b693a393b733a31323a2244656c657465205573657273223b693a31303b733a31383a2244656c65746520557365722047726f757073223b693a31313b733a31373a2244656c6574652050726976696c65676573223b7d7d),
('55f7e6b48ea9452b9dec25d47d5cd51fd1f5ff1e', '127.0.0.1', 1487873214, ''),
('a9646102c1a760392a090d66752aad627d738ac9', '::1', 1487873108, ''),
('2ce8c2c97a434e1d68f07f2df65d19e237001bf6', '::1', 1487873188, ''),
('b696ee701a2daedfa96a1d100bdfbe4535f8e815', '127.0.0.1', 1487873934, '');

-- --------------------------------------------------------

--
-- Table structure for table `counties`
--

CREATE TABLE `counties` (
  `county_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counties`
--

INSERT INTO `counties` (`county_id`, `name`) VALUES
(1, 'Mombasa'),
(2, 'Kwale'),
(3, 'Kilifi'),
(4, 'Tana River'),
(5, 'Lamu'),
(6, 'Taita Taveta'),
(7, 'Garissa'),
(8, 'Wajir'),
(9, 'Mandera'),
(10, 'Marsabit'),
(11, 'Isiolo'),
(12, 'Meru'),
(13, 'Tharaka Nithi'),
(14, 'Embu'),
(15, 'Kitui'),
(16, 'Machakos'),
(17, 'Makueni'),
(18, 'Nyandarua'),
(19, 'Nyeri'),
(20, 'Kirinyaga'),
(21, 'Murang\'a'),
(22, 'Kiambu'),
(23, 'Turkana'),
(24, 'West Pokot'),
(25, 'Samburu'),
(26, 'Trans Nzoia'),
(27, 'Uasin Gishu'),
(28, 'Elgeyo/Marakwet'),
(29, 'Nandi'),
(30, 'Baringo'),
(31, 'Laikipia'),
(32, 'Nakuru'),
(33, 'Narok'),
(34, 'Kajiado'),
(35, 'Kericho'),
(36, 'Bomet'),
(37, 'Kakamega'),
(38, 'Vihiga'),
(39, 'Bung\'oma'),
(40, 'Busia'),
(41, 'Siaya'),
(42, 'Kisumu'),
(43, 'Homa Bay'),
(44, 'Migori'),
(45, 'Kisii'),
(46, 'Nyamira'),
(47, 'Nairobi City');

-- --------------------------------------------------------

--
-- Table structure for table `court_actions`
--

CREATE TABLE `court_actions` (
  `id` int(11) NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `proceeded_by` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `Rank` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court_actions`
--

INSERT INTO `court_actions` (`id`, `action`, `proceeded_by`, `category`, `Rank`) VALUES
(1, 'Register', NULL, 1, 1),
(2, 'Mention', 1, 1, 1),
(3, 'Hearing', 2, 1, 1),
(4, 'Judgement', 3, 1, 1),
(5, 'Register', NULL, 2, 1),
(6, 'Mention', 5, 2, 1),
(7, 'Hearing', 6, 2, 1),
(8, 'Judgement', 7, 2, 1),
(9, 'Register', NULL, 3, 1),
(10, 'Mention', 9, 3, 1),
(11, 'Hearing', 10, 3, 1),
(12, 'Judgement', 11, 3, 1),
(13, 'Orders', 12, 3, 1),
(14, 'Taxation', 13, 3, 1),
(15, 'Registration', NULL, 4, 1),
(16, 'Service', 15, 4, 1),
(17, 'Date Setting', 16, 4, 1),
(18, 'Hearing', 17, 4, 1),
(19, 'Judgement', 18, 4, 1),
(20, 'Orders', 19, 4, 1),
(21, 'Taxation', 20, 4, 1),
(22, 'Registration', NULL, 5, 2),
(23, 'Mention', 22, 5, 2),
(24, 'Responses', 23, 5, 2),
(25, 'Hearing', 24, 5, 2),
(26, 'Judgement', 25, 5, 2),
(27, 'Registration', NULL, 6, 2),
(28, 'Notices of Appeal', 27, 6, 2),
(29, 'Hearing', 28, 6, 2),
(30, 'Judgement', 29, 6, 2),
(31, 'Orders', 30, 6, 2),
(32, 'Taxations', 31, 6, 2),
(33, 'Registration', NULL, 9, 3),
(34, 'Plea Taking', 33, 9, 3),
(35, 'Hearing', 34, 9, 3),
(36, 'Mention', 35, 9, 3),
(37, 'Ruling', 36, 9, 3),
(38, 'Judgement', 37, 9, 3),
(39, 'Registration', NULL, 11, 3),
(40, 'Adminssion of Appeal', 39, 11, 3),
(41, 'Directions', 40, 11, 3),
(42, 'Hearing Date', 41, 11, 3),
(43, 'Hearing', 42, 11, 3),
(44, 'Rulling', 43, 11, 3),
(45, 'Judgement', 44, 11, 3),
(46, 'Registration', NULL, 13, 3),
(47, 'Summons', 46, 13, 3),
(48, 'Notice of motion', 47, 13, 3),
(49, 'Responses', 48, 13, 3),
(50, 'Inter-Parte hearings', 49, 13, 3),
(51, 'Ruling', 50, 13, 3),
(52, 'Defence', 51, 13, 3),
(53, 'Pre-Trial', 52, 13, 3),
(54, 'Date-Fixing', 53, 13, 3),
(55, 'Full Trial', 54, 13, 3),
(56, 'Ruling', 55, 13, 3),
(57, 'Hearing', 56, 13, 3),
(58, 'Judgement', 57, 13, 3),
(59, 'Orders', 58, 13, 3),
(60, 'Notice to show Cause', 59, 13, 3),
(61, 'Examination of directors', 60, 13, 3),
(62, 'Registration', 61, 14, 3),
(63, 'Summons', 62, 14, 3),
(64, 'Notice of motion', 63, 14, 3),
(65, 'Responses', 64, 14, 3),
(66, 'Inter-Parte hearings', 65, 14, 3),
(67, 'Ruling', 66, 14, 3),
(68, 'Defence', 67, 14, 3),
(69, 'Pre-Trial', 68, 14, 3),
(70, 'Date-Fixing', 69, 14, 3),
(71, 'Full Trial', 70, 14, 3),
(72, 'Ruling', 71, 14, 3),
(73, 'Hearing', 72, 14, 3),
(74, 'Judgement', 73, 14, 3),
(75, 'Orders', 74, 14, 3),
(76, 'Notice to show Cause', 75, 14, 3),
(77, 'Examination of directors', 76, 14, 3),
(78, 'Registration', NULL, 15, 3),
(79, 'Mention', 78, 15, 3),
(80, 'Directions', 79, 15, 3),
(81, 'Hearing', 80, 15, 3),
(82, 'Ruling', 81, 15, 3),
(83, 'Judgement', 82, 15, 3),
(84, 'Registration', NULL, 17, 3),
(85, 'Mention', 84, 17, 3),
(86, 'Direction by Judge', 85, 17, 3),
(87, 'Hearing', 86, 17, 3),
(88, 'Judgement', 87, 17, 3),
(89, 'Registraion', NULL, 19, 3),
(90, 'Summons', 89, 19, 3),
(91, 'Notice of Motion', 90, 19, 3),
(92, 'Responses', 91, 19, 3),
(93, 'Inter-parte Hearing', 92, 19, 3),
(94, 'Ruling', 93, 19, 3),
(95, 'Defence', 94, 19, 3),
(96, 'Pre-Trial', 95, 19, 3),
(97, 'Hearing Date Set', 96, 19, 3),
(98, 'Full Trial', 97, 19, 3),
(99, 'Ruling', 98, 19, 3),
(100, 'Hearing', 99, 19, 3),
(101, 'Judgement', 100, 19, 3),
(102, 'Registraion', NULL, 20, 3),
(103, 'Summons', 102, 20, 3),
(104, 'Notice of Motion', 103, 20, 3),
(105, 'Responses', 104, 20, 3),
(106, 'Inter-parte Hearing', 105, 20, 3),
(107, 'Ruling', 106, 20, 3),
(108, 'Defence', 107, 20, 3),
(109, 'Pre-Trial', 108, 20, 3),
(110, 'Hearing Date Set', 109, 20, 3),
(111, 'Full Trial', 110, 20, 3),
(112, 'Ruling', 111, 20, 3),
(113, 'Hearing', 112, 20, 3),
(114, 'Judgement', 113, 20, 3),
(115, 'Registration', NULL, 21, 3),
(116, 'Adminssibility of the appeal', 115, 21, 3),
(117, 'Direction date Fixed', 116, 21, 3),
(118, 'Hearing date', 117, 21, 3),
(119, 'Hearing', 118, 21, 3),
(120, 'Ruling', 119, 21, 3),
(121, 'Judgement', 120, 21, 3),
(122, 'Registration', NULL, 29, 3),
(123, 'Certificate of urgency', 122, 29, 3),
(124, 'Mention', 123, 29, 3),
(125, 'Hearing', 124, 29, 3),
(126, 'Judgement', 125, 29, 3),
(127, 'Registration', NULL, 30, 3),
(128, 'Certificate of urgency', 127, 30, 3),
(129, 'Mention', 128, 30, 3),
(130, 'Hearing', 129, 30, 3),
(131, 'Judgement', 130, 30, 3);

-- --------------------------------------------------------

--
-- Table structure for table `court_divisions`
--

CREATE TABLE `court_divisions` (
  `division_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `station_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court_divisions`
--

INSERT INTO `court_divisions` (`division_id`, `name`, `station_id`) VALUES
(1, 'Milimani High Court Criminal', 150),
(2, 'Milimani High Court Commercial', 150),
(3, 'Milimani High Court Civil', 150),
(4, 'Milimani High Court Family', 150),
(5, 'Milimani High Court Judicial Review', 150),
(6, 'Milimani High Court Constitution and Human Rights', 150);

-- --------------------------------------------------------

--
-- Table structure for table `court_ranks`
--

CREATE TABLE `court_ranks` (
  `court_rank_id` int(11) NOT NULL,
  `court_rank_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court_ranks`
--

INSERT INTO `court_ranks` (`court_rank_id`, `court_rank_name`) VALUES
(1, 'Supreme Court'),
(2, 'Court of Appeal'),
(3, 'High Court'),
(4, 'Employment and Labour Relations Court'),
(5, 'Environment and Land Court'),
(6, 'Subordinate Court'),
(7, 'Tribunials');

-- --------------------------------------------------------

--
-- Table structure for table `court_stations`
--

CREATE TABLE `court_stations` (
  `station_id` int(11) NOT NULL,
  `county_id` int(11) NOT NULL,
  `rank_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `unique_id` varchar(10) NOT NULL,
  `unique_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `court_stations`
--

INSERT INTO `court_stations` (`station_id`, `county_id`, `rank_id`, `name`, `unique_id`, `unique_code`) VALUES
(1, 1, 1, 'Mombasa Court of Appeal', '010201', 'MSACA'),
(2, 1, 3, 'Mombasa High Court', '010301', 'MSAHC'),
(3, 1, 4, 'Mombasa Industrial Court', '010401', 'MSAIC'),
(4, 1, 6, 'Mombasa Magistrate Court', '010601', 'MSAMC'),
(5, 1, 6, 'Tononoka Magistrate Court', '010602', 'TNKMC'),
(6, 1, 6, 'Shanzu Magistrate Court', '010603', 'SNZMC'),
(7, 2, 6, 'Kwale Magistrate  Court', '020601', 'KWLMC'),
(8, 3, 2, 'Malindi Court of Appeal', '030201', 'MLDCA'),
(9, 3, 3, 'Malindi High Court', '030301', 'MLDHC'),
(10, 3, 6, 'Malindi  Magistrate  Court', '030601', 'MLDMC'),
(11, 3, 6, 'Mariakani Magistrate  Court', '030602', 'MRKMC'),
(12, 3, 6, 'Kaloleni Magistrate  Court', '030603', 'KLNMC'),
(13, 3, 6, 'Kilifi Magistrate Court', '030604', 'KLFMC'),
(14, 4, 6, 'Garsen Magistrate  Court', '040601', 'GSNMC'),
(15, 4, 6, 'Hola Magistrate  Court', '040602', 'HLAMC'),
(16, 5, 6, 'Lamu Magistrate  Court', '050601', 'LAMUMC'),
(17, 6, 6, 'Voi  Magistrate  Court', '060601', 'VOIMC'),
(18, 6, 6, 'Wundanyi  Magistrate  Court', '060602', 'WDYMC'),
(19, 6, 6, 'Taveta  Magistrate  Court', '060603', 'TVTMC'),
(20, 7, 3, 'Garissa High Court', '070301', 'GRSHC'),
(21, 7, 6, 'Garissa  Magistrate  Court', '070601', 'GRSMC'),
(22, 8, 6, 'Wajir  Magistrate Court', '080601', 'WJRMC'),
(23, 9, 6, 'Mandera  Magistrate Court', '090601', 'MNDMC'),
(24, 10, 6, 'Marsabit Magistrate Court', '100601', 'MSBMC'),
(25, 11, 6, 'Isiolo Magistrate Court', '110601', 'ISLMC'),
(26, 11, 6, 'Moyale Magistrate Court', '110602', 'MYLMC'),
(27, 12, 6, 'Meru MagistrateCourt', '120601', 'MRUMC'),
(28, 12, 6, 'Nkubu Magistrate Court', '120602', 'NKBMC'),
(29, 12, 6, 'Maua Magistrate Court', '120603', 'MUAMC'),
(30, 12, 6, 'Tigania Magistrate Court', '120604', 'TGAMC'),
(31, 13, 6, 'Chuka Magistrate Court', '130601', 'CKAMC'),
(32, 13, 6, 'Marimati Magistrate Court', '130602', 'MRTMC'),
(33, 14, 6, 'Embu Magistrate Court', '140601', 'EMBMC'),
(34, 14, 6, 'Runyenjes Magistrate Court', '140602', 'RNJMC'),
(35, 14, 6, 'Siakago Magistrate Court', '140603', 'SKGMC'),
(36, 15, 6, 'Kitui  Magistrate  Court', '150601', 'KTIMC'),
(37, 15, 6, 'Mutumo  Magistrate  Court', '150602', 'MTMMC'),
(38, 15, 6, 'Mwingi  Magistrate  Court', '150603', 'MWGMC'),
(39, 15, 6, 'Kyuso  Magistrate  Court', '150604', 'KYSMC'),
(40, 16, 6, 'Machakos Magistrate Court', '160601', 'MKSMC'),
(41, 16, 6, 'Kithimani  Magistrate  Court', '160602', 'KTMMC'),
(42, 16, 6, 'Kangundo Magistrate Court', '160603', 'KGDMC'),
(43, 17, 6, 'Makueni Magistrate Court', '170601', 'MKNMC'),
(44, 17, 6, 'Tawa Magistrate Court', '170602', 'TWAMC'),
(45, 17, 6, 'Kilungu/Nunguni Magistrate Court', '170603', 'KGUMC'),
(46, 17, 6, 'Makindu Magistrate Court', '170604', 'MDUMC'),
(47, 18, 6, 'Engineer  Magistrate  Court', '180601', 'ENGMC'),
(48, 19, 2, 'Nyeri Court of Appeal', '190201', 'NYRCA'),
(49, 19, 3, 'Nyeri High Court', '190301', 'NYRHC'),
(50, 19, 4, 'Nyeri Industrial Court', '190401', 'NYRIC'),
(51, 19, 6, 'Nyeri Magistrate Court', '190601', 'NYRMC'),
(52, 19, 6, 'Othaya Magistrate Court', '190602', 'OTYMC'),
(53, 19, 6, 'Karatina Magistrate Court', '190603', 'KTNMC'),
(54, 19, 6, 'Mukurwe-ini Magistrate Court', '190604', 'MKWMC'),
(55, 20, 6, 'Kirinyaga Magistrate Court', '200601', 'KIRMC'),
(56, 20, 3, 'Kerugoya High Court', '200302', 'KRGHC'),
(57, 20, 6, 'Kerugoya Magistrate Court', '200602', 'KRGMC'),
(58, 20, 6, 'Baricho Magistrate Court', '200603', 'BRCMC'),
(59, 20, 6, 'Gichugu Magistrate Court', '200604', 'GCGMC'),
(60, 20, 6, 'Wang\'uru Magistrate Court', '200605', 'WNGMC'),
(61, 21, 3, 'Murang\'a High Court', '210301', 'MRGHC'),
(62, 21, 6, 'Murang\'a Magistrate Court', '210601', 'MRGMC'),
(63, 21, 6, 'Kangema Magistrate Court', '210602', 'KNGMC'),
(64, 21, 6, 'Kigumo Magistrate Court', '210603', 'KGMMC'),
(65, 21, 6, 'Kandara Magistrate Court', '210604', 'KNDMC'),
(66, 22, 6, 'Kiambu  Magistrate  Court', '220601', 'KMBMC'),
(67, 22, 6, 'Thika  Magistrate  Court', '220602', 'TKAMC'),
(68, 22, 6, 'Kikuyu Magistrate Court', '220605', 'KYKMC'),
(69, 22, 6, 'Limuru  Magistrate  Court', '220606', 'LMUMC'),
(70, 23, 6, 'Lodwar  Magistrate  Court', '230601', 'LDWMC'),
(71, 23, 6, 'Kakuma Magistrate Court', '230602', 'KKMMC'),
(72, 24, 6, 'Kapenguria Magistrate  Court', '240601', 'KPGMC'),
(73, 25, 6, 'Maralal Magistrate Court', '250601', 'MRLMC'),
(74, 26, 3, 'Kitale High Court', '260301', 'KTLHC'),
(75, 26, 6, 'Kitale  Magistrate  Court', '260601', 'KTLMC'),
(76, 27, 2, 'Eldoret Court of Appeal', '270201', 'ELDCA'),
(77, 27, 3, 'Eldoret High Court', '270301', 'ELDHC'),
(78, 27, 6, 'Eldoret  Magistrate  Court', '270601', 'ELDMC'),
(79, 27, 6, 'Sotik  Magistrate  Court', '270602', 'STKMC'),
(80, 28, 6, 'Iten  Magistrate  Court', '280601', 'ITNMC'),
(81, 29, 6, 'Kapsabet  Magistrate  Court', '290601', 'KPBMC'),
(82, 30, 6, 'Kabarnet  Magistrate  Court', '300601', 'KBTMC'),
(83, 31, 6, 'Nanyuki Magistrate Court', '310601', 'NYKMC'),
(84, 31, 6, 'Nyahururu  Magistrate  Court', '310602', 'NYHMC'),
(85, 32, 3, 'Nakuru High Court', '320301', 'NKRHC'),
(86, 32, 3, 'Naivasha High Court', '320302', 'NSHHC'),
(87, 32, 4, 'Nakuru Industrial Court', '320401', 'NKRIC'),
(88, 32, 6, 'Nakuru Magistrate Court', '320601', 'NKRMC'),
(89, 32, 6, 'Molo  Magistrate  Court', '320602', 'MOLMC'),
(90, 32, 6, 'Eldama Ravine Magistrate Court', '320603', 'ERVMC'),
(91, 32, 6, 'Naivasha  Magistrate  Court', '320604', 'NSHMC'),
(92, 33, 6, 'Narok  Magistrate  Court', '330601', 'NRKMC'),
(93, 34, 6, 'Kajiado  Magistrate  Court', '340601', 'KJDMC'),
(94, 35, 3, 'Kericho  High Court', '350301', 'KRCHC'),
(95, 35, 4, 'Kericho Industrial Court', '350401', 'KRCIC'),
(96, 35, 6, 'Kericho  Magistrate  Court', '350601', 'KRCMC'),
(97, 36, 6, 'Bomet  Magistrate  Court', '360601', 'BMTMC'),
(98, 37, 3, 'Kakamega High Court', '370301', 'KKGHC'),
(99, 37, 6, 'Kakamega Magistrate Court', '370601', 'KKGMC'),
(100, 37, 6, 'Mumias Magistrate Court', '370602', 'MMSMC'),
(101, 37, 6, 'Butere Magistrate Court', '370603', 'BTRMC'),
(102, 37, 6, 'Butali Magistrate Court', '370604', 'BTLMC'),
(103, 38, 6, 'Vihiga Magistrate Court', '380601', 'VHGMC'),
(104, 38, 6, 'Hamisi  Magistrate  Court', '380602', 'HMSMC'),
(105, 39, 3, 'Bungoma High Court', '390301', 'BNGHC'),
(106, 39, 6, 'Bungoma Magistrate Court', '390601', 'BNGMC'),
(107, 39, 6, 'Webuye  Magistrate  Court', '390602', 'WBYMC'),
(108, 39, 6, 'Kimilili Magistrate Court', '390603', 'KMLMC'),
(109, 39, 6, 'Sirisia  Magistrate  Court', '390604', 'SRSMC'),
(110, 40, 3, 'Busia High Court', '400301', 'BSAHC'),
(111, 40, 6, 'Busia Magistrate Court', '400601', 'BSAMC'),
(112, 41, 6, 'Siaya Magistrate Court', '410601', 'SYAMC'),
(113, 41, 6, 'Bondo Magistrate Court', '410602', 'BNDMC'),
(114, 41, 6, 'Ukwala Magistrate Court', '410603', 'UKLMC'),
(115, 42, 2, 'Kisumu Court of Appeal', '420201', 'KSMCA'),
(116, 42, 3, 'Kisumu High Court', '420301', 'KSMHC'),
(117, 42, 4, 'Kisumu Industrial Court', '420401', 'KSMIS'),
(118, 42, 6, 'Kisumu Magistrate Court', '420601', 'KSMMC'),
(119, 42, 6, 'Winam Magistrate Court', '420602', 'WNMMC'),
(120, 42, 6, 'Maseno Magistrate Court', '420603', 'MSNMC'),
(121, 47, 1, 'Nairobi Supreme Court', '470101', 'NRBSC'),
(122, 47, 2, 'Nairobi Court of Appeal', '470201', 'NRBCA'),
(123, 47, 4, 'Nairobi Industrial Court', '470401', 'NRBIC'),
(124, 47, 6, 'Kibera  Magistrate  Court', '470601', 'KBRMC'),
(125, 47, 6, 'Makadara  Magistrate  Court', '470602', 'MKDMC'),
(126, 47, 6, ' Milimani  Magistrate Court', '470604', 'MILMC'),
(127, 12, 3, 'Meru High Court', '120301', 'MRUHC'),
(128, 14, 3, 'Embu High Court', '140301', 'EMBHC'),
(129, 16, 3, 'Machakos High Court', '160301', 'MCKHC'),
(130, 16, 6, 'Mavoko  Magistrate  Court', '160604', 'MVKMC'),
(131, 43, 3, 'Homabay High Court', '430301', 'HMBHC'),
(132, 45, 3, 'Kisii High Court', '450301', 'KISHC'),
(133, 44, 3, 'Migori High Court', '440301', 'MGRHC'),
(134, 43, 6, 'Homabay  Magistrate  Court', '430601', 'HMBMC'),
(135, 22, 6, 'Gatundu  Magistrate  Court', '220603', 'GTDMC'),
(136, 22, 6, 'Githunguri  Magistrate  Court', '220604', 'GTGMC'),
(137, 45, 6, 'Kehancha  Magistrate  Court', '450604', 'KHCMC'),
(138, 45, 6, 'Keroka  Magistrate  Court', '450602', 'KRKMC'),
(139, 46, 6, 'Kilgoris  Magistrate  Court', '460602', 'KLGMC'),
(140, 45, 6, 'Kisii  Magistrate  Court', '450601', 'KISMC'),
(141, 44, 6, 'Migori  Magistrate  Court', '440601', 'MGRMC'),
(142, 43, 6, 'Ndhiwa  Magistrate  Court', '430603', 'NDWMC'),
(143, 46, 6, 'Nyamira  Magistrate  Court', '460601', 'NYMMC'),
(144, 42, 6, 'Nyando  Magistrate  Court', '420604', 'NYDMC '),
(145, 45, 6, 'Ogembo Magistrate Court', '450603', 'OGBMC'),
(146, 43, 6, 'Oyugis  Magistrate  Court', '430602', 'OYGMC'),
(147, 44, 6, 'Rongo  Magistrate  Court', '440602', 'RNGMC'),
(148, 42, 6, 'Tamu  Magistrate  Court', '420605', 'TAMMC'),
(149, 43, 6, 'Mbita  Magistrate Court', '430604', 'MBTMC'),
(150, 47, 3, 'Milimani High Court', '470301', 'MILHC'),
(151, 47, 3, 'Milimani Commercial Court', 'MILCC', 'MILCC'),
(152, 17, 3, 'Makueni High Court', 'MKHC', 'MKHC');

-- --------------------------------------------------------

--
-- Table structure for table `demo_user_address`
--

CREATE TABLE `demo_user_address` (
  `uadd_id` int(11) NOT NULL,
  `uadd_uacc_fk` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `uadd_alias` varchar(50) NOT NULL DEFAULT '',
  `uadd_recipient` varchar(100) NOT NULL DEFAULT '',
  `uadd_phone` varchar(25) NOT NULL DEFAULT '',
  `uadd_company` varchar(75) NOT NULL DEFAULT '',
  `uadd_address_01` varchar(100) NOT NULL DEFAULT '',
  `uadd_address_02` varchar(100) NOT NULL DEFAULT '',
  `uadd_city` varchar(50) NOT NULL DEFAULT '',
  `uadd_county` varchar(50) NOT NULL DEFAULT '',
  `uadd_post_code` varchar(25) NOT NULL DEFAULT '',
  `uadd_country` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_user_address`
--

INSERT INTO `demo_user_address` (`uadd_id`, `uadd_uacc_fk`, `uadd_alias`, `uadd_recipient`, `uadd_phone`, `uadd_company`, `uadd_address_01`, `uadd_address_02`, `uadd_city`, `uadd_county`, `uadd_post_code`, `uadd_country`) VALUES
(1, 4, 'Home', 'Joe Public', '0123456789', '', '123', '', 'My City', 'My County', 'My Post Code', 'My Country'),
(2, 4, 'Work', 'Joe Public', '0123456789', 'Flexi', '321', '', 'My Work City', 'My Work County', 'My Work Post Code', 'My Work Country');

-- --------------------------------------------------------

--
-- Table structure for table `demo_user_profiles`
--

CREATE TABLE `demo_user_profiles` (
  `upro_id` int(11) NOT NULL,
  `upro_uacc_fk` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `upro_company` varchar(50) NOT NULL DEFAULT '',
  `upro_first_name` varchar(50) NOT NULL DEFAULT '',
  `upro_last_name` varchar(50) NOT NULL DEFAULT '',
  `upro_phone` varchar(25) NOT NULL DEFAULT '',
  `prefered_name` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `demo_user_profiles`
--

INSERT INTO `demo_user_profiles` (`upro_id`, `upro_uacc_fk`, `upro_company`, `upro_first_name`, `upro_last_name`, `upro_phone`, `prefered_name`) VALUES
(1, 1, '', 'James', 'Kamau', '0123456789', 'Judge Odunga'),
(2, 2, '', 'Jim', 'Moderator', '0123465798', 'Principle Judge R. Mwongo'),
(3, 3, '', 'Joe', 'Public', '0123456789', 'CRJ, Miss Ann'),
(4, 4, '', 'Maina', 'Chelule', '34567890', 'Margistrate Peter J.'),
(5, 5, '', 'Chelule', 'Maina', '07273330', 'P.J Pauline'),
(7, 7, '', 'Maraga', 'David', '0728943223', '0'),
(8, 8, '', 'Geff', 'Atuya', '0745687434', 'Test'),
(9, 9, '', 'Benson ', 'Muchoki', '072438352', '0'),
(10, 10, '', 'Minaya', 'Ivy', '0729044404', '0'),
(11, 11, '', 'Policarp', 'Mwangi', '96789333', '0');

-- --------------------------------------------------------

--
-- Table structure for table `exhibits`
--

CREATE TABLE `exhibits` (
  `exhibit_id` int(11) NOT NULL,
  `case_activity_id` int(11) NOT NULL,
  `exhibit_category_id` int(11) NOT NULL,
  `estimated_value` varchar(50) NOT NULL,
  `photo_path` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `date_produced` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exhibit_categories`
--

CREATE TABLE `exhibit_categories` (
  `exhibit_category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exhibit_categories`
--

INSERT INTO `exhibit_categories` (`exhibit_category_id`, `name`) VALUES
(1, 'Narcotics/Alcoholic Drinks'),
(2, 'Forest and Wildlife Products'),
(3, 'Motor Vehicle'),
(4, 'Perishable'),
(5, 'Non-perishable ');

-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `case_fees_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `fees_type_id` int(11) NOT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `amount` varchar(100) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `receipt_number` varchar(100) DEFAULT NULL,
  `paid_by` varchar(255) DEFAULT NULL,
  `amount_assessed` double(8,2) DEFAULT NULL,
  `assessed_by` int(11) UNSIGNED DEFAULT NULL,
  `date_assessed` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--

INSERT INTO `fees` (`case_fees_id`, `case_id`, `fees_type_id`, `payment_method_id`, `amount`, `payment_date`, `receipt_number`, `paid_by`, `amount_assessed`, `assessed_by`, `date_assessed`) VALUES
(2, 8, 1, NULL, '234', '2017-02-19 21:00:00', NULL, 'wqerewr qwerqwer', 234.00, 1, '2017-02-22 02:02:34'),
(3, 8, 1, NULL, '2134', '2017-02-13 21:00:00', NULL, '2134124 1234123', 2134.00, 1, '2017-02-22 02:02:58'),
(4, 8, 1, NULL, '2134', '2017-02-21 21:00:00', NULL, '2314 234', 234.00, 1, '2017-02-22 03:02:31'),
(5, 8, 1, NULL, '234', '2017-02-20 21:00:00', NULL, 'asdf asdf', 2314.00, 1, '2017-02-22 03:02:58'),
(6, 1, 1, NULL, '2345', '2017-02-14 21:00:00', NULL, '2345 345', 334.00, 1, '2017-02-22 03:02:50'),
(7, 1, 1, NULL, '2345', '2017-02-12 21:00:00', NULL, '2345 2345', 2345.00, 1, '2017-02-22 03:02:39'),
(8, 1, 1, NULL, '2345234', '2017-02-21 21:00:00', NULL, '234345 2345', 432.00, 1, '2017-02-22 03:02:21'),
(9, 29, 1, NULL, '345', '2017-02-20 21:00:00', NULL, '3245 345', 334.00, 1, '2017-02-22 03:02:21'),
(10, 35, 1, NULL, '100', '2017-02-22 21:00:00', NULL, 'chelule Benson', 100.00, 1, '2017-02-23 03:02:49'),
(11, 36, 1, NULL, '345', '2017-02-22 21:00:00', NULL, 'Test Test', 345.00, 8, '2017-02-23 03:02:15'),
(12, 37, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:24'),
(13, 39, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:22'),
(14, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:35'),
(15, 41, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:01'),
(16, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:50'),
(17, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:09'),
(18, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:48'),
(19, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:05'),
(20, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:54'),
(21, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:55'),
(22, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:30'),
(23, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:42'),
(24, 40, 1, NULL, '123412', '2017-02-04 21:00:00', NULL, '1234123 412341324', 213412.00, 8, '2017-02-23 03:02:20'),
(25, 40, 1, NULL, '3500', '2017-02-22 21:00:00', NULL, 'Geofrey  Atuya Ernest', 3500.00, 8, '2017-02-23 04:02:38'),
(26, 42, 1, NULL, '3500', '2017-02-22 21:00:00', NULL, 'Geofrey Atuya Ernest', 3500.00, 8, '2017-02-23 04:02:13');

-- --------------------------------------------------------

--
-- Table structure for table `fees_types`
--

CREATE TABLE `fees_types` (
  `fees_type_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees_types`
--

INSERT INTO `fees_types` (`fees_type_id`, `description`) VALUES
(1, 'Assessment Fee');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `case_id` int(11) NOT NULL,
  `file_type_id` int(11) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `file_types`
--

CREATE TABLE `file_types` (
  `file_type_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file_types`
--

INSERT INTO `file_types` (`file_type_id`, `description`) VALUES
(1, 'Affidavit'),
(2, 'Exhibit'),
(3, 'Plaint'),
(4, 'Memorandum'),
(5, 'Petition');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `payment_method_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`payment_method_id`, `name`, `description`) VALUES
(1, 'MPESA', 'MPESA Paybill Number'),
(2, 'Bank', 'KCB Bank Account Number');

-- --------------------------------------------------------

--
-- Table structure for table `special_criminal_appeal`
--

CREATE TABLE `special_criminal_appeal` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `number_lower_court` varchar(50) NOT NULL,
  `name_lower_court` varchar(255) NOT NULL,
  `judicial_officers_lower_court` varchar(255) NOT NULL,
  `case_ruling_lower_court` mediumtext NOT NULL,
  `case_ruling_date_lower_court` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_criminal_appeal`
--

INSERT INTO `special_criminal_appeal` (`case_special_id`, `case_id`, `number_lower_court`, `name_lower_court`, `judicial_officers_lower_court`, `case_ruling_lower_court`, `case_ruling_date_lower_court`) VALUES
(1, 1, '6', '4', '1', '', '0000-00-00 00:00:00'),
(2, 8, '3', '4', '5', '', '0000-00-00 00:00:00'),
(3, 1, '3', '1', '1', '', '0000-00-00 00:00:00'),
(4, 1, '3', '1', '1', '', '0000-00-00 00:00:00'),
(5, 1, '3', '4', '5', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `special_criminal_revision`
--

CREATE TABLE `special_criminal_revision` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `case_number_lower_court` varchar(50) NOT NULL,
  `case_name_lower_court` varchar(255) NOT NULL,
  `judicial_officers_in_case` varchar(255) NOT NULL,
  `ruling_lower_court` mediumtext NOT NULL,
  `ruling_dates_lower_court` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_criminal_revision`
--

INSERT INTO `special_criminal_revision` (`case_special_id`, `case_id`, `case_number_lower_court`, `case_name_lower_court`, `judicial_officers_in_case`, `ruling_lower_court`, `ruling_dates_lower_court`) VALUES
(1, 8, '3', '1', '1', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `special_divorce`
--

CREATE TABLE `special_divorce` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `place_of_marriage` varchar(255) NOT NULL,
  `date_of_marriage` datetime NOT NULL,
  `marriage_cert_no` varchar(100) NOT NULL,
  `children_id` varchar(20) DEFAULT NULL,
  `parties_domicile` varchar(255) DEFAULT NULL,
  `previous_proceedings_details` mediumtext NOT NULL,
  `matrimonial_offenses_alleged` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `special_divorce_case`
--

CREATE TABLE `special_divorce_case` (
  `divorce_special_case_id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `date_of_marriage` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `place_of_marriage` varchar(255) DEFAULT NULL,
  `complainant_surnames` varchar(255) DEFAULT NULL,
  `complainant_othernames` varchar(255) DEFAULT NULL,
  `plaint_surname` varchar(255) DEFAULT NULL,
  `plaint_othernames` varchar(255) DEFAULT NULL,
  `plaintiff_occupation` varchar(255) DEFAULT NULL,
  `respondent_occupation` varchar(255) DEFAULT NULL,
  `children_dets` varchar(255) DEFAULT NULL,
  `previous_proceedings` varchar(255) DEFAULT NULL,
  `matrimonial_offence` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_divorce_case`
--

INSERT INTO `special_divorce_case` (`divorce_special_case_id`, `case_id`, `date_of_marriage`, `place_of_marriage`, `complainant_surnames`, `complainant_othernames`, `plaint_surname`, `plaint_othernames`, `plaintiff_occupation`, `respondent_occupation`, `children_dets`, `previous_proceedings`, `matrimonial_offence`) VALUES
(1, 7, '0000-00-00 00:00:00', '2134', '2134', '234', '234', '2134', '1234', '234', 'weqrewrqewr, 33\r\n', '2134', '234'),
(2, 7, '0000-00-00 00:00:00', '2134', '2134', '234', '234', '2134', '1234', '234', 'weqrewrqewr, 33\r\n', '2134', '234'),
(3, 1, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(4, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(5, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(6, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(7, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(8, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg'),
(9, 8, '0000-00-00 00:00:00', '12`3`213', 'wertwert', 'ewrtwert', 'erwtwer', 'wertwert', 'ewrtwert', 'erwtwert', 'twertewrtb ,45', 'sdfgsdfg', 'dfgsdfg');

-- --------------------------------------------------------

--
-- Table structure for table `special_misc_app_in_crm_mat`
--

CREATE TABLE `special_misc_app_in_crm_mat` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `nature_of_app` varchar(255) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `parties` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_misc_app_in_crm_mat`
--

INSERT INTO `special_misc_app_in_crm_mat` (`case_special_id`, `case_id`, `nature_of_app`, `description`, `parties`) VALUES
(1, 7, 'dfg', 'ertryuui', '1'),
(2, 8, 'qwert', 'qwert', '2');

-- --------------------------------------------------------

--
-- Table structure for table `special_murder`
--

CREATE TABLE `special_murder` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `reg_date` datetime NOT NULL,
  `charges` mediumtext NOT NULL,
  `name_of_deceased` varchar(100) NOT NULL,
  `rlsp_accd_dcsd` varchar(255) NOT NULL,
  `gender_accused` varchar(50) NOT NULL,
  `gender_deceased` varchar(50) NOT NULL,
  `age_accused` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `special_party_witness`
--

CREATE TABLE `special_party_witness` (
  `special_parties_id` int(11) NOT NULL,
  `case_parties_id` int(11) DEFAULT NULL,
  `witness_for` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `special_probate_n_admin`
--

CREATE TABLE `special_probate_n_admin` (
  `case_special_id` int(11) NOT NULL,
  `case_id` int(11) NOT NULL,
  `deceased_surname` varchar(255) NOT NULL,
  `deceased_othernames` varchar(255) NOT NULL,
  `domicile_date` varchar(255) NOT NULL,
  `domicile_place` varchar(255) NOT NULL,
  `certificate_no` varchar(255) NOT NULL,
  `certificate_serial` datetime NOT NULL,
  `citizenship` varchar(255) NOT NULL,
  `residence` varchar(11) NOT NULL,
  `estate_value` varchar(255) DEFAULT NULL,
  `applicant_statement` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_probate_n_admin`
--

INSERT INTO `special_probate_n_admin` (`case_special_id`, `case_id`, `deceased_surname`, `deceased_othernames`, `domicile_date`, `domicile_place`, `certificate_no`, `certificate_serial`, `citizenship`, `residence`, `estate_value`, `applicant_statement`) VALUES
(1, 7, 'dfgghjkl', 'dfghjkl', '2017-02-22', '456', '2017-02-23', '0000-00-00 00:00:00', '2017-02-15', '3', '2017-02-22', 'rtfyhjk sdfghjk dfghjkl'),
(2, 7, 'dfgghjkl', 'dfghjkl', '2017-02-22', '456', '2017-02-23', '0000-00-00 00:00:00', '2017-02-15', '3', '2017-02-22', 'rtfyhjk sdfghjk dfghjkl'),
(3, 8, 'rtyuio', 'dfghj', '2017-02-22', '456', '2017-02-15', '0000-00-00 00:00:00', '2017-02-07', '34567', '2017-02-22', 'sdfgh dfghj fghjk fghjk'),
(4, 8, 'rtyuio', 'dfghj', '2017-02-22', '456', '2017-02-15', '0000-00-00 00:00:00', '2017-02-07', '34567', '2017-02-22', 'sdfgh dfghj fghjk fghjk');

-- --------------------------------------------------------

--
-- Table structure for table `user2division`
--

CREATE TABLE `user2division` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user2division`
--

INSERT INTO `user2division` (`id`, `user_id`, `division_id`) VALUES
(1, 8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users2activities`
--

CREATE TABLE `users2activities` (
  `id` int(11) NOT NULL,
  `actioned_to_id` int(11) UNSIGNED DEFAULT NULL,
  `activities_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users2activities`
--

INSERT INTO `users2activities` (`id`, `actioned_to_id`, `activities_id`) VALUES
(1, 1, 4),
(2, 2, 4),
(3, 3, 4),
(4, 1, 2),
(5, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `uacc_id` int(11) UNSIGNED NOT NULL,
  `uacc_group_fk` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `uacc_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_username` varchar(15) NOT NULL DEFAULT '',
  `uacc_password` varchar(60) NOT NULL DEFAULT '',
  `uacc_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_salt` varchar(40) NOT NULL DEFAULT '',
  `uacc_activation_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_forgotten_password_expire` datetime NOT NULL,
  `uacc_update_email_token` varchar(40) NOT NULL DEFAULT '',
  `uacc_update_email` varchar(100) NOT NULL DEFAULT '',
  `uacc_active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `uacc_suspend` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `uacc_fail_login_attempts` smallint(5) NOT NULL DEFAULT '0',
  `uacc_fail_login_ip_address` varchar(40) NOT NULL DEFAULT '',
  `uacc_date_fail_login_ban` datetime NOT NULL COMMENT 'Time user is banned until due to repeated failed logins',
  `uacc_date_last_login` datetime NOT NULL,
  `uacc_date_added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`uacc_id`, `uacc_group_fk`, `uacc_email`, `uacc_username`, `uacc_password`, `uacc_ip_address`, `uacc_salt`, `uacc_activation_token`, `uacc_forgotten_password_token`, `uacc_forgotten_password_expire`, `uacc_update_email_token`, `uacc_update_email`, `uacc_active`, `uacc_suspend`, `uacc_fail_login_attempts`, `uacc_fail_login_ip_address`, `uacc_date_fail_login_ban`, `uacc_date_last_login`, `uacc_date_added`) VALUES
(1, 3, 'admin@admin.com', '79198', '$2a$08$lSOQGNqwBFUEDTxm2Y.hb.mfPEAt/iiGY9kJsZsd4ekLJXLD.tCrq', '127.0.0.1', 'XKVT29q2Jr', '', '', '2017-02-23 10:25:17', '', '', 1, 0, 0, '', '2017-02-23 10:27:39', '2017-02-24 12:05:17', '2011-01-01 00:00:00'),
(2, 2, 'moderator@moderator.com', 'moderator', '$2a$08$q.0ZhovC5ZkVpkBLJ.Mz.O4VjWsKohYckJNx4KM40MXdP/zEZpwcm', '0.0.0.0', 'ZC38NNBPjF', '', '', '2017-02-23 10:25:21', '', '', 1, 0, 0, '', '2017-02-23 10:28:20', '2012-04-10 21:58:02', '2011-08-04 16:49:07'),
(3, 1, 'public@public.com', 'public', '$2a$08$GlxQ00VKlev2t.CpvbTOlepTJljxF2RocJghON37r40mbDl4vJLv2', '192.168.0.41', 'CDNFV6dHmn', '', '', '2017-02-23 10:26:08', '', '', 1, 0, 0, '', '2017-02-23 10:28:17', '2017-02-23 12:19:20', '2011-09-15 12:24:45'),
(4, 20, 'sadf@dfg.fdg', '333', '$2a$08$q9HY3BYc2cCJn2SVkLQGYuBhZq4Ln44W68.NldJ0TaD9oxX36V2Um', '::1', '4hyBhntz3p', '', '', '2017-02-06 10:26:41', '', '', 1, 0, 0, '', '2017-02-23 10:28:13', '2017-02-17 10:40:35', '2017-02-17 10:40:35'),
(5, 21, 'chelule.maina@gmail.com', '71933', '$2a$08$s3v7TjvGYACX50vngPDVjOU4LnQxjKqmSjdIp9GKCkHwHzN07D4m2', '::1', 'ppTy8F4PDX', '', '', '2017-02-20 10:26:49', '', '', 1, 0, 0, '', '2017-02-23 10:28:09', '2017-02-18 13:01:11', '2017-02-18 05:31:09'),
(6, 1, 'chelule@gmail.com', '234234', '$2a$08$Vr34s3UGBIhZj.qq3xXo5uiX/72nHo7PqKr8DnJRsQX/pn0UphA7q', '192.168.0.41', '2QkBY3G8pk', '', '', '2017-02-08 10:26:53', '', '', 0, 1, 0, '', '2017-02-23 10:28:06', '2017-02-22 15:36:29', '2017-02-22 15:36:29'),
(7, 6, 'maraga@hudiciary.go.ke', '78453', '$2a$08$xDq.Y6cXQo0TRev6ZG.cgOmhU.RzAZGOa5RPEIK9CAQ0XvOeet2fS', '127.0.0.1', 'XQXPgNMqNp', '', '', '2017-02-01 10:26:58', '', '', 1, 0, 0, '', '2017-02-23 10:28:01', '2016-12-01 22:27:05', '2016-12-01 22:27:05'),
(8, 1, 'atuya@judiciary.go.ke', '98475', '$2a$08$6JQxEtyDN7oDZwqbquCrhenS5ZhVzwqIKmvYLyhFWchRbCJLcudIu', '127.0.0.1', 'j83xM7HMgS', '', '', '2017-02-22 10:27:04', '', '', 1, 0, 0, '', '0000-00-00 00:00:00', '2017-02-24 11:50:47', '2016-12-01 22:30:42'),
(9, 20, 'benson@judiciary.go.ke', '0726783', '$2a$08$Jq/LKtkBa0pnyS7pRAXwke2kjq8gVqCLP97owjU6WEYlIpHUxjf3S', '127.0.0.1', 'kkdb5bShrm', '', '', '2017-02-27 10:26:31', '', '', 1, 0, 0, '', '2017-02-23 10:27:53', '2017-02-23 05:12:09', '2016-12-01 22:34:03'),
(10, 21, 'ivy@judiciary.go.ke', '67890', '$2a$08$y/SS4GszvPoxPm2zHgUE1.gNAUHR4DfG/G9LO8y1puk5RqPGViK4q', '127.0.0.1', 'j9whkWZX9s', '', '', '2017-02-27 10:26:21', '', '', 1, 0, 0, '', '2017-02-28 10:27:49', '2016-12-01 22:39:21', '2016-12-01 22:39:21'),
(11, 23, 'polycarp@judiciary.go.ke', '56789', '$2a$08$Bcjam7mERRyzR/7703nENu24yfki8OKdLHlb8kewUc7ezMIHDsP7G', '127.0.0.1', 'VNP6MB2BN4', '', '', '2017-02-22 10:26:12', '', '', 1, 0, 0, '', '2017-02-07 10:27:43', '2017-02-23 05:12:27', '2016-12-01 22:41:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `ugrp_id` smallint(5) UNSIGNED NOT NULL,
  `ugrp_name` varchar(20) NOT NULL DEFAULT '',
  `ugrp_desc` varchar(100) NOT NULL DEFAULT '',
  `ugrp_admin` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` int(1) DEFAULT NULL COMMENT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`ugrp_id`, `ugrp_name`, `ugrp_desc`, `ugrp_admin`, `deleted`) VALUES
(1, 'CA', 'Court Assistant', 0, 0),
(2, 'DR', 'Deputy Registrar : has partial admin access rights.', 0, 0),
(3, 'Admin', 'Master Admin : has full admin access rights.', 1, 0),
(4, 'eee', 'test', 1, 1),
(5, 'ertyjk', 'rtyu', 0, 1),
(6, 'CJ', 'Chief Justice', 1, 0),
(7, 'Test Groups', 'Test', 0, 1),
(8, 'Test Groups', 'Test', 0, 1),
(9, 'Test', 'Test', 0, 1),
(10, 'Test', 'Test', 0, 1),
(11, 'xvczxcv', 'xzcvz', 0, 1),
(12, 'wer', 'sadfdf', 0, 1),
(13, 'wer', 'sadfdf', 0, 1),
(14, 'wer', 'sadfdf', 0, 1),
(15, 'wer', 'sadfdf', 0, 1),
(16, 'wer', 'sadfdf', 0, 1),
(17, 'wer', 'sadfdf', 0, 1),
(18, 'wer', 'sadfdf', 0, 1),
(19, 'sdfsdfasd', 'asdfadsf', 0, 1),
(20, 'Judge', 'Provide case adjudication and Judgement including rullings and hearings', 0, 0),
(21, 'Margistrate', 'Administer Judgements', 0, 0),
(22, 'Registrar', 'Administer cases', 0, 0),
(23, 'MDR', 'Mediation deputy Registrar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_login_sessions`
--

CREATE TABLE `user_login_sessions` (
  `usess_id` int(10) UNSIGNED NOT NULL,
  `usess_uacc_fk` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `usess_series` varchar(40) NOT NULL DEFAULT '',
  `usess_token` varchar(40) NOT NULL DEFAULT '',
  `usess_login_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login_sessions`
--

INSERT INTO `user_login_sessions` (`usess_id`, `usess_uacc_fk`, `usess_series`, `usess_token`, `usess_login_date`) VALUES
(25, 1, '', '7f88c05a327d43bf1f336546d2d27a4715eb390f', '2017-02-24 14:10:28');

-- --------------------------------------------------------

--
-- Table structure for table `user_privileges`
--

CREATE TABLE `user_privileges` (
  `upriv_id` smallint(5) UNSIGNED NOT NULL,
  `upriv_name` varchar(20) NOT NULL DEFAULT '',
  `upriv_desc` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_privileges`
--

INSERT INTO `user_privileges` (`upriv_id`, `upriv_name`, `upriv_desc`) VALUES
(1, 'View Users', 'User can view user account details.'),
(2, 'View User Groups', 'User can view user groups.'),
(3, 'View Privileges', 'User can view privileges.'),
(4, 'Insert User Groups', 'User can insert new user groups.'),
(5, 'Insert Privileges', 'User can insert privileges.'),
(6, 'Update Users', 'User can update user account details.'),
(7, 'Update User Groups', 'User can update user groups.'),
(8, 'Update Privileges', 'User can update user privileges.'),
(9, 'Delete Users', 'User can delete user accounts.'),
(10, 'Delete User Groups', 'User can delete user groups.'),
(11, 'Delete Privileges', 'User can delete user privileges.');

-- --------------------------------------------------------

--
-- Table structure for table `user_privilege_groups`
--

CREATE TABLE `user_privilege_groups` (
  `upriv_groups_id` smallint(5) UNSIGNED NOT NULL,
  `upriv_groups_ugrp_fk` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `upriv_groups_upriv_fk` smallint(5) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_privilege_groups`
--

INSERT INTO `user_privilege_groups` (`upriv_groups_id`, `upriv_groups_ugrp_fk`, `upriv_groups_upriv_fk`) VALUES
(1, 3, 1),
(3, 3, 3),
(4, 3, 4),
(5, 3, 5),
(6, 3, 6),
(7, 3, 7),
(8, 3, 8),
(9, 3, 9),
(10, 3, 10),
(11, 3, 11),
(12, 2, 2),
(13, 2, 4),
(14, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user_privilege_users`
--

CREATE TABLE `user_privilege_users` (
  `upriv_users_id` smallint(5) NOT NULL,
  `upriv_users_uacc_fk` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `upriv_users_upriv_fk` smallint(5) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_privilege_users`
--

INSERT INTO `user_privilege_users` (`upriv_users_id`, `upriv_users_uacc_fk`, `upriv_users_upriv_fk`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 1),
(13, 2, 2),
(14, 2, 3),
(15, 2, 6),
(16, 4, 7),
(17, 4, 8),
(18, 4, 10),
(19, 4, 1),
(20, 4, 2),
(21, 4, 3),
(22, 4, 4),
(23, 4, 7),
(24, 4, 8),
(25, 4, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`case_id`),
  ADD UNIQUE KEY `number` (`number`),
  ADD KEY `case_type_id` (`case_category_id`),
  ADD KEY `case_status_id` (`case_status_id`),
  ADD KEY `filed_by` (`filed_by`),
  ADD KEY `is_appeal` (`is_appeal`);

--
-- Indexes for table `cases2parties`
--
ALTER TABLE `cases2parties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `case_party` (`case_party_id`);

--
-- Indexes for table `case_activities`
--
ALTER TABLE `case_activities`
  ADD PRIMARY KEY (`case_activity_id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `outcome_id` (`outcome_id`),
  ADD KEY `activity_id` (`activity_id`),
  ADD KEY `entered_by` (`entered_by`),
  ADD KEY `case_activities_ibfk_10` (`next_activity_id`);

--
-- Indexes for table `case_categories`
--
ALTER TABLE `case_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD KEY `court_division_id` (`division_id`);

--
-- Indexes for table `case_outcomes`
--
ALTER TABLE `case_outcomes`
  ADD KEY `outcome_id` (`outcome_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `court_rank_id` (`court_rank_id`);

--
-- Indexes for table `case_parties`
--
ALTER TABLE `case_parties`
  ADD PRIMARY KEY (`case_party_id`),
  ADD KEY `case_party_type_id` (`party_type_id`);

--
-- Indexes for table `case_party_types`
--
ALTER TABLE `case_party_types`
  ADD PRIMARY KEY (`case_party_type_id`);

--
-- Indexes for table `case_special_murder`
--
ALTER TABLE `case_special_murder`
  ADD PRIMARY KEY (`case_murder_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `case_status`
--
ALTER TABLE `case_status`
  ADD PRIMARY KEY (`case_status_id`);

--
-- Indexes for table `case_types`
--
ALTER TABLE `case_types`
  ADD PRIMARY KEY (`case_type_id`),
  ADD KEY `case_category_id` (`case_category_id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `counties`
--
ALTER TABLE `counties`
  ADD PRIMARY KEY (`county_id`);

--
-- Indexes for table `court_actions`
--
ALTER TABLE `court_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category` (`category`),
  ADD KEY `Rank` (`Rank`),
  ADD KEY `proceeded_by` (`proceeded_by`);

--
-- Indexes for table `court_divisions`
--
ALTER TABLE `court_divisions`
  ADD PRIMARY KEY (`division_id`),
  ADD KEY `court_rank_id` (`station_id`);

--
-- Indexes for table `court_ranks`
--
ALTER TABLE `court_ranks`
  ADD PRIMARY KEY (`court_rank_id`);

--
-- Indexes for table `court_stations`
--
ALTER TABLE `court_stations`
  ADD PRIMARY KEY (`station_id`),
  ADD UNIQUE KEY `unique_id` (`unique_id`),
  ADD UNIQUE KEY `unique_code` (`unique_code`),
  ADD KEY `court_county_id` (`county_id`),
  ADD KEY `rank_id` (`rank_id`);

--
-- Indexes for table `demo_user_address`
--
ALTER TABLE `demo_user_address`
  ADD PRIMARY KEY (`uadd_id`),
  ADD UNIQUE KEY `uadd_id` (`uadd_id`),
  ADD KEY `uadd_uacc_fk` (`uadd_uacc_fk`);

--
-- Indexes for table `demo_user_profiles`
--
ALTER TABLE `demo_user_profiles`
  ADD PRIMARY KEY (`upro_id`),
  ADD UNIQUE KEY `upro_id` (`upro_id`),
  ADD KEY `upro_uacc_fk` (`upro_uacc_fk`) USING BTREE;

--
-- Indexes for table `exhibits`
--
ALTER TABLE `exhibits`
  ADD PRIMARY KEY (`exhibit_id`),
  ADD KEY `case_exhibit_category_id` (`exhibit_category_id`),
  ADD KEY `case_activity_id` (`case_activity_id`);

--
-- Indexes for table `exhibit_categories`
--
ALTER TABLE `exhibit_categories`
  ADD PRIMARY KEY (`exhibit_category_id`);

--
-- Indexes for table `fees`
--
ALTER TABLE `fees`
  ADD PRIMARY KEY (`case_fees_id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `payment_method_id` (`payment_method_id`),
  ADD KEY `case_fees_type_id` (`fees_type_id`),
  ADD KEY `assessed_by` (`assessed_by`);

--
-- Indexes for table `fees_types`
--
ALTER TABLE `fees_types`
  ADD KEY `case_fees_type_id` (`fees_type_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `case_file_type_id` (`file_type_id`);

--
-- Indexes for table `file_types`
--
ALTER TABLE `file_types`
  ADD PRIMARY KEY (`file_type_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`payment_method_id`),
  ADD KEY `payment_method_id` (`payment_method_id`);

--
-- Indexes for table `special_criminal_appeal`
--
ALTER TABLE `special_criminal_appeal`
  ADD PRIMARY KEY (`case_special_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_criminal_revision`
--
ALTER TABLE `special_criminal_revision`
  ADD PRIMARY KEY (`case_special_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_divorce`
--
ALTER TABLE `special_divorce`
  ADD PRIMARY KEY (`case_special_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_divorce_case`
--
ALTER TABLE `special_divorce_case`
  ADD PRIMARY KEY (`divorce_special_case_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_misc_app_in_crm_mat`
--
ALTER TABLE `special_misc_app_in_crm_mat`
  ADD PRIMARY KEY (`case_special_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_murder`
--
ALTER TABLE `special_murder`
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `special_party_witness`
--
ALTER TABLE `special_party_witness`
  ADD PRIMARY KEY (`special_parties_id`),
  ADD KEY `case_parties_id` (`case_parties_id`),
  ADD KEY `witness_for` (`witness_for`);

--
-- Indexes for table `special_probate_n_admin`
--
ALTER TABLE `special_probate_n_admin`
  ADD PRIMARY KEY (`case_special_id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `user2division`
--
ALTER TABLE `user2division`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `users2activities`
--
ALTER TABLE `users2activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actioned_to_id` (`actioned_to_id`),
  ADD KEY `activities_id` (`activities_id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`uacc_id`),
  ADD UNIQUE KEY `uacc_id` (`uacc_id`),
  ADD KEY `uacc_group_fk` (`uacc_group_fk`),
  ADD KEY `uacc_email` (`uacc_email`),
  ADD KEY `uacc_username` (`uacc_username`),
  ADD KEY `uacc_fail_login_ip_address` (`uacc_fail_login_ip_address`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`ugrp_id`),
  ADD UNIQUE KEY `ugrp_id` (`ugrp_id`) USING BTREE;

--
-- Indexes for table `user_login_sessions`
--
ALTER TABLE `user_login_sessions`
  ADD PRIMARY KEY (`usess_id`),
  ADD UNIQUE KEY `usess_token` (`usess_token`),
  ADD KEY `usess_uacc_fk` (`usess_uacc_fk`);

--
-- Indexes for table `user_privileges`
--
ALTER TABLE `user_privileges`
  ADD PRIMARY KEY (`upriv_id`),
  ADD UNIQUE KEY `upriv_id` (`upriv_id`) USING BTREE;

--
-- Indexes for table `user_privilege_groups`
--
ALTER TABLE `user_privilege_groups`
  ADD PRIMARY KEY (`upriv_groups_id`),
  ADD UNIQUE KEY `upriv_groups_id` (`upriv_groups_id`) USING BTREE,
  ADD KEY `upriv_groups_ugrp_fk` (`upriv_groups_ugrp_fk`),
  ADD KEY `upriv_groups_upriv_fk` (`upriv_groups_upriv_fk`);

--
-- Indexes for table `user_privilege_users`
--
ALTER TABLE `user_privilege_users`
  ADD PRIMARY KEY (`upriv_users_id`),
  ADD UNIQUE KEY `upriv_users_id` (`upriv_users_id`) USING BTREE,
  ADD KEY `upriv_users_uacc_fk` (`upriv_users_uacc_fk`),
  ADD KEY `upriv_users_upriv_fk` (`upriv_users_upriv_fk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `case_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `cases2parties`
--
ALTER TABLE `cases2parties`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `case_activities`
--
ALTER TABLE `case_activities`
  MODIFY `case_activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `case_categories`
--
ALTER TABLE `case_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `case_parties`
--
ALTER TABLE `case_parties`
  MODIFY `case_party_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `case_party_types`
--
ALTER TABLE `case_party_types`
  MODIFY `case_party_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `case_special_murder`
--
ALTER TABLE `case_special_murder`
  MODIFY `case_murder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `case_status`
--
ALTER TABLE `case_status`
  MODIFY `case_status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `case_types`
--
ALTER TABLE `case_types`
  MODIFY `case_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `counties`
--
ALTER TABLE `counties`
  MODIFY `county_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `court_actions`
--
ALTER TABLE `court_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `court_divisions`
--
ALTER TABLE `court_divisions`
  MODIFY `division_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `court_ranks`
--
ALTER TABLE `court_ranks`
  MODIFY `court_rank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `court_stations`
--
ALTER TABLE `court_stations`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `demo_user_address`
--
ALTER TABLE `demo_user_address`
  MODIFY `uadd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `demo_user_profiles`
--
ALTER TABLE `demo_user_profiles`
  MODIFY `upro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `exhibits`
--
ALTER TABLE `exhibits`
  MODIFY `exhibit_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exhibit_categories`
--
ALTER TABLE `exhibit_categories`
  MODIFY `exhibit_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `fees`
--
ALTER TABLE `fees`
  MODIFY `case_fees_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `fees_types`
--
ALTER TABLE `fees_types`
  MODIFY `fees_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `file_types`
--
ALTER TABLE `file_types`
  MODIFY `file_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `payment_method_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `special_criminal_appeal`
--
ALTER TABLE `special_criminal_appeal`
  MODIFY `case_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `special_criminal_revision`
--
ALTER TABLE `special_criminal_revision`
  MODIFY `case_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `special_divorce_case`
--
ALTER TABLE `special_divorce_case`
  MODIFY `divorce_special_case_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `special_misc_app_in_crm_mat`
--
ALTER TABLE `special_misc_app_in_crm_mat`
  MODIFY `case_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `special_party_witness`
--
ALTER TABLE `special_party_witness`
  MODIFY `special_parties_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `special_probate_n_admin`
--
ALTER TABLE `special_probate_n_admin`
  MODIFY `case_special_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user2division`
--
ALTER TABLE `user2division`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users2activities`
--
ALTER TABLE `users2activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `uacc_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `ugrp_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `user_login_sessions`
--
ALTER TABLE `user_login_sessions`
  MODIFY `usess_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `user_privileges`
--
ALTER TABLE `user_privileges`
  MODIFY `upriv_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `user_privilege_groups`
--
ALTER TABLE `user_privilege_groups`
  MODIFY `upriv_groups_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `user_privilege_users`
--
ALTER TABLE `user_privilege_users`
  MODIFY `upriv_users_id` smallint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `cases_ibfk_3` FOREIGN KEY (`case_status_id`) REFERENCES `case_status` (`case_status_id`),
  ADD CONSTRAINT `cases_ibfk_5` FOREIGN KEY (`filed_by`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `cases_ibfk_6` FOREIGN KEY (`is_appeal`) REFERENCES `cases` (`case_id`),
  ADD CONSTRAINT `cases_ibfk_7` FOREIGN KEY (`case_category_id`) REFERENCES `case_categories` (`category_id`);

--
-- Constraints for table `cases2parties`
--
ALTER TABLE `cases2parties`
  ADD CONSTRAINT `cases2parties_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`),
  ADD CONSTRAINT `cases2parties_ibfk_2` FOREIGN KEY (`case_party_id`) REFERENCES `case_parties` (`case_party_id`);

--
-- Constraints for table `case_activities`
--
ALTER TABLE `case_activities`
  ADD CONSTRAINT `case_activities_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`),
  ADD CONSTRAINT `case_activities_ibfk_10` FOREIGN KEY (`next_activity_id`) REFERENCES `court_actions` (`id`),
  ADD CONSTRAINT `case_activities_ibfk_7` FOREIGN KEY (`activity_id`) REFERENCES `court_actions` (`id`),
  ADD CONSTRAINT `case_activities_ibfk_8` FOREIGN KEY (`entered_by`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `case_activities_ibfk_9` FOREIGN KEY (`outcome_id`) REFERENCES `case_outcomes` (`outcome_id`);

--
-- Constraints for table `case_categories`
--
ALTER TABLE `case_categories`
  ADD CONSTRAINT `case_categories_ibfk_1` FOREIGN KEY (`division_id`) REFERENCES `court_divisions` (`division_id`);

--
-- Constraints for table `case_outcomes`
--
ALTER TABLE `case_outcomes`
  ADD CONSTRAINT `case_outcomes_ibfk_1` FOREIGN KEY (`action_id`) REFERENCES `court_actions` (`id`),
  ADD CONSTRAINT `case_outcomes_ibfk_2` FOREIGN KEY (`court_rank_id`) REFERENCES `court_ranks` (`court_rank_id`);

--
-- Constraints for table `case_parties`
--
ALTER TABLE `case_parties`
  ADD CONSTRAINT `case_parties_ibfk_2` FOREIGN KEY (`party_type_id`) REFERENCES `case_party_types` (`case_party_type_id`);

--
-- Constraints for table `case_special_murder`
--
ALTER TABLE `case_special_murder`
  ADD CONSTRAINT `case_special_murder_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `case_types`
--
ALTER TABLE `case_types`
  ADD CONSTRAINT `case_types_ibfk_1` FOREIGN KEY (`case_category_id`) REFERENCES `cms`.`case_categories` (`category_id`);

--
-- Constraints for table `court_actions`
--
ALTER TABLE `court_actions`
  ADD CONSTRAINT `court_actions_ibfk_3` FOREIGN KEY (`Rank`) REFERENCES `court_ranks` (`court_rank_id`),
  ADD CONSTRAINT `court_actions_ibfk_4` FOREIGN KEY (`proceeded_by`) REFERENCES `court_actions` (`id`);

--
-- Constraints for table `court_divisions`
--
ALTER TABLE `court_divisions`
  ADD CONSTRAINT `court_station_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `court_stations` (`station_id`);

--
-- Constraints for table `court_stations`
--
ALTER TABLE `court_stations`
  ADD CONSTRAINT `court_stations_ibfk_1` FOREIGN KEY (`county_id`) REFERENCES `counties` (`county_id`),
  ADD CONSTRAINT `court_stations_ibfk_2` FOREIGN KEY (`rank_id`) REFERENCES `court_ranks` (`court_rank_id`);

--
-- Constraints for table `demo_user_address`
--
ALTER TABLE `demo_user_address`
  ADD CONSTRAINT `demo_user_address_ibfk_1` FOREIGN KEY (`uadd_uacc_fk`) REFERENCES `user_accounts` (`uacc_id`);

--
-- Constraints for table `demo_user_profiles`
--
ALTER TABLE `demo_user_profiles`
  ADD CONSTRAINT `demo_user_profiles_ibfk_1` FOREIGN KEY (`upro_uacc_fk`) REFERENCES `user_accounts` (`uacc_id`);

--
-- Constraints for table `exhibits`
--
ALTER TABLE `exhibits`
  ADD CONSTRAINT `exhibits_ibfk_2` FOREIGN KEY (`exhibit_category_id`) REFERENCES `exhibit_categories` (`exhibit_category_id`),
  ADD CONSTRAINT `exhibits_ibfk_3` FOREIGN KEY (`case_activity_id`) REFERENCES `case_activities` (`case_activity_id`);

--
-- Constraints for table `fees`
--
ALTER TABLE `fees`
  ADD CONSTRAINT `fees_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`),
  ADD CONSTRAINT `fees_ibfk_4` FOREIGN KEY (`fees_type_id`) REFERENCES `fees_types` (`fees_type_id`),
  ADD CONSTRAINT `fees_ibfk_5` FOREIGN KEY (`assessed_by`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `fees_ibfk_6` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`payment_method_id`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`),
  ADD CONSTRAINT `files_ibfk_3` FOREIGN KEY (`file_type_id`) REFERENCES `file_types` (`file_type_id`);

--
-- Constraints for table `special_criminal_appeal`
--
ALTER TABLE `special_criminal_appeal`
  ADD CONSTRAINT `special_criminal_appeal_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_criminal_revision`
--
ALTER TABLE `special_criminal_revision`
  ADD CONSTRAINT `special_criminal_revision_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_divorce`
--
ALTER TABLE `special_divorce`
  ADD CONSTRAINT `special_divorce_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_divorce_case`
--
ALTER TABLE `special_divorce_case`
  ADD CONSTRAINT `special_divorce_case_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_misc_app_in_crm_mat`
--
ALTER TABLE `special_misc_app_in_crm_mat`
  ADD CONSTRAINT `special_misc_app_in_crm_mat_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_murder`
--
ALTER TABLE `special_murder`
  ADD CONSTRAINT `special_murder_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `special_party_witness`
--
ALTER TABLE `special_party_witness`
  ADD CONSTRAINT `special_party_witness_ibfk_1` FOREIGN KEY (`case_parties_id`) REFERENCES `case_parties` (`case_party_id`),
  ADD CONSTRAINT `special_party_witness_ibfk_2` FOREIGN KEY (`witness_for`) REFERENCES `case_parties` (`case_party_id`);

--
-- Constraints for table `special_probate_n_admin`
--
ALTER TABLE `special_probate_n_admin`
  ADD CONSTRAINT `special_probate_n_admin_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`);

--
-- Constraints for table `user2division`
--
ALTER TABLE `user2division`
  ADD CONSTRAINT `user2division_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `user2division_ibfk_2` FOREIGN KEY (`division_id`) REFERENCES `court_divisions` (`division_id`);

--
-- Constraints for table `users2activities`
--
ALTER TABLE `users2activities`
  ADD CONSTRAINT `users2activities_ibfk_1` FOREIGN KEY (`actioned_to_id`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `users2activities_ibfk_2` FOREIGN KEY (`activities_id`) REFERENCES `case_activities` (`case_activity_id`);

--
-- Constraints for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD CONSTRAINT `user_accounts_ibfk_1` FOREIGN KEY (`uacc_group_fk`) REFERENCES `user_groups` (`ugrp_id`);

--
-- Constraints for table `user_login_sessions`
--
ALTER TABLE `user_login_sessions`
  ADD CONSTRAINT `user_login_sessions_ibfk_1` FOREIGN KEY (`usess_uacc_fk`) REFERENCES `user_accounts` (`uacc_id`);

--
-- Constraints for table `user_privilege_groups`
--
ALTER TABLE `user_privilege_groups`
  ADD CONSTRAINT `user_privilege_groups_ibfk_1` FOREIGN KEY (`upriv_groups_ugrp_fk`) REFERENCES `user_groups` (`ugrp_id`),
  ADD CONSTRAINT `user_privilege_groups_ibfk_2` FOREIGN KEY (`upriv_groups_upriv_fk`) REFERENCES `user_privileges` (`upriv_id`);

--
-- Constraints for table `user_privilege_users`
--
ALTER TABLE `user_privilege_users`
  ADD CONSTRAINT `user_privilege_users_ibfk_1` FOREIGN KEY (`upriv_users_uacc_fk`) REFERENCES `user_accounts` (`uacc_id`),
  ADD CONSTRAINT `user_privilege_users_ibfk_2` FOREIGN KEY (`upriv_users_upriv_fk`) REFERENCES `user_privileges` (`upriv_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
